.class final Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;
.super Ljava/lang/Object;
.source "Zip.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# static fields
.field public static final INSTANCE:Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;

    invoke-direct {v0}, Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;-><init>()V

    sput-object v0, Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;->INSTANCE:Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;

    return-void
.end method

.method constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 0

    .line 273
    invoke-virtual {p0}, Lkotlinx/coroutines/flow/FlowKt__ZipKt$nullArrayFactory$1;->invoke()Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method public final invoke()Ljava/lang/Void;
    .locals 0

    .line 0
    const/4 p0, 0x0

    return-object p0
.end method
