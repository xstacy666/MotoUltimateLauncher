.class public final Lkotlinx/coroutines/YieldContext$Key;
.super Ljava/lang/Object;
.source "Unconfined.kt"

# interfaces
.implements Lkotlin/coroutines/CoroutineContext$Key;


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lkotlinx/coroutines/YieldContext$Key;-><init>()V

    return-void
.end method
