.class public interface abstract Lkotlinx/coroutines/selects/SelectInstance;
.super Ljava/lang/Object;
.source "Select.kt"


# virtual methods
.method public abstract getContext()Lkotlin/coroutines/CoroutineContext;
.end method
