.class public Lcom/motorola/myscreen/api/MyScreenApi;
.super Ljava/lang/Object;
.source "MyScreenApi.java"


# static fields
.field private static LOG:Z = true

.field private static final TAG:Ljava/lang/String; = "MyScreenApi"

.field private static sCount:I


# instance fields
.field private final dataBundle:Landroid/os/Bundle;

.field private mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;

.field private final mCheckConnectionRunnable:Ljava/lang/Runnable;

.field private mConnectAttemptCount:I

.field private final mConnectRunnable:Ljava/lang/Runnable;

.field private final mCount:I

.field private mHasNotifiedServiceState:Z

.field private mHostContext:Landroid/content/Context;

.field private mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

.field private mIsDestroyed:Z

.field private mIsLightNavigationBar:Z

.field private mIsLightStatusBar:Z

.field private mIsResumed:Z

.field private final mIsRtl:Z

.field private mIsStatusBarHidden:Z

.field private mIsTranslucentNavigationBar:Z

.field private mLastNotifiedServiceState:Z

.field private final mLocalMessenger:Landroid/os/Messenger;

.field private final mMainThreadHandler:Landroid/os/Handler;

.field private mRemoteMessenger:Landroid/os/Messenger;

.field private mSentWindowAttributes:Z

.field private final mServiceConnection:Landroid/content/ServiceConnection;

.field private final mSettingsActivityLaunchIntent:Landroid/content/Intent;


# direct methods
.method public static synthetic $r8$lambda$IwGyhNzxTG33v5Vbn-qXQ75GPq8(Lcom/motorola/myscreen/api/MyScreenApi;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnect()V

    return-void
.end method

.method public static synthetic $r8$lambda$NoX05U5zmAZQSWIUnSOVc4VSZKk(Lcom/motorola/myscreen/api/MyScreenApi;Z)V
    .locals 3

    .line 495
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 496
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 496
    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    .line 496
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifyServiceStateChanged: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 498
    :cond_0
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;

    .line 498
    invoke-interface {v0, p1}, Lcom/motorola/myscreen/api/ApiCallback;->onServiceStateChanged(Z)V

    const/4 v0, 0x1

    .line 499
    iput-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHasNotifiedServiceState:Z

    .line 500
    iput-boolean p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mLastNotifiedServiceState:Z

    return-void
.end method

.method public static synthetic $r8$lambda$mO2w5fGocJdsW7H2HemvaBju3EM(Lcom/motorola/myscreen/api/MyScreenApi;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->checkConnection()V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Lcom/motorola/myscreen/api/ApiCallback;ZLandroid/content/Intent;)V
    .locals 7

    .line 69
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v3

    move-object v1, p0

    move-object v2, p1

    move-object v4, p2

    move v5, p3

    move-object v6, p4

    invoke-direct/range {v1 .. v6}, Lcom/motorola/myscreen/api/MyScreenApi;-><init>(Landroid/content/Context;Landroid/view/WindowManager$LayoutParams;Lcom/motorola/myscreen/api/ApiCallback;ZLandroid/content/Intent;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/view/WindowManager$LayoutParams;Lcom/motorola/myscreen/api/ApiCallback;ZLandroid/content/Intent;)V
    .locals 4

    .line 72
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->dataBundle:Landroid/os/Bundle;

    .line 73
    sget v1, Lcom/motorola/myscreen/api/MyScreenApi;->sCount:I

    add-int/lit8 v2, v1, 0x1

    sput v2, Lcom/motorola/myscreen/api/MyScreenApi;->sCount:I

    iput v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    .line 74
    sget-boolean v2, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v2, :cond_0

    .line 75
    sget-object v2, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " constructor"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    if-eqz p1, :cond_2

    if-eqz p3, :cond_1

    .line 82
    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostContext:Landroid/content/Context;

    .line 83
    iput-object p2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    .line 84
    const-string p2, "TOKEN"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p2, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    iput-object p3, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;

    .line 86
    iput-boolean p4, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsRtl:Z

    .line 87
    iput-object p5, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSettingsActivityLaunchIntent:Landroid/content/Intent;

    .line 88
    new-instance p1, Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;

    const/4 p2, 0x0

    invoke-direct {p1, p0, p2}, Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;Lcom/motorola/myscreen/api/MyScreenApi$1;)V

    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    .line 89
    new-instance p2, Landroid/os/Messenger;

    invoke-direct {p2, p1}, Landroid/os/Messenger;-><init>(Landroid/os/Handler;)V

    iput-object p2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mLocalMessenger:Landroid/os/Messenger;

    .line 90
    new-instance p1, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda0;

    invoke-direct {p1, p0}, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda0;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;)V

    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectRunnable:Ljava/lang/Runnable;

    .line 91
    new-instance p2, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda1;

    invoke-direct {p2, p0}, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda1;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;)V

    iput-object p2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    .line 92
    new-instance p2, Lcom/motorola/myscreen/api/MyScreenApi$1;

    invoke-direct {p2, p0}, Lcom/motorola/myscreen/api/MyScreenApi$1;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;)V

    iput-object p2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mServiceConnection:Landroid/content/ServiceConnection;

    .line 104
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    .line 80
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "callbacks must not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 78
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "hostContext must not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static synthetic access$100(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/IBinder;)V
    .locals 0

    .line 29
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->handleOnServiceConnected(Landroid/os/IBinder;)V

    return-void
.end method

.method static synthetic access$200()Z
    .locals 1

    .line 29
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    return v0
.end method

.method static synthetic access$300()Ljava/lang/String;
    .locals 1

    .line 29
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$400(Lcom/motorola/myscreen/api/MyScreenApi;)I
    .locals 0

    .line 29
    iget p0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    return p0
.end method

.method static synthetic access$500(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/RemoteException;)V
    .locals 0

    .line 29
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V

    return-void
.end method

.method static synthetic access$600(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/Message;)V
    .locals 0

    .line 29
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->handleRemoteMessage(Landroid/os/Message;)V

    return-void
.end method

.method private declared-synchronized checkConnection()V
    .locals 3

    monitor-enter p0

    .line 439
    :try_start_0
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mRemoteMessenger:Landroid/os/Messenger;

    if-nez v0, :cond_1

    .line 440
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 441
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " service bound but not connected, retrying..."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 443
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 445
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private declared-synchronized handleConnect()V
    .locals 5

    monitor-enter p0

    .line 410
    :try_start_0
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 411
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " handleConnect"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_2

    .line 413
    :cond_0
    :goto_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.motorola.myscreen.service.MyScreenService"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 414
    const-string v1, "com.motorola.myscreen"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 415
    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostContext:Landroid/content/Context;

    .line 416
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->isNotDestroyed()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_3

    invoke-static {v1}, Lcom/motorola/myscreen/api/MyScreenApi;->isMyScreenAvailable(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_3

    .line 423
    iget-object v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mServiceConnection:Landroid/content/ServiceConnection;

    const/16 v4, 0x241

    invoke-virtual {v1, v0, v2, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    if-nez v0, :cond_1

    .line 425
    invoke-direct {p0, v3}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V

    goto :goto_1

    .line 427
    :cond_1
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_2

    .line 428
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " service bound"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 430
    :cond_2
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0x1388

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    .line 434
    :cond_3
    invoke-direct {p0, v3}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 436
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method private declared-synchronized handleConnectionError(Landroid/os/RemoteException;)V
    .locals 4

    monitor-enter p0

    .line 466
    :try_start_0
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 467
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " handleConnectionError"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto/16 :goto_2

    .line 470
    :cond_0
    :goto_0
    iget-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 471
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->safeUnboundService()V

    const/4 p1, 0x0

    .line 472
    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mRemoteMessenger:Landroid/os/Messenger;

    const/4 p1, 0x0

    .line 473
    iput-boolean p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSentWindowAttributes:Z

    .line 474
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->notifyServiceStateChanged(Z)V

    .line 475
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 476
    iget v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectAttemptCount:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectAttemptCount:I

    int-to-double v0, v0

    const-wide/high16 v2, 0x3ff8000000000000L    # 1.5

    .line 477
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const-wide v2, 0x408f400000000000L    # 1000.0

    mul-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    const-wide/32 v2, 0xea60

    cmp-long v2, v0, v2

    if-gtz v2, :cond_1

    .line 478
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->isNotDestroyed()Z

    move-result v2

    if-eqz v2, :cond_1

    .line 479
    iget-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectRunnable:Ljava/lang/Runnable;

    invoke-virtual {p1, v2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 480
    sget-boolean p1, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz p1, :cond_2

    .line 481
    sget-object p1, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " Retrying in "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    .line 484
    :cond_1
    iput p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectAttemptCount:I

    .line 485
    sget-boolean p1, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz p1, :cond_2

    .line 486
    sget-object p1, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Giving up reconnect retries"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 490
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized handleOnServiceConnected(Landroid/os/IBinder;)V
    .locals 3

    monitor-enter p0

    .line 452
    :try_start_0
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 453
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onServiceConnected"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 455
    :cond_0
    :goto_0
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 456
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->isNotDestroyed()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 457
    new-instance v0, Landroid/os/Messenger;

    invoke-direct {v0, p1}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mRemoteMessenger:Landroid/os/Messenger;

    const/4 p1, 0x0

    .line 458
    iput p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mConnectAttemptCount:I

    .line 459
    invoke-virtual {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->onAttachedToWindow()V

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    .line 461
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 463
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized handleRemoteMessage(Landroid/os/Message;)V
    .locals 2

    monitor-enter p0

    .line 373
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_3

    .line 374
    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    const/16 p1, 0x8

    if-eq v0, p1, :cond_1

    const/16 p1, 0x1d

    if-eq v0, p1, :cond_0

    goto :goto_0

    .line 382
    :cond_0
    iget-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;

    invoke-interface {p1}, Lcom/motorola/myscreen/api/ApiCallback;->requestKeyguardDismiss()V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    const/4 p1, 0x1

    .line 379
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->notifyServiceStateChanged(Z)V

    goto :goto_0

    .line 376
    :cond_2
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;

    iget p1, p1, Landroid/os/Message;->arg1:I

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    invoke-interface {v0, p1}, Lcom/motorola/myscreen/api/ApiCallback;->onScrollUpdated(F)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 386
    :cond_3
    :goto_0
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public static isMyScreenAvailable(Landroid/content/Context;)Z
    .locals 2

    const/4 v0, 0x0

    .line 343
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    .line 344
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "com.motorola.myscreen"

    invoke-virtual {p0, v1}, Landroid/content/pm/PackageManager;->getApplicationEnabledSetting(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    if-eq p0, v1, :cond_0

    const/4 p0, 0x1

    return p0

    :catch_0
    :cond_0
    return v0
.end method

.method private isNotDestroyed()Z
    .locals 0

    .line 448
    iget-boolean p0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method private declared-synchronized notifyServiceStateChanged(Z)V
    .locals 2

    monitor-enter p0

    .line 493
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHasNotifiedServiceState:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mLastNotifiedServiceState:Z

    if-eq v0, p1, :cond_2

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 494
    :cond_0
    :goto_0
    new-instance v0, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda2;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;Z)V

    .line 502
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 503
    iget-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 505
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 508
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private safeUnboundService()V
    .locals 4

    .line 511
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 512
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    const-string v1, " safeUnboundService"

    if-eqz v0, :cond_0

    .line 513
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 516
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mServiceConnection:Landroid/content/ServiceConnection;

    invoke-virtual {v0, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    .line 518
    sget-boolean v2, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v2, :cond_1

    .line 519
    sget-object v2, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget p0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1
    return-void
.end method

.method private declared-synchronized sendRemote(Landroid/os/Message;)Z
    .locals 3

    monitor-enter p0

    .line 389
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 390
    monitor-exit p0

    return v1

    .line 391
    :cond_0
    :try_start_1
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mRemoteMessenger:Landroid/os/Messenger;

    if-nez v0, :cond_2

    .line 392
    sget-boolean p1, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz p1, :cond_1

    .line 393
    sget-object p1, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " mRemoteMessenger is null"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    .line 396
    :cond_1
    :goto_0
    monitor-exit p0

    return v1

    .line 399
    :cond_2
    :try_start_2
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->dataBundle:Landroid/os/Bundle;

    invoke-virtual {p1, v0}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 400
    iget-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mRemoteMessenger:Landroid/os/Messenger;

    invoke-virtual {v0, p1}, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 401
    monitor-exit p0

    const/4 p0, 0x1

    return p0

    :catch_0
    move-exception p1

    .line 403
    :try_start_3
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 404
    monitor-exit p0

    return v1

    :goto_1
    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p1
.end method


# virtual methods
.method public endScroll(F)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x3

    .line 120
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 121
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 122
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method

.method public declared-synchronized hide()V
    .locals 3

    monitor-enter p0

    .line 327
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 328
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 329
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " hide"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0xb

    .line 332
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 333
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 335
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onAttachedToWindow()V
    .locals 5

    monitor-enter p0

    .line 126
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSentWindowAttributes:Z

    if-nez v0, :cond_6

    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsResumed:Z

    if-eqz v0, :cond_6

    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_6

    .line 127
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 128
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onAttachedToWindow"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 130
    invoke-static {v1, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 131
    iget-boolean v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsRtl:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    .line 132
    iget v2, v0, Landroid/os/Message;->arg1:I

    or-int/2addr v2, v3

    iput v2, v0, Landroid/os/Message;->arg1:I

    .line 134
    :cond_1
    iget-boolean v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsLightStatusBar:Z

    if-eqz v2, :cond_2

    .line 135
    iget v2, v0, Landroid/os/Message;->arg1:I

    or-int/lit8 v2, v2, 0x2

    iput v2, v0, Landroid/os/Message;->arg1:I

    .line 137
    :cond_2
    iget-boolean v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsStatusBarHidden:Z

    if-eqz v2, :cond_3

    .line 138
    iget v2, v0, Landroid/os/Message;->arg1:I

    or-int/lit8 v2, v2, 0x4

    iput v2, v0, Landroid/os/Message;->arg1:I

    .line 140
    :cond_3
    iget-boolean v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsLightNavigationBar:Z

    const/16 v4, 0x8

    if-eqz v2, :cond_4

    .line 141
    iget v2, v0, Landroid/os/Message;->arg1:I

    or-int/2addr v2, v4

    iput v2, v0, Landroid/os/Message;->arg1:I

    .line 143
    :cond_4
    iget-boolean v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsTranslucentNavigationBar:Z

    if-eqz v2, :cond_5

    .line 144
    iget v2, v0, Landroid/os/Message;->arg1:I

    or-int/lit8 v2, v2, 0x10

    iput v2, v0, Landroid/os/Message;->arg1:I

    .line 147
    :cond_5
    iput v4, v0, Landroid/os/Message;->arg2:I

    .line 148
    iget-object v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mLocalMessenger:Landroid/os/Messenger;

    iput-object v2, v0, Landroid/os/Message;->replyTo:Landroid/os/Messenger;

    .line 149
    iget-object v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    iput-object v2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 150
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 151
    iput-boolean v3, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSentWindowAttributes:Z

    const/16 v0, 0xe

    .line 152
    invoke-static {v1, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 153
    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSettingsActivityLaunchIntent:Landroid/content/Intent;

    iput-object v1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 154
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 158
    :cond_6
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onDestroy()V
    .locals 3

    monitor-enter p0

    .line 198
    :try_start_0
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 199
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onDestroy"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    .line 201
    :cond_0
    :goto_0
    invoke-direct {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->safeUnboundService()V

    const/4 v0, 0x1

    .line 202
    iput-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    const/4 v0, 0x0

    .line 203
    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostContext:Landroid/content/Context;

    .line 204
    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    .line 205
    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCallbacks:Lcom/motorola/myscreen/api/ApiCallback;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 206
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onDetachedFromWindow()V
    .locals 3

    monitor-enter p0

    .line 161
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 162
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 163
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onDetachedFromWindow"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 166
    iput-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mSentWindowAttributes:Z

    const/4 v0, 0x0

    const/4 v1, 0x5

    .line 167
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 168
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 170
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onPause()V
    .locals 3

    monitor-enter p0

    .line 186
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 187
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 188
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onPause"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 191
    iput-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsResumed:Z

    const/4 v0, 0x0

    const/4 v1, 0x4

    .line 192
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 193
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 195
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onResume()V
    .locals 3

    monitor-enter p0

    .line 173
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 174
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 175
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onResume"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 178
    iput-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsResumed:Z

    .line 179
    invoke-virtual {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->onAttachedToWindow()V

    const/4 v0, 0x0

    const/4 v1, 0x6

    .line 180
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 181
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 183
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized reAttachOverlay()V
    .locals 4

    monitor-enter p0

    .line 248
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 249
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 250
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " reAttachOverlay"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x12

    .line 253
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 255
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 256
    const-string v2, "configuration"

    iget-object v3, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mHostContext:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 257
    iput-object v1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 258
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 260
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized setLightNavigationBar(Z)V
    .locals 3

    monitor-enter p0

    .line 295
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 296
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 297
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " setLightNavigationBar"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    .line 300
    :cond_0
    :goto_0
    iput-boolean p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsLightNavigationBar:Z

    const/4 v0, 0x0

    const/16 v1, 0xf

    .line 301
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    if-eqz p1, :cond_1

    .line 303
    iget p1, v0, Landroid/os/Message;->arg1:I

    or-int/lit8 p1, p1, 0x8

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 306
    :cond_1
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 308
    :cond_2
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized setLightStatusBar(Z)V
    .locals 3

    monitor-enter p0

    .line 263
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 264
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 265
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " setLightStatusBar"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    .line 268
    :cond_0
    :goto_0
    iput-boolean p1, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsLightStatusBar:Z

    const/4 v0, 0x0

    const/16 v1, 0xa

    .line 269
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    if-eqz p1, :cond_1

    .line 271
    iget p1, v0, Landroid/os/Message;->arg1:I

    or-int/lit8 p1, p1, 0x2

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 274
    :cond_1
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 276
    :cond_2
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public startScroll()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    .line 109
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 110
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method

.method public declared-synchronized turnOff()V
    .locals 3

    monitor-enter p0

    .line 212
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 213
    sget-boolean v0, Lcom/motorola/myscreen/api/MyScreenApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 214
    sget-object v0, Lcom/motorola/myscreen/api/MyScreenApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/myscreen/api/MyScreenApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " turnOff"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0xd

    .line 217
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 218
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z

    .line 219
    invoke-virtual {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->onDestroy()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 221
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public updateScroll(F)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x2

    .line 114
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 115
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 116
    invoke-direct {p0, v0}, Lcom/motorola/myscreen/api/MyScreenApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method
