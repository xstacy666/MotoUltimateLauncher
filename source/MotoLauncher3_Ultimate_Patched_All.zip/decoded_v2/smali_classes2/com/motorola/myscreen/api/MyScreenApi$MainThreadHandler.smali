.class final Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;
.super Landroid/os/Handler;
.source "MyScreenApi.java"


# instance fields
.field private final mApiRef:Ljava/lang/ref/SoftReference;


# direct methods
.method private constructor <init>(Lcom/motorola/myscreen/api/MyScreenApi;)V
    .locals 1

    .line 529
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 530
    new-instance v0, Ljava/lang/ref/SoftReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/SoftReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;->mApiRef:Ljava/lang/ref/SoftReference;

    return-void
.end method

.method synthetic constructor <init>(Lcom/motorola/myscreen/api/MyScreenApi;Lcom/motorola/myscreen/api/MyScreenApi$1;)V
    .locals 0

    .line 525
    invoke-direct {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;-><init>(Lcom/motorola/myscreen/api/MyScreenApi;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 0

    .line 534
    iget-object p0, p0, Lcom/motorola/myscreen/api/MyScreenApi$MainThreadHandler;->mApiRef:Ljava/lang/ref/SoftReference;

    invoke-virtual {p0}, Ljava/lang/ref/SoftReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/motorola/myscreen/api/MyScreenApi;

    if-eqz p0, :cond_0

    .line 536
    invoke-static {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->access$600(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/Message;)V

    :cond_0
    return-void
.end method
