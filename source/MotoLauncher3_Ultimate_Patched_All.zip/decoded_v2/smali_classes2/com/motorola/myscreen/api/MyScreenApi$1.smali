.class Lcom/motorola/myscreen/api/MyScreenApi$1;
.super Ljava/lang/Object;
.source "MyScreenApi.java"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field final synthetic this$0:Lcom/motorola/myscreen/api/MyScreenApi;


# direct methods
.method constructor <init>(Lcom/motorola/myscreen/api/MyScreenApi;)V
    .locals 0

    .line 92
    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi$1;->this$0:Lcom/motorola/myscreen/api/MyScreenApi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 0

    .line 94
    iget-object p0, p0, Lcom/motorola/myscreen/api/MyScreenApi$1;->this$0:Lcom/motorola/myscreen/api/MyScreenApi;

    invoke-static {p0, p2}, Lcom/motorola/myscreen/api/MyScreenApi;->access$100(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/IBinder;)V

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2

    .line 98
    invoke-static {}, Lcom/motorola/myscreen/api/MyScreenApi;->access$200()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 99
    invoke-static {}, Lcom/motorola/myscreen/api/MyScreenApi;->access$300()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/motorola/myscreen/api/MyScreenApi$1;->this$0:Lcom/motorola/myscreen/api/MyScreenApi;

    invoke-static {v1}, Lcom/motorola/myscreen/api/MyScreenApi;->access$400(Lcom/motorola/myscreen/api/MyScreenApi;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " onServiceDisconnected"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    :cond_0
    iget-object p0, p0, Lcom/motorola/myscreen/api/MyScreenApi$1;->this$0:Lcom/motorola/myscreen/api/MyScreenApi;

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lcom/motorola/myscreen/api/MyScreenApi;->access$500(Lcom/motorola/myscreen/api/MyScreenApi;Landroid/os/RemoteException;)V

    return-void
.end method
