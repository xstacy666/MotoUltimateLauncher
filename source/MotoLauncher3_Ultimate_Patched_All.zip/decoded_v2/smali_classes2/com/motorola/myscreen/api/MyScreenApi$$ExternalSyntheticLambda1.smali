.class public final synthetic Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/motorola/myscreen/api/MyScreenApi;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/myscreen/api/MyScreenApi;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda1;->f$0:Lcom/motorola/myscreen/api/MyScreenApi;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/motorola/myscreen/api/MyScreenApi$$ExternalSyntheticLambda1;->f$0:Lcom/motorola/myscreen/api/MyScreenApi;

    invoke-static {p0}, Lcom/motorola/myscreen/api/MyScreenApi;->$r8$lambda$mO2w5fGocJdsW7H2HemvaBju3EM(Lcom/motorola/myscreen/api/MyScreenApi;)V

    return-void
.end method
