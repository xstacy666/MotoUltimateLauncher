.class public interface abstract Lcom/motorola/myscreen/api/ApiCallback;
.super Ljava/lang/Object;
.source "ApiCallback.java"


# virtual methods
.method public abstract onScrollUpdated(F)V
.end method

.method public abstract onServiceStateChanged(Z)V
.end method

.method public abstract requestKeyguardDismiss()V
.end method
