.class Lcom/motorola/plugin/sdk/channel/RemoteService$1;
.super Landroid/os/RemoteCallbackList;
.source "RemoteService.java"


# instance fields
.field final synthetic this$0:Lcom/motorola/plugin/sdk/channel/RemoteService;


# direct methods
.method constructor <init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V
    .locals 0

    .line 192
    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$1;->this$0:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-direct {p0}, Landroid/os/RemoteCallbackList;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic onCallbackDied(Landroid/os/IInterface;Ljava/lang/Object;)V
    .locals 0

    .line 192
    check-cast p1, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService$1;->onCallbackDied(Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V

    return-void
.end method

.method public onCallbackDied(Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V
    .locals 0

    .line 195
    invoke-static {}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->obtain()Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    move-result-object p1

    .line 196
    iput-object p2, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    .line 197
    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object p2, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    .line 198
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$1;->this$0:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-static {p0}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$100(Lcom/motorola/plugin/sdk/channel/RemoteService;)Landroid/os/Handler;

    move-result-object p0

    const/4 p2, 0x2

    invoke-virtual {p0, p2, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p0

    .line 199
    invoke-virtual {p0}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method
