.class public final Lcom/motorola/plugin/sdk/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static SharedValue:I

.field public static SharedValueId:I

.field public static a:I

.field public static actionBarDivider:I

.field public static actionBarItemBackground:I

.field public static actionBarPopupTheme:I

.field public static actionBarSize:I

.field public static actionBarSplitStyle:I

.field public static actionBarStyle:I

.field public static actionBarTabBarStyle:I

.field public static actionBarTabStyle:I

.field public static actionBarTabTextStyle:I

.field public static actionBarTheme:I

.field public static actionBarWidgetTheme:I

.field public static actionButtonStyle:I

.field public static actionDividerHeight:I

.field public static actionDropDownStyle:I

.field public static actionLayout:I

.field public static actionMenuTextAppearance:I

.field public static actionMenuTextColor:I

.field public static actionModeBackground:I

.field public static actionModeCloseButtonStyle:I

.field public static actionModeCloseContentDescription:I

.field public static actionModeCloseDrawable:I

.field public static actionModeCopyDrawable:I

.field public static actionModeCutDrawable:I

.field public static actionModeFindDrawable:I

.field public static actionModePasteDrawable:I

.field public static actionModePopupWindowStyle:I

.field public static actionModeSelectAllDrawable:I

.field public static actionModeShareDrawable:I

.field public static actionModeSplitBackground:I

.field public static actionModeStyle:I

.field public static actionModeTheme:I

.field public static actionModeWebSearchDrawable:I

.field public static actionOverflowButtonStyle:I

.field public static actionOverflowMenuStyle:I

.field public static actionProviderClass:I

.field public static actionTextColorAlpha:I

.field public static actionViewClass:I

.field public static activeIndicatorLabelPadding:I

.field public static activityAction:I

.field public static activityChooserViewStyle:I

.field public static activityName:I

.field public static addElevationShadow:I

.field public static adjustable:I

.field public static alertDialogButtonGroupStyle:I

.field public static alertDialogCenterButtons:I

.field public static alertDialogStyle:I

.field public static alertDialogTheme:I

.field public static alignOnIcon:I

.field public static allAppBg:I

.field public static allAppTipsBg:I

.field public static allAppTipsText:I

.field public static allAppsBorderSpace:I

.field public static allAppsBorderSpaceHorizontal:I

.field public static allAppsBorderSpaceLandscape:I

.field public static allAppsBorderSpaceLandscapeHorizontal:I

.field public static allAppsBorderSpaceLandscapeVertical:I

.field public static allAppsBorderSpaceTwoPanelLandscape:I

.field public static allAppsBorderSpaceTwoPanelLandscapeHorizontal:I

.field public static allAppsBorderSpaceTwoPanelLandscapeVertical:I

.field public static allAppsBorderSpaceTwoPanelPortrait:I

.field public static allAppsBorderSpaceTwoPanelPortraitHorizontal:I

.field public static allAppsBorderSpaceTwoPanelPortraitVertical:I

.field public static allAppsBorderSpaceVertical:I

.field public static allAppsCellHeight:I

.field public static allAppsCellHeightLandscape:I

.field public static allAppsCellHeightTwoPanelLandscape:I

.field public static allAppsCellHeightTwoPanelPortrait:I

.field public static allAppsCellSpecsId:I

.field public static allAppsCellSpecsTwoPanelId:I

.field public static allAppsCellWidth:I

.field public static allAppsCellWidthLandscape:I

.field public static allAppsCellWidthTwoPanelLandscape:I

.field public static allAppsCellWidthTwoPanelPortrait:I

.field public static allAppsFolderPreviewColor:I

.field public static allAppsIconSize:I

.field public static allAppsIconSizeLandscape:I

.field public static allAppsIconSizeTwoPanelLandscape:I

.field public static allAppsIconSizeTwoPanelPortrait:I

.field public static allAppsIconTextSize:I

.field public static allAppsIconTextSizeTwoPanelLandscape:I

.field public static allAppsIconTextSizeTwoPanelPortrait:I

.field public static allAppsMenu:I

.field public static allAppsNavBarScrimColor:I

.field public static allAppsScrimColor:I

.field public static allAppsSpecsId:I

.field public static allAppsSpecsTwoPanelId:I

.field public static allAppsStyle:I

.field public static allAppsTheme:I

.field public static allappsHeaderProtectionColor:I

.field public static allowDividerAbove:I

.field public static allowDividerAfterLastItem:I

.field public static allowDividerBelow:I

.field public static allowStacking:I

.field public static alpha:I

.field public static alphabeticModifiers:I

.field public static alsoKeepInApp:I

.field public static altSrc:I

.field public static alwaysExpand:I

.field public static ambientShadowAlpha:I

.field public static ambientShadowBlur:I

.field public static ambientShadowColor:I

.field public static ambientShadowOffsetX:I

.field public static ambientShadowOffsetY:I

.field public static animateCircleAngleTo:I

.field public static animateMenuItems:I

.field public static animateNavigationIcon:I

.field public static animateRelativeTo:I

.field public static animationBackgroundColor:I

.field public static animationMode:I

.field public static appBarLayoutStyle:I

.field public static appIconSize:I

.field public static appPairSurfaceInFolder:I

.field public static applyMotionScene:I

.field public static arcMode:I

.field public static arrowHeadLength:I

.field public static arrowShaftLength:I

.field public static arrowTipBackground:I

.field public static arrowTipTextColor:I

.field public static attributeName:I

.field public static autoAdjustToWithinGrandparentBounds:I

.field public static autoCompleteMode:I

.field public static autoCompleteTextViewStyle:I

.field public static autoShowKeyboard:I

.field public static autoSizeMaxTextSize:I

.field public static autoSizeMinTextSize:I

.field public static autoSizePresetSizes:I

.field public static autoSizeStepGranularity:I

.field public static autoSizeTextType:I

.field public static autoTransition:I

.field public static b:I

.field public static backHandlingEnabled:I

.field public static background:I

.field public static backgroundColor:I

.field public static backgroundInsetBottom:I

.field public static backgroundInsetEnd:I

.field public static backgroundInsetStart:I

.field public static backgroundInsetTop:I

.field public static backgroundOverlayColorAlpha:I

.field public static backgroundSplit:I

.field public static backgroundStacked:I

.field public static backgroundTint:I

.field public static backgroundTintMode:I

.field public static badgeFixedEdge:I

.field public static badgeGravity:I

.field public static badgeHeight:I

.field public static badgeRadius:I

.field public static badgeShapeAppearance:I

.field public static badgeShapeAppearanceOverlay:I

.field public static badgeStyle:I

.field public static badgeText:I

.field public static badgeTextAppearance:I

.field public static badgeTextColor:I

.field public static badgeVerticalPadding:I

.field public static badgeWidePadding:I

.field public static badgeWidth:I

.field public static badgeWithTextHeight:I

.field public static badgeWithTextRadius:I

.field public static badgeWithTextShapeAppearance:I

.field public static badgeWithTextShapeAppearanceOverlay:I

.field public static badgeWithTextWidth:I

.field public static barLength:I

.field public static barrierAllowsGoneWidgets:I

.field public static barrierDirection:I

.field public static barrierMargin:I

.field public static behavior_autoHide:I

.field public static behavior_autoShrink:I

.field public static behavior_draggable:I

.field public static behavior_draggableOnNestedScroll:I

.field public static behavior_expandedOffset:I

.field public static behavior_fitToContents:I

.field public static behavior_halfExpandedRatio:I

.field public static behavior_hideable:I

.field public static behavior_overlapTop:I

.field public static behavior_peekHeight:I

.field public static behavior_saveFlags:I

.field public static behavior_significantVelocityThreshold:I

.field public static behavior_skipCollapsed:I

.field public static blendSrc:I

.field public static borderColor:I

.field public static borderRound:I

.field public static borderRoundPercent:I

.field public static borderSpace:I

.field public static borderSpaceHorizontal:I

.field public static borderSpaceLandscape:I

.field public static borderSpaceLandscapeHorizontal:I

.field public static borderSpaceLandscapeVertical:I

.field public static borderSpaceTwoPanelLandscape:I

.field public static borderSpaceTwoPanelLandscapeHorizontal:I

.field public static borderSpaceTwoPanelLandscapeVertical:I

.field public static borderSpaceTwoPanelPortrait:I

.field public static borderSpaceTwoPanelPortraitHorizontal:I

.field public static borderSpaceTwoPanelPortraitVertical:I

.field public static borderSpaceVertical:I

.field public static borderWidth:I

.field public static borderlessButtonStyle:I

.field public static bottomAppBarStyle:I

.field public static bottomDividerEndPadding:I

.field public static bottomDividerStartPadding:I

.field public static bottomInsetScrimEnabled:I

.field public static bottomNavigationStyle:I

.field public static bottomSheetDialogTheme:I

.field public static bottomSheetDragHandleStyle:I

.field public static bottomSheetStyle:I

.field public static boxBackgroundColor:I

.field public static boxBackgroundMode:I

.field public static boxCollapsedPaddingTop:I

.field public static boxCornerRadiusBottomEnd:I

.field public static boxCornerRadiusBottomStart:I

.field public static boxCornerRadiusTopEnd:I

.field public static boxCornerRadiusTopStart:I

.field public static boxStrokeColor:I

.field public static boxStrokeErrorColor:I

.field public static boxStrokeWidth:I

.field public static boxStrokeWidthFocused:I

.field public static brightness:I

.field public static buttonBarButtonStyle:I

.field public static buttonBarNegativeButtonStyle:I

.field public static buttonBarNeutralButtonStyle:I

.field public static buttonBarPositiveButtonStyle:I

.field public static buttonBarStyle:I

.field public static buttonCompat:I

.field public static buttonGravity:I

.field public static buttonIcon:I

.field public static buttonIconDimen:I

.field public static buttonIconTint:I

.field public static buttonIconTintMode:I

.field public static buttonPanelSideLayout:I

.field public static buttonSizeChange:I

.field public static buttonStyle:I

.field public static buttonStyleSmall:I

.field public static buttonTint:I

.field public static buttonTintMode:I

.field public static c:I

.field public static canBeDefault:I

.field public static canThumbDetach:I

.field public static cardBackgroundColor:I

.field public static cardCornerRadius:I

.field public static cardElevation:I

.field public static cardForegroundColor:I

.field public static cardMaxElevation:I

.field public static cardPreventCornerOverlap:I

.field public static cardUseCompatPadding:I

.field public static cardViewStyle:I

.field public static carousel_alignment:I

.field public static carousel_backwardTransition:I

.field public static carousel_emptyViewsBehavior:I

.field public static carousel_firstView:I

.field public static carousel_forwardTransition:I

.field public static carousel_infinite:I

.field public static carousel_nextState:I

.field public static carousel_previousState:I

.field public static carousel_touchUpMode:I

.field public static carousel_touchUp_dampeningFactor:I

.field public static carousel_touchUp_velocityThreshold:I

.field public static category:I

.field public static cellStyle:I

.field public static centerIfNoTextEnabled:I

.field public static centerVertically:I

.field public static chainUseRtl:I

.field public static checkBoxPreferenceStyle:I

.field public static checkMarkCompat:I

.field public static checkMarkTint:I

.field public static checkMarkTintMode:I

.field public static checkboxStyle:I

.field public static checkedButton:I

.field public static checkedChip:I

.field public static checkedIcon:I

.field public static checkedIconEnabled:I

.field public static checkedIconGravity:I

.field public static checkedIconMargin:I

.field public static checkedIconSize:I

.field public static checkedIconTint:I

.field public static checkedIconVisible:I

.field public static checkedState:I

.field public static checkedTextViewStyle:I

.field public static chipBackgroundColor:I

.field public static chipCornerRadius:I

.field public static chipEndPadding:I

.field public static chipGroupStyle:I

.field public static chipIcon:I

.field public static chipIconEnabled:I

.field public static chipIconSize:I

.field public static chipIconTint:I

.field public static chipIconVisible:I

.field public static chipMinHeight:I

.field public static chipMinTouchTargetSize:I

.field public static chipSpacing:I

.field public static chipSpacingHorizontal:I

.field public static chipSpacingVertical:I

.field public static chipStandaloneStyle:I

.field public static chipStartPadding:I

.field public static chipStrokeColor:I

.field public static chipStrokeWidth:I

.field public static chipStyle:I

.field public static chipSurfaceColor:I

.field public static circleRadius:I

.field public static circularProgressIndicatorStyle:I

.field public static circularflow_angles:I

.field public static circularflow_defaultAngle:I

.field public static circularflow_defaultRadius:I

.field public static circularflow_radiusInDP:I

.field public static circularflow_viewCenter:I

.field public static className:I

.field public static clearInput:I

.field public static clearTop:I

.field public static clearsTag:I

.field public static clickAction:I

.field public static clockFaceBackgroundColor:I

.field public static clockHandColor:I

.field public static clockIcon:I

.field public static clockNumberTextColor:I

.field public static closeIcon:I

.field public static closeIconEnabled:I

.field public static closeIconEndPadding:I

.field public static closeIconSize:I

.field public static closeIconStartPadding:I

.field public static closeIconTint:I

.field public static closeIconVisible:I

.field public static closeItemLayout:I

.field public static collapsable:I

.field public static collapseContentDescription:I

.field public static collapseIcon:I

.field public static collapsedSize:I

.field public static collapsedTitleGravity:I

.field public static collapsedTitleTextAppearance:I

.field public static collapsedTitleTextColor:I

.field public static collapsingToolbarLayoutLargeSize:I

.field public static collapsingToolbarLayoutLargeStyle:I

.field public static collapsingToolbarLayoutMediumSize:I

.field public static collapsingToolbarLayoutMediumStyle:I

.field public static collapsingToolbarLayoutStyle:I

.field public static color:I

.field public static colorAccent:I

.field public static colorAccentPrimaryVariant:I

.field public static colorAccentSecondaryVariant:I

.field public static colorBackgroundFloating:I

.field public static colorButtonNormal:I

.field public static colorContainer:I

.field public static colorContainerChecked:I

.field public static colorContainerUnchecked:I

.field public static colorControlActivated:I

.field public static colorControlHighlight:I

.field public static colorControlNormal:I

.field public static colorError:I

.field public static colorErrorContainer:I

.field public static colorOnBackground:I

.field public static colorOnContainer:I

.field public static colorOnContainerChecked:I

.field public static colorOnContainerUnchecked:I

.field public static colorOnError:I

.field public static colorOnErrorContainer:I

.field public static colorOnPrimary:I

.field public static colorOnPrimaryContainer:I

.field public static colorOnPrimaryFixed:I

.field public static colorOnPrimaryFixedVariant:I

.field public static colorOnPrimarySurface:I

.field public static colorOnSecondary:I

.field public static colorOnSecondaryContainer:I

.field public static colorOnSecondaryFixed:I

.field public static colorOnSecondaryFixedVariant:I

.field public static colorOnSurface:I

.field public static colorOnSurfaceInverse:I

.field public static colorOnSurfaceVariant:I

.field public static colorOnTertiary:I

.field public static colorOnTertiaryContainer:I

.field public static colorOnTertiaryFixed:I

.field public static colorOnTertiaryFixedVariant:I

.field public static colorOutline:I

.field public static colorOutlineVariant:I

.field public static colorPrimary:I

.field public static colorPrimaryContainer:I

.field public static colorPrimaryDark:I

.field public static colorPrimaryFixed:I

.field public static colorPrimaryFixedDim:I

.field public static colorPrimaryInverse:I

.field public static colorPrimarySurface:I

.field public static colorPrimaryVariant:I

.field public static colorSecondary:I

.field public static colorSecondaryContainer:I

.field public static colorSecondaryFixed:I

.field public static colorSecondaryFixedDim:I

.field public static colorSecondaryVariant:I

.field public static colorSurface:I

.field public static colorSurfaceBright:I

.field public static colorSurfaceContainer:I

.field public static colorSurfaceContainerHigh:I

.field public static colorSurfaceContainerHighest:I

.field public static colorSurfaceContainerLow:I

.field public static colorSurfaceContainerLowest:I

.field public static colorSurfaceDim:I

.field public static colorSurfaceInverse:I

.field public static colorSurfaceVariant:I

.field public static colorSwitchThumbNormal:I

.field public static colorTertiary:I

.field public static colorTertiaryContainer:I

.field public static colorTertiaryFixed:I

.field public static colorTertiaryFixedDim:I

.field public static commitIcon:I

.field public static compatShadowEnabled:I

.field public static constraintRotate:I

.field public static constraintSet:I

.field public static constraintSetEnd:I

.field public static constraintSetStart:I

.field public static constraint_referenced_ids:I

.field public static constraint_referenced_tags:I

.field public static constraints:I

.field public static container:I

.field public static containerColor:I

.field public static containerHeight:I

.field public static containerIconPadding:I

.field public static containerIconSize:I

.field public static containerInsetBottom:I

.field public static containerInsetLeft:I

.field public static containerInsetRight:I

.field public static containerInsetTop:I

.field public static containerPaddingBottom:I

.field public static containerPaddingEnd:I

.field public static containerPaddingStart:I

.field public static containerPaddingTop:I

.field public static containerShapeChecked:I

.field public static containerShapeDefault:I

.field public static containerShapePressed:I

.field public static containerStrokeWidth:I

.field public static containerType:I

.field public static containerWidth:I

.field public static content:I

.field public static contentDescription:I

.field public static contentEndPadding:I

.field public static contentInsetEnd:I

.field public static contentInsetEndWithActions:I

.field public static contentInsetLeft:I

.field public static contentInsetRight:I

.field public static contentInsetStart:I

.field public static contentInsetStartWithNavigation:I

.field public static contentMarginTop:I

.field public static contentPadding:I

.field public static contentPaddingBottom:I

.field public static contentPaddingEnd:I

.field public static contentPaddingLeft:I

.field public static contentPaddingRight:I

.field public static contentPaddingStart:I

.field public static contentPaddingTop:I

.field public static contentScrim:I

.field public static contentStartPadding:I

.field public static contrast:I

.field public static controlBackground:I

.field public static coordinatorLayoutStyle:I

.field public static coplanarSiblingViewId:I

.field public static cornerFamily:I

.field public static cornerFamilyBottomLeft:I

.field public static cornerFamilyBottomRight:I

.field public static cornerFamilyTopLeft:I

.field public static cornerFamilyTopRight:I

.field public static cornerRadius:I

.field public static cornerSize:I

.field public static cornerSizeBottomLeft:I

.field public static cornerSizeBottomRight:I

.field public static cornerSizeTopLeft:I

.field public static cornerSizeTopRight:I

.field public static counterEnabled:I

.field public static counterMaxLength:I

.field public static counterOverflowTextAppearance:I

.field public static counterOverflowTextColor:I

.field public static counterTextAppearance:I

.field public static counterTextColor:I

.field public static crossfade:I

.field public static currentState:I

.field public static cursorColor:I

.field public static cursorErrorColor:I

.field public static curveFit:I

.field public static customBoolean:I

.field public static customColorDrawableValue:I

.field public static customColorValue:I

.field public static customDimension:I

.field public static customFloatValue:I

.field public static customIcon:I

.field public static customIntegerValue:I

.field public static customNavigationLayout:I

.field public static customPixelDimension:I

.field public static customReference:I

.field public static customStringValue:I

.field public static darkTintColor:I

.field public static dayInvalidStyle:I

.field public static daySelectedStyle:I

.field public static dayStyle:I

.field public static dayTodayStyle:I

.field public static dbFile:I

.field public static defaultDuration:I

.field public static defaultLayoutId:I

.field public static defaultMarginsEnabled:I

.field public static defaultQueryHint:I

.field public static defaultScrollFlagsEnabled:I

.field public static defaultState:I

.field public static defaultValue:I

.field public static deltaPolarAngle:I

.field public static deltaPolarRadius:I

.field public static demoModeLayoutId:I

.field public static dependency:I

.field public static deriveConstraintsFrom:I

.field public static deviceCategory:I

.field public static devicePaddingId:I

.field public static dialogCornerRadius:I

.field public static dialogIcon:I

.field public static dialogLayout:I

.field public static dialogMessage:I

.field public static dialogPreferenceStyle:I

.field public static dialogPreferredPadding:I

.field public static dialogTheme:I

.field public static dialogTitle:I

.field public static dimensionType:I

.field public static disableDependentsState:I

.field public static disableRecyclerViewItemAnimator:I

.field public static disabledIconAlpha:I

.field public static displayOptions:I

.field public static divider:I

.field public static dividerColor:I

.field public static dividerHorizontal:I

.field public static dividerInsetEnd:I

.field public static dividerInsetStart:I

.field public static dividerPadding:I

.field public static dividerThickness:I

.field public static dividerVertical:I

.field public static dragDirection:I

.field public static dragRangeMaxRatio:I

.field public static dragRangeMinRatio:I

.field public static dragScale:I

.field public static dragThreshold:I

.field public static drawPath:I

.field public static drawableBottomCompat:I

.field public static drawableEndCompat:I

.field public static drawableIconInsetSize:I

.field public static drawableIconSize:I

.field public static drawableLeftCompat:I

.field public static drawableRightCompat:I

.field public static drawableSize:I

.field public static drawableStartCompat:I

.field public static drawableTint:I

.field public static drawableTintMode:I

.field public static drawableTopCompat:I

.field public static drawerArrowStyle:I

.field public static drawerLayoutCornerSize:I

.field public static drawerLayoutStyle:I

.field public static dropDownBackgroundTint:I

.field public static dropDownListViewStyle:I

.field public static dropTargetHoverButtonColor:I

.field public static dropTargetHoverTextColor:I

.field public static dropdownListPreferredItemHeight:I

.field public static dropdownPreferenceStyle:I

.field public static duration:I

.field public static dynamicColorThemeOverlay:I

.field public static editTextBackground:I

.field public static editTextColor:I

.field public static editTextPreferenceStyle:I

.field public static editTextStyle:I

.field public static eduHalfSheetBGColor:I

.field public static elevation:I

.field public static elevationOverlayAccentColor:I

.field public static elevationOverlayColor:I

.field public static elevationOverlayEnabled:I

.field public static embeddingDividerColor:I

.field public static embeddingDividerType:I

.field public static embeddingDividerWidthDp:I

.field public static emojiCompatEnabled:I

.field public static enableCopying:I

.field public static enableEdgeToEdge:I

.field public static enabled:I

.field public static endIconCheckable:I

.field public static endIconContentDescription:I

.field public static endIconDrawable:I

.field public static endIconMinSize:I

.field public static endIconMode:I

.field public static endIconScaleType:I

.field public static endIconTint:I

.field public static endIconTintMode:I

.field public static endInsetScrimEnabled:I

.field public static endItemEndPadding:I

.field public static endItemStartPadding:I

.field public static enforceMaterialTheme:I

.field public static enforceTextAppearance:I

.field public static ensureMinTouchTargetSize:I

.field public static entries:I

.field public static entryValues:I

.field public static errorAccessibilityLabel:I

.field public static errorAccessibilityLiveRegion:I

.field public static errorContentDescription:I

.field public static errorEnabled:I

.field public static errorIconDrawable:I

.field public static errorIconTint:I

.field public static errorIconTintMode:I

.field public static errorShown:I

.field public static errorTextAppearance:I

.field public static errorTextColor:I

.field public static expandActivityOverflowButtonDrawable:I

.field public static expandToAvailableHeight:I

.field public static expanded:I

.field public static expandedHeight:I

.field public static expandedHintEnabled:I

.field public static expandedMarginHorizontal:I

.field public static expandedTitleGravity:I

.field public static expandedTitleMargin:I

.field public static expandedTitleMarginBottom:I

.field public static expandedTitleMarginEnd:I

.field public static expandedTitleMarginStart:I

.field public static expandedTitleMarginTop:I

.field public static expandedTitleTextAppearance:I

.field public static expandedTitleTextColor:I

.field public static expandedWidth:I

.field public static extendMotionSpec:I

.field public static extendStrategy:I

.field public static extendedFloatingActionButtonPrimaryStyle:I

.field public static extendedFloatingActionButtonSecondaryStyle:I

.field public static extendedFloatingActionButtonStyle:I

.field public static extendedFloatingActionButtonSurfaceStyle:I

.field public static extendedFloatingActionButtonTertiaryStyle:I

.field public static extraMultilineHeightEnabled:I

.field public static fabAlignmentMode:I

.field public static fabAlignmentModeEndMargin:I

.field public static fabAnchorMode:I

.field public static fabAnimationMode:I

.field public static fabCradleMargin:I

.field public static fabCradleRoundedCornerRadius:I

.field public static fabCradleVerticalOffset:I

.field public static fabCustomSize:I

.field public static fabSize:I

.field public static fastScrollEnabled:I

.field public static fastScrollHorizontalThumbDrawable:I

.field public static fastScrollHorizontalTrackDrawable:I

.field public static fastScrollVerticalThumbDrawable:I

.field public static fastScrollVerticalTrackDrawable:I

.field public static finishPrimaryWithPlaceholder:I

.field public static finishPrimaryWithSecondary:I

.field public static finishSecondaryWithPrimary:I

.field public static firstBaselineToTopHeight:I

.field public static fixedSize:I

.field public static floatingActionButtonLargePrimaryStyle:I

.field public static floatingActionButtonLargeSecondaryStyle:I

.field public static floatingActionButtonLargeStyle:I

.field public static floatingActionButtonLargeSurfaceStyle:I

.field public static floatingActionButtonLargeTertiaryStyle:I

.field public static floatingActionButtonPrimaryStyle:I

.field public static floatingActionButtonSecondaryStyle:I

.field public static floatingActionButtonSmallPrimaryStyle:I

.field public static floatingActionButtonSmallSecondaryStyle:I

.field public static floatingActionButtonSmallStyle:I

.field public static floatingActionButtonSmallSurfaceStyle:I

.field public static floatingActionButtonSmallTertiaryStyle:I

.field public static floatingActionButtonStyle:I

.field public static floatingActionButtonSurfaceStyle:I

.field public static floatingActionButtonTertiaryStyle:I

.field public static floatingToolbarStyle:I

.field public static flow_firstHorizontalBias:I

.field public static flow_firstHorizontalStyle:I

.field public static flow_firstVerticalBias:I

.field public static flow_firstVerticalStyle:I

.field public static flow_horizontalAlign:I

.field public static flow_horizontalBias:I

.field public static flow_horizontalGap:I

.field public static flow_horizontalStyle:I

.field public static flow_lastHorizontalBias:I

.field public static flow_lastHorizontalStyle:I

.field public static flow_lastVerticalBias:I

.field public static flow_lastVerticalStyle:I

.field public static flow_maxElementsWrap:I

.field public static flow_padding:I

.field public static flow_verticalAlign:I

.field public static flow_verticalBias:I

.field public static flow_verticalGap:I

.field public static flow_verticalStyle:I

.field public static flow_wrapMode:I

.field public static focusBorderColor:I

.field public static focusInnerOutlineColor:I

.field public static focusOutlineColor:I

.field public static folderBackgroundColor:I

.field public static folderBorderSpace:I

.field public static folderCellHeight:I

.field public static folderCellWidth:I

.field public static folderFooterHeight:I

.field public static folderHintTextColor:I

.field public static folderIconBorderColor:I

.field public static folderIconRadius:I

.field public static folderItems:I

.field public static folderPreviewColor:I

.field public static folderSpecsId:I

.field public static folderSpecsTwoPanelId:I

.field public static folderStyle:I

.field public static folderTextColor:I

.field public static folderTopPadding:I

.field public static font:I

.field public static fontFamily:I

.field public static fontProviderAuthority:I

.field public static fontProviderCerts:I

.field public static fontProviderFallbackQuery:I

.field public static fontProviderFetchStrategy:I

.field public static fontProviderFetchTimeout:I

.field public static fontProviderPackage:I

.field public static fontProviderQuery:I

.field public static fontProviderSystemFontFamily:I

.field public static fontStyle:I

.field public static fontVariationSettings:I

.field public static fontWeight:I

.field public static footerPreferenceStyle:I

.field public static forceApplySystemWindowInsetTop:I

.field public static forceDefaultNavigationOnClickListener:I

.field public static foregroundInsidePadding:I

.field public static fragment:I

.field public static framePosition:I

.field public static fullscreenFolderTextColor:I

.field public static gapBetweenBars:I

.field public static gestureInsetBottomIgnored:I

.field public static goIcon:I

.field public static gridBottomPadding:I

.field public static gridSubtitleSize:I

.field public static gridTextVerticalPadding:I

.field public static gridTitleSize:I

.field public static gridTopPadding:I

.field public static grid_columnWeights:I

.field public static grid_columns:I

.field public static grid_horizontalGaps:I

.field public static grid_orientation:I

.field public static grid_rowWeights:I

.field public static grid_rows:I

.field public static grid_skips:I

.field public static grid_spans:I

.field public static grid_useRtl:I

.field public static grid_validateInputs:I

.field public static grid_verticalGaps:I

.field public static guidelineUseRtl:I

.field public static haloColor:I

.field public static haloRadius:I

.field public static headerLayout:I

.field public static headerMarginBottom:I

.field public static headerSubtitleSize:I

.field public static headerTextVerticalPadding:I

.field public static headerTitleSize:I

.field public static height:I

.field public static helperText:I

.field public static helperTextEnabled:I

.field public static helperTextTextAppearance:I

.field public static helperTextTextColor:I

.field public static hideAnimationBehavior:I

.field public static hideHeaderRow:I

.field public static hideMotionSpec:I

.field public static hideNavigationIcon:I

.field public static hideOnContentScroll:I

.field public static hideOnScroll:I

.field public static hintAnimationEnabled:I

.field public static hintEnabled:I

.field public static hintMaxLines:I

.field public static hintTextAppearance:I

.field public static hintTextColor:I

.field public static homeAsUpIndicator:I

.field public static homeLayout:I

.field public static horizontalItemSpacing:I

.field public static horizontalItemTextAppearanceActive:I

.field public static horizontalItemTextAppearanceInactive:I

.field public static horizontalMargin:I

.field public static horizontalMarginLandscape:I

.field public static horizontalMarginTwoPanelLandscape:I

.field public static horizontalMarginTwoPanelPortrait:I

.field public static horizontalOffset:I

.field public static horizontalOffsetWithText:I

.field public static horizontalPadding:I

.field public static hotseatBarBottomSpace:I

.field public static hotseatBarBottomSpaceLandscape:I

.field public static hotseatBarBottomSpaceTwoPanelLandscape:I

.field public static hotseatBarBottomSpaceTwoPanelPortrait:I

.field public static hotseatBorderSpace:I

.field public static hotseatBorderSpaceLandscape:I

.field public static hotseatQsbSpace:I

.field public static hotseatQsbSpaceLandscape:I

.field public static hotseatQsbSpaceTwoPanelLandscape:I

.field public static hotseatQsbSpaceTwoPanelPortrait:I

.field public static hotseatSpecsId:I

.field public static hotseatSpecsTwoPanelId:I

.field public static hoverBorderColor:I

.field public static hoveredFocusedTranslationZ:I

.field public static icon:I

.field public static iconDisplay:I

.field public static iconDrawablePadding:I

.field public static iconEndPadding:I

.field public static iconGravity:I

.field public static iconImageSize:I

.field public static iconLabelHorizontalSpacing:I

.field public static iconOnlyShortcutColor:I

.field public static iconPadding:I

.field public static iconPaddings:I

.field public static iconSize:I

.field public static iconSizeLandscape:I

.field public static iconSizeOverride:I

.field public static iconSizeTwoPanelLandscape:I

.field public static iconSizeTwoPanelPortrait:I

.field public static iconSpaceReserved:I

.field public static iconStartPadding:I

.field public static iconTextSize:I

.field public static iconTextSizeLandscape:I

.field public static iconTextSizeTwoPanelLandscape:I

.field public static iconTextSizeTwoPanelPortrait:I

.field public static iconTint:I

.field public static iconTintMode:I

.field public static iconifiedByDefault:I

.field public static ifTagNotSet:I

.field public static ifTagSet:I

.field public static imageButtonStyle:I

.field public static imageCornerRadius:I

.field public static imagePanX:I

.field public static imagePanY:I

.field public static imageRotate:I

.field public static imageSize:I

.field public static imageZoom:I

.field public static indeterminateAnimationType:I

.field public static indeterminateAnimationTypeCircular:I

.field public static indeterminateAnimatorDurationScale:I

.field public static indeterminateProgressStyle:I

.field public static indeterminateTrackVisible:I

.field public static indicatorColor:I

.field public static indicatorDirectionCircular:I

.field public static indicatorDirectionLinear:I

.field public static indicatorInset:I

.field public static indicatorSize:I

.field public static indicatorTrackGapSize:I

.field public static initialActivityCount:I

.field public static initialExpandedChildrenCount:I

.field public static inlineNavButtonsEndSpacing:I

.field public static inlineQsb:I

.field public static innerCornerSize:I

.field public static insetForeground:I

.field public static isChildClippingToResizeDividerEnabled:I

.field public static isCollapsable:I

.field public static isDraggingToFullscreenAllowed:I

.field public static isFolderDarkText:I

.field public static isLightTheme:I

.field public static isMainColorDark:I

.field public static isMaterial3DynamicColorApplied:I

.field public static isMaterial3Theme:I

.field public static isMaterialTheme:I

.field public static isOverlappingEnabled:I

.field public static isPreferenceVisible:I

.field public static isScalable:I

.field public static isUserResizingEnabled:I

.field public static isWorkspaceDarkText:I

.field public static itemActiveIndicatorStyle:I

.field public static itemBackground:I

.field public static itemFillColor:I

.field public static itemGravity:I

.field public static itemHorizontalPadding:I

.field public static itemHorizontalTranslationEnabled:I

.field public static itemIconGravity:I

.field public static itemIconPadding:I

.field public static itemIconSize:I

.field public static itemIconTint:I

.field public static itemMaxLines:I

.field public static itemMinHeight:I

.field public static itemPadding:I

.field public static itemPaddingBottom:I

.field public static itemPaddingTop:I

.field public static itemRippleColor:I

.field public static itemShapeAppearance:I

.field public static itemShapeAppearanceOverlay:I

.field public static itemShapeFillColor:I

.field public static itemShapeInsetBottom:I

.field public static itemShapeInsetEnd:I

.field public static itemShapeInsetStart:I

.field public static itemShapeInsetTop:I

.field public static itemSpacing:I

.field public static itemStrokeColor:I

.field public static itemStrokeWidth:I

.field public static itemTextAppearance:I

.field public static itemTextAppearanceActive:I

.field public static itemTextAppearanceActiveBoldEnabled:I

.field public static itemTextAppearanceInactive:I

.field public static itemTextColor:I

.field public static itemVerticalPadding:I

.field public static key:I

.field public static keyPositionType:I

.field public static keyShadowAlpha:I

.field public static keyShadowBlur:I

.field public static keyShadowColor:I

.field public static keyShadowOffsetX:I

.field public static keyShadowOffsetY:I

.field public static keyboardIcon:I

.field public static keylines:I

.field public static lStar:I

.field public static labelBehavior:I

.field public static labelStyle:I

.field public static labelTextAppearance:I

.field public static labelVisibilityMode:I

.field public static largeFontVerticalOffsetAdjustment:I

.field public static lastBaselineToBottomHeight:I

.field public static lastItemDecorated:I

.field public static layout:I

.field public static layoutDescription:I

.field public static layoutDuringTransition:I

.field public static layoutHorizontal:I

.field public static layoutManager:I

.field public static layout_anchor:I

.field public static layout_anchorGravity:I

.field public static layout_behavior:I

.field public static layout_collapseMode:I

.field public static layout_collapseParallaxMultiplier:I

.field public static layout_constrainedHeight:I

.field public static layout_constrainedWidth:I

.field public static layout_constraintBaseline_creator:I

.field public static layout_constraintBaseline_toBaselineOf:I

.field public static layout_constraintBaseline_toBottomOf:I

.field public static layout_constraintBaseline_toTopOf:I

.field public static layout_constraintBottom_creator:I

.field public static layout_constraintBottom_toBottomOf:I

.field public static layout_constraintBottom_toTopOf:I

.field public static layout_constraintCircle:I

.field public static layout_constraintCircleAngle:I

.field public static layout_constraintCircleRadius:I

.field public static layout_constraintDimensionRatio:I

.field public static layout_constraintEnd_toEndOf:I

.field public static layout_constraintEnd_toStartOf:I

.field public static layout_constraintGuide_begin:I

.field public static layout_constraintGuide_end:I

.field public static layout_constraintGuide_percent:I

.field public static layout_constraintHeight:I

.field public static layout_constraintHeight_default:I

.field public static layout_constraintHeight_max:I

.field public static layout_constraintHeight_min:I

.field public static layout_constraintHeight_percent:I

.field public static layout_constraintHorizontal_bias:I

.field public static layout_constraintHorizontal_chainStyle:I

.field public static layout_constraintHorizontal_weight:I

.field public static layout_constraintLeft_creator:I

.field public static layout_constraintLeft_toLeftOf:I

.field public static layout_constraintLeft_toRightOf:I

.field public static layout_constraintRight_creator:I

.field public static layout_constraintRight_toLeftOf:I

.field public static layout_constraintRight_toRightOf:I

.field public static layout_constraintStart_toEndOf:I

.field public static layout_constraintStart_toStartOf:I

.field public static layout_constraintTag:I

.field public static layout_constraintTop_creator:I

.field public static layout_constraintTop_toBottomOf:I

.field public static layout_constraintTop_toTopOf:I

.field public static layout_constraintVertical_bias:I

.field public static layout_constraintVertical_chainStyle:I

.field public static layout_constraintVertical_weight:I

.field public static layout_constraintWidth:I

.field public static layout_constraintWidth_default:I

.field public static layout_constraintWidth_max:I

.field public static layout_constraintWidth_min:I

.field public static layout_constraintWidth_percent:I

.field public static layout_dodgeInsetEdges:I

.field public static layout_editor_absoluteX:I

.field public static layout_editor_absoluteY:I

.field public static layout_goneMarginBaseline:I

.field public static layout_goneMarginBottom:I

.field public static layout_goneMarginEnd:I

.field public static layout_goneMarginLeft:I

.field public static layout_goneMarginRight:I

.field public static layout_goneMarginStart:I

.field public static layout_goneMarginTop:I

.field public static layout_ignoreInsets:I

.field public static layout_insetEdge:I

.field public static layout_keyline:I

.field public static layout_marginBaseline:I

.field public static layout_optimizationLevel:I

.field public static layout_scrollEffect:I

.field public static layout_scrollFlags:I

.field public static layout_scrollInterpolator:I

.field public static layout_sticky:I

.field public static layout_wrapBehaviorInParent:I

.field public static liftOnScroll:I

.field public static liftOnScrollColor:I

.field public static liftOnScrollTargetViewId:I

.field public static limitBoundsTo:I

.field public static lineHeight:I

.field public static lineSpacing:I

.field public static linearProgressIndicatorStyle:I

.field public static listChoiceBackgroundIndicator:I

.field public static listChoiceIndicatorMultipleAnimated:I

.field public static listChoiceIndicatorSingleAnimated:I

.field public static listDividerAlertDialog:I

.field public static listItemLayout:I

.field public static listLayout:I

.field public static listMenuViewStyle:I

.field public static listPopupWindowStyle:I

.field public static listPreferredItemHeight:I

.field public static listPreferredItemHeightLarge:I

.field public static listPreferredItemHeightSmall:I

.field public static listPreferredItemPaddingEnd:I

.field public static listPreferredItemPaddingLeft:I

.field public static listPreferredItemPaddingRight:I

.field public static listPreferredItemPaddingStart:I

.field public static loadingIconColor:I

.field public static loadingIndicatorStyle:I

.field public static logIdOff:I

.field public static logIdOn:I

.field public static logo:I

.field public static logoAdjustViewBounds:I

.field public static logoDescription:I

.field public static logoScaleType:I

.field public static lottieAnimationViewStyle:I

.field public static lottie_asyncUpdates:I

.field public static lottie_autoPlay:I

.field public static lottie_cacheComposition:I

.field public static lottie_clipTextToBoundingBox:I

.field public static lottie_clipToCompositionBounds:I

.field public static lottie_colorFilter:I

.field public static lottie_defaultFontFileExtension:I

.field public static lottie_enableMergePathsForKitKatAndAbove:I

.field public static lottie_fallbackRes:I

.field public static lottie_fileName:I

.field public static lottie_ignoreDisabledSystemAnimations:I

.field public static lottie_imageAssetsFolder:I

.field public static lottie_loop:I

.field public static lottie_progress:I

.field public static lottie_rawRes:I

.field public static lottie_renderMode:I

.field public static lottie_repeatCount:I

.field public static lottie_repeatMode:I

.field public static lottie_scale:I

.field public static lottie_speed:I

.field public static lottie_url:I

.field public static lottie_useCompositionFrameRate:I

.field public static marginHorizontal:I

.field public static marginLeftSystemWindowInsets:I

.field public static marginRightSystemWindowInsets:I

.field public static marginTopSystemWindowInsets:I

.field public static matchTextInsetWithQuery:I

.field public static matchWorkspace:I

.field public static materialAlertDialogBodyTextStyle:I

.field public static materialAlertDialogButtonSpacerVisibility:I

.field public static materialAlertDialogTheme:I

.field public static materialAlertDialogTitleIconStyle:I

.field public static materialAlertDialogTitlePanelStyle:I

.field public static materialAlertDialogTitleTextStyle:I

.field public static materialButtonElevatedStyle:I

.field public static materialButtonGroupStyle:I

.field public static materialButtonOutlinedStyle:I

.field public static materialButtonStyle:I

.field public static materialButtonToggleGroupStyle:I

.field public static materialButtonTonalStyle:I

.field public static materialCalendarDay:I

.field public static materialCalendarDayOfWeekLabel:I

.field public static materialCalendarFullscreenTheme:I

.field public static materialCalendarHeaderCancelButton:I

.field public static materialCalendarHeaderConfirmButton:I

.field public static materialCalendarHeaderDivider:I

.field public static materialCalendarHeaderLayout:I

.field public static materialCalendarHeaderSelection:I

.field public static materialCalendarHeaderTitle:I

.field public static materialCalendarHeaderToggleButton:I

.field public static materialCalendarMonth:I

.field public static materialCalendarMonthNavigationButton:I

.field public static materialCalendarStyle:I

.field public static materialCalendarTheme:I

.field public static materialCalendarYearNavigationButton:I

.field public static materialCardViewElevatedStyle:I

.field public static materialCardViewFilledStyle:I

.field public static materialCardViewOutlinedStyle:I

.field public static materialCardViewStyle:I

.field public static materialCircleRadius:I

.field public static materialClockStyle:I

.field public static materialColorErrorContainer:I

.field public static materialColorOnBackground:I

.field public static materialColorOnError:I

.field public static materialColorOnErrorContainer:I

.field public static materialColorOnPrimary:I

.field public static materialColorOnPrimaryContainer:I

.field public static materialColorOnPrimaryFixed:I

.field public static materialColorOnPrimaryFixedVariant:I

.field public static materialColorOnSecondary:I

.field public static materialColorOnSecondaryContainer:I

.field public static materialColorOnSecondaryFixed:I

.field public static materialColorOnSecondaryFixedVariant:I

.field public static materialColorOnSurface:I

.field public static materialColorOnSurfaceInverse:I

.field public static materialColorOnSurfaceVariant:I

.field public static materialColorOnTertiary:I

.field public static materialColorOnTertiaryContainer:I

.field public static materialColorOnTertiaryFixed:I

.field public static materialColorOnTertiaryFixedVariant:I

.field public static materialColorOutline:I

.field public static materialColorOutlineVariant:I

.field public static materialColorPrimary:I

.field public static materialColorPrimaryContainer:I

.field public static materialColorPrimaryFixed:I

.field public static materialColorPrimaryFixedDim:I

.field public static materialColorPrimaryInverse:I

.field public static materialColorSecondary:I

.field public static materialColorSecondaryContainer:I

.field public static materialColorSecondaryFixed:I

.field public static materialColorSecondaryFixedDim:I

.field public static materialColorSurface:I

.field public static materialColorSurfaceBright:I

.field public static materialColorSurfaceContainer:I

.field public static materialColorSurfaceContainerHigh:I

.field public static materialColorSurfaceContainerHighest:I

.field public static materialColorSurfaceContainerLow:I

.field public static materialColorSurfaceContainerLowest:I

.field public static materialColorSurfaceDim:I

.field public static materialColorSurfaceInverse:I

.field public static materialColorSurfaceVariant:I

.field public static materialColorTertiary:I

.field public static materialColorTertiaryContainer:I

.field public static materialColorTertiaryFixed:I

.field public static materialColorTertiaryFixedDim:I

.field public static materialDisplayDividerStyle:I

.field public static materialDividerHeavyStyle:I

.field public static materialDividerStyle:I

.field public static materialIconButtonFilledStyle:I

.field public static materialIconButtonFilledTonalStyle:I

.field public static materialIconButtonOutlinedStyle:I

.field public static materialIconButtonStyle:I

.field public static materialSearchBarStyle:I

.field public static materialSearchViewPrefixStyle:I

.field public static materialSearchViewStyle:I

.field public static materialSearchViewToolbarHeight:I

.field public static materialSearchViewToolbarStyle:I

.field public static materialSizeOverlay:I

.field public static materialSplitButtonIconFilledStyle:I

.field public static materialSplitButtonIconFilledTonalStyle:I

.field public static materialSplitButtonStyle:I

.field public static materialSwitchStyle:I

.field public static materialThemeOverlay:I

.field public static materialTimePickerStyle:I

.field public static materialTimePickerTheme:I

.field public static materialTimePickerTitleStyle:I

.field public static maxAcceleration:I

.field public static maxActionInlineWidth:I

.field public static maxAspectRatio:I

.field public static maxAvailableSize:I

.field public static maxButtonHeight:I

.field public static maxCharacterCount:I

.field public static maxEmptySpace:I

.field public static maxHeight:I

.field public static maxImageSize:I

.field public static maxLines:I

.field public static maxNumber:I

.field public static maxSize:I

.field public static maxVelocity:I

.field public static maxWidth:I

.field public static measureBottomPaddingFromLabelBaseline:I

.field public static measureWithLargestChild:I

.field public static menu:I

.field public static menuAlignmentMode:I

.field public static menuGravity:I

.field public static methodName:I

.field public static min:I

.field public static minCellHeight:I

.field public static minCellHeightLandscape:I

.field public static minCellHeightTwoPanelLandscape:I

.field public static minCellHeightTwoPanelPortrait:I

.field public static minCellWidth:I

.field public static minCellWidthLandscape:I

.field public static minCellWidthTwoPanelLandscape:I

.field public static minCellWidthTwoPanelPortrait:I

.field public static minHeight:I

.field public static minHeightDps:I

.field public static minHideDelay:I

.field public static minSeparation:I

.field public static minTouchTargetSize:I

.field public static minWidth:I

.field public static minWidthDps:I

.field public static mock_diagonalsColor:I

.field public static mock_label:I

.field public static mock_labelBackgroundColor:I

.field public static mock_labelColor:I

.field public static mock_showDiagonals:I

.field public static mock_showLabel:I

.field public static motionDebug:I

.field public static motionDurationExtraLong1:I

.field public static motionDurationExtraLong2:I

.field public static motionDurationExtraLong3:I

.field public static motionDurationExtraLong4:I

.field public static motionDurationLong1:I

.field public static motionDurationLong2:I

.field public static motionDurationLong3:I

.field public static motionDurationLong4:I

.field public static motionDurationMedium1:I

.field public static motionDurationMedium2:I

.field public static motionDurationMedium3:I

.field public static motionDurationMedium4:I

.field public static motionDurationShort1:I

.field public static motionDurationShort2:I

.field public static motionDurationShort3:I

.field public static motionDurationShort4:I

.field public static motionEasingAccelerated:I

.field public static motionEasingDecelerated:I

.field public static motionEasingEmphasized:I

.field public static motionEasingEmphasizedAccelerateInterpolator:I

.field public static motionEasingEmphasizedDecelerateInterpolator:I

.field public static motionEasingEmphasizedInterpolator:I

.field public static motionEasingLinear:I

.field public static motionEasingLinearInterpolator:I

.field public static motionEasingStandard:I

.field public static motionEasingStandardAccelerateInterpolator:I

.field public static motionEasingStandardDecelerateInterpolator:I

.field public static motionEasingStandardInterpolator:I

.field public static motionEffect_alpha:I

.field public static motionEffect_end:I

.field public static motionEffect_move:I

.field public static motionEffect_start:I

.field public static motionEffect_strict:I

.field public static motionEffect_translationX:I

.field public static motionEffect_translationY:I

.field public static motionEffect_viewTransition:I

.field public static motionInterpolator:I

.field public static motionPath:I

.field public static motionPathRotate:I

.field public static motionProgress:I

.field public static motionStagger:I

.field public static motionTarget:I

.field public static motion_postLayoutCollision:I

.field public static motion_triggerOnCollision:I

.field public static moveWhenScrollAtTop:I

.field public static multiChoiceItemLayout:I

.field public static name:I

.field public static navigationContentDescription:I

.field public static navigationIcon:I

.field public static navigationIconTint:I

.field public static navigationMode:I

.field public static navigationRailStyle:I

.field public static navigationViewStyle:I

.field public static negativeButtonText:I

.field public static nestedScrollFlags:I

.field public static nestedScrollViewStyle:I

.field public static nestedScrollable:I

.field public static notificationDotColor:I

.field public static numAllAppsColumns:I

.field public static numAllAppsRowsForCellHeightCalculation:I

.field public static numColumns:I

.field public static numExtendedAllAppsColumns:I

.field public static numExtendedHotseatIcons:I

.field public static numFolderColumns:I

.field public static numFolderColumnsLandscape:I

.field public static numFolderColumnsTwoPanelLandscape:I

.field public static numFolderColumnsTwoPanelPortrait:I

.field public static numFolderRows:I

.field public static numFolderRowsLandscape:I

.field public static numFolderRowsTwoPanelLandscape:I

.field public static numFolderRowsTwoPanelPortrait:I

.field public static numHotseatIcons:I

.field public static numRows:I

.field public static numSearchContainerColumns:I

.field public static numShrunkenHotseatIcons:I

.field public static number:I

.field public static numericModifiers:I

.field public static ofAvailableSpace:I

.field public static ofRemainderSpace:I

.field public static offsetAlignmentMode:I

.field public static offsetX:I

.field public static offsetY:I

.field public static onCross:I

.field public static onHide:I

.field public static onNegativeCross:I

.field public static onPositiveCross:I

.field public static onShow:I

.field public static onStateTransition:I

.field public static onSurfaceBack:I

.field public static onSurfaceHome:I

.field public static onSurfaceOverview:I

.field public static onTouchUp:I

.field public static order:I

.field public static orderingFromXml:I

.field public static overlapAnchor:I

.field public static overlay:I

.field public static overviewScrimColor:I

.field public static packageName:I

.field public static paddingBottomNoButtons:I

.field public static paddingBottomSystemWindowInsets:I

.field public static paddingEnd:I

.field public static paddingLeftSystemWindowInsets:I

.field public static paddingRightSystemWindowInsets:I

.field public static paddingStart:I

.field public static paddingStartSystemWindowInsets:I

.field public static paddingTopNoTitle:I

.field public static paddingTopSystemWindowInsets:I

.field public static pageIndicator:I

.field public static pageIndicatorDotColor:I

.field public static panelBackground:I

.field public static panelMenuListTheme:I

.field public static panelMenuListWidth:I

.field public static passwordToggleContentDescription:I

.field public static passwordToggleDrawable:I

.field public static passwordToggleEnabled:I

.field public static passwordToggleTint:I

.field public static passwordToggleTintMode:I

.field public static pathMotionArc:I

.field public static path_percent:I

.field public static percentHeight:I

.field public static percentWidth:I

.field public static percentX:I

.field public static percentY:I

.field public static perpendicularPath_percent:I

.field public static persistent:I

.field public static pivotAnchor:I

.field public static placeholderActivityName:I

.field public static placeholderBg:I

.field public static placeholderText:I

.field public static placeholderTextAppearance:I

.field public static placeholderTextColor:I

.field public static placeholder_emptyVisibility:I

.field public static polarRelativeTo:I

.field public static popupColorBackground:I

.field public static popupColorPrimary:I

.field public static popupColorSecondary:I

.field public static popupColorTertiary:I

.field public static popupIconTint:I

.field public static popupMenuBackground:I

.field public static popupMenuStyle:I

.field public static popupNotificationDotColor:I

.field public static popupShadeFirst:I

.field public static popupShadeSecond:I

.field public static popupShadeThird:I

.field public static popupTextColor:I

.field public static popupTheme:I

.field public static popupWindowStyle:I

.field public static positiveButtonText:I

.field public static preferenceCategoryStyle:I

.field public static preferenceCategoryTitleTextAppearance:I

.field public static preferenceCategoryTitleTextColor:I

.field public static preferenceFragmentCompatStyle:I

.field public static preferenceFragmentListStyle:I

.field public static preferenceFragmentStyle:I

.field public static preferenceInformationStyle:I

.field public static preferenceScreenStyle:I

.field public static preferenceStyle:I

.field public static preferenceTheme:I

.field public static prefixText:I

.field public static prefixTextAppearance:I

.field public static prefixTextColor:I

.field public static preloadIconAccentColor:I

.field public static preloadIconBackgroundColor:I

.field public static preserveIconSpacing:I

.field public static pressedTranslationZ:I

.field public static primaryActivityName:I

.field public static progressBarEndPadding:I

.field public static progressBarInlineWidth:I

.field public static progressBarPadding:I

.field public static progressBarStartPadding:I

.field public static progressBarStyle:I

.field public static provider:I

.field public static quantizeMotionInterpolator:I

.field public static quantizeMotionPhase:I

.field public static quantizeMotionSteps:I

.field public static queryBackground:I

.field public static queryHint:I

.field public static queryPatterns:I

.field public static radioButtonStyle:I

.field public static rangeFillColor:I

.field public static ratingBarStyle:I

.field public static ratingBarStyleIndicator:I

.field public static ratingBarStyleSmall:I

.field public static reactiveGuide_animateChange:I

.field public static reactiveGuide_applyToAllConstraintSets:I

.field public static reactiveGuide_applyToConstraintSet:I

.field public static reactiveGuide_valueId:I

.field public static recyclerViewStyle:I

.field public static region_heightLessThan:I

.field public static region_heightMoreThan:I

.field public static region_widthLessThan:I

.field public static region_widthMoreThan:I

.field public static removeEmbeddedFabElevation:I

.field public static removeTextDescent:I

.field public static reverseLayout:I

.field public static rippleColor:I

.field public static rotationCenterId:I

.field public static round:I

.field public static roundPercent:I

.field public static rowInlineRangeHeight:I

.field public static rowMaxHeight:I

.field public static rowMinHeight:I

.field public static rowRangeHeight:I

.field public static rowRangeSingleTextHeight:I

.field public static rowStyle:I

.field public static saturation:I

.field public static scaleFromTextSize:I

.field public static screen:I

.field public static scrimAnimationDuration:I

.field public static scrimBackground:I

.field public static scrimVisibleHeightTrigger:I

.field public static scrollingEnabled:I

.field public static searchBarHintText:I

.field public static searchBarText:I

.field public static searchContainer:I

.field public static searchHintIcon:I

.field public static searchIcon:I

.field public static searchPrefixText:I

.field public static searchViewStyle:I

.field public static secondaryActivityAction:I

.field public static secondaryActivityName:I

.field public static secondaryBack:I

.field public static secondaryHome:I

.field public static secondaryOverview:I

.field public static sectionDrawable:I

.field public static sectionTitle:I

.field public static seekBarIncrement:I

.field public static seekBarInlineWidth:I

.field public static seekBarPreferenceStyle:I

.field public static seekBarStyle:I

.field public static selectable:I

.field public static selectableItemBackground:I

.field public static selectableItemBackgroundBorderless:I

.field public static selectionRequired:I

.field public static selectorSize:I

.field public static setsTag:I

.field public static shadowColor:I

.field public static shadowCornerRadius:I

.field public static shadowRadius:I

.field public static shape:I

.field public static shapeAppearance:I

.field public static shapeAppearanceCornerExtraLarge:I

.field public static shapeAppearanceCornerExtraSmall:I

.field public static shapeAppearanceCornerLarge:I

.field public static shapeAppearanceCornerMedium:I

.field public static shapeAppearanceCornerSmall:I

.field public static shapeAppearanceLargeComponent:I

.field public static shapeAppearanceMediumComponent:I

.field public static shapeAppearanceOverlay:I

.field public static shapeAppearanceSmallComponent:I

.field public static shapeCornerFamily:I

.field public static shortcutMatchRequired:I

.field public static shouldDisableView:I

.field public static shouldRemoveExpandedCorners:I

.field public static showAnimationBehavior:I

.field public static showAsAction:I

.field public static showDelay:I

.field public static showDividers:I

.field public static showInBottom:I

.field public static showInLeft:I

.field public static showInRight:I

.field public static showInTop:I

.field public static showMarker:I

.field public static showMotionSpec:I

.field public static showPaths:I

.field public static showSeekBarValue:I

.field public static showText:I

.field public static showTitle:I

.field public static shrinkMotionSpec:I

.field public static sideSheetDialogTheme:I

.field public static sideSheetModalStyle:I

.field public static simpleItemLayout:I

.field public static simpleItemSelectedColor:I

.field public static simpleItemSelectedRippleColor:I

.field public static simpleItems:I

.field public static singleChoiceItemLayout:I

.field public static singleLine:I

.field public static singleLineTitle:I

.field public static singleSelection:I

.field public static sizePercent:I

.field public static sliceViewStyle:I

.field public static sliderColor:I

.field public static sliderRadius:I

.field public static sliderStyle:I

.field public static snackbarButtonStyle:I

.field public static snackbarStyle:I

.field public static snackbarTextViewStyle:I

.field public static spanCount:I

.field public static spanX:I

.field public static spanY:I

.field public static spinBars:I

.field public static spinnerDropDownItemStyle:I

.field public static spinnerStyle:I

.field public static splitChangeAnimation:I

.field public static splitCloseAnimation:I

.field public static splitLayoutDirection:I

.field public static splitMaxAspectRatioInLandscape:I

.field public static splitMaxAspectRatioInPortrait:I

.field public static splitMinHeightDp:I

.field public static splitMinSmallestWidthDp:I

.field public static splitMinWidthDp:I

.field public static splitOpenAnimation:I

.field public static splitRatio:I

.field public static splitTrack:I

.field public static springBoundary:I

.field public static springDamping:I

.field public static springMass:I

.field public static springStiffness:I

.field public static springStopThreshold:I

.field public static srcCompat:I

.field public static stackFromEnd:I

.field public static staggered:I

.field public static startAlignTaskbar:I

.field public static startAlignTaskbarLandscape:I

.field public static startAlignTaskbarTwoPanelLandscape:I

.field public static startAlignTaskbarTwoPanelPortrait:I

.field public static startIconCheckable:I

.field public static startIconContentDescription:I

.field public static startIconDrawable:I

.field public static startIconMinSize:I

.field public static startIconScaleType:I

.field public static startIconTint:I

.field public static startIconTintMode:I

.field public static startInsetScrimEnabled:I

.field public static stateLabels:I

.field public static state_above_anchor:I

.field public static state_collapsed:I

.field public static state_collapsible:I

.field public static state_dragged:I

.field public static state_error:I

.field public static state_indeterminate:I

.field public static state_liftable:I

.field public static state_lifted:I

.field public static state_with_icon:I

.field public static statusBarBackground:I

.field public static statusBarForeground:I

.field public static statusBarScrim:I

.field public static stickyPlaceholder:I

.field public static strokeColor:I

.field public static strokeWidth:I

.field public static subContentEndPadding:I

.field public static subContentStartPadding:I

.field public static subMenuArrow:I

.field public static subheaderColor:I

.field public static subheaderInsetEnd:I

.field public static subheaderInsetStart:I

.field public static subheaderTextAppearance:I

.field public static submitBackground:I

.field public static subtitle:I

.field public static subtitleCentered:I

.field public static subtitleColor:I

.field public static subtitleSize:I

.field public static subtitleTextAppearance:I

.field public static subtitleTextColor:I

.field public static subtitleTextStyle:I

.field public static suffixText:I

.field public static suffixTextAppearance:I

.field public static suffixTextColor:I

.field public static suggestionRowLayout:I

.field public static summary:I

.field public static summaryOff:I

.field public static summaryOn:I

.field public static surfaceBack:I

.field public static surfaceContainer:I

.field public static surfaceHome:I

.field public static surfaceOverview:I

.field public static switchMinWidth:I

.field public static switchPadding:I

.field public static switchPreferenceCompatStyle:I

.field public static switchPreferenceStyle:I

.field public static switchStyle:I

.field public static switchTextAppearance:I

.field public static switchTextOff:I

.field public static switchTextOn:I

.field public static systemShortcut:I

.field public static tabBackground:I

.field public static tabContentStart:I

.field public static tabGravity:I

.field public static tabIconTint:I

.field public static tabIconTintMode:I

.field public static tabIndicator:I

.field public static tabIndicatorAnimationDuration:I

.field public static tabIndicatorAnimationMode:I

.field public static tabIndicatorColor:I

.field public static tabIndicatorFullWidth:I

.field public static tabIndicatorGravity:I

.field public static tabIndicatorHeight:I

.field public static tabInlineLabel:I

.field public static tabMaxWidth:I

.field public static tabMinWidth:I

.field public static tabMode:I

.field public static tabPadding:I

.field public static tabPaddingBottom:I

.field public static tabPaddingEnd:I

.field public static tabPaddingStart:I

.field public static tabPaddingTop:I

.field public static tabRippleColor:I

.field public static tabSecondaryStyle:I

.field public static tabSelectedTextAppearance:I

.field public static tabSelectedTextColor:I

.field public static tabStyle:I

.field public static tabTextAppearance:I

.field public static tabTextColor:I

.field public static tabUnboundedRipple:I

.field public static tag:I

.field public static targetId:I

.field public static telltales_tailColor:I

.field public static telltales_tailScale:I

.field public static telltales_velocityMode:I

.field public static textActionPadding:I

.field public static textAllCaps:I

.field public static textAppearanceBody1:I

.field public static textAppearanceBody2:I

.field public static textAppearanceBodyLarge:I

.field public static textAppearanceBodyLargeEmphasized:I

.field public static textAppearanceBodyMedium:I

.field public static textAppearanceBodyMediumEmphasized:I

.field public static textAppearanceBodySmall:I

.field public static textAppearanceBodySmallEmphasized:I

.field public static textAppearanceButton:I

.field public static textAppearanceCaption:I

.field public static textAppearanceDisplayLarge:I

.field public static textAppearanceDisplayLargeEmphasized:I

.field public static textAppearanceDisplayMedium:I

.field public static textAppearanceDisplayMediumEmphasized:I

.field public static textAppearanceDisplaySmall:I

.field public static textAppearanceDisplaySmallEmphasized:I

.field public static textAppearanceHeadline1:I

.field public static textAppearanceHeadline2:I

.field public static textAppearanceHeadline3:I

.field public static textAppearanceHeadline4:I

.field public static textAppearanceHeadline5:I

.field public static textAppearanceHeadline6:I

.field public static textAppearanceHeadlineLarge:I

.field public static textAppearanceHeadlineLargeEmphasized:I

.field public static textAppearanceHeadlineMedium:I

.field public static textAppearanceHeadlineMediumEmphasized:I

.field public static textAppearanceHeadlineSmall:I

.field public static textAppearanceHeadlineSmallEmphasized:I

.field public static textAppearanceLabelLarge:I

.field public static textAppearanceLabelLargeEmphasized:I

.field public static textAppearanceLabelMedium:I

.field public static textAppearanceLabelMediumEmphasized:I

.field public static textAppearanceLabelSmall:I

.field public static textAppearanceLabelSmallEmphasized:I

.field public static textAppearanceLargePopupMenu:I

.field public static textAppearanceLineHeightEnabled:I

.field public static textAppearanceListItem:I

.field public static textAppearanceListItemSecondary:I

.field public static textAppearanceListItemSmall:I

.field public static textAppearanceOverline:I

.field public static textAppearancePopupMenuHeader:I

.field public static textAppearanceSearchResultSubtitle:I

.field public static textAppearanceSearchResultTitle:I

.field public static textAppearanceSmallPopupMenu:I

.field public static textAppearanceSubtitle1:I

.field public static textAppearanceSubtitle2:I

.field public static textAppearanceTitleLarge:I

.field public static textAppearanceTitleLargeEmphasized:I

.field public static textAppearanceTitleMedium:I

.field public static textAppearanceTitleMediumEmphasized:I

.field public static textAppearanceTitleSmall:I

.field public static textAppearanceTitleSmallEmphasized:I

.field public static textBackground:I

.field public static textBackgroundPanX:I

.field public static textBackgroundPanY:I

.field public static textBackgroundRotate:I

.field public static textBackgroundZoom:I

.field public static textColorAlertDialogListItem:I

.field public static textColorSearchUrl:I

.field public static textDescentExtraPadding:I

.field public static textEndPadding:I

.field public static textFillColor:I

.field public static textInputFilledDenseStyle:I

.field public static textInputFilledExposedDropdownMenuStyle:I

.field public static textInputFilledStyle:I

.field public static textInputLayoutFocusedRectEnabled:I

.field public static textInputOutlinedDenseStyle:I

.field public static textInputOutlinedExposedDropdownMenuStyle:I

.field public static textInputOutlinedStyle:I

.field public static textInputStyle:I

.field public static textLocale:I

.field public static textOutlineColor:I

.field public static textOutlineThickness:I

.field public static textPanX:I

.field public static textPanY:I

.field public static textStartPadding:I

.field public static textVerticalPadding:I

.field public static textureBlurFactor:I

.field public static textureEffect:I

.field public static textureHeight:I

.field public static textureWidth:I

.field public static theme:I

.field public static thickness:I

.field public static thumbColor:I

.field public static thumbElevation:I

.field public static thumbHeight:I

.field public static thumbIcon:I

.field public static thumbIconSize:I

.field public static thumbIconTint:I

.field public static thumbIconTintMode:I

.field public static thumbRadius:I

.field public static thumbStrokeColor:I

.field public static thumbStrokeWidth:I

.field public static thumbTextPadding:I

.field public static thumbTint:I

.field public static thumbTintMode:I

.field public static thumbTrackGapSize:I

.field public static thumbWidth:I

.field public static tickColor:I

.field public static tickColorActive:I

.field public static tickColorInactive:I

.field public static tickMark:I

.field public static tickMarkTint:I

.field public static tickMarkTintMode:I

.field public static tickRadiusActive:I

.field public static tickRadiusInactive:I

.field public static tickVisible:I

.field public static tint:I

.field public static tintColor:I

.field public static tintMode:I

.field public static tintNavigationIcon:I

.field public static title:I

.field public static titleCentered:I

.field public static titleCollapseMode:I

.field public static titleColor:I

.field public static titleEnabled:I

.field public static titleEndPadding:I

.field public static titleItemEndPadding:I

.field public static titleItemStartPadding:I

.field public static titleMargin:I

.field public static titleMarginBottom:I

.field public static titleMarginEnd:I

.field public static titleMarginStart:I

.field public static titleMarginTop:I

.field public static titleMargins:I

.field public static titlePositionInterpolator:I

.field public static titleSize:I

.field public static titleStartPadding:I

.field public static titleTextAppearance:I

.field public static titleTextColor:I

.field public static titleTextEllipsize:I

.field public static titleTextStyle:I

.field public static toggleCheckedStateOnClick:I

.field public static toolbarId:I

.field public static toolbarNavigationButtonStyle:I

.field public static toolbarStyle:I

.field public static toolbarSurfaceStyle:I

.field public static tooltipForegroundColor:I

.field public static tooltipFrameBackground:I

.field public static tooltipStyle:I

.field public static tooltipText:I

.field public static topInsetScrimEnabled:I

.field public static touchAnchorId:I

.field public static touchAnchorSide:I

.field public static touchRegionId:I

.field public static track:I

.field public static trackColor:I

.field public static trackColorActive:I

.field public static trackColorInactive:I

.field public static trackCornerRadius:I

.field public static trackCornerSize:I

.field public static trackDecoration:I

.field public static trackDecorationTint:I

.field public static trackDecorationTintMode:I

.field public static trackHeight:I

.field public static trackIconActiveColor:I

.field public static trackIconActiveEnd:I

.field public static trackIconActiveStart:I

.field public static trackIconInactiveColor:I

.field public static trackIconInactiveEnd:I

.field public static trackIconInactiveStart:I

.field public static trackIconSize:I

.field public static trackInsideCornerSize:I

.field public static trackStopIndicatorSize:I

.field public static trackThickness:I

.field public static trackTint:I

.field public static trackTintMode:I

.field public static transformPivotTarget:I

.field public static transientTaskbarIconSize:I

.field public static transientTaskbarIconSizeLandscape:I

.field public static transientTaskbarIconSizeTwoPanelLandscape:I

.field public static transientTaskbarIconSizeTwoPanelPortrait:I

.field public static transitionDisable:I

.field public static transitionEasing:I

.field public static transitionFlags:I

.field public static transitionPathRotate:I

.field public static transitionShapeAppearance:I

.field public static triggerId:I

.field public static triggerReceiver:I

.field public static triggerSlack:I

.field public static ttcIndex:I

.field public static tutorialSubtitle:I

.field public static upDuration:I

.field public static updatesContinuously:I

.field public static uri:I

.field public static useCompatPadding:I

.field public static useDrawerArrowDrawable:I

.field public static useMaterialThemeColors:I

.field public static useSimpleSummaryProvider:I

.field public static userResizeBehavior:I

.field public static userResizingDividerDrawable:I

.field public static value:I

.field public static values:I

.field public static verticalOffset:I

.field public static verticalOffsetWithText:I

.field public static viewInflaterClass:I

.field public static viewTransitionMode:I

.field public static viewTransitionOnCross:I

.field public static viewTransitionOnNegativeCross:I

.field public static viewTransitionOnPositiveCross:I

.field public static visibilityMode:I

.field public static voiceIcon:I

.field public static warmth:I

.field public static waveAmplitude:I

.field public static waveDecay:I

.field public static waveOffset:I

.field public static wavePeriod:I

.field public static wavePhase:I

.field public static waveShape:I

.field public static waveSpeed:I

.field public static waveVariesBy:I

.field public static wavelength:I

.field public static wavelengthDeterminate:I

.field public static wavelengthIndeterminate:I

.field public static widgetCellSubtitleColor:I

.field public static widgetCellTitleColor:I

.field public static widgetLayout:I

.field public static widgetPickerAddButtonBackgroundColor:I

.field public static widgetPickerAddButtonTextColor:I

.field public static widgetPickerCollapseHandleColor:I

.field public static widgetPickerHeaderAppSubtitleColor:I

.field public static widgetPickerHeaderAppTitleColor:I

.field public static widgetPickerHeaderBackgroundColor:I

.field public static widgetPickerPrimarySurfaceColor:I

.field public static widgetPickerSearchTextColor:I

.field public static widgetPickerSecondarySurfaceColor:I

.field public static widgetPickerSelectedTabTextColor:I

.field public static widgetPickerSuggestionsIconBackgroundColor:I

.field public static widgetPickerSuggestionsIconColor:I

.field public static widgetPickerTabBackgroundSelected:I

.field public static widgetPickerTabBackgroundUnselected:I

.field public static widgetPickerTitleColor:I

.field public static widgetPickerUnselectedTabTextColor:I

.field public static widgetsTheme:I

.field public static widthChange:I

.field public static windowActionBar:I

.field public static windowActionBarOverlay:I

.field public static windowActionModeOverlay:I

.field public static windowFixedHeightMajor:I

.field public static windowFixedHeightMinor:I

.field public static windowFixedWidthMajor:I

.field public static windowFixedWidthMinor:I

.field public static windowMinWidthMajor:I

.field public static windowMinWidthMinor:I

.field public static windowNoTitle:I

.field public static workProfileOverlayTextColor:I

.field public static workspace:I

.field public static workspaceAccentColor:I

.field public static workspaceAmbientShadowColor:I

.field public static workspaceCellSpecsId:I

.field public static workspaceCellSpecsTwoPanelId:I

.field public static workspaceKeyShadowColor:I

.field public static workspaceShadowColor:I

.field public static workspaceSpecsId:I

.field public static workspaceSpecsTwoPanelId:I

.field public static workspaceSurfaceColor:I

.field public static workspaceTextColor:I

.field public static x:I

.field public static y:I

.field public static yearSelectedStyle:I

.field public static yearStyle:I

.field public static yearTodayStyle:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 164
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
