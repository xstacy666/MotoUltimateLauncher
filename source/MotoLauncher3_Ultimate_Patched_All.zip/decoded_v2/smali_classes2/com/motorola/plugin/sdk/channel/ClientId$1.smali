.class Lcom/motorola/plugin/sdk/channel/ClientId$1;
.super Ljava/lang/Object;
.source "ClientId.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/channel/ClientId;
    .locals 0

    .line 19
    new-instance p0, Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-direct {p0, p1}, Lcom/motorola/plugin/sdk/channel/ClientId;-><init>(Landroid/os/Parcel;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 16
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/ClientId$1;->createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/channel/ClientId;

    move-result-object p0

    return-object p0
.end method

.method public newArray(I)[Lcom/motorola/plugin/sdk/channel/ClientId;
    .locals 0

    .line 24
    new-array p0, p1, [Lcom/motorola/plugin/sdk/channel/ClientId;

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    .line 16
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/ClientId$1;->newArray(I)[Lcom/motorola/plugin/sdk/channel/ClientId;

    move-result-object p0

    return-object p0
.end method
