.class public final Lcom/motorola/plugin/sdk/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_action_bar_title_item:I

.field public static abc_action_bar_up_container:I

.field public static abc_action_menu_item_layout:I

.field public static abc_action_menu_layout:I

.field public static abc_action_mode_bar:I

.field public static abc_action_mode_close_item_material:I

.field public static abc_activity_chooser_view:I

.field public static abc_activity_chooser_view_list_item:I

.field public static abc_alert_dialog_button_bar_material:I

.field public static abc_alert_dialog_material:I

.field public static abc_alert_dialog_title_material:I

.field public static abc_cascading_menu_item_layout:I

.field public static abc_dialog_title_material:I

.field public static abc_expanded_menu_layout:I

.field public static abc_list_menu_item_checkbox:I

.field public static abc_list_menu_item_icon:I

.field public static abc_list_menu_item_layout:I

.field public static abc_list_menu_item_radio:I

.field public static abc_popup_menu_header_item_layout:I

.field public static abc_popup_menu_item_layout:I

.field public static abc_screen_content_include:I

.field public static abc_screen_simple:I

.field public static abc_screen_simple_overlay_action_mode:I

.field public static abc_screen_toolbar:I

.field public static abc_search_dropdown_item_icons_2line:I

.field public static abc_search_view:I

.field public static abc_select_dialog_material:I

.field public static abc_slice_grid:I

.field public static abc_slice_grid_see_more:I

.field public static abc_slice_grid_see_more_overlay:I

.field public static abc_slice_grid_text_overlay_image:I

.field public static abc_slice_message:I

.field public static abc_slice_message_local:I

.field public static abc_slice_permission_request:I

.field public static abc_slice_progress_inline_view:I

.field public static abc_slice_progress_view:I

.field public static abc_slice_remote_input:I

.field public static abc_slice_row_selection:I

.field public static abc_slice_row_selection_dropdown_text:I

.field public static abc_slice_row_selection_text:I

.field public static abc_slice_row_show_more:I

.field public static abc_slice_secondary_text:I

.field public static abc_slice_seekbar_view:I

.field public static abc_slice_small_template:I

.field public static abc_slice_switch:I

.field public static abc_slice_title:I

.field public static abc_tooltip:I

.field public static activity_all_apps_folder_editor:I

.field public static activity_allset:I

.field public static add_item_confirmation_activity:I

.field public static alert_dialog_layout:I

.field public static alert_dialog_title:I

.field public static all_apps:I

.field public static all_apps_bottom_sheet_background:I

.field public static all_apps_branch_search_result:I

.field public static all_apps_content:I

.field public static all_apps_divider:I

.field public static all_apps_edu_view:I

.field public static all_apps_empty_background:I

.field public static all_apps_empty_search:I

.field public static all_apps_fast_scroller:I

.field public static all_apps_folder_icon:I

.field public static all_apps_icon:I

.field public static all_apps_icon_twoline:I

.field public static all_apps_personal_work_tabs:I

.field public static all_apps_prediction_row_icon:I

.field public static all_apps_private_space_entrance:I

.field public static all_apps_rv_layout:I

.field public static all_apps_search_market:I

.field public static all_apps_tabs:I

.field public static allset_navigation:I

.field public static allset_navigation_and_hint:I

.field public static app_icon:I

.field public static app_pair_icon:I

.field public static app_widget_resize_frame:I

.field public static appdrawable_settings_activity:I

.field public static appwidget_error:I

.field public static appwidget_not_ready:I

.field public static arrow_toast:I

.field public static arrow_toast_desktop:I

.field public static back_gesture_tutorial_background:I

.field public static branch_app_container:I

.field public static branch_hero_ad:I

.field public static branch_item_app_entity:I

.field public static branch_item_app_url_entity:I

.field public static branch_item_auto_suggest_entity:I

.field public static branch_item_contact_action_entity:I

.field public static branch_item_contact_entity:I

.field public static branch_item_search_more_entity:I

.field public static branch_item_shortcut_entity:I

.field public static branch_item_suggest_app:I

.field public static branch_search_more_container:I

.field public static branch_shortcut_container:I

.field public static branch_suggest_shortcut_container:I

.field public static branch_zero_state:I

.field public static bubble_bar_drop_target:I

.field public static bubble_bar_overflow_button:I

.field public static bubble_expanded_view_drop_target:I

.field public static bubble_view:I

.field public static bubblebar_item_view:I

.field public static cast_search_bar:I

.field public static create_folder_arrow_tip:I

.field public static custom_dialog:I

.field public static custom_list_prefence_dialog:I

.field public static custom_list_prefence_dialog_list_item:I

.field public static deep_shortcut:I

.field public static deep_shortcut_container:I

.field public static design_bottom_navigation_item:I

.field public static design_bottom_sheet_dialog:I

.field public static design_layout_snackbar:I

.field public static design_layout_snackbar_include:I

.field public static design_layout_tab_icon:I

.field public static design_layout_tab_text:I

.field public static design_menu_item_action_area:I

.field public static design_navigation_item:I

.field public static design_navigation_item_header:I

.field public static design_navigation_item_separator:I

.field public static design_navigation_item_subheader:I

.field public static design_navigation_menu:I

.field public static design_navigation_menu_item:I

.field public static design_text_input_end_icon:I

.field public static design_text_input_start_icon:I

.field public static develop_options_edit_text:I

.field public static developer_options_top_bar:I

.field public static digital_wellbeing_toast:I

.field public static discovery_branch_app_store:I

.field public static discovery_branch_entity:I

.field public static discovery_branch_hint:I

.field public static discovery_branch_local_app:I

.field public static discovery_keyboard_activity:I

.field public static discovery_keyboard_banner:I

.field public static discovery_license_activity:I

.field public static discovery_local_ad_entity:I

.field public static discovery_local_container:I

.field public static discovery_local_entity:I

.field public static discovery_personalize:I

.field public static discovery_privacy_dialog:I

.field public static discovery_remote_container:I

.field public static discovery_remote_entity:I

.field public static discovery_setting_activity:I

.field public static discovery_switch_preference:I

.field public static dm_all_apps_empty_search:I

.field public static dm_all_apps_fast_scroller:I

.field public static dm_all_apps_rv_layout:I

.field public static dm_all_apps_search_market:I

.field public static dm_all_apps_suggest_layout:I

.field public static dm_all_apps_tabs:I

.field public static dm_deep_shortcut:I

.field public static dm_desktop_icon:I

.field public static dm_search_results_rv_layout:I

.field public static dm_work_apps_edu:I

.field public static dm_work_apps_paused:I

.field public static drop_target_bar:I

.field public static drop_target_tool_tip:I

.field public static expand_button:I

.field public static fallback_recents_activity:I

.field public static floating_app_pair_view:I

.field public static floating_header_content:I

.field public static floating_icon_view:I

.field public static floating_split_select_view:I

.field public static floating_surface_view:I

.field public static floating_widget_view:I

.field public static folder_app_pair:I

.field public static folder_application:I

.field public static folder_application_fullscreen:I

.field public static folder_content_fullscreen:I

.field public static folder_icon:I

.field public static folder_page:I

.field public static folder_title_fullscreen:I

.field public static gesture_tutorial_activity:I

.field public static gesture_tutorial_dialog:I

.field public static gesture_tutorial_foldable_mock_hotseat:I

.field public static gesture_tutorial_fragment:I

.field public static gesture_tutorial_mock_conversation:I

.field public static gesture_tutorial_mock_conversation_list:I

.field public static gesture_tutorial_mock_hotseat:I

.field public static gesture_tutorial_mock_webpage:I

.field public static gesture_tutorial_rotation_prompt:I

.field public static gesture_tutorial_step_menu:I

.field public static gesture_tutorial_tablet_mock_conversation:I

.field public static gesture_tutorial_tablet_mock_conversation_list:I

.field public static gesture_tutorial_tablet_mock_hotseat:I

.field public static gesture_tutorial_tablet_mock_taskbar:I

.field public static gesture_tutorial_tablet_mock_webpage:I

.field public static global_search_tutorial_activity:I

.field public static home_settings:I

.field public static hotseat:I

.field public static icon_app_chip_view:I

.field public static icon_personalized:I

.field public static icon_personalized_item:I

.field public static icon_view:I

.field public static image_frame:I

.field public static ime_base_split_test_activity:I

.field public static ime_secondary_split_test_activity:I

.field public static keyboard_drag_and_drop:I

.field public static keyboard_quick_switch_taskview:I

.field public static keyboard_quick_switch_taskview_thumbnail:I

.field public static keyboard_quick_switch_textonly_taskview:I

.field public static keyboard_quick_switch_view:I

.field public static launcher:I

.field public static launcher_preview_layout:I

.field public static launcher_preview_two_panel_layout:I

.field public static layout_custom_switch_prefs:I

.field public static longpress_options_menu:I

.field public static m3_alert_dialog:I

.field public static m3_alert_dialog_actions:I

.field public static m3_alert_dialog_title:I

.field public static m3_auto_complete_simple_item:I

.field public static m3_navigation_menu_subheader:I

.field public static m3_side_sheet_dialog:I

.field public static material_chip_input_combo:I

.field public static material_clock_display:I

.field public static material_clock_display_divider:I

.field public static material_clock_period_toggle:I

.field public static material_clock_period_toggle_land:I

.field public static material_clockface_textview:I

.field public static material_clockface_view:I

.field public static material_radial_view_group:I

.field public static material_textinput_timepicker:I

.field public static material_time_chip:I

.field public static material_time_input:I

.field public static material_timepicker:I

.field public static material_timepicker_dialog:I

.field public static material_timepicker_textinput_display:I

.field public static mtrl_alert_dialog:I

.field public static mtrl_alert_dialog_actions:I

.field public static mtrl_alert_dialog_title:I

.field public static mtrl_alert_select_dialog_item:I

.field public static mtrl_alert_select_dialog_multichoice:I

.field public static mtrl_alert_select_dialog_singlechoice:I

.field public static mtrl_auto_complete_simple_item:I

.field public static mtrl_calendar_day:I

.field public static mtrl_calendar_day_of_week:I

.field public static mtrl_calendar_days_of_week:I

.field public static mtrl_calendar_horizontal:I

.field public static mtrl_calendar_month:I

.field public static mtrl_calendar_month_labeled:I

.field public static mtrl_calendar_month_navigation:I

.field public static mtrl_calendar_months:I

.field public static mtrl_calendar_vertical:I

.field public static mtrl_calendar_year:I

.field public static mtrl_layout_snackbar:I

.field public static mtrl_layout_snackbar_include:I

.field public static mtrl_navigation_rail_item:I

.field public static mtrl_picker_actions:I

.field public static mtrl_picker_dialog:I

.field public static mtrl_picker_fullscreen:I

.field public static mtrl_picker_header_dialog:I

.field public static mtrl_picker_header_fullscreen:I

.field public static mtrl_picker_header_selection_text:I

.field public static mtrl_picker_header_title_text:I

.field public static mtrl_picker_header_toggle:I

.field public static mtrl_picker_text_input_date:I

.field public static mtrl_picker_text_input_date_range:I

.field public static mtrl_search_bar:I

.field public static mtrl_search_view:I

.field public static notification_action:I

.field public static notification_action_tombstone:I

.field public static notification_content:I

.field public static notification_gutter:I

.field public static notification_pref_widget:I

.field public static notification_template_custom_big:I

.field public static notification_template_icon_group:I

.field public static notification_template_part_chronometer:I

.field public static notification_template_part_time:I

.field public static overlay_tab:I

.field public static overview_actions_container:I

.field public static overview_clear_all_button:I

.field public static overview_freeform_view:I

.field public static overview_panel:I

.field public static overview_readyfor_view:I

.field public static overview_smarteye_view:I

.field public static page_indicator_dots:I

.field public static popup_container:I

.field public static poup_home_secondary:I

.field public static poup_icon_secondary:I

.field public static predicted_app_icon:I

.field public static predicted_hotseat_edu:I

.field public static preference:I

.field public static preference_ai_search_divider:I

.field public static preference_category:I

.field public static preference_category_material:I

.field public static preference_category_material_customized:I

.field public static preference_dialog_edittext:I

.field public static preference_dropdown:I

.field public static preference_dropdown_material:I

.field public static preference_information:I

.field public static preference_information_material:I

.field public static preference_list_fragment:I

.field public static preference_material:I

.field public static preference_recyclerview:I

.field public static preference_widget_checkbox:I

.field public static preference_widget_seekbar:I

.field public static preference_widget_seekbar_material:I

.field public static preference_widget_switch:I

.field public static preference_widget_switch_compat:I

.field public static private_space_divider:I

.field public static private_space_header:I

.field public static private_space_mask_view:I

.field public static qsb_default_view:I

.field public static qsb_preview:I

.field public static redesigned_gesture_tutorial_foldable_mock_hotseat:I

.field public static redesigned_gesture_tutorial_fragment:I

.field public static redesigned_gesture_tutorial_mock_hotseat:I

.field public static redesigned_gesture_tutorial_tablet_mock_hotseat:I

.field public static rotate_suggestion:I

.field public static search_container_all_apps:I

.field public static search_container_hotseat:I

.field public static search_container_smartspace:I

.field public static search_container_workspace:I

.field public static search_results_rv_layout:I

.field public static secondary_launcher:I

.field public static select_dialog_item_material:I

.field public static select_dialog_multichoice_material:I

.field public static select_dialog_singlechoice_material:I

.field public static setting_option:I

.field public static setting_options:I

.field public static settings_activity:I

.field public static settingslib_dropdown_preference:I

.field public static settingslib_expressive_collapsable_textview:I

.field public static settingslib_expressive_preference:I

.field public static settingslib_expressive_preference_category:I

.field public static settingslib_expressive_preference_icon_frame:I

.field public static settingslib_expressive_preference_switch:I

.field public static settingslib_expressive_preference_text_frame:I

.field public static settingslib_expressive_two_target_divider:I

.field public static settingslib_icon_frame:I

.field public static settingslib_preference:I

.field public static settingslib_preference_category_no_title:I

.field public static settingslib_preference_dialog_edittext:I

.field public static settingslib_preference_frame:I

.field public static settingslib_switch_layout:I

.field public static smart_folder_app_icon:I

.field public static smart_space_date_view:I

.field public static snackbar:I

.field public static sp_extra_action:I

.field public static sp_smart_card_opaque:I

.field public static sp_smart_card_opaque_folder:I

.field public static sp_smart_card_opaque_title_row:I

.field public static sp_smart_card_transparent:I

.field public static sp_smart_folder_icon_fullscreen:I

.field public static split_instructions_view:I

.field public static support_simple_spinner_dropdown_item:I

.field public static switch_compat_layout:I

.field public static switch_preference_with_settings:I

.field public static system_shortcut:I

.field public static system_shortcut_content:I

.field public static system_shortcut_icon_only:I

.field public static system_shortcut_icon_only_end:I

.field public static system_shortcut_icon_only_start:I

.field public static system_shortcut_icons_container:I

.field public static system_shortcut_rows_container:I

.field public static system_shortcut_spacer:I

.field public static task:I

.field public static task_desktop:I

.field public static task_grouped:I

.field public static task_menu:I

.field public static task_menu_with_arrow:I

.field public static task_thumbnail:I

.field public static task_view_menu_option:I

.field public static taskbar:I

.field public static taskbar_all_apps:I

.field public static taskbar_all_apps_button:I

.field public static taskbar_all_apps_sheet:I

.field public static taskbar_app_icon:I

.field public static taskbar_contextual_button:I

.field public static taskbar_divider:I

.field public static taskbar_divider_popup_menu:I

.field public static taskbar_edu_features:I

.field public static taskbar_edu_pinning:I

.field public static taskbar_edu_search:I

.field public static taskbar_edu_swipe:I

.field public static taskbar_edu_tooltip:I

.field public static taskbar_nav_button:I

.field public static taskbar_predicted_app_icon:I

.field public static toast:I

.field public static transient_taskbar:I

.field public static user_folder_icon_fullscreen:I

.field public static user_folder_icon_normalized:I

.field public static widget_cell:I

.field public static widget_cell_content:I

.field public static widget_list_divider:I

.field public static widget_picker_activity:I

.field public static widget_recommendations:I

.field public static widget_recommendations_table:I

.field public static widget_shortcut_container:I

.field public static widget_shortcut_container_material_u:I

.field public static widget_stack_edit:I

.field public static widget_stack_edit_item:I

.field public static widget_stack_item:I

.field public static widgets_bottom_sheet:I

.field public static widgets_bottom_sheet_content:I

.field public static widgets_full_sheet:I

.field public static widgets_full_sheet_paged_view:I

.field public static widgets_full_sheet_recyclerview:I

.field public static widgets_list_row_header:I

.field public static widgets_list_row_header_two_pane:I

.field public static widgets_list_row_view:I

.field public static widgets_search_bar:I

.field public static widgets_table_container:I

.field public static widgets_two_pane_sheet:I

.field public static widgets_two_pane_sheet_paged_view:I

.field public static widgets_two_pane_sheet_recyclerview:I

.field public static work_apps_edu:I

.field public static work_apps_paused:I

.field public static work_mode_fab:I

.field public static work_mode_switch:I

.field public static workspace_screen:I

.field public static workspace_screen_foldable:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20366
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
