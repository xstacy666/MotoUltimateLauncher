.class public final Lcom/motorola/plugin/sdk/R$color;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_background_cache_hint_selector_material_dark:I

.field public static abc_background_cache_hint_selector_material_light:I

.field public static abc_btn_colored_borderless_text_material:I

.field public static abc_btn_colored_text_material:I

.field public static abc_color_highlight_material:I

.field public static abc_decor_view_status_guard:I

.field public static abc_decor_view_status_guard_light:I

.field public static abc_hint_foreground_material_dark:I

.field public static abc_hint_foreground_material_light:I

.field public static abc_primary_text_disable_only_material_dark:I

.field public static abc_primary_text_disable_only_material_light:I

.field public static abc_primary_text_material_dark:I

.field public static abc_primary_text_material_light:I

.field public static abc_search_url_text:I

.field public static abc_search_url_text_normal:I

.field public static abc_search_url_text_pressed:I

.field public static abc_search_url_text_selected:I

.field public static abc_secondary_text_material_dark:I

.field public static abc_secondary_text_material_light:I

.field public static abc_tint_btn_checkable:I

.field public static abc_tint_default:I

.field public static abc_tint_edittext:I

.field public static abc_tint_seek_thumb:I

.field public static abc_tint_spinner:I

.field public static abc_tint_switch_track:I

.field public static accent_material_dark:I

.field public static accent_material_light:I

.field public static accent_ripple_color:I

.field public static add_item_bg:I

.field public static add_item_button_bg:I

.field public static add_item_button_text:I

.field public static add_item_summary:I

.field public static add_item_title:I

.field public static all_apps_bg_hand_fill:I

.field public static all_apps_bg_hand_fill_dark:I

.field public static all_apps_button_bg_color:I

.field public static all_apps_button_color:I

.field public static all_apps_button_color_1:I

.field public static all_apps_button_color_2:I

.field public static all_apps_button_color_3:I

.field public static all_apps_button_color_4:I

.field public static all_apps_clear_input_dark:I

.field public static all_apps_clear_input_light:I

.field public static all_apps_container_dark:I

.field public static all_apps_container_light:I

.field public static all_apps_folder_done_bg_valid:I

.field public static all_apps_folder_done_text_valid:I

.field public static all_apps_folder_edit_text:I

.field public static all_apps_folder_edit_text_hint:I

.field public static all_apps_folder_edit_titie:I

.field public static all_apps_folder_editor_name_bg_color:I

.field public static all_apps_folder_editor_name_bg_color_focused:I

.field public static all_apps_folder_editor_top_bar_text_color:I

.field public static all_apps_foler_done_bg_invalid:I

.field public static all_apps_foler_done_text_invalid:I

.field public static all_apps_label_text:I

.field public static all_apps_label_text_dark:I

.field public static all_apps_label_text_light:I

.field public static all_apps_menu_bg_color:I

.field public static all_apps_menu_color:I

.field public static all_apps_menu_dark:I

.field public static all_apps_menu_light:I

.field public static all_apps_prediction_row_separator:I

.field public static all_apps_prediction_row_separator_dark:I

.field public static all_apps_tab_background_selected:I

.field public static all_apps_tab_text:I

.field public static all_apps_tabs_background:I

.field public static all_apps_tips_dark:I

.field public static all_apps_tips_dismiss:I

.field public static all_apps_tips_light:I

.field public static all_apps_tips_text_dark:I

.field public static all_apps_tips_text_light:I

.field public static all_set_bg_primary:I

.field public static all_set_bg_tertiary:I

.field public static all_set_page_background:I

.field public static androidx_core_ripple_material_light:I

.field public static androidx_core_secondary_text_default_material_light:I

.field public static applock_msg_color:I

.field public static arrow_tip_view_bg:I

.field public static arrow_tip_view_content:I

.field public static back_btn:I

.field public static background_floating_material_dark:I

.field public static background_floating_material_light:I

.field public static background_material_dark:I

.field public static background_material_light:I

.field public static badge_tint_clone:I

.field public static badge_tint_instant:I

.field public static badge_tint_private:I

.field public static badge_tint_vault:I

.field public static badge_tint_work:I

.field public static branch_box_surface:I

.field public static branch_personalize_text:I

.field public static branch_track:I

.field public static branch_turn_on_bg:I

.field public static branch_turn_on_text:I

.field public static bright_foreground_disabled_material_dark:I

.field public static bright_foreground_disabled_material_light:I

.field public static bright_foreground_inverse_material_dark:I

.field public static bright_foreground_inverse_material_light:I

.field public static bright_foreground_material_dark:I

.field public static bright_foreground_material_light:I

.field public static bubble_drop_target_background_color:I

.field public static bubblebar_drop_target_bg_color:I

.field public static button_bg:I

.field public static button_material_dark:I

.field public static button_material_light:I

.field public static button_text:I

.field public static call_notification_answer_color:I

.field public static call_notification_decline_color:I

.field public static cardview_dark_background:I

.field public static cardview_light_background:I

.field public static cardview_shadow_end_color:I

.field public static cardview_shadow_start_color:I

.field public static cast_search_bar_bg_color:I

.field public static cast_search_bar_prompt_hint_color:I

.field public static cast_search_bar_prompt_text_color:I

.field public static cell_layout_bg_color:I

.field public static check_mark_bg_color:I

.field public static check_mark_icon_color:I

.field public static chip_hint_foreground_color:I

.field public static chip_scrim_start_color:I

.field public static create_folder_shadow_color:I

.field public static create_folder_tip_background:I

.field public static create_folder_tip_text_color:I

.field public static custom_list_preference_bg:I

.field public static custom_list_preference_cancel:I

.field public static custom_list_preference_cancel_border:I

.field public static custom_list_preference_cancel_ripper:I

.field public static custom_list_preference_dialog:I

.field public static custom_list_preference_dialog_bg:I

.field public static custom_list_preference_list_item_title:I

.field public static custom_list_preference_title:I

.field public static deep_shortcut_text:I

.field public static default_shadow_color:I

.field public static default_shadow_color_no_alpha:I

.field public static delete_target_hover_tint:I

.field public static design_bottom_navigation_shadow_color:I

.field public static design_box_stroke_color:I

.field public static design_dark_default_color_background:I

.field public static design_dark_default_color_error:I

.field public static design_dark_default_color_on_background:I

.field public static design_dark_default_color_on_error:I

.field public static design_dark_default_color_on_primary:I

.field public static design_dark_default_color_on_secondary:I

.field public static design_dark_default_color_on_surface:I

.field public static design_dark_default_color_primary:I

.field public static design_dark_default_color_primary_dark:I

.field public static design_dark_default_color_primary_variant:I

.field public static design_dark_default_color_secondary:I

.field public static design_dark_default_color_secondary_variant:I

.field public static design_dark_default_color_surface:I

.field public static design_default_color_background:I

.field public static design_default_color_error:I

.field public static design_default_color_on_background:I

.field public static design_default_color_on_error:I

.field public static design_default_color_on_primary:I

.field public static design_default_color_on_secondary:I

.field public static design_default_color_on_surface:I

.field public static design_default_color_primary:I

.field public static design_default_color_primary_dark:I

.field public static design_default_color_primary_variant:I

.field public static design_default_color_secondary:I

.field public static design_default_color_secondary_variant:I

.field public static design_default_color_surface:I

.field public static design_error:I

.field public static design_fab_shadow_end_color:I

.field public static design_fab_shadow_mid_color:I

.field public static design_fab_shadow_start_color:I

.field public static design_fab_stroke_end_inner_color:I

.field public static design_fab_stroke_end_outer_color:I

.field public static design_fab_stroke_top_inner_color:I

.field public static design_fab_stroke_top_outer_color:I

.field public static design_icon_tint:I

.field public static design_snackbar_background_color:I

.field public static dim_foreground_disabled_material_dark:I

.field public static dim_foreground_disabled_material_light:I

.field public static dim_foreground_material_dark:I

.field public static dim_foreground_material_light:I

.field public static discovery_app_name_color:I

.field public static discovery_blue_color:I

.field public static discovery_box_content:I

.field public static discovery_continue_color:I

.field public static discovery_hint_bg_color:I

.field public static discovery_hint_desc_color:I

.field public static discovery_icon_color:I

.field public static discovery_line_color:I

.field public static discovery_link_bg:I

.field public static discovery_personalize_bg:I

.field public static discovery_personalize_icon:I

.field public static discovery_personalize_stroke:I

.field public static discovery_privacy_bg:I

.field public static discovery_privacy_btn:I

.field public static discovery_privacy_btn_disable:I

.field public static discovery_privacy_btn_text_disable:I

.field public static discovery_privacy_checkbox_desc:I

.field public static discovery_privacy_checkbox_unselect:I

.field public static discovery_privacy_gif_bg:I

.field public static discovery_privacy_link:I

.field public static discovery_privacy_sure_color:I

.field public static discovery_section_title:I

.field public static discovery_shortcut_bg:I

.field public static discovery_smart_text_color:I

.field public static discovery_switch_bg:I

.field public static discovery_switch_text:I

.field public static discovery_text:I

.field public static discovery_thumb:I

.field public static discovery_thumb_tick:I

.field public static discovery_track:I

.field public static dm_all_apps_hover_background:I

.field public static dm_all_apps_tab_text:I

.field public static dm_desktop_focused_background:I

.field public static dm_desktop_hover_background:I

.field public static dm_fast_scroll_background:I

.field public static dm_popup_hover_background:I

.field public static dm_right_menu_icon_background:I

.field public static dm_workspace_available_border_selector:I

.field public static dm_workspace_unavailable_border_selector:I

.field public static drop_target_hover_button_color_dark:I

.field public static drop_target_hover_button_color_light:I

.field public static drop_target_hover_text_color_dark:I

.field public static drop_target_hover_text_color_light:I

.field public static drop_target_text:I

.field public static error_color_material_dark:I

.field public static error_color_material_light:I

.field public static floating_rotation_button_dark_color:I

.field public static floating_rotation_button_light_color:I

.field public static focused_background:I

.field public static folder_background_dark:I

.field public static folder_background_light:I

.field public static folder_hint_text_color_dark:I

.field public static folder_hint_text_color_light:I

.field public static folder_preview_background:I

.field public static folder_preview_dark:I

.field public static folder_preview_light:I

.field public static folder_text_color_dark:I

.field public static folder_text_color_light:I

.field public static foreground_material_dark:I

.field public static foreground_material_light:I

.field public static free_form_btn_bg:I

.field public static fullscreen_folder_content_outline_color:I

.field public static gesture_icon_shadow:I

.field public static gesture_tutorial_back_arrow_color:I

.field public static gesture_tutorial_fake_previous_task_view_color:I

.field public static gesture_tutorial_fake_task_view_color:I

.field public static gesture_tutorial_fake_wallpaper_color:I

.field public static gesture_tutorial_ripple_color:I

.field public static gesture_tutorial_taskbar_color:I

.field public static global_search_anim_bg:I

.field public static global_search_bg:I

.field public static global_search_button_bg:I

.field public static global_search_button_text:I

.field public static global_search_icon:I

.field public static global_search_know_bg:I

.field public static global_search_know_text:I

.field public static global_search_list:I

.field public static global_search_title:I

.field public static hello_ui_on_surface_variant:I

.field public static hello_ui_outline:I

.field public static hello_ui_outline_variant:I

.field public static highlighted_text_material_dark:I

.field public static highlighted_text_material_light:I

.field public static home_setting_actionbar_shrink:I

.field public static home_setting_divider:I

.field public static home_setting_done_invalid_dark:I

.field public static home_setting_done_invalid_light:I

.field public static home_setting_expand_title:I

.field public static home_setting_main_list_category:I

.field public static home_setting_main_list_summary:I

.field public static home_setting_main_list_title:I

.field public static home_settings_bg:I

.field public static home_settings_header_accent:I

.field public static home_settings_header_collapsed:I

.field public static home_settings_header_expanded:I

.field public static home_settings_state_off_color:I

.field public static home_settings_state_on_color:I

.field public static home_settings_switch_thumb_color:I

.field public static home_settings_switch_track_color:I

.field public static home_settings_thumb_off_color:I

.field public static home_settings_track_off_color:I

.field public static home_settings_track_on_color:I

.field public static home_style_radio_checked:I

.field public static home_style_radio_unchecked:I

.field public static home_style_setting_icon:I

.field public static home_style_setting_option_divider:I

.field public static ic_launcher_moto_app_launcher_background:I

.field public static icon_background:I

.field public static icon_personalize_bg:I

.field public static icon_personalize_lottie_json_icon:I

.field public static icon_personalize_lottie_json_screen:I

.field public static icon_personalize_lottie_json_time:I

.field public static icon_personalize_recyclerview:I

.field public static icon_personalized_label_bottom_layout_bg:I

.field public static icon_personalized_label_des_color:I

.field public static icon_personalized_label_top_layout_bg:I

.field public static icon_personalized_popup_text_color:I

.field public static icon_personalized_preview_bg:I

.field public static icon_personalized_preview_text:I

.field public static icon_personalized_progree_rate_color:I

.field public static icon_personalized_slider_press_shadow_color:I

.field public static icon_personalized_subtitle_color:I

.field public static icon_size_bg:I

.field public static icon_size_hint:I

.field public static icon_size_progress_shadow:I

.field public static icon_size_seekbar_minus:I

.field public static icon_size_size_control:I

.field public static icon_size_slide_bar_color_selected:I

.field public static icon_size_slide_bar_color_unselected:I

.field public static icon_size_slide_bar_scale:I

.field public static icon_size_slider_color_selected:I

.field public static icon_text_color:I

.field public static important_conversation:I

.field public static list_divider:I

.field public static lottie_blue400:I

.field public static lottie_blue600:I

.field public static lottie_green400:I

.field public static lottie_green600:I

.field public static lottie_grey200:I

.field public static lottie_grey600:I

.field public static lottie_grey700:I

.field public static lottie_red600:I

.field public static lottie_yellow400:I

.field public static lottie_yellow600:I

.field public static m3_appbar_overlay_color:I

.field public static m3_assist_chip_icon_tint_color:I

.field public static m3_assist_chip_stroke_color:I

.field public static m3_bottom_sheet_drag_handle_color:I

.field public static m3_button_background_color_selector:I

.field public static m3_button_foreground_color_selector:I

.field public static m3_button_outline_color_selector:I

.field public static m3_button_ripple_color:I

.field public static m3_button_ripple_color_selector:I

.field public static m3_calendar_item_disabled_text:I

.field public static m3_calendar_item_stroke_color:I

.field public static m3_card_foreground_color:I

.field public static m3_card_ripple_color:I

.field public static m3_card_stroke_color:I

.field public static m3_checkbox_button_icon_tint:I

.field public static m3_checkbox_button_tint:I

.field public static m3_chip_assist_text_color:I

.field public static m3_chip_background_color:I

.field public static m3_chip_ripple_color:I

.field public static m3_chip_stroke_color:I

.field public static m3_chip_text_color:I

.field public static m3_dark_default_color_primary_text:I

.field public static m3_dark_default_color_secondary_text:I

.field public static m3_dark_highlighted_text:I

.field public static m3_dark_hint_foreground:I

.field public static m3_dark_primary_text_disable_only:I

.field public static m3_default_color_primary_text:I

.field public static m3_default_color_secondary_text:I

.field public static m3_dynamic_dark_default_color_primary_text:I

.field public static m3_dynamic_dark_default_color_secondary_text:I

.field public static m3_dynamic_dark_highlighted_text:I

.field public static m3_dynamic_dark_hint_foreground:I

.field public static m3_dynamic_dark_primary_text_disable_only:I

.field public static m3_dynamic_default_color_primary_text:I

.field public static m3_dynamic_default_color_secondary_text:I

.field public static m3_dynamic_highlighted_text:I

.field public static m3_dynamic_hint_foreground:I

.field public static m3_dynamic_primary_text_disable_only:I

.field public static m3_efab_ripple_color_selector:I

.field public static m3_elevated_chip_background_color:I

.field public static m3_fab_efab_background_color_selector:I

.field public static m3_fab_efab_foreground_color_selector:I

.field public static m3_fab_ripple_color_selector:I

.field public static m3_filled_icon_button_container_color_selector:I

.field public static m3_highlighted_text:I

.field public static m3_hint_foreground:I

.field public static m3_icon_button_icon_color_selector:I

.field public static m3_navigation_bar_item_with_indicator_icon_tint:I

.field public static m3_navigation_bar_item_with_indicator_label_tint:I

.field public static m3_navigation_bar_ripple_color_selector:I

.field public static m3_navigation_item_background_color:I

.field public static m3_navigation_item_icon_tint:I

.field public static m3_navigation_item_ripple_color:I

.field public static m3_navigation_item_text_color:I

.field public static m3_navigation_rail_item_with_indicator_icon_tint:I

.field public static m3_navigation_rail_item_with_indicator_label_tint:I

.field public static m3_navigation_rail_ripple_color_selector:I

.field public static m3_popupmenu_overlay_color:I

.field public static m3_primary_text_disable_only:I

.field public static m3_radiobutton_button_tint:I

.field public static m3_radiobutton_ripple_tint:I

.field public static m3_ref_palette_black:I

.field public static m3_ref_palette_blue0:I

.field public static m3_ref_palette_blue10:I

.field public static m3_ref_palette_blue100:I

.field public static m3_ref_palette_blue20:I

.field public static m3_ref_palette_blue30:I

.field public static m3_ref_palette_blue40:I

.field public static m3_ref_palette_blue50:I

.field public static m3_ref_palette_blue60:I

.field public static m3_ref_palette_blue70:I

.field public static m3_ref_palette_blue80:I

.field public static m3_ref_palette_blue90:I

.field public static m3_ref_palette_blue95:I

.field public static m3_ref_palette_blue98:I

.field public static m3_ref_palette_blue_variant0:I

.field public static m3_ref_palette_blue_variant10:I

.field public static m3_ref_palette_blue_variant100:I

.field public static m3_ref_palette_blue_variant20:I

.field public static m3_ref_palette_blue_variant30:I

.field public static m3_ref_palette_blue_variant40:I

.field public static m3_ref_palette_blue_variant50:I

.field public static m3_ref_palette_blue_variant60:I

.field public static m3_ref_palette_blue_variant70:I

.field public static m3_ref_palette_blue_variant80:I

.field public static m3_ref_palette_blue_variant90:I

.field public static m3_ref_palette_blue_variant95:I

.field public static m3_ref_palette_blue_variant98:I

.field public static m3_ref_palette_cyan0:I

.field public static m3_ref_palette_cyan10:I

.field public static m3_ref_palette_cyan100:I

.field public static m3_ref_palette_cyan20:I

.field public static m3_ref_palette_cyan30:I

.field public static m3_ref_palette_cyan40:I

.field public static m3_ref_palette_cyan50:I

.field public static m3_ref_palette_cyan60:I

.field public static m3_ref_palette_cyan70:I

.field public static m3_ref_palette_cyan80:I

.field public static m3_ref_palette_cyan90:I

.field public static m3_ref_palette_cyan95:I

.field public static m3_ref_palette_cyan98:I

.field public static m3_ref_palette_dynamic_neutral0:I

.field public static m3_ref_palette_dynamic_neutral10:I

.field public static m3_ref_palette_dynamic_neutral100:I

.field public static m3_ref_palette_dynamic_neutral12:I

.field public static m3_ref_palette_dynamic_neutral17:I

.field public static m3_ref_palette_dynamic_neutral20:I

.field public static m3_ref_palette_dynamic_neutral22:I

.field public static m3_ref_palette_dynamic_neutral24:I

.field public static m3_ref_palette_dynamic_neutral30:I

.field public static m3_ref_palette_dynamic_neutral4:I

.field public static m3_ref_palette_dynamic_neutral40:I

.field public static m3_ref_palette_dynamic_neutral50:I

.field public static m3_ref_palette_dynamic_neutral6:I

.field public static m3_ref_palette_dynamic_neutral60:I

.field public static m3_ref_palette_dynamic_neutral70:I

.field public static m3_ref_palette_dynamic_neutral80:I

.field public static m3_ref_palette_dynamic_neutral87:I

.field public static m3_ref_palette_dynamic_neutral90:I

.field public static m3_ref_palette_dynamic_neutral92:I

.field public static m3_ref_palette_dynamic_neutral94:I

.field public static m3_ref_palette_dynamic_neutral95:I

.field public static m3_ref_palette_dynamic_neutral96:I

.field public static m3_ref_palette_dynamic_neutral98:I

.field public static m3_ref_palette_dynamic_neutral99:I

.field public static m3_ref_palette_dynamic_neutral_variant0:I

.field public static m3_ref_palette_dynamic_neutral_variant10:I

.field public static m3_ref_palette_dynamic_neutral_variant100:I

.field public static m3_ref_palette_dynamic_neutral_variant12:I

.field public static m3_ref_palette_dynamic_neutral_variant17:I

.field public static m3_ref_palette_dynamic_neutral_variant20:I

.field public static m3_ref_palette_dynamic_neutral_variant22:I

.field public static m3_ref_palette_dynamic_neutral_variant24:I

.field public static m3_ref_palette_dynamic_neutral_variant30:I

.field public static m3_ref_palette_dynamic_neutral_variant4:I

.field public static m3_ref_palette_dynamic_neutral_variant40:I

.field public static m3_ref_palette_dynamic_neutral_variant50:I

.field public static m3_ref_palette_dynamic_neutral_variant6:I

.field public static m3_ref_palette_dynamic_neutral_variant60:I

.field public static m3_ref_palette_dynamic_neutral_variant70:I

.field public static m3_ref_palette_dynamic_neutral_variant80:I

.field public static m3_ref_palette_dynamic_neutral_variant87:I

.field public static m3_ref_palette_dynamic_neutral_variant90:I

.field public static m3_ref_palette_dynamic_neutral_variant92:I

.field public static m3_ref_palette_dynamic_neutral_variant94:I

.field public static m3_ref_palette_dynamic_neutral_variant95:I

.field public static m3_ref_palette_dynamic_neutral_variant96:I

.field public static m3_ref_palette_dynamic_neutral_variant98:I

.field public static m3_ref_palette_dynamic_neutral_variant99:I

.field public static m3_ref_palette_dynamic_primary0:I

.field public static m3_ref_palette_dynamic_primary10:I

.field public static m3_ref_palette_dynamic_primary100:I

.field public static m3_ref_palette_dynamic_primary20:I

.field public static m3_ref_palette_dynamic_primary30:I

.field public static m3_ref_palette_dynamic_primary40:I

.field public static m3_ref_palette_dynamic_primary50:I

.field public static m3_ref_palette_dynamic_primary60:I

.field public static m3_ref_palette_dynamic_primary70:I

.field public static m3_ref_palette_dynamic_primary80:I

.field public static m3_ref_palette_dynamic_primary90:I

.field public static m3_ref_palette_dynamic_primary95:I

.field public static m3_ref_palette_dynamic_primary98:I

.field public static m3_ref_palette_dynamic_primary99:I

.field public static m3_ref_palette_dynamic_secondary0:I

.field public static m3_ref_palette_dynamic_secondary10:I

.field public static m3_ref_palette_dynamic_secondary100:I

.field public static m3_ref_palette_dynamic_secondary20:I

.field public static m3_ref_palette_dynamic_secondary30:I

.field public static m3_ref_palette_dynamic_secondary40:I

.field public static m3_ref_palette_dynamic_secondary50:I

.field public static m3_ref_palette_dynamic_secondary60:I

.field public static m3_ref_palette_dynamic_secondary70:I

.field public static m3_ref_palette_dynamic_secondary80:I

.field public static m3_ref_palette_dynamic_secondary90:I

.field public static m3_ref_palette_dynamic_secondary95:I

.field public static m3_ref_palette_dynamic_secondary98:I

.field public static m3_ref_palette_dynamic_secondary99:I

.field public static m3_ref_palette_dynamic_tertiary0:I

.field public static m3_ref_palette_dynamic_tertiary10:I

.field public static m3_ref_palette_dynamic_tertiary100:I

.field public static m3_ref_palette_dynamic_tertiary20:I

.field public static m3_ref_palette_dynamic_tertiary30:I

.field public static m3_ref_palette_dynamic_tertiary40:I

.field public static m3_ref_palette_dynamic_tertiary50:I

.field public static m3_ref_palette_dynamic_tertiary60:I

.field public static m3_ref_palette_dynamic_tertiary70:I

.field public static m3_ref_palette_dynamic_tertiary80:I

.field public static m3_ref_palette_dynamic_tertiary90:I

.field public static m3_ref_palette_dynamic_tertiary95:I

.field public static m3_ref_palette_dynamic_tertiary98:I

.field public static m3_ref_palette_dynamic_tertiary99:I

.field public static m3_ref_palette_error0:I

.field public static m3_ref_palette_error10:I

.field public static m3_ref_palette_error100:I

.field public static m3_ref_palette_error20:I

.field public static m3_ref_palette_error30:I

.field public static m3_ref_palette_error40:I

.field public static m3_ref_palette_error50:I

.field public static m3_ref_palette_error60:I

.field public static m3_ref_palette_error70:I

.field public static m3_ref_palette_error80:I

.field public static m3_ref_palette_error90:I

.field public static m3_ref_palette_error95:I

.field public static m3_ref_palette_error98:I

.field public static m3_ref_palette_error99:I

.field public static m3_ref_palette_green0:I

.field public static m3_ref_palette_green10:I

.field public static m3_ref_palette_green100:I

.field public static m3_ref_palette_green20:I

.field public static m3_ref_palette_green30:I

.field public static m3_ref_palette_green40:I

.field public static m3_ref_palette_green50:I

.field public static m3_ref_palette_green60:I

.field public static m3_ref_palette_green70:I

.field public static m3_ref_palette_green80:I

.field public static m3_ref_palette_green90:I

.field public static m3_ref_palette_green95:I

.field public static m3_ref_palette_green98:I

.field public static m3_ref_palette_grey0:I

.field public static m3_ref_palette_grey10:I

.field public static m3_ref_palette_grey100:I

.field public static m3_ref_palette_grey20:I

.field public static m3_ref_palette_grey30:I

.field public static m3_ref_palette_grey40:I

.field public static m3_ref_palette_grey50:I

.field public static m3_ref_palette_grey60:I

.field public static m3_ref_palette_grey70:I

.field public static m3_ref_palette_grey80:I

.field public static m3_ref_palette_grey90:I

.field public static m3_ref_palette_grey95:I

.field public static m3_ref_palette_grey98:I

.field public static m3_ref_palette_grey_variant0:I

.field public static m3_ref_palette_grey_variant10:I

.field public static m3_ref_palette_grey_variant100:I

.field public static m3_ref_palette_grey_variant20:I

.field public static m3_ref_palette_grey_variant30:I

.field public static m3_ref_palette_grey_variant40:I

.field public static m3_ref_palette_grey_variant50:I

.field public static m3_ref_palette_grey_variant60:I

.field public static m3_ref_palette_grey_variant70:I

.field public static m3_ref_palette_grey_variant80:I

.field public static m3_ref_palette_grey_variant90:I

.field public static m3_ref_palette_grey_variant95:I

.field public static m3_ref_palette_grey_variant98:I

.field public static m3_ref_palette_neutral0:I

.field public static m3_ref_palette_neutral10:I

.field public static m3_ref_palette_neutral100:I

.field public static m3_ref_palette_neutral12:I

.field public static m3_ref_palette_neutral17:I

.field public static m3_ref_palette_neutral20:I

.field public static m3_ref_palette_neutral22:I

.field public static m3_ref_palette_neutral24:I

.field public static m3_ref_palette_neutral30:I

.field public static m3_ref_palette_neutral4:I

.field public static m3_ref_palette_neutral40:I

.field public static m3_ref_palette_neutral50:I

.field public static m3_ref_palette_neutral6:I

.field public static m3_ref_palette_neutral60:I

.field public static m3_ref_palette_neutral70:I

.field public static m3_ref_palette_neutral80:I

.field public static m3_ref_palette_neutral87:I

.field public static m3_ref_palette_neutral90:I

.field public static m3_ref_palette_neutral92:I

.field public static m3_ref_palette_neutral94:I

.field public static m3_ref_palette_neutral95:I

.field public static m3_ref_palette_neutral96:I

.field public static m3_ref_palette_neutral98:I

.field public static m3_ref_palette_neutral99:I

.field public static m3_ref_palette_neutral_variant0:I

.field public static m3_ref_palette_neutral_variant10:I

.field public static m3_ref_palette_neutral_variant100:I

.field public static m3_ref_palette_neutral_variant20:I

.field public static m3_ref_palette_neutral_variant30:I

.field public static m3_ref_palette_neutral_variant40:I

.field public static m3_ref_palette_neutral_variant50:I

.field public static m3_ref_palette_neutral_variant60:I

.field public static m3_ref_palette_neutral_variant70:I

.field public static m3_ref_palette_neutral_variant80:I

.field public static m3_ref_palette_neutral_variant90:I

.field public static m3_ref_palette_neutral_variant95:I

.field public static m3_ref_palette_neutral_variant98:I

.field public static m3_ref_palette_neutral_variant99:I

.field public static m3_ref_palette_orange0:I

.field public static m3_ref_palette_orange10:I

.field public static m3_ref_palette_orange100:I

.field public static m3_ref_palette_orange20:I

.field public static m3_ref_palette_orange30:I

.field public static m3_ref_palette_orange40:I

.field public static m3_ref_palette_orange50:I

.field public static m3_ref_palette_orange60:I

.field public static m3_ref_palette_orange70:I

.field public static m3_ref_palette_orange80:I

.field public static m3_ref_palette_orange90:I

.field public static m3_ref_palette_orange95:I

.field public static m3_ref_palette_orange98:I

.field public static m3_ref_palette_pink0:I

.field public static m3_ref_palette_pink10:I

.field public static m3_ref_palette_pink100:I

.field public static m3_ref_palette_pink20:I

.field public static m3_ref_palette_pink30:I

.field public static m3_ref_palette_pink40:I

.field public static m3_ref_palette_pink50:I

.field public static m3_ref_palette_pink60:I

.field public static m3_ref_palette_pink70:I

.field public static m3_ref_palette_pink80:I

.field public static m3_ref_palette_pink90:I

.field public static m3_ref_palette_pink95:I

.field public static m3_ref_palette_pink98:I

.field public static m3_ref_palette_primary0:I

.field public static m3_ref_palette_primary10:I

.field public static m3_ref_palette_primary100:I

.field public static m3_ref_palette_primary20:I

.field public static m3_ref_palette_primary30:I

.field public static m3_ref_palette_primary40:I

.field public static m3_ref_palette_primary50:I

.field public static m3_ref_palette_primary60:I

.field public static m3_ref_palette_primary70:I

.field public static m3_ref_palette_primary80:I

.field public static m3_ref_palette_primary90:I

.field public static m3_ref_palette_primary95:I

.field public static m3_ref_palette_primary98:I

.field public static m3_ref_palette_primary99:I

.field public static m3_ref_palette_purple0:I

.field public static m3_ref_palette_purple10:I

.field public static m3_ref_palette_purple100:I

.field public static m3_ref_palette_purple20:I

.field public static m3_ref_palette_purple30:I

.field public static m3_ref_palette_purple40:I

.field public static m3_ref_palette_purple50:I

.field public static m3_ref_palette_purple60:I

.field public static m3_ref_palette_purple70:I

.field public static m3_ref_palette_purple80:I

.field public static m3_ref_palette_purple90:I

.field public static m3_ref_palette_purple95:I

.field public static m3_ref_palette_purple98:I

.field public static m3_ref_palette_red0:I

.field public static m3_ref_palette_red10:I

.field public static m3_ref_palette_red100:I

.field public static m3_ref_palette_red20:I

.field public static m3_ref_palette_red30:I

.field public static m3_ref_palette_red40:I

.field public static m3_ref_palette_red50:I

.field public static m3_ref_palette_red60:I

.field public static m3_ref_palette_red70:I

.field public static m3_ref_palette_red80:I

.field public static m3_ref_palette_red90:I

.field public static m3_ref_palette_red95:I

.field public static m3_ref_palette_red98:I

.field public static m3_ref_palette_secondary0:I

.field public static m3_ref_palette_secondary10:I

.field public static m3_ref_palette_secondary100:I

.field public static m3_ref_palette_secondary20:I

.field public static m3_ref_palette_secondary30:I

.field public static m3_ref_palette_secondary40:I

.field public static m3_ref_palette_secondary50:I

.field public static m3_ref_palette_secondary60:I

.field public static m3_ref_palette_secondary70:I

.field public static m3_ref_palette_secondary80:I

.field public static m3_ref_palette_secondary90:I

.field public static m3_ref_palette_secondary95:I

.field public static m3_ref_palette_secondary98:I

.field public static m3_ref_palette_secondary99:I

.field public static m3_ref_palette_tertiary0:I

.field public static m3_ref_palette_tertiary10:I

.field public static m3_ref_palette_tertiary100:I

.field public static m3_ref_palette_tertiary20:I

.field public static m3_ref_palette_tertiary30:I

.field public static m3_ref_palette_tertiary40:I

.field public static m3_ref_palette_tertiary50:I

.field public static m3_ref_palette_tertiary60:I

.field public static m3_ref_palette_tertiary70:I

.field public static m3_ref_palette_tertiary80:I

.field public static m3_ref_palette_tertiary90:I

.field public static m3_ref_palette_tertiary95:I

.field public static m3_ref_palette_tertiary98:I

.field public static m3_ref_palette_tertiary99:I

.field public static m3_ref_palette_white:I

.field public static m3_ref_palette_yellow0:I

.field public static m3_ref_palette_yellow10:I

.field public static m3_ref_palette_yellow100:I

.field public static m3_ref_palette_yellow20:I

.field public static m3_ref_palette_yellow30:I

.field public static m3_ref_palette_yellow40:I

.field public static m3_ref_palette_yellow50:I

.field public static m3_ref_palette_yellow60:I

.field public static m3_ref_palette_yellow70:I

.field public static m3_ref_palette_yellow80:I

.field public static m3_ref_palette_yellow90:I

.field public static m3_ref_palette_yellow95:I

.field public static m3_ref_palette_yellow98:I

.field public static m3_selection_control_ripple_color_selector:I

.field public static m3_simple_item_ripple_color:I

.field public static m3_slider_active_tick_marks_color:I

.field public static m3_slider_active_track_color:I

.field public static m3_slider_active_track_color_legacy:I

.field public static m3_slider_halo_color_legacy:I

.field public static m3_slider_inactive_tick_marks_color:I

.field public static m3_slider_inactive_track_color:I

.field public static m3_slider_inactive_track_color_legacy:I

.field public static m3_slider_thumb_color:I

.field public static m3_slider_thumb_color_legacy:I

.field public static m3_switch_thumb_tint:I

.field public static m3_switch_track_tint:I

.field public static m3_sys_color_dark_background:I

.field public static m3_sys_color_dark_error:I

.field public static m3_sys_color_dark_error_container:I

.field public static m3_sys_color_dark_inverse_on_surface:I

.field public static m3_sys_color_dark_inverse_primary:I

.field public static m3_sys_color_dark_inverse_surface:I

.field public static m3_sys_color_dark_on_background:I

.field public static m3_sys_color_dark_on_error:I

.field public static m3_sys_color_dark_on_error_container:I

.field public static m3_sys_color_dark_on_primary:I

.field public static m3_sys_color_dark_on_primary_container:I

.field public static m3_sys_color_dark_on_secondary:I

.field public static m3_sys_color_dark_on_secondary_container:I

.field public static m3_sys_color_dark_on_surface:I

.field public static m3_sys_color_dark_on_surface_variant:I

.field public static m3_sys_color_dark_on_tertiary:I

.field public static m3_sys_color_dark_on_tertiary_container:I

.field public static m3_sys_color_dark_outline:I

.field public static m3_sys_color_dark_outline_variant:I

.field public static m3_sys_color_dark_primary:I

.field public static m3_sys_color_dark_primary_container:I

.field public static m3_sys_color_dark_secondary:I

.field public static m3_sys_color_dark_secondary_container:I

.field public static m3_sys_color_dark_surface:I

.field public static m3_sys_color_dark_surface_bright:I

.field public static m3_sys_color_dark_surface_container:I

.field public static m3_sys_color_dark_surface_container_high:I

.field public static m3_sys_color_dark_surface_container_highest:I

.field public static m3_sys_color_dark_surface_container_low:I

.field public static m3_sys_color_dark_surface_container_lowest:I

.field public static m3_sys_color_dark_surface_dim:I

.field public static m3_sys_color_dark_surface_variant:I

.field public static m3_sys_color_dark_tertiary:I

.field public static m3_sys_color_dark_tertiary_container:I

.field public static m3_sys_color_dynamic_dark_background:I

.field public static m3_sys_color_dynamic_dark_error:I

.field public static m3_sys_color_dynamic_dark_error_container:I

.field public static m3_sys_color_dynamic_dark_inverse_on_surface:I

.field public static m3_sys_color_dynamic_dark_inverse_primary:I

.field public static m3_sys_color_dynamic_dark_inverse_surface:I

.field public static m3_sys_color_dynamic_dark_on_background:I

.field public static m3_sys_color_dynamic_dark_on_error:I

.field public static m3_sys_color_dynamic_dark_on_error_container:I

.field public static m3_sys_color_dynamic_dark_on_primary:I

.field public static m3_sys_color_dynamic_dark_on_primary_container:I

.field public static m3_sys_color_dynamic_dark_on_secondary:I

.field public static m3_sys_color_dynamic_dark_on_secondary_container:I

.field public static m3_sys_color_dynamic_dark_on_surface:I

.field public static m3_sys_color_dynamic_dark_on_surface_variant:I

.field public static m3_sys_color_dynamic_dark_on_tertiary:I

.field public static m3_sys_color_dynamic_dark_on_tertiary_container:I

.field public static m3_sys_color_dynamic_dark_outline:I

.field public static m3_sys_color_dynamic_dark_outline_variant:I

.field public static m3_sys_color_dynamic_dark_primary:I

.field public static m3_sys_color_dynamic_dark_primary_container:I

.field public static m3_sys_color_dynamic_dark_secondary:I

.field public static m3_sys_color_dynamic_dark_secondary_container:I

.field public static m3_sys_color_dynamic_dark_surface:I

.field public static m3_sys_color_dynamic_dark_surface_bright:I

.field public static m3_sys_color_dynamic_dark_surface_container:I

.field public static m3_sys_color_dynamic_dark_surface_container_high:I

.field public static m3_sys_color_dynamic_dark_surface_container_highest:I

.field public static m3_sys_color_dynamic_dark_surface_container_low:I

.field public static m3_sys_color_dynamic_dark_surface_container_lowest:I

.field public static m3_sys_color_dynamic_dark_surface_dim:I

.field public static m3_sys_color_dynamic_dark_surface_variant:I

.field public static m3_sys_color_dynamic_dark_tertiary:I

.field public static m3_sys_color_dynamic_dark_tertiary_container:I

.field public static m3_sys_color_dynamic_light_background:I

.field public static m3_sys_color_dynamic_light_error:I

.field public static m3_sys_color_dynamic_light_error_container:I

.field public static m3_sys_color_dynamic_light_inverse_on_surface:I

.field public static m3_sys_color_dynamic_light_inverse_primary:I

.field public static m3_sys_color_dynamic_light_inverse_surface:I

.field public static m3_sys_color_dynamic_light_on_background:I

.field public static m3_sys_color_dynamic_light_on_error:I

.field public static m3_sys_color_dynamic_light_on_error_container:I

.field public static m3_sys_color_dynamic_light_on_primary:I

.field public static m3_sys_color_dynamic_light_on_primary_container:I

.field public static m3_sys_color_dynamic_light_on_secondary:I

.field public static m3_sys_color_dynamic_light_on_secondary_container:I

.field public static m3_sys_color_dynamic_light_on_surface:I

.field public static m3_sys_color_dynamic_light_on_surface_variant:I

.field public static m3_sys_color_dynamic_light_on_tertiary:I

.field public static m3_sys_color_dynamic_light_on_tertiary_container:I

.field public static m3_sys_color_dynamic_light_outline:I

.field public static m3_sys_color_dynamic_light_outline_variant:I

.field public static m3_sys_color_dynamic_light_primary:I

.field public static m3_sys_color_dynamic_light_primary_container:I

.field public static m3_sys_color_dynamic_light_secondary:I

.field public static m3_sys_color_dynamic_light_secondary_container:I

.field public static m3_sys_color_dynamic_light_surface:I

.field public static m3_sys_color_dynamic_light_surface_bright:I

.field public static m3_sys_color_dynamic_light_surface_container:I

.field public static m3_sys_color_dynamic_light_surface_container_high:I

.field public static m3_sys_color_dynamic_light_surface_container_highest:I

.field public static m3_sys_color_dynamic_light_surface_container_low:I

.field public static m3_sys_color_dynamic_light_surface_container_lowest:I

.field public static m3_sys_color_dynamic_light_surface_dim:I

.field public static m3_sys_color_dynamic_light_surface_variant:I

.field public static m3_sys_color_dynamic_light_tertiary:I

.field public static m3_sys_color_dynamic_light_tertiary_container:I

.field public static m3_sys_color_dynamic_on_primary_fixed:I

.field public static m3_sys_color_dynamic_on_primary_fixed_variant:I

.field public static m3_sys_color_dynamic_on_secondary_fixed:I

.field public static m3_sys_color_dynamic_on_secondary_fixed_variant:I

.field public static m3_sys_color_dynamic_on_tertiary_fixed:I

.field public static m3_sys_color_dynamic_on_tertiary_fixed_variant:I

.field public static m3_sys_color_dynamic_primary_fixed:I

.field public static m3_sys_color_dynamic_primary_fixed_dim:I

.field public static m3_sys_color_dynamic_secondary_fixed:I

.field public static m3_sys_color_dynamic_secondary_fixed_dim:I

.field public static m3_sys_color_dynamic_tertiary_fixed:I

.field public static m3_sys_color_dynamic_tertiary_fixed_dim:I

.field public static m3_sys_color_light_background:I

.field public static m3_sys_color_light_error:I

.field public static m3_sys_color_light_error_container:I

.field public static m3_sys_color_light_inverse_on_surface:I

.field public static m3_sys_color_light_inverse_primary:I

.field public static m3_sys_color_light_inverse_surface:I

.field public static m3_sys_color_light_on_background:I

.field public static m3_sys_color_light_on_error:I

.field public static m3_sys_color_light_on_error_container:I

.field public static m3_sys_color_light_on_primary:I

.field public static m3_sys_color_light_on_primary_container:I

.field public static m3_sys_color_light_on_secondary:I

.field public static m3_sys_color_light_on_secondary_container:I

.field public static m3_sys_color_light_on_surface:I

.field public static m3_sys_color_light_on_surface_variant:I

.field public static m3_sys_color_light_on_tertiary:I

.field public static m3_sys_color_light_on_tertiary_container:I

.field public static m3_sys_color_light_outline:I

.field public static m3_sys_color_light_outline_variant:I

.field public static m3_sys_color_light_primary:I

.field public static m3_sys_color_light_primary_container:I

.field public static m3_sys_color_light_secondary:I

.field public static m3_sys_color_light_secondary_container:I

.field public static m3_sys_color_light_surface:I

.field public static m3_sys_color_light_surface_bright:I

.field public static m3_sys_color_light_surface_container:I

.field public static m3_sys_color_light_surface_container_high:I

.field public static m3_sys_color_light_surface_container_highest:I

.field public static m3_sys_color_light_surface_container_low:I

.field public static m3_sys_color_light_surface_container_lowest:I

.field public static m3_sys_color_light_surface_dim:I

.field public static m3_sys_color_light_surface_variant:I

.field public static m3_sys_color_light_tertiary:I

.field public static m3_sys_color_light_tertiary_container:I

.field public static m3_sys_color_on_primary_fixed:I

.field public static m3_sys_color_on_primary_fixed_variant:I

.field public static m3_sys_color_on_secondary_fixed:I

.field public static m3_sys_color_on_secondary_fixed_variant:I

.field public static m3_sys_color_on_tertiary_fixed:I

.field public static m3_sys_color_on_tertiary_fixed_variant:I

.field public static m3_sys_color_primary_fixed:I

.field public static m3_sys_color_primary_fixed_dim:I

.field public static m3_sys_color_secondary_fixed:I

.field public static m3_sys_color_secondary_fixed_dim:I

.field public static m3_sys_color_tertiary_fixed:I

.field public static m3_sys_color_tertiary_fixed_dim:I

.field public static m3_tabs_icon_color:I

.field public static m3_tabs_icon_color_secondary:I

.field public static m3_tabs_ripple_color:I

.field public static m3_tabs_ripple_color_secondary:I

.field public static m3_tabs_text_color:I

.field public static m3_tabs_text_color_secondary:I

.field public static m3_text_button_background_color_selector:I

.field public static m3_text_button_foreground_color_selector:I

.field public static m3_text_button_ripple_color_selector:I

.field public static m3_textfield_filled_background_color:I

.field public static m3_textfield_indicator_text_color:I

.field public static m3_textfield_input_text_color:I

.field public static m3_textfield_label_color:I

.field public static m3_textfield_stroke_color:I

.field public static m3_timepicker_button_background_color:I

.field public static m3_timepicker_button_ripple_color:I

.field public static m3_timepicker_button_text_color:I

.field public static m3_timepicker_clock_text_color:I

.field public static m3_timepicker_display_background_color:I

.field public static m3_timepicker_display_ripple_color:I

.field public static m3_timepicker_display_text_color:I

.field public static m3_timepicker_secondary_text_button_ripple_color:I

.field public static m3_timepicker_secondary_text_button_text_color:I

.field public static m3_timepicker_time_input_stroke_color:I

.field public static m3_tonal_button_ripple_color_selector:I

.field public static materialColorOnPrimaryFixed:I

.field public static materialColorPrimaryFixed:I

.field public static materialColorSurfaceBright:I

.field public static materialColorSurfaceDim:I

.field public static material_blue_grey_800:I

.field public static material_blue_grey_900:I

.field public static material_blue_grey_950:I

.field public static material_color_error_container:I

.field public static material_color_on_background:I

.field public static material_color_on_error:I

.field public static material_color_on_error_container:I

.field public static material_color_on_primary:I

.field public static material_color_on_primary_container:I

.field public static material_color_on_primary_fixed:I

.field public static material_color_on_primary_fixed_variant:I

.field public static material_color_on_secondary:I

.field public static material_color_on_secondary_container:I

.field public static material_color_on_secondary_fixed:I

.field public static material_color_on_secondary_fixed_variant:I

.field public static material_color_on_surface:I

.field public static material_color_on_surface_inverse:I

.field public static material_color_on_surface_variant:I

.field public static material_color_on_tertiary:I

.field public static material_color_on_tertiary_container:I

.field public static material_color_on_tertiary_fixed:I

.field public static material_color_on_tertiary_fixed_variant:I

.field public static material_color_outline:I

.field public static material_color_outline_variant:I

.field public static material_color_primary:I

.field public static material_color_primary_container:I

.field public static material_color_primary_fixed:I

.field public static material_color_primary_fixed_dim:I

.field public static material_color_primary_inverse:I

.field public static material_color_secondary:I

.field public static material_color_secondary_container:I

.field public static material_color_secondary_fixed:I

.field public static material_color_secondary_fixed_dim:I

.field public static material_color_surface:I

.field public static material_color_surface_bright:I

.field public static material_color_surface_container:I

.field public static material_color_surface_container_high:I

.field public static material_color_surface_container_highest:I

.field public static material_color_surface_container_low:I

.field public static material_color_surface_container_lowest:I

.field public static material_color_surface_dim:I

.field public static material_color_surface_inverse:I

.field public static material_color_surface_variant:I

.field public static material_color_tertiary:I

.field public static material_color_tertiary_container:I

.field public static material_color_tertiary_fixed:I

.field public static material_color_tertiary_fixed_dim:I

.field public static material_cursor_color:I

.field public static material_deep_teal_200:I

.field public static material_deep_teal_500:I

.field public static material_divider_color:I

.field public static material_dynamic_color_dark_error:I

.field public static material_dynamic_color_dark_error_container:I

.field public static material_dynamic_color_dark_on_error:I

.field public static material_dynamic_color_dark_on_error_container:I

.field public static material_dynamic_color_light_error:I

.field public static material_dynamic_color_light_error_container:I

.field public static material_dynamic_color_light_on_error:I

.field public static material_dynamic_color_light_on_error_container:I

.field public static material_dynamic_neutral0:I

.field public static material_dynamic_neutral10:I

.field public static material_dynamic_neutral100:I

.field public static material_dynamic_neutral20:I

.field public static material_dynamic_neutral30:I

.field public static material_dynamic_neutral40:I

.field public static material_dynamic_neutral50:I

.field public static material_dynamic_neutral60:I

.field public static material_dynamic_neutral70:I

.field public static material_dynamic_neutral80:I

.field public static material_dynamic_neutral90:I

.field public static material_dynamic_neutral95:I

.field public static material_dynamic_neutral99:I

.field public static material_dynamic_neutral_variant0:I

.field public static material_dynamic_neutral_variant10:I

.field public static material_dynamic_neutral_variant100:I

.field public static material_dynamic_neutral_variant20:I

.field public static material_dynamic_neutral_variant30:I

.field public static material_dynamic_neutral_variant40:I

.field public static material_dynamic_neutral_variant50:I

.field public static material_dynamic_neutral_variant60:I

.field public static material_dynamic_neutral_variant70:I

.field public static material_dynamic_neutral_variant80:I

.field public static material_dynamic_neutral_variant90:I

.field public static material_dynamic_neutral_variant95:I

.field public static material_dynamic_neutral_variant99:I

.field public static material_dynamic_primary0:I

.field public static material_dynamic_primary10:I

.field public static material_dynamic_primary100:I

.field public static material_dynamic_primary20:I

.field public static material_dynamic_primary30:I

.field public static material_dynamic_primary40:I

.field public static material_dynamic_primary50:I

.field public static material_dynamic_primary60:I

.field public static material_dynamic_primary70:I

.field public static material_dynamic_primary80:I

.field public static material_dynamic_primary90:I

.field public static material_dynamic_primary95:I

.field public static material_dynamic_primary99:I

.field public static material_dynamic_secondary0:I

.field public static material_dynamic_secondary10:I

.field public static material_dynamic_secondary100:I

.field public static material_dynamic_secondary20:I

.field public static material_dynamic_secondary30:I

.field public static material_dynamic_secondary40:I

.field public static material_dynamic_secondary50:I

.field public static material_dynamic_secondary60:I

.field public static material_dynamic_secondary70:I

.field public static material_dynamic_secondary80:I

.field public static material_dynamic_secondary90:I

.field public static material_dynamic_secondary95:I

.field public static material_dynamic_secondary99:I

.field public static material_dynamic_tertiary0:I

.field public static material_dynamic_tertiary10:I

.field public static material_dynamic_tertiary100:I

.field public static material_dynamic_tertiary20:I

.field public static material_dynamic_tertiary30:I

.field public static material_dynamic_tertiary40:I

.field public static material_dynamic_tertiary50:I

.field public static material_dynamic_tertiary60:I

.field public static material_dynamic_tertiary70:I

.field public static material_dynamic_tertiary80:I

.field public static material_dynamic_tertiary90:I

.field public static material_dynamic_tertiary95:I

.field public static material_dynamic_tertiary99:I

.field public static material_grey_100:I

.field public static material_grey_300:I

.field public static material_grey_50:I

.field public static material_grey_600:I

.field public static material_grey_800:I

.field public static material_grey_850:I

.field public static material_grey_900:I

.field public static material_harmonized_color_error:I

.field public static material_harmonized_color_error_container:I

.field public static material_harmonized_color_on_error:I

.field public static material_harmonized_color_on_error_container:I

.field public static material_on_background_disabled:I

.field public static material_on_background_emphasis_high_type:I

.field public static material_on_background_emphasis_medium:I

.field public static material_on_primary_disabled:I

.field public static material_on_primary_emphasis_high_type:I

.field public static material_on_primary_emphasis_medium:I

.field public static material_on_surface_disabled:I

.field public static material_on_surface_emphasis_high_type:I

.field public static material_on_surface_emphasis_medium:I

.field public static material_on_surface_stroke:I

.field public static material_personalized__highlighted_text:I

.field public static material_personalized__highlighted_text_inverse:I

.field public static material_personalized_color_background:I

.field public static material_personalized_color_control_activated:I

.field public static material_personalized_color_control_highlight:I

.field public static material_personalized_color_control_normal:I

.field public static material_personalized_color_error:I

.field public static material_personalized_color_error_container:I

.field public static material_personalized_color_on_background:I

.field public static material_personalized_color_on_error:I

.field public static material_personalized_color_on_error_container:I

.field public static material_personalized_color_on_primary:I

.field public static material_personalized_color_on_primary_container:I

.field public static material_personalized_color_on_secondary:I

.field public static material_personalized_color_on_secondary_container:I

.field public static material_personalized_color_on_surface:I

.field public static material_personalized_color_on_surface_inverse:I

.field public static material_personalized_color_on_surface_variant:I

.field public static material_personalized_color_on_tertiary:I

.field public static material_personalized_color_on_tertiary_container:I

.field public static material_personalized_color_outline:I

.field public static material_personalized_color_outline_variant:I

.field public static material_personalized_color_primary:I

.field public static material_personalized_color_primary_container:I

.field public static material_personalized_color_primary_inverse:I

.field public static material_personalized_color_primary_text:I

.field public static material_personalized_color_primary_text_inverse:I

.field public static material_personalized_color_secondary:I

.field public static material_personalized_color_secondary_container:I

.field public static material_personalized_color_secondary_text:I

.field public static material_personalized_color_secondary_text_inverse:I

.field public static material_personalized_color_surface:I

.field public static material_personalized_color_surface_bright:I

.field public static material_personalized_color_surface_container:I

.field public static material_personalized_color_surface_container_high:I

.field public static material_personalized_color_surface_container_highest:I

.field public static material_personalized_color_surface_container_low:I

.field public static material_personalized_color_surface_container_lowest:I

.field public static material_personalized_color_surface_dim:I

.field public static material_personalized_color_surface_inverse:I

.field public static material_personalized_color_surface_variant:I

.field public static material_personalized_color_tertiary:I

.field public static material_personalized_color_tertiary_container:I

.field public static material_personalized_color_text_hint_foreground_inverse:I

.field public static material_personalized_color_text_primary_inverse:I

.field public static material_personalized_color_text_primary_inverse_disable_only:I

.field public static material_personalized_color_text_secondary_and_tertiary_inverse:I

.field public static material_personalized_color_text_secondary_and_tertiary_inverse_disabled:I

.field public static material_personalized_hint_foreground:I

.field public static material_personalized_hint_foreground_inverse:I

.field public static material_personalized_primary_inverse_text_disable_only:I

.field public static material_personalized_primary_text_disable_only:I

.field public static material_slider_active_tick_marks_color:I

.field public static material_slider_active_track_color:I

.field public static material_slider_halo_color:I

.field public static material_slider_inactive_tick_marks_color:I

.field public static material_slider_inactive_track_color:I

.field public static material_slider_thumb_color:I

.field public static material_timepicker_button_background:I

.field public static material_timepicker_button_stroke:I

.field public static material_timepicker_clock_text_color:I

.field public static material_timepicker_clockface:I

.field public static material_timepicker_modebutton_tint:I

.field public static menu_item_hover_state_color:I

.field public static mock_app_icon:I

.field public static mock_conversation_background:I

.field public static mock_conversation_message_input:I

.field public static mock_conversation_profile_icon:I

.field public static mock_conversation_received_message:I

.field public static mock_conversation_sent_message:I

.field public static mock_conversation_top_bar:I

.field public static mock_conversation_top_bar_item:I

.field public static mock_list_background:I

.field public static mock_list_button:I

.field public static mock_list_preview_message:I

.field public static mock_list_profile_icon:I

.field public static mock_list_top_bar:I

.field public static mock_list_top_bar_item:I

.field public static mock_search_bar:I

.field public static mock_webpage_background:I

.field public static mock_webpage_page_text:I

.field public static mock_webpage_top_bar:I

.field public static mock_webpage_top_bar_item:I

.field public static mock_webpage_url_bar:I

.field public static mock_webpage_url_bar_item:I

.field public static moto_accents_on_primary:I

.field public static moto_accents_primary:I

.field public static mtrl_btn_bg_color_selector:I

.field public static mtrl_btn_ripple_color:I

.field public static mtrl_btn_stroke_color_selector:I

.field public static mtrl_btn_text_btn_bg_color_selector:I

.field public static mtrl_btn_text_btn_ripple_color:I

.field public static mtrl_btn_text_color_disabled:I

.field public static mtrl_btn_text_color_selector:I

.field public static mtrl_btn_transparent_bg_color:I

.field public static mtrl_calendar_item_stroke_color:I

.field public static mtrl_calendar_selected_range:I

.field public static mtrl_card_view_foreground:I

.field public static mtrl_card_view_ripple:I

.field public static mtrl_chip_background_color:I

.field public static mtrl_chip_close_icon_tint:I

.field public static mtrl_chip_surface_color:I

.field public static mtrl_chip_text_color:I

.field public static mtrl_choice_chip_background_color:I

.field public static mtrl_choice_chip_ripple_color:I

.field public static mtrl_choice_chip_text_color:I

.field public static mtrl_error:I

.field public static mtrl_fab_bg_color_selector:I

.field public static mtrl_fab_icon_text_color_selector:I

.field public static mtrl_fab_ripple_color:I

.field public static mtrl_filled_background_color:I

.field public static mtrl_filled_icon_tint:I

.field public static mtrl_filled_stroke_color:I

.field public static mtrl_indicator_text_color:I

.field public static mtrl_navigation_bar_colored_item_tint:I

.field public static mtrl_navigation_bar_colored_ripple_color:I

.field public static mtrl_navigation_bar_item_tint:I

.field public static mtrl_navigation_bar_ripple_color:I

.field public static mtrl_navigation_item_background_color:I

.field public static mtrl_navigation_item_icon_tint:I

.field public static mtrl_navigation_item_text_color:I

.field public static mtrl_on_primary_text_btn_text_color_selector:I

.field public static mtrl_on_surface_ripple_color:I

.field public static mtrl_outlined_icon_tint:I

.field public static mtrl_outlined_stroke_color:I

.field public static mtrl_popupmenu_overlay_color:I

.field public static mtrl_scrim_color:I

.field public static mtrl_switch_thumb_icon_tint:I

.field public static mtrl_switch_thumb_tint:I

.field public static mtrl_switch_track_decoration_tint:I

.field public static mtrl_switch_track_tint:I

.field public static mtrl_tabs_colored_ripple_color:I

.field public static mtrl_tabs_icon_color_selector:I

.field public static mtrl_tabs_icon_color_selector_colored:I

.field public static mtrl_tabs_legacy_text_color_selector:I

.field public static mtrl_tabs_ripple_color:I

.field public static mtrl_text_btn_text_color_selector:I

.field public static mtrl_textinput_default_box_stroke_color:I

.field public static mtrl_textinput_disabled_color:I

.field public static mtrl_textinput_filled_box_default_background_color:I

.field public static mtrl_textinput_focused_box_stroke_color:I

.field public static mtrl_textinput_hovered_box_stroke_color:I

.field public static n1_20:I

.field public static n1_30:I

.field public static n1_40:I

.field public static n1_60:I

.field public static n1_830:I

.field public static n1_880:I

.field public static n1_940:I

.field public static n1_960:I

.field public static n2_130:I

.field public static n2_750:I

.field public static notification_action_color_filter:I

.field public static notification_dot_color_dark:I

.field public static notification_dot_color_light:I

.field public static notification_icon_bg_color:I

.field public static notification_icon_default_color:I

.field public static outline_button_text:I

.field public static overlay_tab_indicator_color:I

.field public static overlay_tab_text:I

.field public static overview_button:I

.field public static overview_button_prc:I

.field public static overview_clear_all_button:I

.field public static overview_clear_all_button_prc:I

.field public static overview_foreground_scrim_color:I

.field public static overview_left_clear_all:I

.field public static overview_left_clear_all_pure_bg:I

.field public static overview_locked_bg:I

.field public static overview_locked_bg_prc:I

.field public static overview_locked_icon:I

.field public static overview_scrim:I

.field public static overview_scrim_dark:I

.field public static page_indicator_dot_color_dark:I

.field public static page_indicator_dot_color_light:I

.field public static pagination_indicator_dot_color_dark:I

.field public static pagination_indicator_dot_color_light:I

.field public static popup_color_background:I

.field public static popup_color_neutral_dark:I

.field public static popup_color_primary_dark:I

.field public static popup_color_primary_light:I

.field public static popup_color_secondary_dark:I

.field public static popup_color_secondary_light:I

.field public static popup_color_tertiary_dark:I

.field public static popup_color_tertiary_light:I

.field public static popup_notification_dot_dark:I

.field public static popup_notification_dot_light:I

.field public static popup_shade_first:I

.field public static popup_shade_first_dark:I

.field public static popup_shade_first_light:I

.field public static popup_shade_second:I

.field public static popup_shade_second_dark:I

.field public static popup_shade_second_light:I

.field public static popup_shade_third:I

.field public static popup_shade_third_dark:I

.field public static popup_shade_third_light:I

.field public static popup_text_color_dark:I

.field public static popup_text_color_light:I

.field public static preference_fallback_accent_color:I

.field public static preload_icon_accent_color_dark:I

.field public static preload_icon_accent_color_light:I

.field public static preload_icon_background_color_dark:I

.field public static preload_icon_background_color_light:I

.field public static primary_dark_material_dark:I

.field public static primary_dark_material_light:I

.field public static primary_material_dark:I

.field public static primary_material_light:I

.field public static primary_text_default_material_dark:I

.field public static primary_text_default_material_light:I

.field public static primary_text_disabled_material_dark:I

.field public static primary_text_disabled_material_light:I

.field public static recent_arrow_btn:I

.field public static recent_arrow_btn_prc:I

.field public static recent_blur:I

.field public static recent_btn_bg:I

.field public static recent_btn_bg_prc:I

.field public static recent_btn_bg_pressed:I

.field public static recent_btn_content:I

.field public static recent_btn_content_disabled:I

.field public static recent_btn_content_disabled_prc:I

.field public static recent_btn_content_prc:I

.field public static recent_btn_content_pressed:I

.field public static recent_clear_all_btn_content:I

.field public static recent_clear_all_btn_content_prc:I

.field public static recent_empty_msg_icon:I

.field public static recent_empty_msg_icon_color:I

.field public static recent_empty_msg_icon_color_prc:I

.field public static recent_empty_msg_icon_prc:I

.field public static recent_empty_msg_text_prc:I

.field public static recent_lock:I

.field public static recent_lock_circle:I

.field public static recent_lock_hint:I

.field public static recent_lock_hint_text_color:I

.field public static recent_lock_hint_text_color_prc:I

.field public static recent_locked_app_btn:I

.field public static recent_locked_app_btn_prc:I

.field public static recent_locked_bg:I

.field public static recent_locked_bg_prc:I

.field public static recent_locked_content:I

.field public static recent_locked_content_prc:I

.field public static recent_locked_icon:I

.field public static recent_tooltip_close_btn:I

.field public static recents_filter_icon:I

.field public static ripple_material_dark:I

.field public static ripple_material_light:I

.field public static search_bar_container_dark:I

.field public static search_bar_container_light:I

.field public static search_bar_text_dark:I

.field public static search_bar_text_hint_dark:I

.field public static search_bar_text_hint_light:I

.field public static search_bar_text_light:I

.field public static secondary_text_default_material_dark:I

.field public static secondary_text_default_material_light:I

.field public static secondary_text_disabled_material_dark:I

.field public static secondary_text_disabled_material_light:I

.field public static selector_switch_thumb_color:I

.field public static selector_switch_trace_color:I

.field public static sensi_on_primary:I

.field public static sensi_outline:I

.field public static sensi_primary:I

.field public static sensi_seekbar_thumb_active_color:I

.field public static sensi_seekbar_thumb_disabled_color:I

.field public static sensi_seekbar_tickmark_color:I

.field public static sensi_seekbar_track_color:I

.field public static sensi_seekbar_track_disabled_color:I

.field public static setting_option_icon_color:I

.field public static setting_option_icon_color_selector:I

.field public static setting_option_summary_color:I

.field public static setting_option_title_color:I

.field public static settings_accent_color:I

.field public static settings_screen_color:I

.field public static settings_toolbar_title:I

.field public static settingslib_accent_device_default_dark:I

.field public static settingslib_accent_device_default_light:I

.field public static settingslib_accent_primary_device_default:I

.field public static settingslib_accent_primary_variant:I

.field public static settingslib_accent_secondary_device_default:I

.field public static settingslib_background_color_accent:I

.field public static settingslib_background_color_accent_dark:I

.field public static settingslib_background_color_accent_light:I

.field public static settingslib_background_device_default_dark:I

.field public static settingslib_background_device_default_light:I

.field public static settingslib_colorAccentPrimary:I

.field public static settingslib_colorAccentSecondary:I

.field public static settingslib_colorBackgroundLevel_high:I

.field public static settingslib_colorBackgroundLevel_low:I

.field public static settingslib_colorBackgroundLevel_medium:I

.field public static settingslib_colorContentLevel_high:I

.field public static settingslib_colorContentLevel_low:I

.field public static settingslib_colorContentLevel_medium:I

.field public static settingslib_colorSurface:I

.field public static settingslib_colorSurfaceHeader:I

.field public static settingslib_colorSurfaceVariant:I

.field public static settingslib_dialog_accent:I

.field public static settingslib_dialog_accent_dark:I

.field public static settingslib_dialog_accent_light:I

.field public static settingslib_dialog_background:I

.field public static settingslib_dialog_background_dark:I

.field public static settingslib_dialog_background_light:I

.field public static settingslib_dialog_colorError:I

.field public static settingslib_dialog_colorError_dark:I

.field public static settingslib_dialog_colorError_light:I

.field public static settingslib_dialog_filled_text_color:I

.field public static settingslib_dialog_filled_text_dark:I

.field public static settingslib_dialog_filled_text_light:I

.field public static settingslib_dialog_outline_color_control:I

.field public static settingslib_error_0:I

.field public static settingslib_error_10:I

.field public static settingslib_error_100:I

.field public static settingslib_error_1000:I

.field public static settingslib_error_200:I

.field public static settingslib_error_300:I

.field public static settingslib_error_400:I

.field public static settingslib_error_50:I

.field public static settingslib_error_500:I

.field public static settingslib_error_600:I

.field public static settingslib_error_700:I

.field public static settingslib_error_800:I

.field public static settingslib_error_900:I

.field public static settingslib_expressive_button_outline_color_selector:I

.field public static settingslib_expressive_button_outlined_background_color_selector:I

.field public static settingslib_expressive_color_main_switch_track:I

.field public static settingslib_expressive_filled_button_color:I

.field public static settingslib_list_divider_color:I

.field public static settingslib_materialColorBackground:I

.field public static settingslib_materialColorError:I

.field public static settingslib_materialColorErrorContainer:I

.field public static settingslib_materialColorOnBackground:I

.field public static settingslib_materialColorOnError:I

.field public static settingslib_materialColorOnErrorContainer:I

.field public static settingslib_materialColorOnPrimary:I

.field public static settingslib_materialColorOnPrimaryContainer:I

.field public static settingslib_materialColorOnPrimaryFixed:I

.field public static settingslib_materialColorOnPrimaryFixedVariant:I

.field public static settingslib_materialColorOnSecondary:I

.field public static settingslib_materialColorOnSecondaryContainer:I

.field public static settingslib_materialColorOnSecondaryFixed:I

.field public static settingslib_materialColorOnSecondaryFixedVariant:I

.field public static settingslib_materialColorOnSurface:I

.field public static settingslib_materialColorOnSurfaceInverse:I

.field public static settingslib_materialColorOnSurfaceVariant:I

.field public static settingslib_materialColorOnTertiary:I

.field public static settingslib_materialColorOnTertiaryContainer:I

.field public static settingslib_materialColorOnTertiaryFixed:I

.field public static settingslib_materialColorOnTertiaryFixedVariant:I

.field public static settingslib_materialColorOutline:I

.field public static settingslib_materialColorOutlineVariant:I

.field public static settingslib_materialColorPrimary:I

.field public static settingslib_materialColorPrimaryContainer:I

.field public static settingslib_materialColorPrimaryFixed:I

.field public static settingslib_materialColorPrimaryFixedDim:I

.field public static settingslib_materialColorPrimaryInverse:I

.field public static settingslib_materialColorSecondary:I

.field public static settingslib_materialColorSecondaryContainer:I

.field public static settingslib_materialColorSecondaryFixed:I

.field public static settingslib_materialColorSecondaryFixedDim:I

.field public static settingslib_materialColorSurface:I

.field public static settingslib_materialColorSurfaceBright:I

.field public static settingslib_materialColorSurfaceContainer:I

.field public static settingslib_materialColorSurfaceContainerHigh:I

.field public static settingslib_materialColorSurfaceContainerHighest:I

.field public static settingslib_materialColorSurfaceContainerLow:I

.field public static settingslib_materialColorSurfaceContainerLowest:I

.field public static settingslib_materialColorSurfaceDim:I

.field public static settingslib_materialColorSurfaceInverse:I

.field public static settingslib_materialColorSurfaceVariant:I

.field public static settingslib_materialColorTertiary:I

.field public static settingslib_materialColorTertiaryContainer:I

.field public static settingslib_materialColorTertiaryFixed:I

.field public static settingslib_materialColorTertiaryFixedDim:I

.field public static settingslib_neutral_variant12:I

.field public static settingslib_neutral_variant17:I

.field public static settingslib_neutral_variant22:I

.field public static settingslib_neutral_variant24:I

.field public static settingslib_neutral_variant4:I

.field public static settingslib_neutral_variant55:I

.field public static settingslib_neutral_variant6:I

.field public static settingslib_neutral_variant87:I

.field public static settingslib_neutral_variant92:I

.field public static settingslib_neutral_variant94:I

.field public static settingslib_neutral_variant96:I

.field public static settingslib_neutral_variant98:I

.field public static settingslib_preference_bg_color:I

.field public static settingslib_primary_dark_device_default_settings:I

.field public static settingslib_primary_device_default_settings_light:I

.field public static settingslib_ripple_color:I

.field public static settingslib_spinner_dropdown_color:I

.field public static settingslib_spinner_title_color:I

.field public static settingslib_state_off_color:I

.field public static settingslib_state_on_color:I

.field public static settingslib_surface_dark:I

.field public static settingslib_surface_light:I

.field public static settingslib_switch_thumb_color:I

.field public static settingslib_switch_track_color:I

.field public static settingslib_switch_track_off:I

.field public static settingslib_switch_track_on:I

.field public static settingslib_switch_track_outline_color:I

.field public static settingslib_text_color_accent:I

.field public static settingslib_text_color_accent_dark:I

.field public static settingslib_text_color_accent_light:I

.field public static settingslib_text_color_preference_category_title:I

.field public static settingslib_text_color_primary:I

.field public static settingslib_text_color_primary_dark:I

.field public static settingslib_text_color_primary_device_default:I

.field public static settingslib_text_color_primary_device_default_dark:I

.field public static settingslib_text_color_primary_device_default_light:I

.field public static settingslib_text_color_secondary:I

.field public static settingslib_text_color_secondary_dark:I

.field public static settingslib_text_color_secondary_device_default:I

.field public static settingslib_text_color_secondary_device_default_dark:I

.field public static settingslib_text_color_secondary_device_default_light:I

.field public static settingslib_thumb_disabled_color:I

.field public static settingslib_thumb_off_color:I

.field public static settingslib_thumb_on_color:I

.field public static settingslib_track_off_color:I

.field public static settingslib_track_on_color:I

.field public static settingslib_track_online_color:I

.field public static shape_button_press:I

.field public static shape_button_press_ripple:I

.field public static sp_extra_action_font_color:I

.field public static sp_extra_action_outline_color:I

.field public static sp_smart_card_bg_opaque_color:I

.field public static spring_loaded_highlighted_panel_border_color:I

.field public static spring_loaded_panel_color:I

.field public static stream_app_text_color:I

.field public static stream_app_text_color_row:I

.field public static surface:I

.field public static switch_compat_close_color:I

.field public static switch_compat_close_track_color:I

.field public static switch_compat_open_color:I

.field public static switch_compat_open_track_color:I

.field public static switch_compat_track:I

.field public static switch_item_bg:I

.field public static switch_thumb_disabled_material_dark:I

.field public static switch_thumb_disabled_material_light:I

.field public static switch_thumb_material_dark:I

.field public static switch_thumb_material_light:I

.field public static switch_thumb_normal_material_dark:I

.field public static switch_thumb_normal_material_light:I

.field public static system_on_primary_fixed:I

.field public static system_primary_fixed:I

.field public static system_shortcut_bg_dark:I

.field public static system_shortcut_bg_light:I

.field public static system_shortcut_text:I

.field public static system_surface_bright_dark:I

.field public static system_surface_bright_light:I

.field public static system_surface_dim_dark:I

.field public static system_surface_dim_light:I

.field public static taskbar_background:I

.field public static taskbar_background_dark:I

.field public static taskbar_divider_background:I

.field public static taskbar_edu_button_color:I

.field public static taskbar_nav_icon_dark_color:I

.field public static taskbar_nav_icon_dark_color_on_home:I

.field public static taskbar_nav_icon_light_color:I

.field public static taskbar_nav_icon_light_color_on_home:I

.field public static taskbar_nav_icon_selection_ripple:I

.field public static taskbar_running_app_indicator_color:I

.field public static taskbar_stashed_handle_dark_color:I

.field public static taskbar_stashed_handle_light_color:I

.field public static taskbar_stroke:I

.field public static textColorOnAccent:I

.field public static text_color_on_accent_device_default:I

.field public static text_color_primary_dark:I

.field public static text_color_secondary_dark:I

.field public static text_color_tertiary_dark:I

.field public static themed_badge_icon_background_color:I

.field public static themed_badge_icon_color:I

.field public static themed_icon_background_color:I

.field public static themed_icon_color:I

.field public static tooltip_background_dark:I

.field public static tooltip_background_light:I

.field public static transient_taskbar_background:I

.field public static transparent_bg:I

.field public static uninstall_target_hover_tint:I

.field public static wallpaper_popup_scrim:I

.field public static widget_cell_subtitle_color_dark:I

.field public static widget_cell_subtitle_color_light:I

.field public static widget_cell_title_color_dark:I

.field public static widget_cell_title_color_light:I

.field public static widget_desc:I

.field public static widget_name:I

.field public static widget_picker_add_button_background_color_dark:I

.field public static widget_picker_add_button_background_color_light:I

.field public static widget_picker_add_button_text_color_dark:I

.field public static widget_picker_add_button_text_color_light:I

.field public static widget_picker_collapse_handle_color_dark:I

.field public static widget_picker_collapse_handle_color_light:I

.field public static widget_picker_header_app_subtitle_color_dark:I

.field public static widget_picker_header_app_subtitle_color_light:I

.field public static widget_picker_header_app_title_color_dark:I

.field public static widget_picker_header_app_title_color_light:I

.field public static widget_picker_header_background_color_dark:I

.field public static widget_picker_header_background_color_light:I

.field public static widget_picker_primary_surface_color_dark:I

.field public static widget_picker_primary_surface_color_light:I

.field public static widget_picker_search_text_color_dark:I

.field public static widget_picker_search_text_color_light:I

.field public static widget_picker_secondary_surface_color_dark:I

.field public static widget_picker_secondary_surface_color_light:I

.field public static widget_picker_selected_tab_text_color_dark:I

.field public static widget_picker_selected_tab_text_color_light:I

.field public static widget_picker_suggestions_icon_background_color_dark:I

.field public static widget_picker_suggestions_icon_background_color_light:I

.field public static widget_picker_suggestions_icon_color_dark:I

.field public static widget_picker_suggestions_icon_color_light:I

.field public static widget_picker_tab_background_selected_dark:I

.field public static widget_picker_tab_background_selected_light:I

.field public static widget_picker_tab_background_unselected_dark:I

.field public static widget_picker_tab_background_unselected_light:I

.field public static widget_picker_tab_text:I

.field public static widget_picker_title_color_dark:I

.field public static widget_picker_title_color_light:I

.field public static widget_picker_unselected_tab_text_color_dark:I

.field public static widget_picker_unselected_tab_text_color_light:I

.field public static widget_scrim:I

.field public static widget_search_text:I

.field public static widget_solid_bg:I

.field public static widget_solid_handle:I

.field public static widget_solid_recommend_bg:I

.field public static widget_solid_search_bg:I

.field public static widget_solid_thumb:I

.field public static widget_solid_title:I

.field public static widget_stack_edit_btn_bg:I

.field public static widget_stack_edit_btn_text:I

.field public static widget_stack_edit_scrim:I

.field public static widget_stack_solid_edit_btn_bg:I

.field public static widget_stack_solid_edit_btn_text:I

.field public static widget_surface:I

.field public static widget_thumb:I

.field public static widget_title:I

.field public static widgets_picker_scrim:I

.field public static work_fab_bg_color:I

.field public static work_fab_icon_color:I

.field public static work_turn_on_stroke:I

.field public static workspace_accent_color_dark:I

.field public static workspace_accent_color_light:I

.field public static workspace_surface_color:I

.field public static workspace_text_color_dark:I

.field public static workspace_text_color_light:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 13709
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
