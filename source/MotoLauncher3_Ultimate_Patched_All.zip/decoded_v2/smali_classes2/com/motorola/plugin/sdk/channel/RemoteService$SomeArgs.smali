.class final Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;
.super Ljava/lang/Object;
.source "RemoteService.java"


# static fields
.field private static final MAX_POOL_SIZE:I = 0xa

.field static final WAIT_FINISHED:I = 0x2

.field static final WAIT_NONE:I = 0x0

.field static final WAIT_WAITING:I = 0x1

.field private static sPool:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

.field private static final sPoolLock:Ljava/lang/Object;

.field private static sPoolSize:I


# instance fields
.field public arg1:Ljava/lang/Object;

.field public arg2:Ljava/lang/Object;

.field public argI1:I

.field public argI2:I

.field private mInPool:Z

.field private mNext:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

.field mWaitState:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 564
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolLock:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 575
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 571
    iput v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mWaitState:I

    return-void
.end method

.method private clear()V
    .locals 1

    const/4 v0, 0x0

    .line 623
    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    .line 624
    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    const/4 v0, 0x0

    .line 625
    iput v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->argI1:I

    .line 626
    iput v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->argI2:I

    return-void
.end method

.method public static obtain()Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;
    .locals 4

    .line 580
    sget-object v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolLock:Ljava/lang/Object;

    monitor-enter v0

    .line 581
    :try_start_0
    sget v1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolSize:I

    if-lez v1, :cond_0

    .line 582
    sget-object v2, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPool:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 583
    iget-object v3, v2, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mNext:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    sput-object v3, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPool:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    const/4 v3, 0x0

    .line 584
    iput-object v3, v2, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mNext:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    const/4 v3, 0x0

    .line 585
    iput-boolean v3, v2, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mInPool:Z

    add-int/lit8 v1, v1, -0x1

    .line 586
    sput v1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolSize:I

    .line 587
    monitor-exit v0

    return-object v2

    :catchall_0
    move-exception v1

    goto :goto_0

    .line 589
    :cond_0
    new-instance v1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    invoke-direct {v1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;-><init>()V

    monitor-exit v0

    return-object v1

    .line 591
    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method


# virtual methods
.method public complete()V
    .locals 2

    .line 595
    monitor-enter p0

    .line 596
    :try_start_0
    iget v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mWaitState:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 v0, 0x2

    .line 599
    iput v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mWaitState:I

    .line 600
    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V

    .line 601
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    goto :goto_0

    .line 597
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Not waiting"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 601
    :goto_0
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public recycle()V
    .locals 3

    .line 605
    iget-boolean v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mInPool:Z

    if-nez v0, :cond_2

    .line 608
    iget v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mWaitState:I

    if-eqz v0, :cond_0

    return-void

    .line 611
    :cond_0
    sget-object v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolLock:Ljava/lang/Object;

    monitor-enter v0

    .line 612
    :try_start_0
    invoke-direct {p0}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->clear()V

    .line 613
    sget v1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolSize:I

    const/16 v2, 0xa

    if-ge v1, v2, :cond_1

    .line 614
    sget-object v2, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPool:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    iput-object v2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mNext:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    const/4 v2, 0x1

    .line 615
    iput-boolean v2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->mInPool:Z

    .line 616
    sput-object p0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPool:Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    add-int/2addr v1, v2

    .line 617
    sput v1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->sPoolSize:I

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 619
    :cond_1
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 606
    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Already recycled."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
