.class public abstract Lcom/motorola/plugin/sdk/channel/RemoteService;
.super Landroid/app/Service;
.source "RemoteService.java"


# annotations
.annotation runtime Lcom/motorola/plugin/sdk/annotations/ProvidesInterface;
    version = 0xc1d
.end annotation


# static fields
.field public static final ACTION_PLUGIN_DISCOVERY:Ljava/lang/String; = "com.motorola.plugin.action.PLUGIN_DISCOVERY"

.field private static final DEBUG:Z = false

.field public static final EXTRA_BUNDLE_DATA:Ljava/lang/String; = "com.motorola.plugin.extra.EXTRA_BUNDLE_DATA"

.field public static final EXTRA_METHOD:Ljava/lang/String; = "com.motorola.plugin.extra.METHOD"

.field public static final EXTRA_NOTIFY_URIS:Ljava/lang/String; = "com.motorola.plugin.extra.NOTIFY_URIS"

.field public static final EXTRA_RECEIPT:Ljava/lang/String; = "com.motorola.plugin.extra.RECEIPT"

.field public static final EXTRA_SEQUENCE:Ljava/lang/String; = "com.motorola.plugin.extra.SEQUENCE"

.field public static final META_DATA_KEY_PROVIDER:Ljava/lang/String; = "com.motorola.plugin.provider"

.field public static final METHOD_CLEAR_CACHE:Ljava/lang/String; = "com.motorola.plugin.extra.METHOD_CLEAR_CACHE"

.field public static final METHOD_CLEAR_DATA:Ljava/lang/String; = "com.motorola.plugin.extra.METHOD_CLEAR_DATA"

.field public static final METHOD_NOTIFY_DATASET_CHANGE:Ljava/lang/String; = "com.motorola.plugin.extra.METHOD_NOTIFY_DATASET_CHANGE"

.field public static final METHOD_SEND_EXTRA_DATA:Ljava/lang/String; = "com.motorola.plugin.extra.METHOD_SEND_EXTRA_DATA"

.field public static final PLUGIN_CHANNEL_BIND_PERMISSION:Ljava/lang/String; = "com.motorola.myscreen.permission.ACCESS_MYSCREEN"

.field public static final TAG:Ljava/lang/String; = "RemoteService"


# instance fields
.field private mHandler:Landroid/os/Handler;

.field private mRemoteCallbackList:Landroid/os/RemoteCallbackList;


# direct methods
.method public static synthetic $r8$lambda$46kXulUfFGoOnAQN_ZXgsVoSc1U([Landroid/net/Uri;Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V
    .locals 2

    .line 381
    new-instance p3, Landroid/os/Bundle;

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    .line 382
    const-string v0, "com.motorola.plugin.extra.METHOD"

    const-string v1, "com.motorola.plugin.extra.METHOD_NOTIFY_DATASET_CHANGE"

    invoke-virtual {p3, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 383
    new-instance v0, Ljava/util/ArrayList;

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-string p0, "com.motorola.plugin.extra.NOTIFY_URIS"

    invoke-virtual {p3, p0, v0}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    if-eqz p1, :cond_0

    .line 385
    const-string p0, "com.motorola.plugin.extra.EXTRA_BUNDLE_DATA"

    invoke-virtual {p3, p0, p1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 387
    :cond_0
    invoke-interface {p2, p3}, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;->sendResult(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$93VbG-EnUALCHrK0817CJOqFcxA(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V
    .locals 0

    .line 374
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    .line 374
    invoke-virtual {p0, p1}, Landroid/os/RemoteCallbackList;->unregister(Landroid/os/IInterface;)Z

    return-void
.end method

.method public static synthetic $r8$lambda$dusQsLsrG4zkTvSZGZlzU5qqhd4(Ljava/io/PrintWriter;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V
    .locals 2

    .line 412
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 413
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "    "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sYWmOxUL29IxASFPzkG_ZcZnSZA(Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V
    .locals 1

    if-eqz p0, :cond_1

    if-ne p0, p3, :cond_0

    goto :goto_0

    :cond_0
    return-void

    .line 398
    :cond_1
    :goto_0
    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    .line 399
    const-string p3, "com.motorola.plugin.extra.METHOD"

    const-string v0, "com.motorola.plugin.extra.METHOD_SEND_EXTRA_DATA"

    invoke-virtual {p0, p3, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 400
    const-string p3, "com.motorola.plugin.extra.EXTRA_BUNDLE_DATA"

    invoke-virtual {p0, p3, p1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 401
    invoke-interface {p2, p0}, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;->sendResult(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$slsPEmHcIQz7fSVtuASo75F5FvE(Lcom/motorola/plugin/sdk/channel/ClientId;Ljava/util/List;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V
    .locals 0

    if-ne p3, p0, :cond_0

    .line 371
    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 92
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method static synthetic access$100(Lcom/motorola/plugin/sdk/channel/RemoteService;)Landroid/os/Handler;
    .locals 0

    .line 92
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$200(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V
    .locals 0

    .line 92
    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->handleRemoteConnect(Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V

    return-void
.end method

.method static synthetic access$300(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V
    .locals 0

    .line 92
    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->handleRemoteRequest(Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V

    return-void
.end method

.method static synthetic access$400(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Z)V
    .locals 0

    .line 92
    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->handleRemoteDisconnect(Lcom/motorola/plugin/sdk/channel/ClientId;Z)V

    return-void
.end method

.method static synthetic access$500(Lcom/motorola/plugin/sdk/channel/RemoteService;[Landroid/net/Uri;Landroid/os/Bundle;)V
    .locals 0

    .line 92
    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->handleNotifyDataChanged([Landroid/net/Uri;Landroid/os/Bundle;)V

    return-void
.end method

.method static synthetic access$600(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V
    .locals 0

    .line 92
    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->handleSendExtraDataToRemoteClient(Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V

    return-void
.end method

.method private broadcastSafely(Landroid/os/RemoteCallbackList;Lcom/motorola/plugin/sdk/channel/ThrowingBiConsumer;)V
    .locals 6

    .line 420
    invoke-virtual {p1}, Landroid/os/RemoteCallbackList;->beginBroadcast()I

    move-result p0

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p0, :cond_1

    .line 422
    invoke-virtual {p1, v0}, Landroid/os/RemoteCallbackList;->getBroadcastCookie(I)Ljava/lang/Object;

    move-result-object v1

    .line 424
    :try_start_0
    invoke-virtual {p1, v0}, Landroid/os/RemoteCallbackList;->getBroadcastItem(I)Landroid/os/IInterface;

    move-result-object v2

    invoke-interface {p2, v2, v1}, Lcom/motorola/plugin/sdk/channel/ThrowingBiConsumer;->accept(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v2

    const/4 v3, 0x5

    .line 426
    const-string v4, "RemoteService"

    invoke-static {v4, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 427
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "["

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "] Error invoking a remote callback"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    :goto_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 431
    :cond_1
    invoke-virtual {p1}, Landroid/os/RemoteCallbackList;->finishBroadcast()V

    return-void
.end method

.method private forEach(Landroid/os/RemoteCallbackList;Ljava/util/function/BiConsumer;)V
    .locals 3

    .line 436
    invoke-virtual {p1}, Landroid/os/RemoteCallbackList;->getRegisteredCallbackCount()I

    move-result p0

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p0, :cond_0

    .line 438
    invoke-virtual {p1, v0}, Landroid/os/RemoteCallbackList;->getRegisteredCallbackItem(I)Landroid/os/IInterface;

    move-result-object v1

    .line 439
    invoke-virtual {p1, v0}, Landroid/os/RemoteCallbackList;->getRegisteredCallbackCookie(I)Ljava/lang/Object;

    move-result-object v2

    .line 438
    invoke-interface {p2, v1, v2}, Ljava/util/function/BiConsumer;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private handleNotifyDataChanged([Landroid/net/Uri;Landroid/os/Bundle;)V
    .locals 2

    .line 380
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    new-instance v1, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;-><init>([Landroid/net/Uri;Landroid/os/Bundle;)V

    invoke-direct {p0, v0, v1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->broadcastSafely(Landroid/os/RemoteCallbackList;Lcom/motorola/plugin/sdk/channel/ThrowingBiConsumer;)V

    return-void
.end method

.method private handleRemoteConnect(Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V
    .locals 1

    if-eqz p2, :cond_0

    .line 360
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    invoke-virtual {v0, p2, p1}, Landroid/os/RemoteCallbackList;->register(Landroid/os/IInterface;Ljava/lang/Object;)Z

    .line 362
    :cond_0
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onConnected(Lcom/motorola/plugin/sdk/channel/ClientId;)V

    return-void
.end method

.method private handleRemoteDisconnect(Lcom/motorola/plugin/sdk/channel/ClientId;Z)V
    .locals 2

    if-nez p2, :cond_0

    .line 368
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 369
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    new-instance v1, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;

    invoke-direct {v1, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;-><init>(Lcom/motorola/plugin/sdk/channel/ClientId;Ljava/util/List;)V

    invoke-direct {p0, v0, v1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->forEach(Landroid/os/RemoteCallbackList;Ljava/util/function/BiConsumer;)V

    .line 374
    new-instance v0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0}, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda4;-><init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V

    invoke-interface {p2, v0}, Ljava/util/List;->forEach(Ljava/util/function/Consumer;)V

    .line 376
    :cond_0
    iget-object p1, p1, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onDisconnected(Ljava/lang/String;)V

    return-void
.end method

.method private handleRemoteRequest(Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V
    .locals 4

    .line 338
    const-string v0, "com.motorola.plugin.extra.METHOD_CLEAR_CACHE"

    iget-object v1, p1, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->bundle:Landroid/os/Bundle;

    const-string v2, "com.motorola.plugin.extra.METHOD"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 339
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    const-string v2, "com.motorola.plugin.extra.METHOD_CLEAR_DATA"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    .line 352
    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onRemoteRequest(Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V

    return-void

    .line 342
    :cond_0
    iget-object v2, p1, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

    iget-object p1, p1, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->pluginId:Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 345
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 342
    invoke-virtual {p0, v2, p1, v0}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onRequestClearPluginData(Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/ClientId;Z)Z

    move-result p0

    .line 346
    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 347
    const-string v0, "com.motorola.plugin.extra.RECEIPT"

    invoke-virtual {p1, v0, p0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 348
    invoke-virtual {p2, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->onReplyToRemoteApp(Landroid/os/Bundle;)V

    return-void
.end method

.method private handleSendExtraDataToRemoteClient(Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V
    .locals 2

    .line 396
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    new-instance v1, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda2;

    invoke-direct {v1, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda2;-><init>(Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V

    invoke-direct {p0, v0, v1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->broadcastSafely(Landroid/os/RemoteCallbackList;Lcom/motorola/plugin/sdk/channel/ThrowingBiConsumer;)V

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 190
    invoke-super {p0, p1}, Landroid/app/Service;->attachBaseContext(Landroid/content/Context;)V

    .line 191
    new-instance p1, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;-><init>(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/RemoteService$1;)V

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mHandler:Landroid/os/Handler;

    .line 192
    new-instance p1, Lcom/motorola/plugin/sdk/channel/RemoteService$1;

    invoke-direct {p1, p0}, Lcom/motorola/plugin/sdk/channel/RemoteService$1;-><init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    const/4 p1, 0x3

    .line 203
    const-string v0, "RemoteService"

    invoke-static {v0, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 204
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "["

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "] onAttach"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void
.end method

.method protected dump(Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 0

    .line 408
    const-string p1, "RemoteService:[3101]"

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 409
    const-string p1, "RemoteService"

    const/4 p3, 0x3

    invoke-static {p1, p3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 410
    const-string p1, "  observers:"

    invoke-virtual {p2, p1}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 411
    iget-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    new-instance p3, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda1;

    invoke-direct {p3, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda1;-><init>(Ljava/io/PrintWriter;)V

    invoke-direct {p0, p1, p3}, Lcom/motorola/plugin/sdk/channel/RemoteService;->forEach(Landroid/os/RemoteCallbackList;Ljava/util/function/BiConsumer;)V

    :cond_0
    return-void
.end method

.method public varargs notifyDataChanged([Landroid/net/Uri;)V
    .locals 1

    const/4 v0, 0x0

    .line 303
    invoke-virtual {p0, p1, v0}, Lcom/motorola/plugin/sdk/channel/RemoteService;->notifyDataChanged([Landroid/net/Uri;Landroid/os/Bundle;)V

    return-void
.end method

.method public notifyDataChanged([Landroid/net/Uri;Landroid/os/Bundle;)V
    .locals 2

    .line 310
    array-length v0, p1

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    .line 311
    invoke-static {}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->obtain()Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    move-result-object v0

    .line 312
    iput-object p1, v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    .line 313
    iput-object p2, v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    .line 314
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mHandler:Landroid/os/Handler;

    invoke-virtual {p0, v1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p0

    .line 315
    invoke-virtual {p0}, Landroid/os/Message;->sendToTarget()V

    return-void

    .line 317
    :cond_0
    const-string p0, "RemoteService"

    invoke-static {p0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 318
    const-string p1, "ignore empty dataset change request"

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    .line 219
    new-instance p1, Lcom/motorola/plugin/sdk/channel/RemoteService$2;

    invoke-direct {p1, p0}, Lcom/motorola/plugin/sdk/channel/RemoteService$2;-><init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V

    return-object p1
.end method

.method public onConnected(Lcom/motorola/plugin/sdk/channel/ClientId;)V
    .locals 0

    .line 155
    iget-object p1, p1, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onConnected(Ljava/lang/String;)V

    return-void
.end method

.method public onConnected(Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onDestroy()V
    .locals 3

    const/4 v0, 0x3

    .line 210
    const-string v1, "RemoteService"

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 211
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "["

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] onDestroy"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 213
    :cond_0
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mRemoteCallbackList:Landroid/os/RemoteCallbackList;

    invoke-virtual {v0}, Landroid/os/RemoteCallbackList;->kill()V

    .line 214
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onDisconnected(Lcom/motorola/plugin/sdk/channel/ClientId;)V
    .locals 0

    .line 164
    iget-object p1, p1, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->onDisconnected(Ljava/lang/String;)V

    return-void
.end method

.method public onDisconnected(Ljava/lang/String;)V
    .locals 0

    .line 0
    return-void
.end method

.method public abstract onRemoteRequest(Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V
.end method

.method public onRequestClearPluginData(Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/ClientId;Z)Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    return p0
.end method

.method public sendExtraDataToClient(Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V
    .locals 1

    .line 328
    invoke-static {}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->obtain()Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    move-result-object v0

    .line 329
    iput-object p1, v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    .line 330
    iput-object p2, v0, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    .line 331
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService;->mHandler:Landroid/os/Handler;

    const/4 p1, 0x4

    invoke-virtual {p0, p1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p0

    .line 332
    invoke-virtual {p0}, Landroid/os/Message;->sendToTarget()V

    return-void
.end method
