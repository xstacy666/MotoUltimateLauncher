.class public interface abstract Lcom/motorola/plugin/sdk/channel/IDataSetChangedCallback;
.super Ljava/lang/Object;
.source "IDataSetChangedCallback.java"


# virtual methods
.method public abstract onDataSetChanged(Ljava/util/List;Landroid/os/Bundle;)V
.end method

.method public onReceivedExtraData(Landroid/os/Bundle;)V
    .locals 0

    .line 0
    return-void
.end method
