.class public interface abstract Lcom/motorola/plugin/sdk/channel/IRemoteChannel;
.super Ljava/lang/Object;
.source "IRemoteChannel.java"


# virtual methods
.method public abstract getDataSetChangedRegistry()Lcom/motorola/plugin/sdk/channel/IDataSetChangedRegistry;
.end method

.method public abstract isClosed()Z
.end method

.method public abstract requestClearPluginData(Z)V
.end method

.method public abstract subscribeConnectStatus(Lcom/motorola/plugin/sdk/channel/IRemoteChannelConnectionStatusCallback;)V
.end method

.method public transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteChannelTransferCallback;)V
    .locals 0

    .line 93
    invoke-interface {p0, p1, p2, p2}, Lcom/motorola/plugin/sdk/channel/IRemoteChannel;->transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteError;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V

    return-void
.end method

.method public abstract transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteError;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V
.end method

.method public transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V
    .locals 1

    const/4 v0, 0x0

    .line 88
    invoke-interface {p0, p1, v0, p2}, Lcom/motorola/plugin/sdk/channel/IRemoteChannel;->transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteError;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V

    return-void
.end method

.method public transfer(Ljava/lang/String;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteChannelTransferCallback;)V
    .locals 2

    .line 152
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 153
    const-string v1, "com.motorola.plugin.extra.METHOD"

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    invoke-interface {p0, v0, p2}, Lcom/motorola/plugin/sdk/channel/IRemoteChannel;->transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteChannelTransferCallback;)V

    return-void
.end method

.method public transfer(Ljava/lang/String;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V
    .locals 2

    .line 122
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 123
    const-string v1, "com.motorola.plugin.extra.METHOD"

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    invoke-interface {p0, v0, p2}, Lcom/motorola/plugin/sdk/channel/IRemoteChannel;->transfer(Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;)V

    return-void
.end method

.method public abstract unsubscribeConnectStatus(Lcom/motorola/plugin/sdk/channel/IRemoteChannelConnectionStatusCallback;)V
.end method
