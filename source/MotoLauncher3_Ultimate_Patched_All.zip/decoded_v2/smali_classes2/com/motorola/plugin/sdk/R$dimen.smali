.class public final Lcom/motorola/plugin/sdk/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_action_bar_content_inset_material:I

.field public static abc_action_bar_content_inset_with_nav:I

.field public static abc_action_bar_default_height_material:I

.field public static abc_action_bar_default_padding_end_material:I

.field public static abc_action_bar_default_padding_start_material:I

.field public static abc_action_bar_elevation_material:I

.field public static abc_action_bar_icon_vertical_padding_material:I

.field public static abc_action_bar_overflow_padding_end_material:I

.field public static abc_action_bar_overflow_padding_start_material:I

.field public static abc_action_bar_stacked_max_height:I

.field public static abc_action_bar_stacked_tab_max_width:I

.field public static abc_action_bar_subtitle_bottom_margin_material:I

.field public static abc_action_bar_subtitle_top_margin_material:I

.field public static abc_action_button_min_height_material:I

.field public static abc_action_button_min_width_material:I

.field public static abc_action_button_min_width_overflow_material:I

.field public static abc_alert_dialog_button_bar_height:I

.field public static abc_alert_dialog_button_dimen:I

.field public static abc_button_inset_horizontal_material:I

.field public static abc_button_inset_vertical_material:I

.field public static abc_button_padding_horizontal_material:I

.field public static abc_button_padding_vertical_material:I

.field public static abc_cascading_menus_min_smallest_width:I

.field public static abc_config_prefDialogWidth:I

.field public static abc_control_corner_material:I

.field public static abc_control_inset_material:I

.field public static abc_control_padding_material:I

.field public static abc_dialog_corner_radius_material:I

.field public static abc_dialog_fixed_height_major:I

.field public static abc_dialog_fixed_height_minor:I

.field public static abc_dialog_fixed_width_major:I

.field public static abc_dialog_fixed_width_minor:I

.field public static abc_dialog_list_padding_bottom_no_buttons:I

.field public static abc_dialog_list_padding_top_no_title:I

.field public static abc_dialog_min_width_major:I

.field public static abc_dialog_min_width_minor:I

.field public static abc_dialog_padding_material:I

.field public static abc_dialog_padding_top_material:I

.field public static abc_dialog_title_divider_material:I

.field public static abc_disabled_alpha_material_dark:I

.field public static abc_disabled_alpha_material_light:I

.field public static abc_dropdownitem_icon_width:I

.field public static abc_dropdownitem_text_padding_left:I

.field public static abc_dropdownitem_text_padding_right:I

.field public static abc_edit_text_inset_bottom_material:I

.field public static abc_edit_text_inset_horizontal_material:I

.field public static abc_edit_text_inset_top_material:I

.field public static abc_floating_window_z:I

.field public static abc_list_item_height_large_material:I

.field public static abc_list_item_height_material:I

.field public static abc_list_item_height_small_material:I

.field public static abc_list_item_padding_horizontal_material:I

.field public static abc_panel_menu_list_width:I

.field public static abc_progress_bar_height_material:I

.field public static abc_search_view_preferred_height:I

.field public static abc_search_view_preferred_width:I

.field public static abc_seekbar_track_background_height_material:I

.field public static abc_seekbar_track_progress_height_material:I

.field public static abc_select_dialog_padding_start_material:I

.field public static abc_slice_action_row_height:I

.field public static abc_slice_big_pic_max_height:I

.field public static abc_slice_big_pic_min_height:I

.field public static abc_slice_grid_gutter:I

.field public static abc_slice_grid_image_min_width:I

.field public static abc_slice_grid_image_only_height:I

.field public static abc_slice_grid_image_text_height:I

.field public static abc_slice_grid_max_height:I

.field public static abc_slice_grid_min_height:I

.field public static abc_slice_grid_raw_image_text_offset:I

.field public static abc_slice_grid_small_image_text_height:I

.field public static abc_slice_grid_text_inner_padding:I

.field public static abc_slice_grid_text_padding:I

.field public static abc_slice_icon_size:I

.field public static abc_slice_large_height:I

.field public static abc_slice_padding:I

.field public static abc_slice_row_active_input_height:I

.field public static abc_slice_row_max_height:I

.field public static abc_slice_row_min_height:I

.field public static abc_slice_row_range_height:I

.field public static abc_slice_row_range_inline_height:I

.field public static abc_slice_row_range_multi_text_height:I

.field public static abc_slice_row_range_single_text_height:I

.field public static abc_slice_row_selection_height:I

.field public static abc_slice_row_selection_multi_text_height:I

.field public static abc_slice_row_selection_single_text_height:I

.field public static abc_slice_shortcut_size:I

.field public static abc_slice_small_height:I

.field public static abc_slice_small_image_size:I

.field public static abc_star_big:I

.field public static abc_star_medium:I

.field public static abc_star_small:I

.field public static abc_switch_padding:I

.field public static abc_text_size_body_1_material:I

.field public static abc_text_size_body_2_material:I

.field public static abc_text_size_button_material:I

.field public static abc_text_size_caption_material:I

.field public static abc_text_size_display_1_material:I

.field public static abc_text_size_display_2_material:I

.field public static abc_text_size_display_3_material:I

.field public static abc_text_size_display_4_material:I

.field public static abc_text_size_headline_material:I

.field public static abc_text_size_large_material:I

.field public static abc_text_size_medium_material:I

.field public static abc_text_size_menu_header_material:I

.field public static abc_text_size_menu_material:I

.field public static abc_text_size_small_material:I

.field public static abc_text_size_subhead_material:I

.field public static abc_text_size_subtitle_material_toolbar:I

.field public static abc_text_size_title_material:I

.field public static abc_text_size_title_material_toolbar:I

.field public static accessibility_gesture_min_swipe_distance:I

.field public static action_button_margin_bottom_landscape_offset:I

.field public static action_button_padding_horizon:I

.field public static action_button_padding_horizon_landscape:I

.field public static action_button_padding_horizon_landscape_offset:I

.field public static activity_split_ratio:I

.field public static all_app_floating_view_extra_padding:I

.field public static all_app_tipview_margin_End:I

.field public static all_apps_additional_top_padding_floating_search:I

.field public static all_apps_background_canvas_height:I

.field public static all_apps_background_canvas_width:I

.field public static all_apps_bottom_sheet_horizontal_padding:I

.field public static all_apps_content_fade_in_offset:I

.field public static all_apps_divider_height:I

.field public static all_apps_divider_margin_vertical:I

.field public static all_apps_divider_width:I

.field public static all_apps_editor_folder_name_height:I

.field public static all_apps_empty_search_bg_top_offset:I

.field public static all_apps_empty_search_message_top_offset:I

.field public static all_apps_fast_scroller_margin_bottom:I

.field public static all_apps_folder_editor_bottom_bar_padding_h:I

.field public static all_apps_folder_editor_bottom_bar_padding_v:I

.field public static all_apps_folder_editor_recycler_view_padding_top:I

.field public static all_apps_folder_editor_scroll_bar_top:I

.field public static all_apps_folder_editor_top_bar_gap:I

.field public static all_apps_folder_editor_top_bar_margin_bottom:I

.field public static all_apps_folder_editor_top_bar_title_text_size:I

.field public static all_apps_header_bottom_adjustment:I

.field public static all_apps_header_bottom_padding:I

.field public static all_apps_header_pill_corner_radius:I

.field public static all_apps_header_pill_height:I

.field public static all_apps_header_tab_height:I

.field public static all_apps_header_top_adjustment:I

.field public static all_apps_header_top_margin:I

.field public static all_apps_header_top_padding:I

.field public static all_apps_height_extra:I

.field public static all_apps_icon_drawable_padding:I

.field public static all_apps_label_bottom_padding:I

.field public static all_apps_label_line_margin:I

.field public static all_apps_label_text_size:I

.field public static all_apps_label_top_padding:I

.field public static all_apps_overlay_search_height:I

.field public static all_apps_padding_right:I

.field public static all_apps_paged_view_top_padding:I

.field public static all_apps_predicted_icon_vertical_padding:I

.field public static all_apps_prediction_row_divider_height:I

.field public static all_apps_recycler_view_decorator_group_radius:I

.field public static all_apps_recycler_view_decorator_padding:I

.field public static all_apps_recycler_view_decorator_result_radius:I

.field public static all_apps_recyclerview_margin_bottom:I

.field public static all_apps_search_bar_bottom_padding:I

.field public static all_apps_search_bar_content_overlap:I

.field public static all_apps_search_bar_padding_top:I

.field public static all_apps_search_container_height:I

.field public static all_apps_search_top_row_extra_height:I

.field public static all_apps_starting_vertical_translate:I

.field public static all_apps_tabs_button_horizontal_padding:I

.field public static all_apps_tabs_indicator_height:I

.field public static all_apps_tabs_margin_top:I

.field public static all_apps_tabs_vertical_padding:I

.field public static all_apps_tip_bottom_margin:I

.field public static all_apps_work_profile_tab_footer_bottom_padding:I

.field public static all_apps_work_profile_tab_footer_top_padding:I

.field public static allset_page_allset_text_size:I

.field public static allset_page_margin_horizontal:I

.field public static allset_page_swipe_up_text_size:I

.field public static allset_subtitle_margin_top:I

.field public static allset_subtitle_width_max:I

.field public static allset_swipe_up_shift:I

.field public static allset_title_icon_margin_top:I

.field public static allset_title_margin_top:I

.field public static ambient_shadow_blur:I

.field public static app_icon_min_width:I

.field public static app_preference_padding_start:I

.field public static app_stream_detector_fling_release_velocity:I

.field public static app_tray_cell_height_extra:I

.field public static appbar_layout_height:I

.field public static appbar_layout_height_one_line:I

.field public static appcompat_dialog_background_inset:I

.field public static applock_msg_padding_top:I

.field public static applock_msg_text_size:I

.field public static applock_total_top_offset:I

.field public static arrow_tips_margin_top:I

.field public static arrow_toast_arrow_height:I

.field public static arrow_toast_arrow_width:I

.field public static arrow_toast_corner_radius:I

.field public static arrow_toast_desktop_close_btn_margin:I

.field public static arrow_toast_desktop_close_btn_padding_top:I

.field public static arrow_toast_desktop_dismiss_btn_height:I

.field public static arrow_toast_desktop_dismiss_btn_width:I

.field public static arrow_toast_desktop_text_padding_bottom:I

.field public static arrow_toast_desktop_text_padding_top:I

.field public static arrow_toast_desktop_text_width:I

.field public static arrow_toast_desktop_tip_arrow_height:I

.field public static arrow_toast_desktop_tip_arrow_width:I

.field public static arrow_toast_desktop_tip_content_margin_Start:I

.field public static arrow_toast_desktop_tip_text_size:I

.field public static arrow_toast_elevation:I

.field public static arrow_toast_text_size:I

.field public static base_swift_detector_fling_release_velocity:I

.field public static bg_popup_item_height:I

.field public static bg_popup_item_vertical_padding:I

.field public static bg_popup_item_width:I

.field public static bg_popup_padding:I

.field public static bg_round_rect_radius:I

.field public static big_folder_bottom_extra:I

.field public static bitmap_outline:I

.field public static blur_size_click_shadow:I

.field public static blur_size_medium_outline:I

.field public static blur_size_thin_outline:I

.field public static bottom_sheet_edu_padding:I

.field public static bottom_sheet_handle_area_height:I

.field public static bottom_sheet_handle_corner_radius:I

.field public static bottom_sheet_handle_height:I

.field public static bottom_sheet_handle_margin:I

.field public static bottom_sheet_handle_width:I

.field public static bubble_expanded_view_drop_target_corner_radius:I

.field public static bubble_expanded_view_drop_target_default_height:I

.field public static bubble_expanded_view_drop_target_default_width:I

.field public static bubble_expanded_view_drop_target_margin:I

.field public static bubble_expanded_view_drop_target_padding:I

.field public static bubblebar_badge_size:I

.field public static bubblebar_dismiss_floating_gradient_height:I

.field public static bubblebar_dismiss_target_bottom_margin:I

.field public static bubblebar_dismiss_target_icon_size:I

.field public static bubblebar_dismiss_target_size:I

.field public static bubblebar_dismiss_target_small_size:I

.field public static bubblebar_dismiss_zone_height:I

.field public static bubblebar_dismiss_zone_width:I

.field public static bubblebar_drag_elevation:I

.field public static bubblebar_drop_target_corner_radius:I

.field public static bubblebar_elevation:I

.field public static bubblebar_expanded_icon_spacing:I

.field public static bubblebar_hotseat_adjustment_threshold:I

.field public static bubblebar_icon_elevation:I

.field public static bubblebar_icon_overlap:I

.field public static bubblebar_icon_size:I

.field public static bubblebar_icon_size_persistent_taskbar:I

.field public static bubblebar_icon_size_small:I

.field public static bubblebar_icon_spacing:I

.field public static bubblebar_icon_spacing_large:I

.field public static bubblebar_icon_spacing_persistent_taskbar:I

.field public static bubblebar_overflow_inset:I

.field public static bubblebar_pointer_height:I

.field public static bubblebar_pointer_radius:I

.field public static bubblebar_pointer_visible_size:I

.field public static bubblebar_pointer_width:I

.field public static bubblebar_size:I

.field public static bubblebar_size_with_pointer:I

.field public static bubblebar_stashed_handle_height:I

.field public static bubblebar_stashed_handle_spring_velocity_dp_per_s:I

.field public static bubblebar_stashed_handle_width:I

.field public static bubblebar_stashed_size:I

.field public static button_drop_target_min_text_size:I

.field public static button_drop_target_resize_text_increment:I

.field public static cardview_compat_inset_shadow:I

.field public static cardview_default_elevation:I

.field public static cardview_default_radius:I

.field public static cast_search_bar_bottom:I

.field public static cast_search_bar_height:I

.field public static cast_search_bar_icon_size:I

.field public static cast_search_bar_margin_h:I

.field public static cast_search_bar_prompt_padding:I

.field public static cast_search_bar_prompt_text_size:I

.field public static cast_search_bar_search_box_padding_h:I

.field public static cast_search_bar_search_box_padding_v:I

.field public static cast_search_bar_translationZ:I

.field public static cell_layout_padding:I

.field public static center_offset:I

.field public static chip_hint_border_width:I

.field public static chip_hint_corner_radius:I

.field public static chip_hint_elevation:I

.field public static chip_hint_end_padding:I

.field public static chip_hint_horizontal_margin:I

.field public static chip_hint_outer_padding:I

.field public static chip_hint_start_padding:I

.field public static chip_hint_vertical_offset:I

.field public static chip_icon_size:I

.field public static chip_text_height:I

.field public static chip_text_size:I

.field public static chip_text_start_padding:I

.field public static chip_text_top_padding:I

.field public static click_shadow_elevation:I

.field public static click_shadow_high_shift:I

.field public static clock_face_margin_start:I

.field public static closing_window_trans_y:I

.field public static collapsing_toolbar_font_size:I

.field public static compat_button_inset_horizontal_material:I

.field public static compat_button_inset_vertical_material:I

.field public static compat_button_padding_horizontal_material:I

.field public static compat_button_padding_vertical_material:I

.field public static compat_control_corner_material:I

.field public static compat_notification_large_icon_max_height:I

.field public static compat_notification_large_icon_max_width:I

.field public static config_wallpaperMaxScale:I

.field public static create_folder_dismiss_btn_height:I

.field public static create_folder_dismiss_btn_margin:I

.field public static create_folder_dismiss_btn_width:I

.field public static create_folder_tip_arrow_height:I

.field public static create_folder_tip_arrow_margin_end:I

.field public static create_folder_tip_arrow_width:I

.field public static create_folder_tip_content_margin_Start:I

.field public static create_folder_tip_content_width:I

.field public static create_folder_tip_shadow_corner_radius:I

.field public static create_folder_tip_shadow_offset_x:I

.field public static create_folder_tip_shadow_offset_y:I

.field public static create_folder_tip_shadow_radius:I

.field public static create_folder_tip_text_padding_bottom:I

.field public static create_folder_tip_text_padding_top:I

.field public static create_folder_tip_text_size:I

.field public static create_folder_tips_margin_end:I

.field public static custom_list_preference_cancel:I

.field public static custom_list_preference_cancel_height:I

.field public static custom_list_preference_cancel_margin:I

.field public static custom_list_preference_cancel_width:I

.field public static custom_list_preference_dialog_width:I

.field public static custom_list_preference_list_item:I

.field public static custom_list_preference_list_item_title:I

.field public static custom_list_preference_title:I

.field public static custom_list_preference_title_margin:I

.field public static custom_list_preference_title_margin_bottom:I

.field public static deep_shortcut_drag_handle_size:I

.field public static deep_shortcut_drawable_padding:I

.field public static deep_shortcut_icon_size:I

.field public static deep_shortcuts_elevation:I

.field public static deep_shortcuts_start_drag_threshold:I

.field public static deep_shortcuts_text_padding_start:I

.field public static def_drawer_elevation:I

.field public static def_spacing_from_nav_bar:I

.field public static default_dialog_corner_radius:I

.field public static default_icon_bitmap_size:I

.field public static default_ime_height:I

.field public static default_navigation_active_text_size:I

.field public static default_navigation_text_size:I

.field public static default_task_dismiss_drag_velocity:I

.field public static default_task_dismiss_drag_velocity_grid:I

.field public static default_task_dismiss_drag_velocity_grid_focus_task:I

.field public static design_appbar_elevation:I

.field public static design_bottom_navigation_active_item_max_width:I

.field public static design_bottom_navigation_active_item_min_width:I

.field public static design_bottom_navigation_active_text_size:I

.field public static design_bottom_navigation_elevation:I

.field public static design_bottom_navigation_height:I

.field public static design_bottom_navigation_icon_size:I

.field public static design_bottom_navigation_item_max_width:I

.field public static design_bottom_navigation_item_min_width:I

.field public static design_bottom_navigation_label_padding:I

.field public static design_bottom_navigation_margin:I

.field public static design_bottom_navigation_shadow_height:I

.field public static design_bottom_navigation_text_size:I

.field public static design_bottom_sheet_elevation:I

.field public static design_bottom_sheet_modal_elevation:I

.field public static design_bottom_sheet_peek_height_min:I

.field public static design_fab_border_width:I

.field public static design_fab_elevation:I

.field public static design_fab_image_size:I

.field public static design_fab_size_mini:I

.field public static design_fab_size_normal:I

.field public static design_fab_translation_z_hovered_focused:I

.field public static design_fab_translation_z_pressed:I

.field public static design_navigation_elevation:I

.field public static design_navigation_icon_padding:I

.field public static design_navigation_icon_size:I

.field public static design_navigation_item_horizontal_padding:I

.field public static design_navigation_item_icon_padding:I

.field public static design_navigation_item_vertical_padding:I

.field public static design_navigation_max_width:I

.field public static design_navigation_padding_bottom:I

.field public static design_navigation_separator_vertical_padding:I

.field public static design_snackbar_action_inline_max_width:I

.field public static design_snackbar_action_text_color_alpha:I

.field public static design_snackbar_background_corner_radius:I

.field public static design_snackbar_elevation:I

.field public static design_snackbar_extra_spacing_horizontal:I

.field public static design_snackbar_max_width:I

.field public static design_snackbar_min_width:I

.field public static design_snackbar_padding_horizontal:I

.field public static design_snackbar_padding_vertical:I

.field public static design_snackbar_padding_vertical_2lines:I

.field public static design_snackbar_text_size:I

.field public static design_tab_max_width:I

.field public static design_tab_scrollable_min_width:I

.field public static design_tab_text_size:I

.field public static design_tab_text_size_2line:I

.field public static design_textinput_caption_translate_y:I

.field public static desktop_windowing_freeform_rounded_corner_radius:I

.field public static developer_options_filter_margins:I

.field public static device_locked_y_offset:I

.field public static dialogCornerRadius:I

.field public static digital_wellbeing_toast_height:I

.field public static disabled_alpha_material_dark:I

.field public static disabled_alpha_material_light:I

.field public static discovery_ad_height:I

.field public static discovery_ad_margin_start:I

.field public static discovery_ad_width:I

.field public static discovery_app_image_size:I

.field public static discovery_app_store_height:I

.field public static discovery_auto_suggest_height:I

.field public static discovery_auto_suggest_image_size:I

.field public static discovery_auto_suggest_text_margin_left:I

.field public static discovery_box_close_size:I

.field public static discovery_box_margin_top:I

.field public static discovery_contact_actions_margin_left:I

.field public static discovery_contact_actions_padding_horizontal:I

.field public static discovery_contact_actions_size:I

.field public static discovery_contact_image_size:I

.field public static discovery_container_recycler_margin_vertical:I

.field public static discovery_content_padding_bottom:I

.field public static discovery_content_padding_horizontal:I

.field public static discovery_divider_margin_horizontal:I

.field public static discovery_entity_image_size:I

.field public static discovery_hero_ad_padding:I

.field public static discovery_hint_content_padding_horizontal:I

.field public static discovery_hint_content_padding_vertical:I

.field public static discovery_hint_icon_margin_right:I

.field public static discovery_hint_padding_horizontal:I

.field public static discovery_hint_padding_vertical:I

.field public static discovery_line_margin_bottom:I

.field public static discovery_line_margin_top:I

.field public static discovery_link_margin_horizontal:I

.field public static discovery_link_padding_vertical:I

.field public static discovery_local_header_margin_left:I

.field public static discovery_local_margin_vertical:I

.field public static discovery_local_padding_bottom:I

.field public static discovery_local_padding_horizontal:I

.field public static discovery_local_padding_top:I

.field public static discovery_personalize_icon:I

.field public static discovery_primary_image_size:I

.field public static discovery_privacy_check_height:I

.field public static discovery_privacy_check_size:I

.field public static discovery_privacy_content_line_spacing:I

.field public static discovery_privacy_content_margin_vertical:I

.field public static discovery_privacy_image_height:I

.field public static discovery_privacy_image_margin_top:I

.field public static discovery_privacy_image_width:I

.field public static discovery_privacy_next_height:I

.field public static discovery_privacy_next_margin_bottom:I

.field public static discovery_privacy_next_margin_top:I

.field public static discovery_privacy_next_padding:I

.field public static discovery_privacy_next_width:I

.field public static discovery_privacy_padding_horizontal:I

.field public static discovery_privacy_title_margin_top:I

.field public static discovery_search_app_padding:I

.field public static discovery_search_padding_horizontal:I

.field public static discovery_secondary_image_size:I

.field public static discovery_setting_back_margin_top:I

.field public static discovery_setting_back_size:I

.field public static discovery_setting_desc_margin_top:I

.field public static discovery_setting_padding_horizontal:I

.field public static discovery_setting_padding_start:I

.field public static discovery_setting_switch_margin_top:I

.field public static discovery_setting_title_margin_top:I

.field public static discovery_setting_title_padding_left:I

.field public static discovery_shortcut_image_size:I

.field public static discovery_shortcut_name_margin_left:I

.field public static discovery_shortcut_padding_vertical:I

.field public static discovery_suggest_title_margin_top:I

.field public static dismiss_task_trans_y_damping_ratio:I

.field public static dismiss_task_trans_y_stiffness:I

.field public static dm_all_app_cell_width:I

.field public static dm_all_app_icon_padding:I

.field public static dm_all_app_icon_size:I

.field public static dm_all_app_padding:I

.field public static dm_all_app_text_size:I

.field public static dm_all_apps_cell_space:I

.field public static dm_all_apps_header_tab_height:I

.field public static dm_all_apps_header_top_padding:I

.field public static dm_all_apps_margin_end:I

.field public static dm_all_apps_suggest_icon_height:I

.field public static dm_all_apps_suggest_icon_width:I

.field public static dm_all_apps_suggest_layout_height:I

.field public static dm_all_apps_suggest_layout_margin_right:I

.field public static dm_all_apps_suggest_layout_margin_top:I

.field public static dm_all_apps_suggest_layout_width:I

.field public static dm_all_apps_suggest_text_left_padding:I

.field public static dm_all_apps_suggest_text_right_padding:I

.field public static dm_all_apps_suggest_text_size:I

.field public static dm_arrow_pop_padding:I

.field public static dm_deep_shortcuts_elevation:I

.field public static dm_rv_top_margin:I

.field public static dm_search_container_height:I

.field public static dm_search_container_width:I

.field public static dm_workspace_cell_width:I

.field public static dm_workspace_icon_padding:I

.field public static dm_workspace_icon_size:I

.field public static dm_workspace_icon_text_size:I

.field public static drag_distanceThreshold:I

.field public static drag_elevation:I

.field public static drag_flingToDeleteMinVelocity:I

.field public static drag_zone_bubble_fold:I

.field public static drag_zone_bubble_tablet:I

.field public static drag_zone_desktop_window_expanded_view_height:I

.field public static drag_zone_desktop_window_expanded_view_width:I

.field public static drag_zone_desktop_window_height:I

.field public static drag_zone_desktop_window_width:I

.field public static drag_zone_dismiss_fold:I

.field public static drag_zone_dismiss_tablet:I

.field public static drag_zone_full_screen_height:I

.field public static drag_zone_full_screen_width:I

.field public static drag_zone_h_split_from_app_width_fold:I

.field public static drag_zone_h_split_from_expanded_view_width:I

.field public static drag_zone_split_from_bubble_height:I

.field public static drag_zone_split_from_bubble_width:I

.field public static drag_zone_v_split_from_expanded_view_height_fold_short:I

.field public static drag_zone_v_split_from_expanded_view_height_fold_tall:I

.field public static drag_zone_v_split_from_expanded_view_height_tablet:I

.field public static drag_zone_v_split_from_expanded_view_width:I

.field public static dragged_bubble_elevation:I

.field public static drop_target_bar_margin_horizontal:I

.field public static drop_target_bottom_margin:I

.field public static drop_target_bottom_margin_wide_portrait:I

.field public static drop_target_button_drawable_horizontal_padding:I

.field public static drop_target_button_drawable_padding:I

.field public static drop_target_button_drawable_size:I

.field public static drop_target_button_drawable_vertical_padding:I

.field public static drop_target_button_frame_radius:I

.field public static drop_target_button_gap:I

.field public static drop_target_button_no_text_padding:I

.field public static drop_target_button_with_text_drawable_padding:I

.field public static drop_target_button_with_text_padding:I

.field public static drop_target_button_workspace_edge_gap:I

.field public static drop_target_desktop_window_padding_large:I

.field public static drop_target_desktop_window_padding_small:I

.field public static drop_target_drag_padding:I

.field public static drop_target_elevation:I

.field public static drop_target_expanded_view_height:I

.field public static drop_target_expanded_view_padding_bottom:I

.field public static drop_target_expanded_view_padding_horizontal:I

.field public static drop_target_expanded_view_width:I

.field public static drop_target_full_screen_padding:I

.field public static drop_target_radius:I

.field public static drop_target_shadow_elevation:I

.field public static drop_target_stroke:I

.field public static drop_target_text_size:I

.field public static drop_target_top_margin:I

.field public static drop_target_vertical_gap:I

.field public static dynamic_grid_cell_border_spacing:I

.field public static dynamic_grid_cell_layout_padding:I

.field public static dynamic_grid_cell_padding_x:I

.field public static dynamic_grid_drop_target_size:I

.field public static dynamic_grid_edge_margin:I

.field public static dynamic_grid_hotseat_bottom_tall_padding:I

.field public static dynamic_grid_hotseat_extra_vertical_size:I

.field public static dynamic_grid_hotseat_side_padding:I

.field public static dynamic_grid_hotseat_top_padding:I

.field public static dynamic_grid_icon_drawable_padding:I

.field public static dynamic_grid_left_right_margin:I

.field public static dynamic_grid_spring_loaded_min_next_space_visible:I

.field public static easy_fling_threshold_velocity:I

.field public static enforced_rounded_corner_max_radius:I

.field public static fastscroll_bottom_margin_floating_search:I

.field public static fastscroll_default_thickness:I

.field public static fastscroll_end_margin:I

.field public static fastscroll_margin:I

.field public static fastscroll_minimum_range:I

.field public static fastscroll_offset_left:I

.field public static fastscroll_popup_height:I

.field public static fastscroll_popup_margin:I

.field public static fastscroll_popup_padding:I

.field public static fastscroll_popup_text_size:I

.field public static fastscroll_popup_width:I

.field public static fastscroll_thumb_height:I

.field public static fastscroll_thumb_padding:I

.field public static fastscroll_thumb_touch_inset:I

.field public static fastscroll_track_max_width:I

.field public static fastscroll_track_min_width:I

.field public static fastscroll_width:I

.field public static fling_target_height:I

.field public static fling_threshold_velocity:I

.field public static fling_view_origin_height:I

.field public static floating_dismiss_background_size:I

.field public static floating_dismiss_icon_size:I

.field public static floating_ime_inset_height:I

.field public static floating_rotation_button_diameter:I

.field public static floating_rotation_button_min_margin:I

.field public static floating_rotation_button_taskbar_bottom_margin:I

.field public static floating_rotation_button_taskbar_left_margin:I

.field public static focus_inner_outline_radius:I

.field public static focus_outline_radius:I

.field public static focus_outline_stroke_width:I

.field public static focus_rect_widget_outsets:I

.field public static folder_cell_x_padding:I

.field public static folder_cell_y_padding:I

.field public static folder_content_padding_left_right:I

.field public static folder_content_padding_top:I

.field public static folder_editor_padding_bottom_extra:I

.field public static folder_editor_search_bar_container_margin_start:I

.field public static folder_footer_height_default:I

.field public static folder_footer_horiz_padding:I

.field public static folder_label_height:I

.field public static folder_label_height_2:I

.field public static folder_label_height_change_reserve:I

.field public static folder_label_text_scale:I

.field public static folder_top_padding_default:I

.field public static folder_y_pos_extra:I

.field public static free_form_icon_show_pos:I

.field public static free_form_icon_size:I

.field public static free_view_tooltip_y_offset:I

.field public static freeform_btn_hover_layer_size_height:I

.field public static freeform_btn_hover_layer_size_width:I

.field public static freeform_btn_margin_bottom:I

.field public static freeform_btn_margin_top:I

.field public static freeform_btn_size:I

.field public static freeform_window_height_size:I

.field public static freeform_window_width_size:I

.field public static fullscreen_folder_padding:I

.field public static fullscreen_page_indicator_height:I

.field public static fullscreen_smart_folder_content_padding:I

.field public static gesture_hint_margin_bottom:I

.field public static gesture_hint_text_height:I

.field public static gesture_tutorial_back_gesture_end_corner_radius:I

.field public static gesture_tutorial_back_gesture_exiting_app_margin:I

.field public static gesture_tutorial_conversation_bottom_padding:I

.field public static gesture_tutorial_conversation_icon_corner_radius:I

.field public static gesture_tutorial_conversation_icon_size:I

.field public static gesture_tutorial_conversation_line_1_margin_end:I

.field public static gesture_tutorial_conversation_line_2_margin_end:I

.field public static gesture_tutorial_conversation_line_3_margin_end:I

.field public static gesture_tutorial_conversation_line_4_margin_end:I

.field public static gesture_tutorial_conversation_line_5_margin_end:I

.field public static gesture_tutorial_conversation_line_6_margin_end:I

.field public static gesture_tutorial_conversation_line_7_margin_end:I

.field public static gesture_tutorial_conversation_line_8_margin_end:I

.field public static gesture_tutorial_conversation_line_padding_start:I

.field public static gesture_tutorial_conversation_list_padding_top:I

.field public static gesture_tutorial_done_button_bottom_margin:I

.field public static gesture_tutorial_done_button_end_margin:I

.field public static gesture_tutorial_feedback_margin_start_end:I

.field public static gesture_tutorial_feedback_margin_top:I

.field public static gesture_tutorial_hotseat_height:I

.field public static gesture_tutorial_hotseat_icon_corner_radius:I

.field public static gesture_tutorial_hotseat_icon_search_margin:I

.field public static gesture_tutorial_hotseat_icon_size:I

.field public static gesture_tutorial_hotseat_padding_start_end:I

.field public static gesture_tutorial_hotseat_search_corner_radius:I

.field public static gesture_tutorial_hotseat_search_height:I

.field public static gesture_tutorial_hotseat_width:I

.field public static gesture_tutorial_input_margin_end:I

.field public static gesture_tutorial_input_margin_start:I

.field public static gesture_tutorial_menu_back_shape_bottom_margin:I

.field public static gesture_tutorial_menu_button_height:I

.field public static gesture_tutorial_menu_button_radius:I

.field public static gesture_tutorial_menu_button_spacing:I

.field public static gesture_tutorial_menu_done_button_spacing:I

.field public static gesture_tutorial_menu_done_button_top_spacing:I

.field public static gesture_tutorial_menu_padding_bottom:I

.field public static gesture_tutorial_menu_padding_horizontal:I

.field public static gesture_tutorial_menu_padding_top:I

.field public static gesture_tutorial_message_icon_corner_radius:I

.field public static gesture_tutorial_message_icon_size:I

.field public static gesture_tutorial_message_input_margin_top:I

.field public static gesture_tutorial_message_large_margin_bottom:I

.field public static gesture_tutorial_message_margin_start:I

.field public static gesture_tutorial_message_padding_end:I

.field public static gesture_tutorial_message_padding_start:I

.field public static gesture_tutorial_message_small_margin_bottom:I

.field public static gesture_tutorial_mock_button_margin_bottom:I

.field public static gesture_tutorial_mock_button_margin_end:I

.field public static gesture_tutorial_mock_taskbar_height:I

.field public static gesture_tutorial_multi_row_task_view_spacing:I

.field public static gesture_tutorial_reply_margin_end:I

.field public static gesture_tutorial_small_task_view_corner_radius:I

.field public static gesture_tutorial_tablet_conversation_line_10_margin_end:I

.field public static gesture_tutorial_tablet_conversation_line_6_margin_end:I

.field public static gesture_tutorial_tablet_conversation_line_8_margin_end:I

.field public static gesture_tutorial_tablet_feedback_margin_start_end:I

.field public static gesture_tutorial_tablet_feedback_margin_top:I

.field public static gesture_tutorial_tablet_message_1_margin:I

.field public static gesture_tutorial_tablet_message_2_margin:I

.field public static gesture_tutorial_tablet_message_3_margin:I

.field public static gesture_tutorial_tablet_message_padding_start_end:I

.field public static gesture_tutorial_tablet_reply_1_margin:I

.field public static gesture_tutorial_tablet_reply_2_margin:I

.field public static gesture_tutorial_taskbar_all_apps_mini_size:I

.field public static gesture_tutorial_taskbar_corner_radius:I

.field public static gesture_tutorial_taskbar_icon_corner_radius:I

.field public static gesture_tutorial_taskbar_icon_size:I

.field public static gesture_tutorial_taskbar_icon_spacing:I

.field public static gesture_tutorial_taskbar_margin_bottom:I

.field public static gesture_tutorial_taskbar_padding:I

.field public static gesture_tutorial_taskbar_padding_start_end:I

.field public static gesture_tutorial_top_bar_button_margin_end:I

.field public static gesture_tutorial_top_bar_margin_end:I

.field public static gesture_tutorial_top_bar_margin_start:I

.field public static gesture_tutorial_webpage_block_margin_end:I

.field public static gesture_tutorial_webpage_large_corner_radius:I

.field public static gesture_tutorial_webpage_large_line_height:I

.field public static gesture_tutorial_webpage_large_margin_top:I

.field public static gesture_tutorial_webpage_line_1_margin_end:I

.field public static gesture_tutorial_webpage_line_2_margin_end:I

.field public static gesture_tutorial_webpage_line_3_margin_end:I

.field public static gesture_tutorial_webpage_medium_corner_radius:I

.field public static gesture_tutorial_webpage_padding_top:I

.field public static gesture_tutorial_webpage_small_corner_radius:I

.field public static gesture_tutorial_webpage_small_line_height:I

.field public static gesture_tutorial_webpage_small_margin_top:I

.field public static gesture_tutorial_webpage_top_bar_button_margin_start:I

.field public static gesture_tutorial_webpage_top_bar_margin_end:I

.field public static gesture_tutorial_webpage_top_bar_margin_start:I

.field public static gesture_tutorial_webpage_url_margin_start_end:I

.field public static gestures_assistant_drag_threshold:I

.field public static gestures_assistant_fling_threshold:I

.field public static gestures_assistant_width:I

.field public static gestures_onehanded_drag_threshold:I

.field public static gestures_overscroll_active_threshold:I

.field public static gestures_overscroll_finish_threshold:I

.field public static gestures_overscroll_fling_threshold:I

.field public static global_search_anim_margin_top:I

.field public static global_search_hint_margin_top:I

.field public static global_search_hint_text_width:I

.field public static global_search_know_height:I

.field public static global_search_know_margin_top:I

.field public static global_search_know_radius:I

.field public static global_search_know_width:I

.field public static grid_visualization_cell_spacing:I

.field public static grid_visualization_horizontal_cell_spacing:I

.field public static grid_visualization_rounding_radius:I

.field public static grid_visualization_vertical_cell_spacing:I

.field public static highlight_alpha_material_colored:I

.field public static highlight_alpha_material_dark:I

.field public static highlight_alpha_material_light:I

.field public static hint_alpha_material_dark:I

.field public static hint_alpha_material_light:I

.field public static hint_pressed_alpha_material_dark:I

.field public static hint_pressed_alpha_material_light:I

.field public static hint_scale_damping_ratio:I

.field public static hint_scale_stiffness:I

.field public static hint_scale_velocity_dp_per_s:I

.field public static home_pullback_distance:I

.field public static home_screen_padding_end:I

.field public static home_screen_padding_start:I

.field public static home_setting_main_list_category:I

.field public static home_setting_main_list_summary:I

.field public static home_setting_main_list_title:I

.field public static home_setting_main_page_padding:I

.field public static home_setting_other_page_padding:I

.field public static home_setting_switch_width:I

.field public static home_setting_tool_bar_height:I

.field public static home_style_radio_margin_end:I

.field public static home_style_radio_margin_start:I

.field public static home_style_radio_padding:I

.field public static home_style_setting_option_divider_padding:I

.field public static horizontal_ellipsis_size:I

.field public static hotseat_bar_bottom_space_default:I

.field public static hotseat_bar_size:I

.field public static hotseat_edu_content_max_height:I

.field public static hotseat_edu_heading_max_height:I

.field public static hotseat_qsb_space_default:I

.field public static iconSize110dp:I

.field public static iconSize144dp:I

.field public static iconSize48dp:I

.field public static iconSize50dp:I

.field public static iconSize52dp:I

.field public static iconSize54dp:I

.field public static iconSize56dp:I

.field public static iconSize58dp:I

.field public static iconSize60dp:I

.field public static iconSize66dp:I

.field public static iconSize72dp:I

.field public static iconSize82dp:I

.field public static icon_create_folder_submit_bg_height:I

.field public static icon_create_folder_submit_btn_height:I

.field public static icon_create_folder_submit_btn_margin_bottom:I

.field public static icon_create_folder_submit_btn_margin_top:I

.field public static icon_personalize_recycerview_margin_start:I

.field public static icon_personalize_recycerview_margin_top:I

.field public static icon_personalize_recyclerview_corner:I

.field public static icon_personalize_rv_item_height_extra:I

.field public static icon_personalized_degree_scale_radius:I

.field public static icon_personalized_des:I

.field public static icon_personalized_des_height:I

.field public static icon_personalized_des_marginBottom:I

.field public static icon_personalized_des_marginTop:I

.field public static icon_personalized_des_margin_start:I

.field public static icon_personalized_drawable_padding:I

.field public static icon_personalized_popup_text_margin:I

.field public static icon_personalized_popup_text_size:I

.field public static icon_personalized_preview_height:I

.field public static icon_personalized_preview_padding_start:I

.field public static icon_personalized_preview_size:I

.field public static icon_personalized_rv_height:I

.field public static icon_personalized_rv_item_padding:I

.field public static icon_personalized_rv_padding_start:I

.field public static icon_personalized_rv_padding_top:I

.field public static icon_personalized_seekbar_hieght:I

.field public static icon_personalized_seekbar_margin_bottom:I

.field public static icon_personalized_seekbar_margin_top:I

.field public static icon_personalized_seekbar_minus_height:I

.field public static icon_personalized_seekbar_minus_margin_bottom:I

.field public static icon_personalized_seekbar_minus_margin_end:I

.field public static icon_personalized_seekbar_minus_margin_start:I

.field public static icon_personalized_seekbar_minus_width:I

.field public static icon_personalized_slide_bar_height:I

.field public static icon_personalized_slide_bar_margin_start:I

.field public static icon_personalized_slide_bar_width:I

.field public static icon_personalized_slider_bar_margin:I

.field public static icon_personalized_slider_press_radius:I

.field public static icon_personalized_slider_press_shadow_radius:I

.field public static icon_personalized_slider_radius_size:I

.field public static icon_personalized_top_layout_height:I

.field public static icon_size_hint_margin_bottom:I

.field public static icon_size_hint_margin_start:I

.field public static icon_size_recyclerview_height:I

.field public static icon_size_slide_bar_radius:I

.field public static icon_size_slide_bar_scale_margin_horizontal:I

.field public static item_touch_helper_max_drag_scroll_per_frame:I

.field public static item_touch_helper_swipe_escape_max_velocity:I

.field public static item_touch_helper_swipe_escape_velocity:I

.field public static key_button_ripple_max_width:I

.field public static keyboard_drag_stroke_width:I

.field public static keyboard_quick_switch_border_width:I

.field public static keyboard_quick_switch_margin_ends:I

.field public static keyboard_quick_switch_margin_top:I

.field public static keyboard_quick_switch_no_recent_items_icon_margin:I

.field public static keyboard_quick_switch_no_recent_items_icon_size:I

.field public static keyboard_quick_switch_recents_icon_size:I

.field public static keyboard_quick_switch_split_view_spacing:I

.field public static keyboard_quick_switch_task_view_radius:I

.field public static keyboard_quick_switch_taskview_height:I

.field public static keyboard_quick_switch_taskview_icon_size:I

.field public static keyboard_quick_switch_taskview_width:I

.field public static keyboard_quick_switch_view_radius:I

.field public static keyboard_quick_switch_view_spacing:I

.field public static m3_alert_dialog_action_bottom_padding:I

.field public static m3_alert_dialog_action_top_padding:I

.field public static m3_alert_dialog_corner_size:I

.field public static m3_alert_dialog_elevation:I

.field public static m3_alert_dialog_icon_margin:I

.field public static m3_alert_dialog_icon_size:I

.field public static m3_alert_dialog_title_bottom_margin:I

.field public static m3_appbar_expanded_title_margin_bottom:I

.field public static m3_appbar_expanded_title_margin_horizontal:I

.field public static m3_appbar_scrim_height_trigger:I

.field public static m3_appbar_scrim_height_trigger_large:I

.field public static m3_appbar_scrim_height_trigger_medium:I

.field public static m3_appbar_size_compact:I

.field public static m3_appbar_size_large:I

.field public static m3_appbar_size_medium:I

.field public static m3_back_progress_bottom_container_max_scale_x_distance:I

.field public static m3_back_progress_bottom_container_max_scale_y_distance:I

.field public static m3_back_progress_main_container_max_translation_y:I

.field public static m3_back_progress_main_container_min_edge_gap:I

.field public static m3_back_progress_side_container_max_scale_x_distance_grow:I

.field public static m3_back_progress_side_container_max_scale_x_distance_shrink:I

.field public static m3_back_progress_side_container_max_scale_y_distance:I

.field public static m3_badge_horizontal_offset:I

.field public static m3_badge_offset:I

.field public static m3_badge_size:I

.field public static m3_badge_vertical_offset:I

.field public static m3_badge_with_text_horizontal_offset:I

.field public static m3_badge_with_text_offset:I

.field public static m3_badge_with_text_size:I

.field public static m3_badge_with_text_vertical_offset:I

.field public static m3_badge_with_text_vertical_padding:I

.field public static m3_bottom_nav_item_active_indicator_height:I

.field public static m3_bottom_nav_item_active_indicator_margin_horizontal:I

.field public static m3_bottom_nav_item_active_indicator_width:I

.field public static m3_bottom_nav_item_expanded_active_indicator_height:I

.field public static m3_bottom_nav_item_padding_bottom:I

.field public static m3_bottom_nav_item_padding_top:I

.field public static m3_bottom_nav_min_height:I

.field public static m3_bottom_sheet_drag_handle_bottom_padding:I

.field public static m3_bottom_sheet_elevation:I

.field public static m3_bottom_sheet_modal_elevation:I

.field public static m3_bottomappbar_fab_cradle_margin:I

.field public static m3_bottomappbar_fab_cradle_rounded_corner_radius:I

.field public static m3_bottomappbar_fab_cradle_vertical_offset:I

.field public static m3_bottomappbar_fab_end_margin:I

.field public static m3_bottomappbar_height:I

.field public static m3_bottomappbar_horizontal_padding:I

.field public static m3_btn_dialog_btn_min_width:I

.field public static m3_btn_dialog_btn_spacing:I

.field public static m3_btn_disabled_elevation:I

.field public static m3_btn_disabled_translation_z:I

.field public static m3_btn_elevated_translation_z_hovered:I

.field public static m3_btn_elevation:I

.field public static m3_btn_icon_btn_padding_left:I

.field public static m3_btn_icon_btn_padding_right:I

.field public static m3_btn_icon_only_default_padding:I

.field public static m3_btn_icon_only_default_size:I

.field public static m3_btn_icon_only_icon_padding:I

.field public static m3_btn_icon_only_min_width:I

.field public static m3_btn_inset:I

.field public static m3_btn_max_width:I

.field public static m3_btn_padding_bottom:I

.field public static m3_btn_padding_left:I

.field public static m3_btn_padding_right:I

.field public static m3_btn_padding_top:I

.field public static m3_btn_stroke_size:I

.field public static m3_btn_text_btn_icon_padding_left:I

.field public static m3_btn_text_btn_icon_padding_right:I

.field public static m3_btn_text_btn_padding_left:I

.field public static m3_btn_text_btn_padding_right:I

.field public static m3_btn_translation_z_base:I

.field public static m3_btn_translation_z_hovered:I

.field public static m3_card_disabled_z:I

.field public static m3_card_dragged_z:I

.field public static m3_card_elevated_disabled_z:I

.field public static m3_card_elevated_dragged_z:I

.field public static m3_card_elevated_elevation:I

.field public static m3_card_elevated_hovered_z:I

.field public static m3_card_elevation:I

.field public static m3_card_hovered_z:I

.field public static m3_card_stroke_width:I

.field public static m3_carousel_debug_keyline_width:I

.field public static m3_carousel_extra_small_item_size:I

.field public static m3_carousel_gone_size:I

.field public static m3_carousel_small_item_default_corner_size:I

.field public static m3_carousel_small_item_size_max:I

.field public static m3_carousel_small_item_size_min:I

.field public static m3_chip_checked_hovered_translation_z:I

.field public static m3_chip_corner_size:I

.field public static m3_chip_disabled_translation_z:I

.field public static m3_chip_dragged_translation_z:I

.field public static m3_chip_elevated_elevation:I

.field public static m3_chip_hovered_translation_z:I

.field public static m3_chip_icon_size:I

.field public static m3_comp_assist_chip_container_height:I

.field public static m3_comp_assist_chip_elevated_container_elevation:I

.field public static m3_comp_assist_chip_flat_container_elevation:I

.field public static m3_comp_assist_chip_flat_outline_width:I

.field public static m3_comp_assist_chip_with_icon_icon_size:I

.field public static m3_comp_badge_large_size:I

.field public static m3_comp_badge_size:I

.field public static m3_comp_bottom_app_bar_container_elevation:I

.field public static m3_comp_bottom_app_bar_container_height:I

.field public static m3_comp_button_elevated_container_elevation:I

.field public static m3_comp_button_elevated_disabled_container_elevation:I

.field public static m3_comp_button_filled_container_elevation:I

.field public static m3_comp_button_filled_disabled_container_elevation:I

.field public static m3_comp_button_group_connected_small_between_space:I

.field public static m3_comp_button_group_standard_small_between_space:I

.field public static m3_comp_button_small_icon_label_space:I

.field public static m3_comp_button_small_leading_space:I

.field public static m3_comp_button_small_outlined_outline_width:I

.field public static m3_comp_button_text_focused_state_layer_opacity:I

.field public static m3_comp_button_text_hovered_state_layer_opacity:I

.field public static m3_comp_button_text_pressed_state_layer_opacity:I

.field public static m3_comp_button_tonal_container_elevation:I

.field public static m3_comp_checkbox_selected_disabled_container_opacity:I

.field public static m3_comp_date_picker_modal_date_today_container_outline_width:I

.field public static m3_comp_date_picker_modal_header_container_height:I

.field public static m3_comp_date_picker_modal_range_selection_header_container_height:I

.field public static m3_comp_divider_thickness:I

.field public static m3_comp_elevated_card_container_elevation:I

.field public static m3_comp_elevated_card_icon_size:I

.field public static m3_comp_extended_fab_primary_container_elevation:I

.field public static m3_comp_extended_fab_primary_container_height:I

.field public static m3_comp_extended_fab_primary_focus_container_elevation:I

.field public static m3_comp_extended_fab_primary_focus_state_layer_opacity:I

.field public static m3_comp_extended_fab_primary_hover_container_elevation:I

.field public static m3_comp_extended_fab_primary_hover_state_layer_opacity:I

.field public static m3_comp_extended_fab_primary_icon_size:I

.field public static m3_comp_extended_fab_primary_pressed_container_elevation:I

.field public static m3_comp_extended_fab_primary_pressed_state_layer_opacity:I

.field public static m3_comp_fab_primary_container_elevation:I

.field public static m3_comp_fab_primary_container_height:I

.field public static m3_comp_fab_primary_focus_state_layer_opacity:I

.field public static m3_comp_fab_primary_hover_container_elevation:I

.field public static m3_comp_fab_primary_hover_state_layer_opacity:I

.field public static m3_comp_fab_primary_icon_size:I

.field public static m3_comp_fab_primary_large_container_height:I

.field public static m3_comp_fab_primary_large_icon_size:I

.field public static m3_comp_fab_primary_pressed_container_elevation:I

.field public static m3_comp_fab_primary_pressed_state_layer_opacity:I

.field public static m3_comp_fab_primary_small_container_height:I

.field public static m3_comp_fab_primary_small_icon_size:I

.field public static m3_comp_filled_autocomplete_menu_container_elevation:I

.field public static m3_comp_filled_card_container_elevation:I

.field public static m3_comp_filled_card_dragged_state_layer_opacity:I

.field public static m3_comp_filled_card_focus_state_layer_opacity:I

.field public static m3_comp_filled_card_hover_state_layer_opacity:I

.field public static m3_comp_filled_card_icon_size:I

.field public static m3_comp_filled_card_pressed_state_layer_opacity:I

.field public static m3_comp_filled_text_field_disabled_active_indicator_opacity:I

.field public static m3_comp_filter_chip_container_height:I

.field public static m3_comp_filter_chip_elevated_container_elevation:I

.field public static m3_comp_filter_chip_flat_container_elevation:I

.field public static m3_comp_filter_chip_flat_unselected_outline_width:I

.field public static m3_comp_filter_chip_with_icon_icon_size:I

.field public static m3_comp_icon_button_small_outlined_outline_width:I

.field public static m3_comp_input_chip_container_elevation:I

.field public static m3_comp_input_chip_container_height:I

.field public static m3_comp_input_chip_unselected_outline_width:I

.field public static m3_comp_input_chip_with_avatar_avatar_size:I

.field public static m3_comp_input_chip_with_leading_icon_leading_icon_size:I

.field public static m3_comp_loading_indicator_container_height:I

.field public static m3_comp_loading_indicator_container_width:I

.field public static m3_comp_menu_container_elevation:I

.field public static m3_comp_navigation_bar_active_indicator_height:I

.field public static m3_comp_navigation_bar_active_indicator_width:I

.field public static m3_comp_navigation_bar_container_elevation:I

.field public static m3_comp_navigation_bar_container_height:I

.field public static m3_comp_navigation_bar_focus_state_layer_opacity:I

.field public static m3_comp_navigation_bar_hover_state_layer_opacity:I

.field public static m3_comp_navigation_bar_icon_size:I

.field public static m3_comp_navigation_bar_pressed_state_layer_opacity:I

.field public static m3_comp_navigation_drawer_container_width:I

.field public static m3_comp_navigation_drawer_focus_state_layer_opacity:I

.field public static m3_comp_navigation_drawer_hover_state_layer_opacity:I

.field public static m3_comp_navigation_drawer_icon_size:I

.field public static m3_comp_navigation_drawer_modal_container_elevation:I

.field public static m3_comp_navigation_drawer_pressed_state_layer_opacity:I

.field public static m3_comp_navigation_drawer_standard_container_elevation:I

.field public static m3_comp_navigation_rail_active_indicator_height:I

.field public static m3_comp_navigation_rail_active_indicator_width:I

.field public static m3_comp_navigation_rail_container_elevation:I

.field public static m3_comp_navigation_rail_container_width:I

.field public static m3_comp_navigation_rail_focus_state_layer_opacity:I

.field public static m3_comp_navigation_rail_hover_state_layer_opacity:I

.field public static m3_comp_navigation_rail_icon_size:I

.field public static m3_comp_navigation_rail_pressed_state_layer_opacity:I

.field public static m3_comp_outlined_autocomplete_menu_container_elevation:I

.field public static m3_comp_outlined_card_container_elevation:I

.field public static m3_comp_outlined_card_disabled_outline_opacity:I

.field public static m3_comp_outlined_card_icon_size:I

.field public static m3_comp_outlined_card_outline_width:I

.field public static m3_comp_outlined_text_field_disabled_input_text_opacity:I

.field public static m3_comp_outlined_text_field_disabled_label_text_opacity:I

.field public static m3_comp_outlined_text_field_disabled_supporting_text_opacity:I

.field public static m3_comp_outlined_text_field_focus_outline_width:I

.field public static m3_comp_outlined_text_field_outline_width:I

.field public static m3_comp_primary_navigation_tab_active_focus_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_active_hover_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_active_indicator_height:I

.field public static m3_comp_primary_navigation_tab_active_pressed_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_inactive_focus_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_inactive_hover_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_inactive_pressed_state_layer_opacity:I

.field public static m3_comp_primary_navigation_tab_with_icon_icon_size:I

.field public static m3_comp_progress_indicator_circular_size:I

.field public static m3_comp_progress_indicator_circular_track_active_indicator_space:I

.field public static m3_comp_progress_indicator_circular_track_thickness:I

.field public static m3_comp_progress_indicator_linear_stop_indicator_size:I

.field public static m3_comp_progress_indicator_linear_track_active_indicator_space:I

.field public static m3_comp_progress_indicator_linear_track_thickness:I

.field public static m3_comp_radio_button_disabled_selected_icon_opacity:I

.field public static m3_comp_radio_button_disabled_unselected_icon_opacity:I

.field public static m3_comp_radio_button_selected_focus_state_layer_opacity:I

.field public static m3_comp_radio_button_selected_hover_state_layer_opacity:I

.field public static m3_comp_radio_button_selected_pressed_state_layer_opacity:I

.field public static m3_comp_radio_button_unselected_focus_state_layer_opacity:I

.field public static m3_comp_radio_button_unselected_hover_state_layer_opacity:I

.field public static m3_comp_radio_button_unselected_pressed_state_layer_opacity:I

.field public static m3_comp_scrim_container_opacity:I

.field public static m3_comp_search_bar_avatar_size:I

.field public static m3_comp_search_bar_container_elevation:I

.field public static m3_comp_search_bar_container_height:I

.field public static m3_comp_search_bar_hover_state_layer_opacity:I

.field public static m3_comp_search_bar_pressed_state_layer_opacity:I

.field public static m3_comp_search_view_container_elevation:I

.field public static m3_comp_search_view_docked_header_container_height:I

.field public static m3_comp_search_view_full_screen_header_container_height:I

.field public static m3_comp_secondary_navigation_tab_active_indicator_height:I

.field public static m3_comp_secondary_navigation_tab_focus_state_layer_opacity:I

.field public static m3_comp_secondary_navigation_tab_hover_state_layer_opacity:I

.field public static m3_comp_secondary_navigation_tab_pressed_state_layer_opacity:I

.field public static m3_comp_sheet_bottom_docked_drag_handle_height:I

.field public static m3_comp_sheet_bottom_docked_drag_handle_width:I

.field public static m3_comp_sheet_bottom_docked_modal_container_elevation:I

.field public static m3_comp_sheet_bottom_docked_standard_container_elevation:I

.field public static m3_comp_sheet_side_docked_container_width:I

.field public static m3_comp_sheet_side_docked_modal_container_elevation:I

.field public static m3_comp_sheet_side_docked_standard_container_elevation:I

.field public static m3_comp_slider_active_handle_height:I

.field public static m3_comp_slider_active_handle_leading_space:I

.field public static m3_comp_slider_active_handle_width:I

.field public static m3_comp_slider_active_stop_indicator_container_opacity:I

.field public static m3_comp_slider_disabled_active_track_opacity:I

.field public static m3_comp_slider_disabled_handle_opacity:I

.field public static m3_comp_slider_disabled_inactive_track_opacity:I

.field public static m3_comp_slider_inactive_stop_indicator_container_opacity:I

.field public static m3_comp_slider_inactive_track_height:I

.field public static m3_comp_slider_stop_indicator_size:I

.field public static m3_comp_slider_value_indicator_active_bottom_space:I

.field public static m3_comp_snackbar_container_elevation:I

.field public static m3_comp_split_button_large_leading_button_leading_space:I

.field public static m3_comp_split_button_large_leading_button_trailing_space:I

.field public static m3_comp_split_button_large_trailing_button_icon_size:I

.field public static m3_comp_split_button_large_trailing_button_leading_space:I

.field public static m3_comp_split_button_large_trailing_button_trailing_space:I

.field public static m3_comp_split_button_medium_leading_button_leading_space:I

.field public static m3_comp_split_button_medium_leading_button_trailing_space:I

.field public static m3_comp_split_button_medium_trailing_button_icon_size:I

.field public static m3_comp_split_button_medium_trailing_button_leading_space:I

.field public static m3_comp_split_button_medium_trailing_button_trailing_space:I

.field public static m3_comp_split_button_small_leading_button_leading_space:I

.field public static m3_comp_split_button_small_leading_button_trailing_space:I

.field public static m3_comp_split_button_small_trailing_button_icon_size:I

.field public static m3_comp_split_button_small_trailing_button_leading_space:I

.field public static m3_comp_split_button_small_trailing_button_trailing_space:I

.field public static m3_comp_split_button_xlarge_leading_button_leading_space:I

.field public static m3_comp_split_button_xlarge_leading_button_trailing_space:I

.field public static m3_comp_split_button_xlarge_trailing_button_icon_size:I

.field public static m3_comp_split_button_xlarge_trailing_button_leading_space:I

.field public static m3_comp_split_button_xlarge_trailing_button_trailing_space:I

.field public static m3_comp_split_button_xsmall_leading_button_leading_space:I

.field public static m3_comp_split_button_xsmall_leading_button_trailing_space:I

.field public static m3_comp_split_button_xsmall_trailing_button_icon_size:I

.field public static m3_comp_split_button_xsmall_trailing_button_leading_space:I

.field public static m3_comp_split_button_xsmall_trailing_button_trailing_space:I

.field public static m3_comp_suggestion_chip_container_height:I

.field public static m3_comp_suggestion_chip_elevated_container_elevation:I

.field public static m3_comp_suggestion_chip_flat_container_elevation:I

.field public static m3_comp_suggestion_chip_flat_outline_width:I

.field public static m3_comp_suggestion_chip_with_leading_icon_leading_icon_size:I

.field public static m3_comp_switch_disabled_selected_handle_opacity:I

.field public static m3_comp_switch_disabled_selected_icon_opacity:I

.field public static m3_comp_switch_disabled_track_opacity:I

.field public static m3_comp_switch_disabled_unselected_handle_opacity:I

.field public static m3_comp_switch_disabled_unselected_icon_opacity:I

.field public static m3_comp_switch_selected_focus_state_layer_opacity:I

.field public static m3_comp_switch_selected_hover_state_layer_opacity:I

.field public static m3_comp_switch_selected_pressed_state_layer_opacity:I

.field public static m3_comp_switch_track_height:I

.field public static m3_comp_switch_track_width:I

.field public static m3_comp_switch_unselected_focus_state_layer_opacity:I

.field public static m3_comp_switch_unselected_hover_state_layer_opacity:I

.field public static m3_comp_switch_unselected_pressed_state_layer_opacity:I

.field public static m3_comp_time_input_time_input_field_focus_outline_width:I

.field public static m3_comp_time_picker_container_elevation:I

.field public static m3_comp_time_picker_period_selector_focus_state_layer_opacity:I

.field public static m3_comp_time_picker_period_selector_hover_state_layer_opacity:I

.field public static m3_comp_time_picker_period_selector_outline_width:I

.field public static m3_comp_time_picker_period_selector_pressed_state_layer_opacity:I

.field public static m3_comp_time_picker_time_selector_focus_state_layer_opacity:I

.field public static m3_comp_time_picker_time_selector_hover_state_layer_opacity:I

.field public static m3_comp_time_picker_time_selector_pressed_state_layer_opacity:I

.field public static m3_comp_toolbar_floating_container_external_padding:I

.field public static m3_comp_toolbar_floating_container_height:I

.field public static m3_comp_toolbar_floating_container_leading_space:I

.field public static m3_comp_toolbar_floating_container_trailing_space:I

.field public static m3_comp_top_app_bar_large_container_height:I

.field public static m3_comp_top_app_bar_medium_container_height:I

.field public static m3_comp_top_app_bar_small_container_elevation:I

.field public static m3_comp_top_app_bar_small_container_height:I

.field public static m3_comp_top_app_bar_small_on_scroll_container_elevation:I

.field public static m3_datepicker_elevation:I

.field public static m3_divider_heavy_thickness:I

.field public static m3_extended_fab_bottom_padding:I

.field public static m3_extended_fab_end_padding:I

.field public static m3_extended_fab_icon_padding:I

.field public static m3_extended_fab_min_height:I

.field public static m3_extended_fab_start_padding:I

.field public static m3_extended_fab_top_padding:I

.field public static m3_fab_border_width:I

.field public static m3_fab_corner_size:I

.field public static m3_fab_translation_z_hovered_focused:I

.field public static m3_fab_translation_z_pressed:I

.field public static m3_floatingtoolbar_min_height:I

.field public static m3_floatingtoolbar_min_width:I

.field public static m3_large_fab_max_image_size:I

.field public static m3_large_fab_size:I

.field public static m3_large_text_vertical_offset_adjustment:I

.field public static m3_loading_indicator_container_size:I

.field public static m3_loading_indicator_shape_size:I

.field public static m3_menu_elevation:I

.field public static m3_multiline_hint_filled_text_extra_space:I

.field public static m3_nav_badge_with_text_vertical_offset:I

.field public static m3_navigation_drawer_layout_corner_size:I

.field public static m3_navigation_item_active_indicator_label_padding:I

.field public static m3_navigation_item_expanded_active_indicator_height_default:I

.field public static m3_navigation_item_horizontal_padding:I

.field public static m3_navigation_item_icon_padding:I

.field public static m3_navigation_item_leading_trailing_space:I

.field public static m3_navigation_item_shape_inset_bottom:I

.field public static m3_navigation_item_shape_inset_end:I

.field public static m3_navigation_item_shape_inset_start:I

.field public static m3_navigation_item_shape_inset_top:I

.field public static m3_navigation_item_vertical_padding:I

.field public static m3_navigation_menu_divider_horizontal_padding:I

.field public static m3_navigation_menu_headline_horizontal_padding:I

.field public static m3_navigation_rail_default_width:I

.field public static m3_navigation_rail_elevation:I

.field public static m3_navigation_rail_expanded_active_indicator_height:I

.field public static m3_navigation_rail_expanded_item_min_height:I

.field public static m3_navigation_rail_expanded_item_spacing:I

.field public static m3_navigation_rail_expanded_leading_trailing_space:I

.field public static m3_navigation_rail_icon_label_horizontal_padding:I

.field public static m3_navigation_rail_icon_label_padding:I

.field public static m3_navigation_rail_icon_size:I

.field public static m3_navigation_rail_item_active_indicator_height:I

.field public static m3_navigation_rail_item_active_indicator_margin_horizontal:I

.field public static m3_navigation_rail_item_active_indicator_width:I

.field public static m3_navigation_rail_item_min_height:I

.field public static m3_navigation_rail_item_padding_bottom:I

.field public static m3_navigation_rail_item_padding_bottom_with_large_font:I

.field public static m3_navigation_rail_item_padding_top:I

.field public static m3_navigation_rail_item_padding_top_with_large_font:I

.field public static m3_navigation_rail_label_padding_horizontal:I

.field public static m3_navigation_rail_max_expanded_width:I

.field public static m3_navigation_rail_min_expanded_width:I

.field public static m3_navigation_subheader_horizontal_margin:I

.field public static m3_navigation_subheader_horizontal_padding:I

.field public static m3_navigation_subheader_top_margin:I

.field public static m3_navigation_subheader_vertical_padding:I

.field public static m3_ripple_default_alpha:I

.field public static m3_ripple_focused_alpha:I

.field public static m3_ripple_hovered_alpha:I

.field public static m3_ripple_pressed_alpha:I

.field public static m3_ripple_selectable_pressed_alpha:I

.field public static m3_searchbar_elevation:I

.field public static m3_searchbar_height:I

.field public static m3_searchbar_margin_horizontal:I

.field public static m3_searchbar_margin_vertical:I

.field public static m3_searchbar_outlined_stroke_width:I

.field public static m3_searchbar_padding_start:I

.field public static m3_searchbar_text_margin_start_no_navigation_icon:I

.field public static m3_searchbar_text_size:I

.field public static m3_searchview_divider_size:I

.field public static m3_searchview_elevation:I

.field public static m3_searchview_height:I

.field public static m3_side_sheet_margin_detached:I

.field public static m3_side_sheet_modal_elevation:I

.field public static m3_side_sheet_standard_elevation:I

.field public static m3_side_sheet_width:I

.field public static m3_simple_item_color_hovered_alpha:I

.field public static m3_simple_item_color_selected_alpha:I

.field public static m3_slider_thumb_elevation:I

.field public static m3_slider_track_icon_padding:I

.field public static m3_small_fab_max_image_size:I

.field public static m3_small_fab_size:I

.field public static m3_snackbar_action_text_color_alpha:I

.field public static m3_snackbar_margin:I

.field public static m3_sys_elevation_level0:I

.field public static m3_sys_elevation_level1:I

.field public static m3_sys_elevation_level2:I

.field public static m3_sys_elevation_level3:I

.field public static m3_sys_elevation_level4:I

.field public static m3_sys_elevation_level5:I

.field public static m3_sys_motion_easing_emphasized_accelerate_control_x1:I

.field public static m3_sys_motion_easing_emphasized_accelerate_control_x2:I

.field public static m3_sys_motion_easing_emphasized_accelerate_control_y1:I

.field public static m3_sys_motion_easing_emphasized_accelerate_control_y2:I

.field public static m3_sys_motion_easing_emphasized_decelerate_control_x1:I

.field public static m3_sys_motion_easing_emphasized_decelerate_control_x2:I

.field public static m3_sys_motion_easing_emphasized_decelerate_control_y1:I

.field public static m3_sys_motion_easing_emphasized_decelerate_control_y2:I

.field public static m3_sys_motion_easing_legacy_accelerate_control_x1:I

.field public static m3_sys_motion_easing_legacy_accelerate_control_x2:I

.field public static m3_sys_motion_easing_legacy_accelerate_control_y1:I

.field public static m3_sys_motion_easing_legacy_accelerate_control_y2:I

.field public static m3_sys_motion_easing_legacy_control_x1:I

.field public static m3_sys_motion_easing_legacy_control_x2:I

.field public static m3_sys_motion_easing_legacy_control_y1:I

.field public static m3_sys_motion_easing_legacy_control_y2:I

.field public static m3_sys_motion_easing_legacy_decelerate_control_x1:I

.field public static m3_sys_motion_easing_legacy_decelerate_control_x2:I

.field public static m3_sys_motion_easing_legacy_decelerate_control_y1:I

.field public static m3_sys_motion_easing_legacy_decelerate_control_y2:I

.field public static m3_sys_motion_easing_linear_control_x1:I

.field public static m3_sys_motion_easing_linear_control_x2:I

.field public static m3_sys_motion_easing_linear_control_y1:I

.field public static m3_sys_motion_easing_linear_control_y2:I

.field public static m3_sys_motion_easing_standard_accelerate_control_x1:I

.field public static m3_sys_motion_easing_standard_accelerate_control_x2:I

.field public static m3_sys_motion_easing_standard_accelerate_control_y1:I

.field public static m3_sys_motion_easing_standard_accelerate_control_y2:I

.field public static m3_sys_motion_easing_standard_control_x1:I

.field public static m3_sys_motion_easing_standard_control_x2:I

.field public static m3_sys_motion_easing_standard_control_y1:I

.field public static m3_sys_motion_easing_standard_control_y2:I

.field public static m3_sys_motion_easing_standard_decelerate_control_x1:I

.field public static m3_sys_motion_easing_standard_decelerate_control_x2:I

.field public static m3_sys_motion_easing_standard_decelerate_control_y1:I

.field public static m3_sys_motion_easing_standard_decelerate_control_y2:I

.field public static m3_sys_state_dragged_state_layer_opacity:I

.field public static m3_sys_state_focus_state_layer_opacity:I

.field public static m3_sys_state_hover_state_layer_opacity:I

.field public static m3_sys_state_pressed_state_layer_opacity:I

.field public static m3_timepicker_display_stroke_width:I

.field public static m3_timepicker_window_elevation:I

.field public static m3_toolbar_text_size_title:I

.field public static material_bottom_sheet_max_width:I

.field public static material_clock_display_height:I

.field public static material_clock_display_padding:I

.field public static material_clock_display_width:I

.field public static material_clock_face_margin_bottom:I

.field public static material_clock_face_margin_top:I

.field public static material_clock_hand_center_dot_radius:I

.field public static material_clock_hand_padding:I

.field public static material_clock_hand_stroke_width:I

.field public static material_clock_number_text_size:I

.field public static material_clock_period_toggle_height:I

.field public static material_clock_period_toggle_horizontal_gap:I

.field public static material_clock_period_toggle_vertical_gap:I

.field public static material_clock_period_toggle_width:I

.field public static material_clock_size:I

.field public static material_cursor_inset:I

.field public static material_cursor_width:I

.field public static material_divider_thickness:I

.field public static material_emphasis_disabled:I

.field public static material_emphasis_disabled_background:I

.field public static material_emphasis_high_type:I

.field public static material_emphasis_medium:I

.field public static material_filled_edittext_font_1_3_padding_bottom:I

.field public static material_filled_edittext_font_1_3_padding_top:I

.field public static material_filled_edittext_font_2_0_padding_bottom:I

.field public static material_filled_edittext_font_2_0_padding_top:I

.field public static material_font_1_3_box_collapsed_padding_top:I

.field public static material_font_2_0_box_collapsed_padding_top:I

.field public static material_helper_text_default_padding_top:I

.field public static material_helper_text_font_1_3_padding_horizontal:I

.field public static material_helper_text_font_1_3_padding_top:I

.field public static material_input_text_to_prefix_suffix_padding:I

.field public static material_textinput_default_width:I

.field public static material_textinput_max_width:I

.field public static material_textinput_min_width:I

.field public static material_textinput_min_width_with_label:I

.field public static material_time_picker_minimum_screen_height:I

.field public static material_time_picker_minimum_screen_width:I

.field public static max_hotseat_icon_space:I

.field public static max_shadow_radius:I

.field public static max_task_dismiss_drag_velocity:I

.field public static max_width_and_height_of_small_display_cutout:I

.field public static min_fling_velocity:I

.field public static min_hotseat_icon_space:I

.field public static min_hotseat_qsb_width:I

.field public static min_page_snap_velocity:I

.field public static min_qsb_margin:I

.field public static minimum_icon_label_size:I

.field public static motion_pause_detector_min_displacement_from_app:I

.field public static motion_pause_detector_speed_fast:I

.field public static motion_pause_detector_speed_slow:I

.field public static motion_pause_detector_speed_somewhat_fast:I

.field public static motion_pause_detector_speed_very_slow:I

.field public static mtrl_alert_dialog_background_inset_bottom:I

.field public static mtrl_alert_dialog_background_inset_end:I

.field public static mtrl_alert_dialog_background_inset_start:I

.field public static mtrl_alert_dialog_background_inset_top:I

.field public static mtrl_alert_dialog_picker_background_inset:I

.field public static mtrl_badge_horizontal_edge_offset:I

.field public static mtrl_badge_long_text_horizontal_padding:I

.field public static mtrl_badge_size:I

.field public static mtrl_badge_text_horizontal_edge_offset:I

.field public static mtrl_badge_text_size:I

.field public static mtrl_badge_toolbar_action_menu_item_horizontal_offset:I

.field public static mtrl_badge_toolbar_action_menu_item_vertical_offset:I

.field public static mtrl_badge_with_text_size:I

.field public static mtrl_bottomappbar_fabOffsetEndMode:I

.field public static mtrl_bottomappbar_fab_bottom_margin:I

.field public static mtrl_bottomappbar_fab_cradle_margin:I

.field public static mtrl_bottomappbar_fab_cradle_rounded_corner_radius:I

.field public static mtrl_bottomappbar_fab_cradle_vertical_offset:I

.field public static mtrl_bottomappbar_height:I

.field public static mtrl_btn_corner_radius:I

.field public static mtrl_btn_dialog_btn_min_width:I

.field public static mtrl_btn_disabled_elevation:I

.field public static mtrl_btn_disabled_z:I

.field public static mtrl_btn_elevation:I

.field public static mtrl_btn_focused_z:I

.field public static mtrl_btn_hovered_z:I

.field public static mtrl_btn_icon_btn_padding_left:I

.field public static mtrl_btn_icon_padding:I

.field public static mtrl_btn_inset:I

.field public static mtrl_btn_letter_spacing:I

.field public static mtrl_btn_max_width:I

.field public static mtrl_btn_padding_bottom:I

.field public static mtrl_btn_padding_left:I

.field public static mtrl_btn_padding_right:I

.field public static mtrl_btn_padding_top:I

.field public static mtrl_btn_pressed_z:I

.field public static mtrl_btn_snackbar_margin_horizontal:I

.field public static mtrl_btn_stroke_size:I

.field public static mtrl_btn_text_btn_icon_padding:I

.field public static mtrl_btn_text_btn_padding_left:I

.field public static mtrl_btn_text_btn_padding_right:I

.field public static mtrl_btn_text_size:I

.field public static mtrl_btn_z:I

.field public static mtrl_calendar_action_confirm_button_min_width:I

.field public static mtrl_calendar_action_height:I

.field public static mtrl_calendar_action_padding:I

.field public static mtrl_calendar_bottom_padding:I

.field public static mtrl_calendar_content_padding:I

.field public static mtrl_calendar_day_corner:I

.field public static mtrl_calendar_day_height:I

.field public static mtrl_calendar_day_horizontal_padding:I

.field public static mtrl_calendar_day_today_stroke:I

.field public static mtrl_calendar_day_vertical_padding:I

.field public static mtrl_calendar_day_width:I

.field public static mtrl_calendar_days_of_week_height:I

.field public static mtrl_calendar_dialog_background_inset:I

.field public static mtrl_calendar_header_content_padding:I

.field public static mtrl_calendar_header_content_padding_fullscreen:I

.field public static mtrl_calendar_header_divider_thickness:I

.field public static mtrl_calendar_header_height:I

.field public static mtrl_calendar_header_height_fullscreen:I

.field public static mtrl_calendar_header_selection_line_height:I

.field public static mtrl_calendar_header_text_padding:I

.field public static mtrl_calendar_header_toggle_margin_bottom:I

.field public static mtrl_calendar_header_toggle_margin_top:I

.field public static mtrl_calendar_landscape_header_width:I

.field public static mtrl_calendar_maximum_default_fullscreen_minor_axis:I

.field public static mtrl_calendar_month_horizontal_padding:I

.field public static mtrl_calendar_month_vertical_padding:I

.field public static mtrl_calendar_navigation_bottom_padding:I

.field public static mtrl_calendar_navigation_height:I

.field public static mtrl_calendar_navigation_top_padding:I

.field public static mtrl_calendar_selection_baseline_to_top_fullscreen:I

.field public static mtrl_calendar_selection_text_baseline_to_bottom:I

.field public static mtrl_calendar_selection_text_baseline_to_bottom_fullscreen:I

.field public static mtrl_calendar_selection_text_baseline_to_top:I

.field public static mtrl_calendar_text_input_padding_top:I

.field public static mtrl_calendar_title_baseline_to_top:I

.field public static mtrl_calendar_title_baseline_to_top_fullscreen:I

.field public static mtrl_calendar_year_corner:I

.field public static mtrl_calendar_year_height:I

.field public static mtrl_calendar_year_horizontal_padding:I

.field public static mtrl_calendar_year_vertical_padding:I

.field public static mtrl_calendar_year_width:I

.field public static mtrl_card_checked_icon_margin:I

.field public static mtrl_card_checked_icon_size:I

.field public static mtrl_card_corner_radius:I

.field public static mtrl_card_dragged_z:I

.field public static mtrl_card_elevation:I

.field public static mtrl_card_spacing:I

.field public static mtrl_chip_pressed_translation_z:I

.field public static mtrl_chip_text_size:I

.field public static mtrl_exposed_dropdown_menu_popup_elevation:I

.field public static mtrl_exposed_dropdown_menu_popup_vertical_offset:I

.field public static mtrl_exposed_dropdown_menu_popup_vertical_padding:I

.field public static mtrl_extended_fab_bottom_padding:I

.field public static mtrl_extended_fab_disabled_elevation:I

.field public static mtrl_extended_fab_disabled_translation_z:I

.field public static mtrl_extended_fab_elevation:I

.field public static mtrl_extended_fab_end_padding:I

.field public static mtrl_extended_fab_end_padding_icon:I

.field public static mtrl_extended_fab_icon_size:I

.field public static mtrl_extended_fab_icon_text_spacing:I

.field public static mtrl_extended_fab_min_height:I

.field public static mtrl_extended_fab_min_width:I

.field public static mtrl_extended_fab_start_padding:I

.field public static mtrl_extended_fab_start_padding_icon:I

.field public static mtrl_extended_fab_top_padding:I

.field public static mtrl_extended_fab_translation_z_base:I

.field public static mtrl_extended_fab_translation_z_hovered_focused:I

.field public static mtrl_extended_fab_translation_z_pressed:I

.field public static mtrl_fab_elevation:I

.field public static mtrl_fab_min_touch_target:I

.field public static mtrl_fab_translation_z_hovered_focused:I

.field public static mtrl_fab_translation_z_pressed:I

.field public static mtrl_high_ripple_default_alpha:I

.field public static mtrl_high_ripple_focused_alpha:I

.field public static mtrl_high_ripple_hovered_alpha:I

.field public static mtrl_high_ripple_pressed_alpha:I

.field public static mtrl_low_ripple_default_alpha:I

.field public static mtrl_low_ripple_focused_alpha:I

.field public static mtrl_low_ripple_hovered_alpha:I

.field public static mtrl_low_ripple_pressed_alpha:I

.field public static mtrl_min_touch_target_size:I

.field public static mtrl_navigation_bar_item_default_icon_size:I

.field public static mtrl_navigation_bar_item_default_margin:I

.field public static mtrl_navigation_elevation:I

.field public static mtrl_navigation_item_horizontal_padding:I

.field public static mtrl_navigation_item_icon_padding:I

.field public static mtrl_navigation_item_icon_size:I

.field public static mtrl_navigation_item_shape_horizontal_margin:I

.field public static mtrl_navigation_item_shape_vertical_margin:I

.field public static mtrl_navigation_rail_active_text_size:I

.field public static mtrl_navigation_rail_compact_width:I

.field public static mtrl_navigation_rail_default_width:I

.field public static mtrl_navigation_rail_elevation:I

.field public static mtrl_navigation_rail_icon_margin:I

.field public static mtrl_navigation_rail_icon_size:I

.field public static mtrl_navigation_rail_margin:I

.field public static mtrl_navigation_rail_text_bottom_margin:I

.field public static mtrl_navigation_rail_text_size:I

.field public static mtrl_progress_circular_inset:I

.field public static mtrl_progress_circular_inset_extra_small:I

.field public static mtrl_progress_circular_inset_medium:I

.field public static mtrl_progress_circular_inset_small:I

.field public static mtrl_progress_circular_radius:I

.field public static mtrl_progress_circular_size:I

.field public static mtrl_progress_circular_size_extra_small:I

.field public static mtrl_progress_circular_size_medium:I

.field public static mtrl_progress_circular_size_small:I

.field public static mtrl_progress_circular_track_thickness_extra_small:I

.field public static mtrl_progress_circular_track_thickness_medium:I

.field public static mtrl_progress_circular_track_thickness_small:I

.field public static mtrl_progress_indicator_full_rounded_corner_radius:I

.field public static mtrl_progress_track_thickness:I

.field public static mtrl_shape_corner_size_large_component:I

.field public static mtrl_shape_corner_size_medium_component:I

.field public static mtrl_shape_corner_size_small_component:I

.field public static mtrl_slider_halo_radius:I

.field public static mtrl_slider_label_padding:I

.field public static mtrl_slider_label_radius:I

.field public static mtrl_slider_label_square_side:I

.field public static mtrl_slider_thumb_elevation:I

.field public static mtrl_slider_thumb_radius:I

.field public static mtrl_slider_tick_min_spacing:I

.field public static mtrl_slider_tick_radius:I

.field public static mtrl_slider_track_height:I

.field public static mtrl_slider_track_side_padding:I

.field public static mtrl_slider_widget_height:I

.field public static mtrl_snackbar_action_text_color_alpha:I

.field public static mtrl_snackbar_background_corner_radius:I

.field public static mtrl_snackbar_background_overlay_color_alpha:I

.field public static mtrl_snackbar_margin:I

.field public static mtrl_snackbar_message_margin_horizontal:I

.field public static mtrl_snackbar_padding_horizontal:I

.field public static mtrl_switch_text_padding:I

.field public static mtrl_switch_thumb_elevation:I

.field public static mtrl_switch_thumb_icon_size:I

.field public static mtrl_switch_thumb_size:I

.field public static mtrl_switch_track_height:I

.field public static mtrl_switch_track_width:I

.field public static mtrl_textinput_box_corner_radius_medium:I

.field public static mtrl_textinput_box_corner_radius_small:I

.field public static mtrl_textinput_box_label_cutout_padding:I

.field public static mtrl_textinput_box_stroke_width_default:I

.field public static mtrl_textinput_box_stroke_width_focused:I

.field public static mtrl_textinput_counter_margin_start:I

.field public static mtrl_textinput_end_icon_margin_start:I

.field public static mtrl_textinput_outline_box_expanded_padding:I

.field public static mtrl_textinput_start_icon_margin_end:I

.field public static mtrl_toolbar_default_height:I

.field public static mtrl_tooltip_arrowSize:I

.field public static mtrl_tooltip_cornerSize:I

.field public static mtrl_tooltip_minHeight:I

.field public static mtrl_tooltip_minWidth:I

.field public static mtrl_tooltip_padding:I

.field public static mtrl_transition_shared_axis_slide_distance:I

.field public static multi_window_task_divider_size:I

.field public static navigation_home_handle_width:I

.field public static navigation_key_padding:I

.field public static notification_action_icon_size:I

.field public static notification_action_text_size:I

.field public static notification_big_circle_margin:I

.field public static notification_circle_icon_size:I

.field public static notification_container_height:I

.field public static notification_content_margin_start:I

.field public static notification_header_count_text_size:I

.field public static notification_header_padding_start:I

.field public static notification_header_text_size:I

.field public static notification_icon_padding_start:I

.field public static notification_icon_size:I

.field public static notification_large_icon_height:I

.field public static notification_large_icon_width:I

.field public static notification_main_column_padding_top:I

.field public static notification_main_text_padding_start:I

.field public static notification_main_text_size:I

.field public static notification_main_title_size:I

.field public static notification_max_trans:I

.field public static notification_media_narrow_margin:I

.field public static notification_padding_bottom:I

.field public static notification_padding_end:I

.field public static notification_padding_header_top:I

.field public static notification_padding_top:I

.field public static notification_right_icon_size:I

.field public static notification_right_side_padding_top:I

.field public static notification_small_icon_background_padding:I

.field public static notification_small_icon_size_as_large:I

.field public static notification_space:I

.field public static notification_subtext_size:I

.field public static notification_top_pad:I

.field public static notification_top_pad_large_text:I

.field public static options_menu_icon_size:I

.field public static options_menu_thumb_size:I

.field public static overlay_tab_badge_size:I

.field public static overlay_tab_padding_bottom:I

.field public static overlay_tab_padding_h:I

.field public static overlay_tab_padding_top:I

.field public static overlay_tab_text_size:I

.field public static overlay_tabs_margin_start:I

.field public static overview_actions_bottom_margin:I

.field public static overview_actions_btn_height:I

.field public static overview_actions_btn_width:I

.field public static overview_actions_button_spacing:I

.field public static overview_actions_clear_all_btn_height:I

.field public static overview_actions_clear_all_btn_layout_height:I

.field public static overview_actions_clear_all_btn_layout_width:I

.field public static overview_actions_height:I

.field public static overview_actions_horizontal_margin:I

.field public static overview_actions_margin_gesture:I

.field public static overview_actions_padding_bottom:I

.field public static overview_actions_radius:I

.field public static overview_actions_top_margin:I

.field public static overview_bottom_margin_grid_only:I

.field public static overview_carousel_min_scale:I

.field public static overview_container_clear_all_height:I

.field public static overview_grid_row_spacing:I

.field public static overview_grid_side_margin:I

.field public static overview_max_scale:I

.field public static overview_minimum_next_prev_size:I

.field public static overview_modal_max_scale:I

.field public static overview_page_spacing:I

.field public static overview_proactive_row_bottom_margin:I

.field public static overview_proactive_row_height:I

.field public static overview_task_margin:I

.field public static overview_top_margin_grid_only:I

.field public static padded_rounded_button_height:I

.field public static padded_rounded_button_padding:I

.field public static page_indicator_dot_size:I

.field public static page_indicator_size:I

.field public static pending_widget_elevation:I

.field public static pending_widget_min_padding:I

.field public static persistent_taskbar_corner_radius:I

.field public static pin_widget_button_inset_horizontal:I

.field public static pin_widget_button_inset_vertical:I

.field public static pin_widget_button_padding_horizontal:I

.field public static pin_widget_button_padding_vertical:I

.field public static popup_arrow_corner_radius:I

.field public static popup_arrow_height:I

.field public static popup_arrow_horizontal_center_offset:I

.field public static popup_arrow_vertical_offset:I

.field public static popup_arrow_width:I

.field public static popup_margin:I

.field public static popup_padding_end:I

.field public static popup_padding_start:I

.field public static popup_single_item_radius:I

.field public static popup_smaller_radius:I

.field public static popup_vertical_padding:I

.field public static pre_drag_view_scale:I

.field public static preference_dropdown_padding_start:I

.field public static preference_icon_minWidth:I

.field public static preference_seekbar_padding_horizontal:I

.field public static preference_seekbar_padding_vertical:I

.field public static preference_seekbar_value_minWidth:I

.field public static preferences_detail_width:I

.field public static preferences_header_width:I

.field public static profile_badge_minimum_top:I

.field public static profile_badge_size:I

.field public static ps_app_divider_horizontal_padding:I

.field public static ps_app_divider_vertical_padding:I

.field public static ps_button_height:I

.field public static ps_button_width:I

.field public static ps_container_corner_radius:I

.field public static ps_extra_bottom_padding:I

.field public static ps_floating_mask_corner_radius:I

.field public static ps_floating_mask_end_padding:I

.field public static ps_header_height:I

.field public static ps_header_image_height:I

.field public static ps_header_layout_margin:I

.field public static ps_header_relative_layout_height:I

.field public static ps_header_text_height:I

.field public static ps_header_text_size:I

.field public static ps_lock_button_background_padding:I

.field public static ps_lock_button_margin_end:I

.field public static ps_lock_button_width:I

.field public static ps_lock_corner_radius:I

.field public static ps_lock_icon_margin_bottom:I

.field public static ps_lock_icon_margin_top:I

.field public static ps_lock_icon_size:I

.field public static ps_lock_icon_text_margin_end_expanded:I

.field public static ps_lock_icon_text_margin_start_expanded:I

.field public static qsb_height:I

.field public static qsb_shadow_height:I

.field public static qsb_widget_height:I

.field public static quick_switch_scaling_scroll_threshold:I

.field public static quickstep_fling_threshold_speed:I

.field public static ready_for_bg_height_size:I

.field public static ready_for_bg_radius:I

.field public static ready_for_bg_width_size:I

.field public static ready_for_container_height_size:I

.field public static ready_for_container_width_size:I

.field public static ready_for_icon_margin_bottom:I

.field public static ready_for_icon_margin_top:I

.field public static ready_for_icon_size:I

.field public static ready_for_tooltip_bottom_margin:I

.field public static ready_for_window_margin_right:I

.field public static ready_for_window_size:I

.field public static recents_clear_all_deadzone_vertical_margin:I

.field public static recents_clear_all_outline_padding:I

.field public static recents_clear_all_outline_radius:I

.field public static recents_empty_message_text_padding:I

.field public static recents_empty_message_text_size:I

.field public static recents_fast_fling_velocity:I

.field public static recents_filter_icon_size:I

.field public static resize_frame_background_padding:I

.field public static resize_frame_invalid_drag_across_two_panel_opacity_margin:I

.field public static resize_frame_margin:I

.field public static rounded_button_height:I

.field public static rounded_button_padding:I

.field public static rounded_button_radius:I

.field public static rounded_button_width:I

.field public static rounded_corner_content_padding:I

.field public static sdl_dynamic_grid_edge_margin:I

.field public static search_and_recommended_widgets_container_bottom_margin:I

.field public static search_and_recommended_widgets_container_small_bottom_margin:I

.field public static search_bar_container_margin_start:I

.field public static search_bar_padding:I

.field public static search_bar_padding_end:I

.field public static search_bar_padding_start:I

.field public static search_bar_text:I

.field public static search_row_icon_size:I

.field public static search_row_small_icon_size:I

.field public static searchwidget_searchbox_height_with_shadow:I

.field public static secondary_app_icon_size:I

.field public static sensi_switch_width:I

.field public static setting_option_gap:I

.field public static setting_option_preview_height:I

.field public static setting_option_preview_padding_top:I

.field public static settings_list_preference_corner:I

.field public static settingslib_background_accent_alpha:I

.field public static settingslib_dialogButtonCornerRadius:I

.field public static settingslib_dialogCornerRadius:I

.field public static settingslib_dialogTitleMarginBottom:I

.field public static settingslib_dialogTitleMarginTop:I

.field public static settingslib_expressive_radius_extralarge1:I

.field public static settingslib_expressive_radius_extralarge2:I

.field public static settingslib_expressive_radius_extralarge3:I

.field public static settingslib_expressive_radius_extrasmall1:I

.field public static settingslib_expressive_radius_extrasmall2:I

.field public static settingslib_expressive_radius_full:I

.field public static settingslib_expressive_radius_large1:I

.field public static settingslib_expressive_radius_large2:I

.field public static settingslib_expressive_radius_large3:I

.field public static settingslib_expressive_radius_medium:I

.field public static settingslib_expressive_radius_none:I

.field public static settingslib_expressive_radius_small:I

.field public static settingslib_expressive_space_extrasmall1:I

.field public static settingslib_expressive_space_extrasmall2:I

.field public static settingslib_expressive_space_extrasmall3:I

.field public static settingslib_expressive_space_extrasmall4:I

.field public static settingslib_expressive_space_extrasmall5:I

.field public static settingslib_expressive_space_extrasmall6:I

.field public static settingslib_expressive_space_extrasmall7:I

.field public static settingslib_expressive_space_large1:I

.field public static settingslib_expressive_space_large2:I

.field public static settingslib_expressive_space_large3:I

.field public static settingslib_expressive_space_large4:I

.field public static settingslib_expressive_space_large5:I

.field public static settingslib_expressive_space_medium1:I

.field public static settingslib_expressive_space_medium2:I

.field public static settingslib_expressive_space_medium3:I

.field public static settingslib_expressive_space_medium4:I

.field public static settingslib_expressive_space_medium5:I

.field public static settingslib_expressive_space_none:I

.field public static settingslib_expressive_space_small1:I

.field public static settingslib_expressive_space_small2:I

.field public static settingslib_expressive_space_small3:I

.field public static settingslib_expressive_space_small4:I

.field public static settingslib_listPreferredItemPaddingEnd:I

.field public static settingslib_listPreferredItemPaddingStart:I

.field public static settingslib_preferenceIconSize:I

.field public static settingslib_preference_corner_radius:I

.field public static settingslib_preference_title_size:I

.field public static settingslib_preferred_minimum_touch_target:I

.field public static settingslib_spinner_height:I

.field public static settingslib_text_accent_alpha:I

.field public static shape_bottom_button_height:I

.field public static shape_button_elevation:I

.field public static shape_button_margin_v:I

.field public static shape_button_min_width:I

.field public static shape_button_padding_h:I

.field public static shape_button_press_shadow_anim_size:I

.field public static shape_button_radius:I

.field public static shape_button_text_size:I

.field public static shortcut_preview_padding_left:I

.field public static shortcut_preview_padding_right:I

.field public static shortcut_preview_padding_top:I

.field public static smart_folder_bottom_extra:I

.field public static smart_folder_games_picks_icons_padding_top:I

.field public static smart_folder_title_margin_bottom:I

.field public static snackbar_content_height:I

.field public static snackbar_elevation:I

.field public static snackbar_height:I

.field public static snackbar_margin_bottom:I

.field public static snackbar_max_margin_left_right:I

.field public static snackbar_max_text_size:I

.field public static snackbar_max_width:I

.field public static snackbar_min_margin_left_right:I

.field public static snackbar_min_text_size:I

.field public static snackbar_padding:I

.field public static sp_app_recommendations_page_indicator_height:I

.field public static sp_app_recommendations_page_indicator_padding:I

.field public static sp_extra_action_height:I

.field public static sp_extra_action_icon_gap:I

.field public static sp_extra_action_icon_padding_top:I

.field public static sp_extra_action_icon_size:I

.field public static sp_extra_action_text_size:I

.field public static sp_smart_card_opaque_display_icon_gap:I

.field public static sp_smart_card_opaque_display_icon_padding_top:I

.field public static sp_smart_card_opaque_display_icon_size:I

.field public static sp_smart_card_opaque_display_title_size:I

.field public static sp_smart_card_opaque_padding_h:I

.field public static sp_smart_card_opaque_title_row_height:I

.field public static sp_smart_card_opaque_title_row_margin_top:I

.field public static sp_smart_card_title_icon_gap:I

.field public static sp_smart_card_title_icon_size:I

.field public static sp_smart_card_title_text_size:I

.field public static sp_smart_card_transparent_display_title_font_size:I

.field public static sp_smart_card_transparent_display_title_height:I

.field public static sp_smart_card_transparent_display_title_padding_h:I

.field public static sp_smart_folder_section_margin:I

.field public static split_divider_handle_region_height:I

.field public static split_divider_handle_region_width:I

.field public static split_instructions_bottom_margin_phone_landscape:I

.field public static split_instructions_bottom_margin_phone_portrait:I

.field public static split_instructions_drawable_padding:I

.field public static split_instructions_elevation:I

.field public static split_instructions_horizontal_padding:I

.field public static split_instructions_radius:I

.field public static split_instructions_start_margin_cancel:I

.field public static split_instructions_vertical_padding:I

.field public static split_instructions_view_max_width:I

.field public static split_placeholder_icon_size:I

.field public static split_placeholder_inset:I

.field public static split_placeholder_size:I

.field public static spring_loaded_hotseat_top_margin:I

.field public static spring_loaded_hotseat_top_margin_wide_portrait:I

.field public static spring_loaded_panel_border:I

.field public static staggered_damping_ratio:I

.field public static staggered_stiffness:I

.field public static starting_surface_exit_animation_window_shift_length:I

.field public static swipe_back_window_corner_radius:I

.field public static swipe_back_window_scale_x_margin:I

.field public static swipe_edu_circle_size:I

.field public static swipe_edu_max_height:I

.field public static swipe_edu_padding:I

.field public static swipe_edu_width:I

.field public static swipe_up_fling_min_visible_change:I

.field public static swipe_up_max_velocity:I

.field public static swipe_up_max_velocity_fall_off_factor:I

.field public static swipe_up_max_velocity_x_px_per_s:I

.field public static swipe_up_max_velocity_y_px_per_s:I

.field public static swipe_up_max_workspace_trans_y:I

.field public static swipe_up_min_velocity_x_px_per_s:I

.field public static swipe_up_min_velocity_y_px_per_s:I

.field public static swipe_up_rect_scale_damping_ratio:I

.field public static swipe_up_rect_scale_damping_ratio_v2:I

.field public static swipe_up_rect_scale_higher_stiffness:I

.field public static swipe_up_rect_scale_stiffness:I

.field public static swipe_up_rect_scale_stiffness_v2:I

.field public static swipe_up_rect_x_damping_ratio:I

.field public static swipe_up_rect_x_stiffness:I

.field public static swipe_up_rect_xy_damping_ratio:I

.field public static swipe_up_rect_xy_fling_friction:I

.field public static swipe_up_rect_xy_stiffness:I

.field public static swipe_up_rect_y_damping_ratio:I

.field public static swipe_up_rect_y_stiffness:I

.field public static swipe_up_scale_start:I

.field public static switch_reference_height:I

.field public static switch_reference_radius:I

.field public static switch_reference_width:I

.field public static system_shortcut_header_height:I

.field public static system_shortcut_header_icon_padding:I

.field public static system_shortcut_header_icon_padding_inner:I

.field public static system_shortcut_header_icon_padding_outer:I

.field public static system_shortcut_header_icon_touch_size:I

.field public static system_shortcut_icon_size:I

.field public static system_shortcut_margin_start:I

.field public static task_arrow_size:I

.field public static task_card_margin:I

.field public static task_card_menu_option_vertical_padding:I

.field public static task_card_menu_shadow_height:I

.field public static task_corner_radius_override:I

.field public static task_corner_radius_small:I

.field public static task_hover_border_width:I

.field public static task_icon_cache_default_icon_size:I

.field public static task_lock_hint_height:I

.field public static task_lock_hint_padding_top:I

.field public static task_lock_offset:I

.field public static task_lock_size:I

.field public static task_margin_top:I

.field public static task_menu_corner_radius:I

.field public static task_menu_edge_padding:I

.field public static task_menu_horizontal_padding:I

.field public static task_menu_item_corner_radius:I

.field public static task_menu_option_height:I

.field public static task_menu_option_start_margin:I

.field public static task_menu_option_text_start_margin:I

.field public static task_menu_primary_corner_radius:I

.field public static task_menu_spacing:I

.field public static task_menu_width_grid:I

.field public static task_thumbnail_icon_drawable_height_size:I

.field public static task_thumbnail_icon_drawable_size:I

.field public static task_thumbnail_icon_drawable_size_grid:I

.field public static task_thumbnail_icon_drawable_width_size:I

.field public static task_thumbnail_icon_height:I

.field public static task_thumbnail_icon_menu_app_icon_collapsed_size:I

.field public static task_thumbnail_icon_menu_app_icon_expanded_size:I

.field public static task_thumbnail_icon_menu_app_name_margin_horizontal_collapsed:I

.field public static task_thumbnail_icon_menu_arrow_margin:I

.field public static task_thumbnail_icon_menu_arrow_size:I

.field public static task_thumbnail_icon_menu_background_margin_top_start:I

.field public static task_thumbnail_icon_menu_collapsed_height:I

.field public static task_thumbnail_icon_menu_collapsed_width:I

.field public static task_thumbnail_icon_menu_drawable_touch_size:I

.field public static task_thumbnail_icon_menu_elevation:I

.field public static task_thumbnail_icon_menu_expanded_gap:I

.field public static task_thumbnail_icon_menu_expanded_height:I

.field public static task_thumbnail_icon_menu_expanded_top_start_margin:I

.field public static task_thumbnail_icon_menu_expanded_width:I

.field public static task_thumbnail_icon_menu_text_collapsed_max_width:I

.field public static task_thumbnail_icon_menu_text_expanded_max_width:I

.field public static task_thumbnail_icon_menu_text_size:I

.field public static task_thumbnail_icon_size:I

.field public static task_thumbnail_icon_view_start_margin:I

.field public static task_thumbnail_icon_width:I

.field public static taskbar_all_apps_button_translation_x_offset:I

.field public static taskbar_all_apps_search_button_translation_x_offset:I

.field public static taskbar_app_window_threshold:I

.field public static taskbar_app_window_threshold_mult:I

.field public static taskbar_back_button_left_margin_kids:I

.field public static taskbar_back_button_suw_bottom_margin:I

.field public static taskbar_back_button_suw_height:I

.field public static taskbar_back_button_suw_start_margin:I

.field public static taskbar_button_margin_6_5:I

.field public static taskbar_button_margin_default:I

.field public static taskbar_button_margin_split:I

.field public static taskbar_button_space_inbetween:I

.field public static taskbar_button_space_inbetween_phone:I

.field public static taskbar_catch_up_threshold:I

.field public static taskbar_catch_up_threshold_mult:I

.field public static taskbar_contextual_button_padding:I

.field public static taskbar_contextual_button_suw_height:I

.field public static taskbar_contextual_button_suw_margin:I

.field public static taskbar_contextual_buttons_size:I

.field public static taskbar_contextual_padding_top:I

.field public static taskbar_edu_features_horizontal_spacing:I

.field public static taskbar_edu_features_lottie_height:I

.field public static taskbar_edu_features_lottie_width:I

.field public static taskbar_edu_features_tooltip_width_with_one_feature:I

.field public static taskbar_edu_features_tooltip_width_with_three_features:I

.field public static taskbar_edu_features_tooltip_width_with_two_features:I

.field public static taskbar_edu_horizontal_margin:I

.field public static taskbar_edu_search_subtitle_text_size:I

.field public static taskbar_edu_swipe_lottie_height:I

.field public static taskbar_edu_swipe_lottie_width:I

.field public static taskbar_edu_tooltip_elevation:I

.field public static taskbar_edu_tooltip_enter_y_delta:I

.field public static taskbar_edu_tooltip_exit_y_delta:I

.field public static taskbar_edu_tooltip_horizontal_margin:I

.field public static taskbar_edu_tooltip_vertical_margin:I

.field public static taskbar_folder_margin:I

.field public static taskbar_from_nav_threshold:I

.field public static taskbar_home_button_left_margin_kids:I

.field public static taskbar_home_overview_threshold:I

.field public static taskbar_home_overview_threshold_mult:I

.field public static taskbar_hotseat_nav_spacing:I

.field public static taskbar_icon_drag_icon_size:I

.field public static taskbar_icon_min_touch_size:I

.field public static taskbar_icon_size:I

.field public static taskbar_icon_size_kids:I

.field public static taskbar_icon_spacing:I

.field public static taskbar_ime_size:I

.field public static taskbar_ime_switcher_button_margin_start:I

.field public static taskbar_minimized_app_indicator_height:I

.field public static taskbar_minimized_app_indicator_top_margin:I

.field public static taskbar_minimized_app_indicator_width:I

.field public static taskbar_nav_buttons_corner_radius_kids:I

.field public static taskbar_nav_buttons_height_kids:I

.field public static taskbar_nav_buttons_size:I

.field public static taskbar_nav_buttons_width_kids:I

.field public static taskbar_nav_threshold_mult:I

.field public static taskbar_phone_content_padding:I

.field public static taskbar_phone_home_button_size:I

.field public static taskbar_phone_rounded_corner_content_margin:I

.field public static taskbar_phone_size:I

.field public static taskbar_pinning_popup_menu_vertical_margin:I

.field public static taskbar_pinning_popup_menu_width:I

.field public static taskbar_running_app_indicator_height:I

.field public static taskbar_running_app_indicator_top_margin:I

.field public static taskbar_running_app_indicator_width:I

.field public static taskbar_size:I

.field public static taskbar_slow_velocity_y_threshold:I

.field public static taskbar_split_instructions_margin:I

.field public static taskbar_stashed_below_hover_deadzone_height:I

.field public static taskbar_stashed_handle_height:I

.field public static taskbar_stashed_handle_width:I

.field public static taskbar_stashed_screen_edge_hover_deadzone_height:I

.field public static taskbar_stashed_size:I

.field public static taskbar_stashed_small_screen:I

.field public static taskbar_suw_frame:I

.field public static taskbar_suw_insets:I

.field public static taskbar_swipe_up_rect_scale_stiffness:I

.field public static taskbar_swipe_up_rect_x_damping:I

.field public static taskbar_swipe_up_rect_x_stiffness:I

.field public static taskbar_swipe_up_rect_y_damping:I

.field public static taskbar_swipe_up_rect_y_stiffness:I

.field public static taskbar_to_nav_threshold:I

.field public static taskbar_tooltip_horizontal_padding:I

.field public static taskbar_tooltip_vertical_padding:I

.field public static taskbar_unstash_input_area:I

.field public static tooltip_corner_radius:I

.field public static tooltip_horizontal_padding:I

.field public static tooltip_margin:I

.field public static tooltip_precise_anchor_extra_offset:I

.field public static tooltip_precise_anchor_threshold:I

.field public static tooltip_vertical_padding:I

.field public static tooltip_y_offset_non_touch:I

.field public static tooltip_y_offset_touch:I

.field public static transient_taskbar_all_apps_button_translation_x_offset:I

.field public static transient_taskbar_bottom_margin:I

.field public static transient_taskbar_clamped_offset_bound:I

.field public static transient_taskbar_key_shadow_distance:I

.field public static transient_taskbar_min_width:I

.field public static transient_taskbar_padding:I

.field public static transient_taskbar_shadow_blur:I

.field public static transient_taskbar_stash_spring_velocity_dp_per_s:I

.field public static transient_taskbar_stashed_height:I

.field public static transient_taskbar_stroke_width:I

.field public static transient_taskbar_two_panels_size:I

.field public static two_target_min_width:I

.field public static unlock_staggered_velocity_dp_per_s:I

.field public static widget_apps_tabs_vertical_padding:I

.field public static widget_bottom_sheet_horizontal_margin:I

.field public static widget_cell_add_button_drawable_padding:I

.field public static widget_cell_add_button_drawable_width:I

.field public static widget_cell_add_button_end_padding:I

.field public static widget_cell_add_button_font_size:I

.field public static widget_cell_add_button_height:I

.field public static widget_cell_add_button_line_height:I

.field public static widget_cell_add_button_scroll_padding:I

.field public static widget_cell_add_button_start_padding:I

.field public static widget_cell_add_icon_button_start_padding:I

.field public static widget_cell_app_icon_padding:I

.field public static widget_cell_app_icon_size:I

.field public static widget_cell_description_font_size:I

.field public static widget_cell_description_line_height:I

.field public static widget_cell_dims_font_size:I

.field public static widget_cell_dims_line_height:I

.field public static widget_cell_horizontal_padding:I

.field public static widget_cell_title_font_size:I

.field public static widget_cell_title_line_height:I

.field public static widget_cell_vertical_padding:I

.field public static widget_drag_view_min_scale_down_size:I

.field public static widget_handle_margin:I

.field public static widget_list_content_corner_radius:I

.field public static widget_list_entry_spacing:I

.field public static widget_list_header_view_vertical_padding:I

.field public static widget_list_horizontal_margin:I

.field public static widget_list_horizontal_margin_two_pane:I

.field public static widget_list_left_pane_horizontal_margin:I

.field public static widget_list_top_bottom_corner_radius:I

.field public static widget_picker_education_tip_max_width:I

.field public static widget_picker_education_tip_min_margin:I

.field public static widget_picker_header_app_subtitle_font_size:I

.field public static widget_picker_header_app_subtitle_line_height:I

.field public static widget_picker_header_app_title_font_size:I

.field public static widget_picker_header_app_title_line_height:I

.field public static widget_picker_landscape_tablet_left_right_margin:I

.field public static widget_picker_two_panels_left_right_margin:I

.field public static widget_picker_vertical_margin_right_pane:I

.field public static widget_preview_cell_divider_width:I

.field public static widget_preview_corner_radius:I

.field public static widget_preview_key_shadow_distance:I

.field public static widget_preview_shadow_blur:I

.field public static widget_preview_shortcut_padding:I

.field public static widget_recommendations_table_vertical_padding:I

.field public static widget_reconfigure_button_corner_radius:I

.field public static widget_reconfigure_button_margin:I

.field public static widget_reconfigure_button_padding:I

.field public static widget_reconfigure_button_size:I

.field public static widget_reconfigure_tip_top_margin:I

.field public static widget_row_divider:I

.field public static widget_row_padding:I

.field public static widget_section_height:I

.field public static widget_section_horizontal_padding:I

.field public static widget_section_icon_size:I

.field public static widget_section_vertical_padding:I

.field public static widget_stack_dot_padding:I

.field public static widget_stack_dot_radius:I

.field public static widget_stack_dot_spacing:I

.field public static widget_stack_edit_button_height:I

.field public static widget_stack_edit_button_margin_bottom:I

.field public static widget_stack_edit_button_margin_top:I

.field public static widget_stack_edit_button_radius:I

.field public static widget_stack_edit_button_width:I

.field public static widget_stack_edit_margin_top:I

.field public static widget_stack_edit_title_margin:I

.field public static widget_tabs_button_horizontal_padding:I

.field public static widget_tabs_horizontal_padding:I

.field public static widgets_bottom_sheet_handle_margin:I

.field public static work_apps_paused_button_stroke:I

.field public static work_card_button_height:I

.field public static work_card_margin:I

.field public static work_card_padding_horizontal:I

.field public static work_edu_card_bottom_margin:I

.field public static work_edu_card_margin:I

.field public static work_edu_card_radius:I

.field public static work_edu_card_text_end_margin:I

.field public static work_fab_height:I

.field public static work_fab_icon_end_margin:I

.field public static work_fab_margin:I

.field public static work_fab_margin_bottom:I

.field public static work_fab_radius:I

.field public static work_fab_text_end_margin:I

.field public static work_fab_width:I

.field public static work_mode_fab_background_end_padding:I

.field public static work_mode_fab_background_start_padding:I

.field public static work_paused_content_margin_bottom:I

.field public static work_paused_content_margin_top:I

.field public static work_profile_footer_padding:I

.field public static work_profile_footer_text_size:I

.field public static work_unpause_button_margin_bottom:I

.field public static workspace_content_scale:I

.field public static workspace_global_search_end_padding:I

.field public static workspace_global_search_gap:I

.field public static workspace_global_search_height:I

.field public static workspace_global_search_icon_size:I

.field public static workspace_global_search_margin_vertical:I

.field public static workspace_global_search_start_padding:I

.field public static workspace_global_search_text_size:I

.field public static workspace_global_search_vertical_padding:I

.field public static workspace_global_search_width:I

.field public static workspace_padding_bottom_extra:I

.field public static workspace_page_indicator_height:I

.field public static workspace_page_indicator_line_height:I

.field public static workspace_page_indicator_overlap_workspace:I

.field public static x_icon_size:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 15558
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
