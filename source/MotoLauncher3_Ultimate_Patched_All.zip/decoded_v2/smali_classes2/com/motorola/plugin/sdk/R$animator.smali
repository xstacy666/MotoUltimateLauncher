.class public final Lcom/motorola/plugin/sdk/R$animator;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static all_apps_fastscroll_icon_anim:I

.field public static chevron_checked_unchecked:I

.field public static chevron_unchecked_checked:I

.field public static design_appbar_state_list_animator:I

.field public static design_fab_hide_motion_spec:I

.field public static design_fab_show_motion_spec:I

.field public static discovery_bounce:I

.field public static fragment_close_enter:I

.field public static fragment_close_exit:I

.field public static fragment_fade_enter:I

.field public static fragment_fade_exit:I

.field public static fragment_open_enter:I

.field public static fragment_open_exit:I

.field public static m3_appbar_state_list_animator:I

.field public static m3_btn_elevated_btn_state_list_anim:I

.field public static m3_btn_state_list_anim:I

.field public static m3_card_elevated_state_list_anim:I

.field public static m3_card_state_list_anim:I

.field public static m3_chip_state_list_anim:I

.field public static m3_elevated_chip_state_list_anim:I

.field public static m3_extended_fab_change_size_collapse_motion_spec:I

.field public static m3_extended_fab_change_size_expand_motion_spec:I

.field public static m3_extended_fab_hide_motion_spec:I

.field public static m3_extended_fab_show_motion_spec:I

.field public static m3_extended_fab_state_list_animator:I

.field public static m3_split_button_chevron_overshoot_interpolator:I

.field public static m3_split_button_chevron_reverse_rotation:I

.field public static m3_split_button_chevron_rotation:I

.field public static mtrl_btn_state_list_anim:I

.field public static mtrl_btn_unelevated_state_list_anim:I

.field public static mtrl_card_state_list_anim:I

.field public static mtrl_chip_state_list_anim:I

.field public static mtrl_extended_fab_change_size_collapse_motion_spec:I

.field public static mtrl_extended_fab_change_size_expand_motion_spec:I

.field public static mtrl_extended_fab_hide_motion_spec:I

.field public static mtrl_extended_fab_show_motion_spec:I

.field public static mtrl_extended_fab_state_list_animator:I

.field public static mtrl_fab_hide_motion_spec:I

.field public static mtrl_fab_show_motion_spec:I

.field public static mtrl_fab_transformation_sheet_collapse_spec:I

.field public static mtrl_fab_transformation_sheet_expand_spec:I

.field public static overview_button_anim:I

.field public static shape_button_press_shadow:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
