.class public final Lcom/motorola/plugin/sdk/R$mipmap;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static ic_launcher_home:I

.field public static ic_launcher_home_background:I

.field public static ic_launcher_home_foreground:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20777
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
