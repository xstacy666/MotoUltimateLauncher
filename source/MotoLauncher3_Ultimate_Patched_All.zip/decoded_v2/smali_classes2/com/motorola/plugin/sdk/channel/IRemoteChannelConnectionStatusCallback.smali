.class public interface abstract Lcom/motorola/plugin/sdk/channel/IRemoteChannelConnectionStatusCallback;
.super Ljava/lang/Object;
.source "IRemoteChannelConnectionStatusCallback.java"


# virtual methods
.method public onRemoteChannelDisconnected()V
    .locals 0

    .line 0
    return-void
.end method

.method public abstract onRemoteChannelReconnected()V
.end method
