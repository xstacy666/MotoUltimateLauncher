.class public interface abstract Lcom/motorola/plugin/sdk/Plugin;
.super Ljava/lang/Object;
.source "Plugin.java"


# virtual methods
.method public onCreate(Landroid/content/Context;Landroid/content/Context;Lcom/motorola/plugin/sdk/channel/IRemoteChannel;)V
    .locals 0

    .line 0
    return-void
.end method

.method public onDestroy()V
    .locals 0

    .line 0
    return-void
.end method
