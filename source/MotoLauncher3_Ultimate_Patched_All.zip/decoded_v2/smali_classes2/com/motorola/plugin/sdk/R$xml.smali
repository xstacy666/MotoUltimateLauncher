.class public final Lcom/motorola/plugin/sdk/R$xml;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static app_drawer_settings_preferences:I

.field public static backupscheme:I

.field public static default_test2_workspace:I

.field public static default_test_workspace:I

.field public static default_workspace_3x3:I

.field public static default_workspace_3x4:I

.field public static default_workspace_4x4:I

.field public static default_workspace_4x5:I

.field public static default_workspace_4x6:I

.field public static default_workspace_5x5:I

.field public static default_workspace_5x6:I

.field public static default_workspace_6x5:I

.field public static device_profiles:I

.field public static discovery_keyboard_preference:I

.field public static discovery_preference:I

.field public static dynamic_resources:I

.field public static folder_shapes:I

.field public static grayscale_icon_map:I

.field public static indexable_launcher_prefs:I

.field public static launcher_preferences:I

.field public static m3_button_group_child_size_change:I

.field public static overview_file_provider_paths:I

.field public static paddings_6x5:I

.field public static paddings_handhelds:I

.field public static settingslib_button_shape_state_list:I

.field public static settingslib_inner_corner_size_state_list:I

.field public static split_configuration:I

.field public static widget_sections:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 64991
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
