.class public Lcom/motorola/plugin/sdk/channel/ClientId;
.super Ljava/lang/Object;
.source "ClientId.java"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;


# instance fields
.field public final packageName:Ljava/lang/String;

.field public final uniqueId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 16
    new-instance v0, Lcom/motorola/plugin/sdk/channel/ClientId$1;

    invoke-direct {v0}, Lcom/motorola/plugin/sdk/channel/ClientId$1;-><init>()V

    sput-object v0, Lcom/motorola/plugin/sdk/channel/ClientId;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 37
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->packageName:Ljava/lang/String;

    .line 38
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->packageName:Ljava/lang/String;

    .line 33
    iput-object p2, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public copy()Lcom/motorola/plugin/sdk/channel/ClientId;
    .locals 2

    .line 42
    new-instance v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    iget-object v1, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->packageName:Ljava/lang/String;

    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-direct {v0, v1, p0}, Lcom/motorola/plugin/sdk/channel/ClientId;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public describeContents()I
    .locals 0

    .line 0
    const/4 p0, 0x0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 59
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Identity:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "|"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->packageName:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 0

    .line 52
    iget-object p2, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->packageName:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 53
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/ClientId;->uniqueId:Ljava/lang/String;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return-void
.end method
