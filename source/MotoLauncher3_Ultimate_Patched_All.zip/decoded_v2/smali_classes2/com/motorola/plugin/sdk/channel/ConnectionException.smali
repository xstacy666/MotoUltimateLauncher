.class public Lcom/motorola/plugin/sdk/channel/ConnectionException;
.super Landroid/os/RemoteException;
.source "ConnectionException.java"


# static fields
.field public static final FAILURE_BIG_DATA:I = 0x3

.field public static final FAILURE_BIND:I = 0x1

.field public static final FAILURE_CALL:I = 0x2


# instance fields
.field public final failure:I


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 0

    .line 22
    invoke-direct {p0, p2}, Landroid/os/RemoteException;-><init>(Ljava/lang/String;)V

    .line 23
    iput p1, p0, Lcom/motorola/plugin/sdk/channel/ConnectionException;->failure:I

    return-void
.end method
