.class Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;
.super Landroid/os/Handler;
.source "RemoteService.java"


# static fields
.field public static final MSG_NOTIFY_DATASET_CHANGE:I = 0x3

.field public static final MSG_REMOTE_CALL:I = 0x1

.field public static final MSG_REMOTE_CONNECT:I = 0x0

.field public static final MSG_REMOTE_DISCONNECT:I = 0x2

.field public static final MSG_REQUEST_SEND_EXTRA_DATA:I = 0x4


# instance fields
.field private final service:Lcom/motorola/plugin/sdk/channel/RemoteService;


# direct methods
.method private constructor <init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V
    .locals 1

    .line 454
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 455
    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    return-void
.end method

.method synthetic constructor <init>(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/RemoteService$1;)V
    .locals 0

    .line 443
    invoke-direct {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;-><init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 6

    .line 460
    iget v0, p1, Landroid/os/Message;->what:I

    const-string v1, "["

    const/4 v2, 0x3

    const-string v3, "RemoteService"

    if-eqz v0, :cond_9

    const/4 v4, 0x1

    if-eq v0, v4, :cond_7

    const/4 v4, 0x2

    if-eq v0, v4, :cond_5

    if-eq v0, v2, :cond_3

    const/4 v1, 0x4

    if-eq v0, v1, :cond_0

    return-void

    .line 510
    :cond_0
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 511
    iget-object v0, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 512
    iget-object v1, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v1, Landroid/os/Bundle;

    .line 513
    invoke-virtual {p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->recycle()V

    .line 515
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 516
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "request send extra data to "

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v0, :cond_1

    move-object v2, v0

    goto :goto_0

    :cond_1
    const-string v2, "all clients"

    :goto_0
    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 518
    :cond_2
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-static {p0, v0, v1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$600(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V

    return-void

    .line 498
    :cond_3
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 499
    iget-object v0, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v0, [Landroid/net/Uri;

    .line 500
    iget-object v1, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v1, Landroid/os/Bundle;

    .line 501
    invoke-virtual {p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->recycle()V

    .line 503
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_4

    .line 504
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "request notify dataset change for "

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 506
    :cond_4
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-static {p0, v0, v1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$500(Lcom/motorola/plugin/sdk/channel/RemoteService;[Landroid/net/Uri;Landroid/os/Bundle;)V

    return-void

    .line 486
    :cond_5
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 487
    iget-object v0, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 488
    iget-object v4, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    .line 489
    invoke-virtual {p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->recycle()V

    if-nez v4, :cond_6

    .line 491
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_6

    .line 492
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "] remote client disconnected"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 494
    :cond_6
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-static {p0, v0, v4}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$400(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Z)V

    return-void

    .line 473
    :cond_7
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 474
    iget-object v0, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;

    .line 475
    iget-object v4, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v4, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    .line 476
    iget v5, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->argI1:I

    .line 477
    invoke-virtual {p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->recycle()V

    .line 478
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_8

    .line 479
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "]["

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "] transfer request"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 481
    :cond_8
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    new-instance p1, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;

    invoke-direct {p1, v5, v4}, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;-><init>(ILcom/motorola/plugin/sdk/channel/IRemoteCallback;)V

    invoke-static {p0, v0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$300(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;)V

    return-void

    .line 462
    :cond_9
    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;

    .line 463
    iget-object v0, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg1:Ljava/lang/Object;

    check-cast v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 464
    iget-object v4, p1, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->arg2:Ljava/lang/Object;

    check-cast v4, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    .line 465
    invoke-virtual {p1}, Lcom/motorola/plugin/sdk/channel/RemoteService$SomeArgs;->recycle()V

    .line 466
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_a

    .line 467
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "] remote client connected"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 469
    :cond_a
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$ServiceHandler;->service:Lcom/motorola/plugin/sdk/channel/RemoteService;

    invoke-static {p0, v0, v4}, Lcom/motorola/plugin/sdk/channel/RemoteService;->access$200(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V

    return-void
.end method
