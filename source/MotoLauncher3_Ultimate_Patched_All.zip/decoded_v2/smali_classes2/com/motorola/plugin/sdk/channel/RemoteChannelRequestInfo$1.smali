.class Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;
.super Ljava/lang/Object;
.source "RemoteChannelRequestInfo.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;
    .locals 1

    .line 21
    new-instance p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;-><init>(Landroid/os/Parcel;Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 18
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;->createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;

    move-result-object p0

    return-object p0
.end method

.method public newArray(I)[Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;
    .locals 0

    .line 26
    new-array p0, p1, [Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    .line 18
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;->newArray(I)[Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;

    move-result-object p0

    return-object p0
.end method
