.class public final Lcom/motorola/plugin/sdk/R$string;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abandoned_clean_this:I

.field public static abandoned_promise_explanation:I

.field public static abandoned_promises_title:I

.field public static abandoned_search:I

.field public static abc_action_bar_home_description:I

.field public static abc_action_bar_up_description:I

.field public static abc_action_menu_overflow_description:I

.field public static abc_action_mode_done:I

.field public static abc_activity_chooser_view_see_all:I

.field public static abc_activitychooserview_choose_application:I

.field public static abc_capital_off:I

.field public static abc_capital_on:I

.field public static abc_menu_alt_shortcut_label:I

.field public static abc_menu_ctrl_shortcut_label:I

.field public static abc_menu_delete_shortcut_label:I

.field public static abc_menu_enter_shortcut_label:I

.field public static abc_menu_function_shortcut_label:I

.field public static abc_menu_meta_shortcut_label:I

.field public static abc_menu_shift_shortcut_label:I

.field public static abc_menu_space_shortcut_label:I

.field public static abc_menu_sym_shortcut_label:I

.field public static abc_prepend_shortcut_label:I

.field public static abc_search_hint:I

.field public static abc_searchview_description_clear:I

.field public static abc_searchview_description_query:I

.field public static abc_searchview_description_search:I

.field public static abc_searchview_description_submit:I

.field public static abc_searchview_description_voice:I

.field public static abc_shareactionprovider_share_with:I

.field public static abc_shareactionprovider_share_with_application:I

.field public static abc_slice_error:I

.field public static abc_slice_more:I

.field public static abc_slice_more_content:I

.field public static abc_slice_permission_allow:I

.field public static abc_slice_permission_deny:I

.field public static abc_slice_permission_text_1:I

.field public static abc_slice_permission_text_2:I

.field public static abc_slice_permission_title:I

.field public static abc_slice_show_more:I

.field public static abc_slice_updated:I

.field public static abc_slices_permission_request:I

.field public static abc_toolbar_collapse_description:I

.field public static accessibility_app_usage_settings:I

.field public static accessibility_close:I

.field public static accessibility_freeform:I

.field public static accessibility_lock_task:I

.field public static accessibility_readyFor:I

.field public static accessibility_recent_apps:I

.field public static accessibility_rotate_button:I

.field public static accessibility_screenshot:I

.field public static action_add_to_workspace:I

.field public static action_decrease_height:I

.field public static action_decrease_width:I

.field public static action_deep_shortcut:I

.field public static action_delete_shortcut:I

.field public static action_dismiss_notification:I

.field public static action_increase_height:I

.field public static action_increase_width:I

.field public static action_move:I

.field public static action_move_here:I

.field public static action_move_to_workspace:I

.field public static action_pin_to_taskbar:I

.field public static action_resize:I

.field public static action_save_app_pair:I

.field public static action_screenshot:I

.field public static action_share:I

.field public static action_split:I

.field public static action_switch:I

.field public static action_unpin_from_taskbar:I

.field public static activity_not_available:I

.field public static activity_not_found:I

.field public static add:I

.field public static add_item_request_drag_hint:I

.field public static add_to_folder:I

.field public static add_to_folder_label:I

.field public static add_to_folder_with_app:I

.field public static add_to_home_screen:I

.field public static added_to_folder:I

.field public static added_to_home_screen_accessibility_text:I

.field public static adding_app_to_folder_error_toast:I

.field public static all_apps_button_label:I

.field public static all_apps_button_personal_label:I

.field public static all_apps_button_work_label:I

.field public static all_apps_folder_editor_name_hint:I

.field public static all_apps_folder_unnamed:I

.field public static all_apps_folders_title:I

.field public static all_apps_label:I

.field public static all_apps_loading_message:I

.field public static all_apps_no_search_results:I

.field public static all_apps_overlay_key:I

.field public static all_apps_overlay_package:I

.field public static all_apps_overlay_service:I

.field public static all_apps_overlay_settings_service:I

.field public static all_apps_overlay_title:I

.field public static all_apps_personal_tab:I

.field public static all_apps_prediction_tip:I

.field public static all_apps_search_bar_hint:I

.field public static all_apps_search_market_message:I

.field public static all_apps_search_results:I

.field public static all_apps_suggestions_title:I

.field public static all_apps_tab:I

.field public static all_apps_work_tab:I

.field public static allow_rotation_desc:I

.field public static allow_rotation_title:I

.field public static allow_use_minus_one_panel_left_desc:I

.field public static allow_use_minus_one_panel_right_desc:I

.field public static allset_button_hint:I

.field public static allset_description_generic:I

.field public static allset_hint:I

.field public static allset_navigation_settings:I

.field public static allset_title:I

.field public static always_show_taskbar:I

.field public static androidx_startup:I

.field public static api_wrapper_class:I

.field public static app_archived_title:I

.field public static app_downloading_title:I

.field public static app_filter_class:I

.field public static app_info_drop_target_label:I

.field public static app_installing_title:I

.field public static app_label_title:I

.field public static app_launch_tracker_class:I

.field public static app_name:I

.field public static app_name_moto:I

.field public static app_not_support_sharing:I

.field public static app_pair_default_title:I

.field public static app_pair_name_format:I

.field public static app_pair_needs_unfold:I

.field public static app_pair_not_available:I

.field public static app_pair_unlaunchable_at_screen_size:I

.field public static app_waiting_download_title:I

.field public static appbar_scrolling_view_behavior:I

.field public static applock_msg:I

.field public static applock_msg_row:I

.field public static applying:I

.field public static arrow_toast_desktop_tip:I

.field public static assist_state_manager_class:I

.field public static assist_utils_class:I

.field public static assistant_gesture_feedback_swipe_not_diagonal:I

.field public static assistant_gesture_feedback_swipe_not_long_enough:I

.field public static assistant_gesture_feedback_swipe_too_far_from_corner:I

.field public static assistant_gesture_tutorial_playground_subtitle:I

.field public static assistant_gesture_tutorial_playground_title:I

.field public static auto_add_shortcuts_description:I

.field public static auto_add_shortcuts_label:I

.field public static back_gesture_feedback_cancelled:I

.field public static back_gesture_feedback_complete_with_follow_up:I

.field public static back_gesture_feedback_complete_with_overview_follow_up:I

.field public static back_gesture_feedback_complete_without_follow_up:I

.field public static back_gesture_feedback_swipe_in_nav_bar:I

.field public static back_gesture_feedback_swipe_too_far_from_edge:I

.field public static back_gesture_intro_subtitle:I

.field public static back_gesture_intro_title:I

.field public static back_gesture_spoken_intro_subtitle:I

.field public static back_gesture_tutorial_confirm_subtitle:I

.field public static back_gesture_tutorial_subtitle:I

.field public static back_gesture_tutorial_title:I

.field public static beta_label:I

.field public static blocked_by_policy:I

.field public static bottom_sheet_behavior:I

.field public static bottomsheet_action_collapse:I

.field public static bottomsheet_action_expand:I

.field public static bottomsheet_action_expand_halfway:I

.field public static bottomsheet_drag_handle_clicked:I

.field public static bottomsheet_drag_handle_content_description:I

.field public static bubble_bar_bubble_description:I

.field public static bubble_bar_bubble_fallback_description:I

.field public static bubble_bar_description_multiple_bubbles:I

.field public static bubble_bar_overflow_description:I

.field public static cache_db_name:I

.field public static calendar_component_name:I

.field public static call_notification_answer_action:I

.field public static call_notification_answer_video_action:I

.field public static call_notification_decline_action:I

.field public static call_notification_hang_up_action:I

.field public static call_notification_incoming_text:I

.field public static call_notification_ongoing_text:I

.field public static call_notification_screening_text:I

.field public static change_navigation_mode:I

.field public static change_to_app_tray_style_prompt:I

.field public static change_to_app_tray_style_title:I

.field public static change_to_single_layer_style_prompt:I

.field public static change_to_single_layer_style_title:I

.field public static character_counter_content_description:I

.field public static character_counter_overflowed_content_description:I

.field public static character_counter_pattern:I

.field public static choose_folder_move:I

.field public static clear_all_input:I

.field public static clear_text_end_icon_content_description:I

.field public static clock_component_name:I

.field public static config_bodyFontFamilyMedium:I

.field public static config_default_minus_one_panel:I

.field public static copilot_minus_one_service:I

.field public static copilot_package:I

.field public static copy:I

.field public static create_folder_label:I

.field public static create_folder_promt:I

.field public static create_folder_with:I

.field public static create_new_folder:I

.field public static creating_folder_error_toast:I

.field public static curated_content_desc:I

.field public static curated_content_title:I

.field public static custom_activity_picker:I

.field public static custom_list_preference_cancel:I

.field public static default_device_name:I

.field public static default_icon_packname:I

.field public static default_scroll_format:I

.field public static delete_folder_label:I

.field public static delete_function_drop_target_label:I

.field public static delete_package_intent:I

.field public static deleting_folder_error_toast:I

.field public static derived_app_name:I

.field public static developer_options_filter_hint:I

.field public static developer_options_title:I

.field public static dialog_remove:I

.field public static dialog_update:I

.field public static dialog_update_message:I

.field public static dialog_update_title:I

.field public static disable_smart_plugin_label:I

.field public static disabled_app_label:I

.field public static disallow_use_minus_one_panel_desc:I

.field public static discovery_ad:I

.field public static discovery_ad_flag:I

.field public static discovery_app_store:I

.field public static discovery_app_store_download:I

.field public static discovery_app_store_size:I

.field public static discovery_back:I

.field public static discovery_box_close:I

.field public static discovery_box_content:I

.field public static discovery_hero_ad_open:I

.field public static discovery_keyboard:I

.field public static discovery_keyboard_banner:I

.field public static discovery_keyboard_desc:I

.field public static discovery_keyboard_fragment_name:I

.field public static discovery_keyboard_got:I

.field public static discovery_keyboard_switch:I

.field public static discovery_keyboard_title:I

.field public static discovery_local:I

.field public static discovery_on_toast:I

.field public static discovery_open_branch_tip:I

.field public static discovery_opt_out_tip:I

.field public static discovery_personalize_allow:I

.field public static discovery_personalize_content:I

.field public static discovery_personalize_not_allow:I

.field public static discovery_personalize_title:I

.field public static discovery_privacy_cancel:I

.field public static discovery_privacy_desc:I

.field public static discovery_privacy_link_privacy:I

.field public static discovery_privacy_link_terms:I

.field public static discovery_privacy_powered:I

.field public static discovery_privacy_sure:I

.field public static discovery_privacy_title:I

.field public static discovery_privacy_turn_on:I

.field public static discovery_privacy_understand:I

.field public static discovery_setting:I

.field public static discovery_setting_desc:I

.field public static discovery_setting_fragment_name:I

.field public static discovery_setting_result:I

.field public static discovery_setting_result_desc:I

.field public static discovery_setting_search:I

.field public static discovery_setting_tip:I

.field public static discovery_setting_title:I

.field public static discovery_suggested:I

.field public static dismiss_prediction_label:I

.field public static do_not_support_multiwindow:I

.field public static do_not_support_smart_eye:I

.field public static done:I

.field public static dotted_app_label:I

.field public static easy_mode_config:I

.field public static edit_folder_label:I

.field public static edit_folder_label2:I

.field public static edit_home_screen:I

.field public static editing_folder_error_toast:I

.field public static editing_folder_name_error_toast:I

.field public static eldin_hint:I

.field public static entertainment_widget_recommendation_category_label:I

.field public static error_a11y_label:I

.field public static error_icon_content_description:I

.field public static expand_button_title:I

.field public static exposed_dropdown_menu_content_description:I

.field public static external_wallpaper_button_text:I

.field public static external_wallpaper_picker_package:I

.field public static extrenal_display_setting_text:I

.field public static fab_transformation_scrim_behavior:I

.field public static fab_transformation_sheet_behavior:I

.field public static folder_closed:I

.field public static folder_created:I

.field public static folder_deleted:I

.field public static folder_hint_text:I

.field public static folder_name_format_exact:I

.field public static folder_name_format_overflow:I

.field public static folder_name_provider_class:I

.field public static folder_opened:I

.field public static folder_renamed:I

.field public static folder_tap_to_close:I

.field public static folder_tap_to_rename:I

.field public static free_arrangement_mode:I

.field public static free_arrangement_mode_summary:I

.field public static freeform_msg:I

.field public static gadget_complete_setup_text:I

.field public static gadget_error_text:I

.field public static gadget_setup_text:I

.field public static gadget_stack_full_text:I

.field public static gesture_hint_msg:I

.field public static gesture_tutorial_action_button_label:I

.field public static gesture_tutorial_action_button_label_cancel:I

.field public static gesture_tutorial_action_button_label_settings:I

.field public static gesture_tutorial_action_button_label_skip:I

.field public static gesture_tutorial_close_button_content_description:I

.field public static gesture_tutorial_confirm_title:I

.field public static gesture_tutorial_nice:I

.field public static gesture_tutorial_rotation_prompt:I

.field public static gesture_tutorial_rotation_prompt_title:I

.field public static gesture_tutorial_step:I

.field public static gesture_tutorial_try_again:I

.field public static global_search_desc:I

.field public static global_search_hint:I

.field public static global_search_know:I

.field public static global_search_preference_category:I

.field public static global_search_show_button_title:I

.field public static global_search_swipe_down_title:I

.field public static global_search_title:I

.field public static hide_bottom_view_on_scroll_behavior:I

.field public static home_gesture_feedback_complete_with_follow_up:I

.field public static home_gesture_feedback_complete_without_follow_up:I

.field public static home_gesture_feedback_overview_detected:I

.field public static home_gesture_feedback_swipe_too_far_from_edge:I

.field public static home_gesture_feedback_wrong_swipe_direction:I

.field public static home_gesture_intro_subtitle:I

.field public static home_gesture_intro_title:I

.field public static home_gesture_spoken_intro_subtitle:I

.field public static home_gesture_tutorial_subtitle:I

.field public static home_gesture_tutorial_success:I

.field public static home_gesture_tutorial_title:I

.field public static home_screen:I

.field public static home_screen_style:I

.field public static home_screen_style_app_drawer:I

.field public static home_screen_style_app_drawer_settings:I

.field public static home_screen_style_app_drawer_summary:I

.field public static home_screen_style_single_layer:I

.field public static home_screen_style_single_layer_settings:I

.field public static home_screen_style_single_layer_summary:I

.field public static hotsaet_tip_prediction_disabled:I

.field public static hotsaet_tip_prediction_enabled:I

.field public static hotseat_auto_enrolled:I

.field public static hotseat_edu_accept:I

.field public static hotseat_edu_dismiss:I

.field public static hotseat_edu_message_migrate:I

.field public static hotseat_edu_message_migrate_landscape:I

.field public static hotseat_edu_title_migrate:I

.field public static hotseat_edu_title_migrate_landscape:I

.field public static hotseat_out_of_space:I

.field public static hotseat_prediction_content_description:I

.field public static hotseat_prediction_settings:I

.field public static hotseat_suggestions_summary:I

.field public static hotseat_suggestions_title:I

.field public static hotseat_tip_gaps_filled:I

.field public static hotseat_tip_no_empty_slots:I

.field public static icon_content_description:I

.field public static icon_pack:I

.field public static icon_personalize_decrease_size:I

.field public static icon_personalize_inscrease_size:I

.field public static icon_personalized_label:I

.field public static icon_personalized_label_des:I

.field public static icon_personalized_label_summary:I

.field public static icon_personalized_preview:I

.field public static icon_personalized_seekbar_large:I

.field public static icon_personalized_seekbar_larger:I

.field public static icon_personalized_seekbar_largest:I

.field public static icon_personalized_seekbar_normal:I

.field public static icon_personalized_seekbar_small:I

.field public static install_drop_target_label:I

.field public static install_in_secure_folder:I

.field public static install_private_system_shortcut_label:I

.field public static instant_app_resolver_class:I

.field public static internal_wallpaper_picker_package:I

.field public static ios_to_android_migration_layout_provider:I

.field public static item_added_to_workspace:I

.field public static item_moved:I

.field public static item_removed:I

.field public static item_view_role_description:I

.field public static label_application:I

.field public static launcher_activity_logic_class:I

.field public static launcher_restore_event_logger_class:I

.field public static local_colors_extraction_class:I

.field public static lock_button_text:I

.field public static lock_layout_desc:I

.field public static lock_layout_title:I

.field public static lock_layout_toast:I

.field public static long_accessible_way_to_add:I

.field public static long_accessible_way_to_add_shortcut:I

.field public static long_press_shortcut_to_add:I

.field public static long_press_widget_to_add:I

.field public static m3_exceed_max_badge_text_suffix:I

.field public static m3_loading_indicator_content_description:I

.field public static m3_ref_typeface_brand_medium:I

.field public static m3_ref_typeface_brand_regular:I

.field public static m3_ref_typeface_plain_medium:I

.field public static m3_ref_typeface_plain_regular:I

.field public static m3_sys_motion_easing_emphasized:I

.field public static m3_sys_motion_easing_emphasized_accelerate:I

.field public static m3_sys_motion_easing_emphasized_decelerate:I

.field public static m3_sys_motion_easing_emphasized_path_data:I

.field public static m3_sys_motion_easing_legacy:I

.field public static m3_sys_motion_easing_legacy_accelerate:I

.field public static m3_sys_motion_easing_legacy_decelerate:I

.field public static m3_sys_motion_easing_linear:I

.field public static m3_sys_motion_easing_standard:I

.field public static m3_sys_motion_easing_standard_accelerate:I

.field public static m3_sys_motion_easing_standard_decelerate:I

.field public static main_process_initializer_class:I

.field public static manage_windows_icon_text:I

.field public static market_search_intent:I

.field public static material_clock_display_divider:I

.field public static material_clock_toggle_content_description:I

.field public static material_hour_24h_suffix:I

.field public static material_hour_selection:I

.field public static material_hour_suffix:I

.field public static material_minute_selection:I

.field public static material_minute_suffix:I

.field public static material_motion_easing_accelerated:I

.field public static material_motion_easing_decelerated:I

.field public static material_motion_easing_emphasized:I

.field public static material_motion_easing_linear:I

.field public static material_motion_easing_standard:I

.field public static material_slider_range_end:I

.field public static material_slider_range_start:I

.field public static material_slider_value:I

.field public static material_timepicker_am:I

.field public static material_timepicker_clock_mode_description:I

.field public static material_timepicker_hour:I

.field public static material_timepicker_minute:I

.field public static material_timepicker_pm:I

.field public static material_timepicker_select_time:I

.field public static material_timepicker_text_input_mode_description:I

.field public static menu_display_text:I

.field public static menu_pc_text:I

.field public static menu_restart_text:I

.field public static minus_one_panel_choice_AppFlash:I

.field public static minus_one_panel_choice_Copilot:I

.field public static minus_one_panel_choice_GoogleNow:I

.field public static minus_one_panel_choice_MyScreen:I

.field public static minus_one_panel_choice_None:I

.field public static minus_one_panel_choice_title_AppFlash:I

.field public static minus_one_panel_choice_title_Copilot:I

.field public static minus_one_panel_choice_title_GoogleNow:I

.field public static minus_one_panel_choice_title_MyScreen:I

.field public static minus_one_panel_choice_title_None:I

.field public static minus_one_panel_choice_title_None_summary:I

.field public static minus_one_panel_title:I

.field public static model_delegate_class:I

.field public static more:I

.field public static more_options:I

.field public static move_drop_target_bottom_or_right:I

.field public static move_drop_target_top_or_left:I

.field public static move_to_empty_cell_description:I

.field public static move_to_hotseat_position:I

.field public static move_to_position:I

.field public static msg_disabled_by_admin:I

.field public static msg_missing_notification_access:I

.field public static mtrl_badge_numberless_content_description:I

.field public static mtrl_checkbox_button_icon_path_checked:I

.field public static mtrl_checkbox_button_icon_path_group_name:I

.field public static mtrl_checkbox_button_icon_path_indeterminate:I

.field public static mtrl_checkbox_button_icon_path_name:I

.field public static mtrl_checkbox_button_path_checked:I

.field public static mtrl_checkbox_button_path_group_name:I

.field public static mtrl_checkbox_button_path_name:I

.field public static mtrl_checkbox_button_path_unchecked:I

.field public static mtrl_checkbox_state_description_checked:I

.field public static mtrl_checkbox_state_description_indeterminate:I

.field public static mtrl_checkbox_state_description_unchecked:I

.field public static mtrl_chip_close_icon_content_description:I

.field public static mtrl_exceed_max_badge_number_content_description:I

.field public static mtrl_exceed_max_badge_number_suffix:I

.field public static mtrl_picker_a11y_next_month:I

.field public static mtrl_picker_a11y_prev_month:I

.field public static mtrl_picker_announce_current_range_selection:I

.field public static mtrl_picker_announce_current_selection:I

.field public static mtrl_picker_announce_current_selection_none:I

.field public static mtrl_picker_cancel:I

.field public static mtrl_picker_confirm:I

.field public static mtrl_picker_date_header_selected:I

.field public static mtrl_picker_date_header_title:I

.field public static mtrl_picker_date_header_unselected:I

.field public static mtrl_picker_day_of_week_column_header:I

.field public static mtrl_picker_end_date_description:I

.field public static mtrl_picker_invalid_format:I

.field public static mtrl_picker_invalid_format_example:I

.field public static mtrl_picker_invalid_format_use:I

.field public static mtrl_picker_invalid_range:I

.field public static mtrl_picker_navigate_to_current_year_description:I

.field public static mtrl_picker_navigate_to_year_description:I

.field public static mtrl_picker_out_of_range:I

.field public static mtrl_picker_range_header_only_end_selected:I

.field public static mtrl_picker_range_header_only_start_selected:I

.field public static mtrl_picker_range_header_selected:I

.field public static mtrl_picker_range_header_title:I

.field public static mtrl_picker_range_header_unselected:I

.field public static mtrl_picker_save:I

.field public static mtrl_picker_start_date_description:I

.field public static mtrl_picker_text_input_date_hint:I

.field public static mtrl_picker_text_input_date_range_end_hint:I

.field public static mtrl_picker_text_input_date_range_start_hint:I

.field public static mtrl_picker_text_input_day_abbr:I

.field public static mtrl_picker_text_input_month_abbr:I

.field public static mtrl_picker_text_input_year_abbr:I

.field public static mtrl_picker_today_description:I

.field public static mtrl_picker_toggle_to_calendar_input_mode:I

.field public static mtrl_picker_toggle_to_day_selection:I

.field public static mtrl_picker_toggle_to_text_input_mode:I

.field public static mtrl_picker_toggle_to_year_selection:I

.field public static mtrl_picker_toggled_to_day_selection:I

.field public static mtrl_picker_toggled_to_year_selection:I

.field public static mtrl_switch_thumb_group_name:I

.field public static mtrl_switch_thumb_path_checked:I

.field public static mtrl_switch_thumb_path_morphing:I

.field public static mtrl_switch_thumb_path_name:I

.field public static mtrl_switch_thumb_path_pressed:I

.field public static mtrl_switch_thumb_path_unchecked:I

.field public static mtrl_switch_track_decoration_path:I

.field public static mtrl_switch_track_path:I

.field public static mtrl_timepicker_cancel:I

.field public static mtrl_timepicker_confirm:I

.field public static my_screen_package:I

.field public static my_screen_service:I

.field public static nav_handle_long_press_handler_class:I

.field public static nav_rail_collapsed_a11y_label:I

.field public static nav_rail_expanded_a11y_label:I

.field public static navigate_up:I

.field public static news_widget_recommendation_category_label:I

.field public static no_search_results:I

.field public static no_thanks:I

.field public static no_widgets_available:I

.field public static not_set:I

.field public static notification_dot_style_dot:I

.field public static notification_dot_style_dot_and_number:I

.field public static notification_dot_style_no:I

.field public static notification_dot_style_title:I

.field public static notification_dots_desc_off:I

.field public static notification_dots_desc_on:I

.field public static notification_dots_service_title:I

.field public static notification_dots_title:I

.field public static notifications_header:I

.field public static others_widget_recommendation_category_label:I

.field public static out_of_space:I

.field public static overlay_plugin_manager_class:I

.field public static overscroll_plugin_factory_class:I

.field public static overview_gesture_feedback_complete_with_follow_up:I

.field public static overview_gesture_feedback_complete_without_follow_up:I

.field public static overview_gesture_feedback_home_detected:I

.field public static overview_gesture_feedback_swipe_too_far_from_edge:I

.field public static overview_gesture_feedback_wrong_swipe_direction:I

.field public static overview_gesture_intro_subtitle:I

.field public static overview_gesture_intro_title:I

.field public static overview_gesture_spoken_intro_subtitle:I

.field public static overview_gesture_tutorial_subtitle:I

.field public static overview_gesture_tutorial_success:I

.field public static overview_gesture_tutorial_title:I

.field public static package_state_unknown:I

.field public static password_toggle_content_description:I

.field public static path_password_eye:I

.field public static path_password_eye_mask_strike_through:I

.field public static path_password_eye_mask_visible:I

.field public static path_password_strike_through:I

.field public static permdesc_deactivate_branch:I

.field public static permdesc_install_shortcut:I

.field public static permdesc_read_settings:I

.field public static permdesc_write_settings:I

.field public static permlab_deactivate_branch:I

.field public static permlab_install_shortcut:I

.field public static permlab_read_settings:I

.field public static permlab_write_settings:I

.field public static pin_prediction:I

.field public static plugin_manager_wrapper_class:I

.field public static popup_container_iterate_children:I

.field public static preference_copied:I

.field public static private_space_label:I

.field public static private_space_secondary_label:I

.field public static productivity_widget_recommendation_category_label:I

.field public static ps_add_button_content_description:I

.field public static ps_add_button_label:I

.field public static ps_container_lock_button_content_description:I

.field public static ps_container_lock_title:I

.field public static ps_container_settings:I

.field public static ps_container_title:I

.field public static ps_container_transition:I

.field public static ps_container_unlock_button_content_description:I

.field public static quick_remove_tip_button_text:I

.field public static quick_remove_tip_message:I

.field public static quick_switch_desktop:I

.field public static quick_switch_overflow:I

.field public static quick_switch_split_task:I

.field public static ready_for_gesture:I

.field public static recent_task_all_lock:I

.field public static recent_task_app_stream_tip:I

.field public static recent_task_clear_all_toast:I

.field public static recent_task_clear_one_toast:I

.field public static recent_task_lock_success:I

.field public static recent_task_lock_tip:I

.field public static recent_task_lock_toast:I

.field public static recent_task_one_lock:I

.field public static recent_task_option_desktop:I

.field public static recent_task_option_endless_mode:I

.field public static recent_task_option_freeform:I

.field public static recent_task_option_full_screen:I

.field public static recent_task_option_lock_app:I

.field public static recent_task_option_pin:I

.field public static recent_task_option_split_screen:I

.field public static recent_task_option_unlock_app:I

.field public static recent_task_some_lock:I

.field public static recent_task_unlock_success:I

.field public static recents_back:I

.field public static recents_clear_all:I

.field public static recents_empty_message:I

.field public static reconfigurable_widget_education_tip:I

.field public static remote_action_failed:I

.field public static remove_drop_target_label:I

.field public static remove_folder_label:I

.field public static remove_from_folder_label:I

.field public static removing_from_folder_error_toast:I

.field public static reorder_button_text:I

.field public static safemode_shortcut_error:I

.field public static safemode_widget_error:I

.field public static samrt_eye_msg:I

.field public static sandbox_mode_assistant_gesture_feedback_successful:I

.field public static sandbox_mode_back_gesture_feedback_successful:I

.field public static sandbox_mode_back_gesture_feedback_swipe_too_far_from_edge:I

.field public static sandbox_mode_home_gesture_feedback_successful:I

.field public static sandbox_mode_overview_gesture_feedback_successful:I

.field public static sandbox_mode_subtitle:I

.field public static sandbox_mode_title:I

.field public static save_app_pair:I

.field public static sdl_shortcut_already_added_on_desktop:I

.field public static search_apps_tab:I

.field public static search_menu_title:I

.field public static search_pref_screen_title:I

.field public static search_pref_screen_title_tablet:I

.field public static search_screen_a11y_title:I

.field public static search_session_manager_class:I

.field public static searchbar_scrolling_view_behavior:I

.field public static searchview_clear_text_content_description:I

.field public static searchview_navigation_content_description:I

.field public static secondary_display_predictions_class:I

.field public static select_at_least_two_apps_toast:I

.field public static send_to_secure_folder:I

.field public static set_default_home_app:I

.field public static setting_button_text:I

.field public static settings_button_text:I

.field public static settings_feedback_title:I

.field public static settings_fragment_name:I

.field public static settings_licenses:I

.field public static settings_subtitle:I

.field public static settingslib_config_headlineFontFamily:I

.field public static settingslib_dismiss_button_content_description:I

.field public static settingslib_expressive_text_collapse:I

.field public static settingslib_expressive_text_expand:I

.field public static setup_wizard_pkg:I

.field public static shortcut_not_available:I

.field public static shortcuts_count:I

.field public static shorter_duration_less_than_one_minute:I

.field public static show_as_big_folder:I

.field public static show_as_small_folder:I

.field public static side_sheet_accessibility_pane_title:I

.field public static side_sheet_behavior:I

.field public static skip_tutorial_dialog_subtitle:I

.field public static skip_tutorial_dialog_title:I

.field public static smart_plugins_package:I

.field public static snackbar_accessibility_pane_title:I

.field public static social_widget_recommendation_category_label:I

.field public static split_app_info_accessibility:I

.field public static split_app_usage_settings:I

.field public static split_widgets_not_supported:I

.field public static stats_log_manager_class:I

.field public static status_bar_notification_info_overflow:I

.field public static strict_arrangement_mode:I

.field public static strict_arrangement_mode_summary:I

.field public static styles_button_text:I

.field public static styles_wallpaper_button_text:I

.field public static suggested_widgets_header_title:I

.field public static suggestions_options_summary:I

.field public static suggestions_options_title:I

.field public static summary_collapsed_preference_list:I

.field public static system:I

.field public static task_contents_description_with_remaining_time:I

.field public static task_overlay_factory_class:I

.field public static task_view_closed:I

.field public static taskbar_a11y_hidden_title:I

.field public static taskbar_a11y_shown_title:I

.field public static taskbar_a11y_title:I

.field public static taskbar_button_a11y:I

.field public static taskbar_button_back:I

.field public static taskbar_button_home:I

.field public static taskbar_button_ime_switcher:I

.field public static taskbar_button_notifications:I

.field public static taskbar_button_quick_settings:I

.field public static taskbar_button_recents:I

.field public static taskbar_divider_a11y_title:I

.field public static taskbar_edu_a11y_title:I

.field public static taskbar_edu_close:I

.field public static taskbar_edu_done:I

.field public static taskbar_edu_features:I

.field public static taskbar_edu_pinning:I

.field public static taskbar_edu_pinning_standalone:I

.field public static taskbar_edu_pinning_title:I

.field public static taskbar_edu_search_disclosure:I

.field public static taskbar_edu_splitscreen:I

.field public static taskbar_edu_stashing:I

.field public static taskbar_edu_suggestions:I

.field public static taskbar_edu_tooltip_controller_class:I

.field public static taskbar_model_callbacks_factory_class:I

.field public static taskbar_phone_a11y_title:I

.field public static taskbar_search_edu_title:I

.field public static taskbar_search_session_controller_class:I

.field public static taskbar_view_callbacks_factory_class:I

.field public static test_information_handler_class:I

.field public static themed_icons_title:I

.field public static time_left_for_app:I

.field public static title_app_suggestions:I

.field public static title_change_settings:I

.field public static title_missing_notification_access:I

.field public static toast_contextual_split_select_app:I

.field public static toast_split_app_unsupported:I

.field public static toast_split_select_app:I

.field public static toast_split_select_app_cancel:I

.field public static toast_split_select_cont_desc:I

.field public static udfps_accessibility_touch_hints_down:I

.field public static udfps_accessibility_touch_hints_left:I

.field public static udfps_accessibility_touch_hints_right:I

.field public static udfps_accessibility_touch_hints_up:I

.field public static undo:I

.field public static uninstall_drop_target_label:I

.field public static uninstall_private_system_shortcut_label:I

.field public static uninstall_system_app_text:I

.field public static v7_preference_off:I

.field public static v7_preference_on:I

.field public static wallpaper_button_text:I

.field public static wallpaper_picker_package:I

.field public static wellbeing_provider_pkg:I

.field public static widget_accessible_dims_format:I

.field public static widget_add_button_content_description:I

.field public static widget_add_button_label:I

.field public static widget_button_text:I

.field public static widget_category_conversations:I

.field public static widget_category_note_taking:I

.field public static widget_dims_format:I

.field public static widget_holder_factory_class:I

.field public static widget_picker_right_pane_accessibility_title:I

.field public static widget_preview_context_description:I

.field public static widget_preview_name_and_dims_content_description:I

.field public static widget_recommendation_category_provider_class:I

.field public static widget_reconfigure_button_content_description:I

.field public static widget_resized:I

.field public static widget_stack_edit_add:I

.field public static widget_stack_edit_title:I

.field public static widgets_and_shortcuts_count:I

.field public static widgets_count:I

.field public static widgets_full_sheet_cancel_button_description:I

.field public static widgets_full_sheet_personal_tab:I

.field public static widgets_full_sheet_search_bar_hint:I

.field public static widgets_full_sheet_work_tab:I

.field public static widgets_list:I

.field public static widgets_list_closed:I

.field public static window_manager_proxy_class:I

.field public static work_apps_enable_btn_text:I

.field public static work_apps_pause_btn_text:I

.field public static work_apps_paused_body:I

.field public static work_apps_paused_edu_accept:I

.field public static work_apps_paused_edu_banner:I

.field public static work_apps_paused_info_body:I

.field public static work_apps_paused_telephony_unavailable_body:I

.field public static work_apps_paused_title:I

.field public static work_folder_name:I

.field public static work_profile_edu_accept:I

.field public static work_profile_edu_section:I

.field public static work_profile_edu_work_apps:I

.field public static work_profile_toggle_label:I

.field public static workspace_new_page:I

.field public static workspace_preload_top_end_item:I

.field public static workspace_scroll_format:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20819
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
