.class public final Lcom/motorola/plugin/sdk/R$plurals;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_slice_duration_days:I

.field public static abc_slice_duration_min:I

.field public static abc_slice_duration_years:I

.field public static mtrl_badge_content_description:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20782
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
