.class Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;
.super Ljava/lang/Object;
.source "StartActivityParams.java"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;
    .locals 1

    .line 24
    new-instance p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;-><init>(Landroid/os/Parcel;Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;)V

    return-object p0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 0

    .line 21
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;->createFromParcel(Landroid/os/Parcel;)Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;

    move-result-object p0

    return-object p0
.end method

.method public newArray(I)[Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;
    .locals 0

    .line 29
    new-array p0, p1, [Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;

    return-object p0
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 0

    .line 21
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;->newArray(I)[Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;

    move-result-object p0

    return-object p0
.end method
