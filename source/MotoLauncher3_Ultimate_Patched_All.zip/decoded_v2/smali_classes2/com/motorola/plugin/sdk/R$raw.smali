.class public final Lcom/motorola/plugin/sdk/R$raw;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static all_set_page_bg:I

.field public static arrangement_mode_auto_fill:I

.field public static arrangement_mode_free:I

.field public static back_gesture_tutorial_animation:I

.field public static back_gesture_tutorial_open_foldable_animation:I

.field public static back_gesture_tutorial_tablet_animation:I

.field public static branch_checkbox_off_channel_ids:I

.field public static branch_search:I

.field public static checkmark_animation_end:I

.field public static checkmark_animation_in_progress:I

.field public static downgrade_schema:I

.field public static global_search:I

.field public static home_gesture_tutorial_animation:I

.field public static home_gesture_tutorial_open_foldable_animation:I

.field public static home_gesture_tutorial_tablet_animation:I

.field public static home_screen_style_app_tray:I

.field public static home_screen_style_open:I

.field public static notice:I

.field public static overview_gesture_tutorial_animation:I

.field public static overview_gesture_tutorial_open_foldable_animation:I

.field public static overview_gesture_tutorial_tablet_animation:I

.field public static smart_eye_icon:I

.field public static taskbar_edu_pinning:I

.field public static taskbar_edu_search:I

.field public static taskbar_edu_splitscreen_persistent:I

.field public static taskbar_edu_splitscreen_transient:I

.field public static taskbar_edu_stashing:I

.field public static taskbar_edu_suggestions_persistent:I

.field public static taskbar_edu_suggestions_transient:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20788
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
