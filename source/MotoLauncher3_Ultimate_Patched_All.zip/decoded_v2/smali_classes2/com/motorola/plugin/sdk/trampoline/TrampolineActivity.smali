.class public Lcom/motorola/plugin/sdk/trampoline/TrampolineActivity;
.super Landroid/app/Activity;
.source "TrampolineActivity.java"


# static fields
.field public static final EXTRA_KEY_TARGET_INTENT:Ljava/lang/String; = "com.motorola.plugin.intent.extra.target_intent"

.field public static final TAG:Ljava/lang/String; = "TrampolineActivity"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 17
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static getLaunchIntent(Landroid/content/Context;Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;)Landroid/content/Intent;
    .locals 2

    .line 23
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/motorola/plugin/sdk/trampoline/TrampolineActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p0, "com.motorola.plugin.intent.extra.target_intent"

    .line 24
    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object p0

    const p1, 0x10208000

    .line 25
    invoke-virtual {p0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 9

    .line 33
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 p1, 0x0

    .line 35
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setVisible(Z)V

    .line 37
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "com.motorola.plugin.intent.extra.target_intent"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;

    .line 38
    const-string v1, "TrampolineActivity"

    if-nez p1, :cond_0

    .line 39
    const-string p1, "Trampoline activity started without params"

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 40
    invoke-virtual {p0}, Landroid/app/Activity;->finishAndRemoveTask()V

    return-void

    .line 44
    :cond_0
    :try_start_0
    iget-object v0, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-eqz v0, :cond_1

    .line 45
    :try_start_1
    iget-object p1, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    invoke-virtual {p0, v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-object v2, p0

    goto :goto_2

    :catch_0
    move-exception v0

    move-object p1, v0

    move-object v2, p0

    goto :goto_1

    .line 46
    :cond_1
    :try_start_2
    iget-object v3, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    if-eqz v3, :cond_2

    .line 47
    iget-object v4, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    iget v5, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    iget v6, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    iget v7, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    iget-object v8, p1, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    move-object v2, p0

    :try_start_3
    invoke-virtual/range {v2 .. v8}, Landroid/app/Activity;->startIntentSender(Landroid/content/IntentSender;Landroid/content/Intent;IIILandroid/os/Bundle;)V

    goto :goto_2

    :catch_1
    move-exception v0

    :goto_0
    move-object p1, v0

    goto :goto_1

    :catch_2
    move-exception v0

    move-object v2, p0

    goto :goto_0

    :cond_2
    move-object v2, p0

    .line 56
    const-string p0, "Trampoline activity started failed without intent"

    invoke-static {v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_2

    .line 59
    :goto_1
    const-string p0, "Trampoline activity started error"

    invoke-static {v1, p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 61
    :goto_2
    invoke-virtual {v2}, Landroid/app/Activity;->finish()V

    return-void
.end method
