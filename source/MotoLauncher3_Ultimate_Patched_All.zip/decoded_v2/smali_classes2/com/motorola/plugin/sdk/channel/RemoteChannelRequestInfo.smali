.class public Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;
.super Ljava/lang/Object;
.source "RemoteChannelRequestInfo.java"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;


# instance fields
.field public final bundle:Landroid/os/Bundle;

.field public final callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

.field public final origIntent:Landroid/content/Intent;

.field public final pluginId:Lcom/motorola/plugin/sdk/channel/ClientId;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 18
    new-instance v0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;

    invoke-direct {v0}, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;-><init>()V

    sput-object v0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Landroid/content/Intent;Lcom/motorola/plugin/sdk/channel/ClientId;Lcom/motorola/plugin/sdk/channel/ClientId;Landroid/os/Bundle;)V
    .locals 0

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 55
    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->origIntent:Landroid/content/Intent;

    .line 56
    iput-object p2, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 57
    iput-object p3, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->pluginId:Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 58
    iput-object p4, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->bundle:Landroid/os/Bundle;

    return-void
.end method

.method private constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    .line 61
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 62
    const-class v0, Landroid/content/Intent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->origIntent:Landroid/content/Intent;

    .line 63
    const-class v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 64
    const-class v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Lcom/motorola/plugin/sdk/channel/ClientId;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->pluginId:Lcom/motorola/plugin/sdk/channel/ClientId;

    .line 65
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->bundle:Landroid/os/Bundle;

    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Parcel;Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo$1;)V
    .locals 0

    .line 16
    invoke-direct {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;-><init>(Landroid/os/Parcel;)V

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 0

    .line 70
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->bundle:Landroid/os/Bundle;

    invoke-virtual {p0}, Landroid/os/Bundle;->describeContents()I

    move-result p0

    return p0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    .line 75
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->origIntent:Landroid/content/Intent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 76
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->callingClientId:Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 77
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->pluginId:Lcom/motorola/plugin/sdk/channel/ClientId;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 78
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteChannelRequestInfo;->bundle:Landroid/os/Bundle;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    return-void
.end method
