.class public final synthetic Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic f$0:Lcom/motorola/plugin/sdk/channel/ClientId;

.field public final synthetic f$1:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/plugin/sdk/channel/ClientId;Ljava/util/List;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;->f$0:Lcom/motorola/plugin/sdk/channel/ClientId;

    iput-object p2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;->f$1:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;->f$0:Lcom/motorola/plugin/sdk/channel/ClientId;

    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda3;->f$1:Ljava/util/List;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    invoke-static {v0, p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->$r8$lambda$slsPEmHcIQz7fSVtuASo75F5FvE(Lcom/motorola/plugin/sdk/channel/ClientId;Ljava/util/List;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V

    return-void
.end method
