.class public Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;
.super Ljava/lang/Object;
.source "RemoteService.java"


# instance fields
.field private final callback:Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

.field private final sequence:I


# direct methods
.method public constructor <init>(ILcom/motorola/plugin/sdk/channel/IRemoteCallback;)V
    .locals 0

    .line 535
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 536
    iput p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->sequence:I

    .line 537
    iput-object p2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->callback:Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    return-void
.end method


# virtual methods
.method public onReplyToRemoteApp(Landroid/os/Bundle;)V
    .locals 4

    .line 541
    const-string v0, "["

    const-string v1, "RemoteService"

    const-string v2, "com.motorola.plugin.extra.SEQUENCE"

    iget v3, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->sequence:I

    invoke-virtual {p1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const/4 v2, 0x2

    .line 543
    :try_start_0
    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 544
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->sequence:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "] reply to remote client"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catch_0
    move-exception p1

    goto :goto_1

    .line 546
    :cond_0
    :goto_0
    iget-object v2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->callback:Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    invoke-interface {v2, p1}, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;->sendResult(Landroid/os/Bundle;)V

    const/4 p1, 0x3

    .line 547
    invoke-static {v1, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 548
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->sequence:I

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "] reply to remote client done"

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_1
    const/4 v2, 0x5

    .line 551
    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 552
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$RemoteAppResolutionCallback;->sequence:I

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "] Error reply to client"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1
    return-void
.end method
