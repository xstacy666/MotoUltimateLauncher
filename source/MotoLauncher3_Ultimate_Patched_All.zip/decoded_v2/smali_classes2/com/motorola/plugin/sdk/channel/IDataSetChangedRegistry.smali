.class public interface abstract Lcom/motorola/plugin/sdk/channel/IDataSetChangedRegistry;
.super Ljava/lang/Object;
.source "IDataSetChangedRegistry.java"


# virtual methods
.method public varargs abstract register(Lcom/motorola/plugin/sdk/channel/IDataSetChangedCallback;[Landroid/net/Uri;)V
.end method

.method public varargs abstract unregister(Lcom/motorola/plugin/sdk/channel/IDataSetChangedCallback;[Landroid/net/Uri;)V
.end method
