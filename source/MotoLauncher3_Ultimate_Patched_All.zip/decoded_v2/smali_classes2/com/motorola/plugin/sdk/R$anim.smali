.class public final Lcom/motorola/plugin/sdk/R$anim;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_fade_in:I

.field public static abc_fade_out:I

.field public static abc_grow_fade_in_from_bottom:I

.field public static abc_popup_enter:I

.field public static abc_popup_exit:I

.field public static abc_shrink_fade_out_from_bottom:I

.field public static abc_slide_in_bottom:I

.field public static abc_slide_in_top:I

.field public static abc_slide_out_bottom:I

.field public static abc_slide_out_top:I

.field public static abc_tooltip_enter:I

.field public static abc_tooltip_exit:I

.field public static btn_checkbox_to_checked_box_inner_merged_animation:I

.field public static btn_checkbox_to_checked_box_outer_merged_animation:I

.field public static btn_checkbox_to_checked_icon_null_animation:I

.field public static btn_checkbox_to_unchecked_box_inner_merged_animation:I

.field public static btn_checkbox_to_unchecked_check_path_merged_animation:I

.field public static btn_checkbox_to_unchecked_icon_null_animation:I

.field public static btn_radio_to_off_mtrl_dot_group_animation:I

.field public static btn_radio_to_off_mtrl_ring_outer_animation:I

.field public static btn_radio_to_off_mtrl_ring_outer_path_animation:I

.field public static btn_radio_to_on_mtrl_dot_group_animation:I

.field public static btn_radio_to_on_mtrl_ring_outer_animation:I

.field public static btn_radio_to_on_mtrl_ring_outer_path_animation:I

.field public static design_bottom_sheet_slide_in:I

.field public static design_bottom_sheet_slide_out:I

.field public static design_snackbar_in:I

.field public static design_snackbar_out:I

.field public static eldin_fade_in:I

.field public static eldin_fade_in_slow:I

.field public static fade_in:I

.field public static fragment_fast_out_extra_slow_in:I

.field public static launch_dialog_enter:I

.field public static launch_dialog_exit:I

.field public static linear_indeterminate_line1_head_interpolator:I

.field public static linear_indeterminate_line1_tail_interpolator:I

.field public static linear_indeterminate_line2_head_interpolator:I

.field public static linear_indeterminate_line2_tail_interpolator:I

.field public static m3_bottom_sheet_slide_in:I

.field public static m3_bottom_sheet_slide_out:I

.field public static m3_motion_fade_enter:I

.field public static m3_motion_fade_exit:I

.field public static m3_side_sheet_enter_from_left:I

.field public static m3_side_sheet_enter_from_right:I

.field public static m3_side_sheet_exit_to_left:I

.field public static m3_side_sheet_exit_to_right:I

.field public static mtrl_bottom_sheet_slide_in:I

.field public static mtrl_bottom_sheet_slide_out:I

.field public static mtrl_card_lowers_interpolator:I

.field public static no_anim:I

.field public static task_open_enter:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
