.class public final Lcom/motorola/plugin/sdk/R$bool;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_action_bar_embed_tabs:I

.field public static abc_config_actionMenuItemAllCaps:I

.field public static add_icon_preference_default:I

.field public static all_apps_folders_blur_background:I

.field public static all_apps_folders_default:I

.field public static all_apps_folders_enable:I

.field public static all_apps_folders_filter_folder_apps_in_all_apps:I

.field public static all_apps_google_folder_enable:I

.field public static all_apps_suggestions_default:I

.field public static all_apps_suggestions_enable:I

.field public static branch_search_checkbox_on:I

.field public static branch_search_enable:I

.field public static config_enableTaskSnapshotPreloading:I

.field public static config_enable_all_apps_overlay:I

.field public static config_enable_all_apps_search_ui:I

.field public static config_enable_minus_one_panel:I

.field public static config_enable_remote_plugin:I

.field public static config_enable_smart_plugins:I

.field public static config_header_protection_supported:I

.field public static config_largeHeap:I

.field public static config_materialPreferenceIconSpaceReserved:I

.field public static config_use_google_now_panel_in_left_screen:I

.field public static dream_overlay_complication_clock_bottom_padding:I

.field public static enable_big_folder:I

.field public static enable_checkin:I

.field public static enable_forced_themed_icon:I

.field public static enable_fullscreen_folder:I

.field public static enable_quickstep_live_tile:I

.field public static enable_system_alarm_service_default:I

.field public static enable_system_foreground_service_default:I

.field public static enable_system_job_service_default:I

.field public static floating_rotation_button_position_left:I

.field public static home_screen_style_feature_enable:I

.field public static home_settings_allow_divider:I

.field public static home_settings_icon_space_reserved:I

.field public static hotseat_suggestions_default:I

.field public static hotseat_suggestions_enable:I

.field public static hotseat_transpose_layout_with_orientation:I

.field public static is_app_label_show_two_line_default:I

.field public static is_apptray_twolines_enabled:I

.field public static is_language_support_two_lines_text:I

.field public static is_support_dnd:I

.field public static mtrl_btn_textappearance_all_caps:I

.field public static pin_unpin_taskbar_enabled:I

.field public static settingslib_config_allow_divider:I

.field public static settingslib_config_icon_space_reserved:I

.field public static show_dots_with_number_default:I

.field public static show_search_market:I

.field public static simple_cache_enable_im_memory:I

.field public static test_day_of_week:I

.field public static wallpaper_zoom_out_enable:I

.field public static workmanager_test_configuration:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 13591
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
