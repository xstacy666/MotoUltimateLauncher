.class public final Lcom/motorola/plugin/sdk/R$array;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static additional_apps:I

.field public static all_apps_folders:I

.field public static all_apps_folders_components:I

.field public static app_label_entries:I

.field public static app_label_values:I

.field public static back_gesture_blocking_activities:I

.field public static config_appsSupportMultiInstancesSplit:I

.field public static config_predefined_pluginWaivePriorityList:I

.field public static config_predefined_pluginWhitelist:I

.field public static custom_widget_package_spans:I

.field public static custom_widget_providers:I

.field public static default_predicted_apps:I

.field public static defer_gesture_pkgs:I

.field public static dynamic_icon_calendar_component_list:I

.field public static dynamic_icon_clock_component_list:I

.field public static dynamic_resources:I

.field public static filtered_components:I

.field public static icon_pack_actions:I

.field public static icon_size_steps:I

.field public static migrate_icons_apps:I

.field public static notification_blacklist:I

.field public static notification_dot_style_items:I

.field public static skip_private_profile_shortcut_packages:I

.field public static split_screen_blacklist:I

.field public static widget_span_exception_apps:I

.field public static workspace_preload_items:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 109
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
