.class public final synthetic Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Lcom/motorola/plugin/sdk/channel/ThrowingBiConsumer;


# instance fields
.field public final synthetic f$0:[Landroid/net/Uri;

.field public final synthetic f$1:Landroid/os/Bundle;


# direct methods
.method public synthetic constructor <init>([Landroid/net/Uri;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;->f$0:[Landroid/net/Uri;

    iput-object p2, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;->f$1:Landroid/os/Bundle;

    return-void
.end method


# virtual methods
.method public final acceptOrThrow(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;->f$0:[Landroid/net/Uri;

    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda0;->f$1:Landroid/os/Bundle;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    invoke-static {v0, p0, p1, p2}, Lcom/motorola/plugin/sdk/channel/RemoteService;->$r8$lambda$46kXulUfFGoOnAQN_ZXgsVoSc1U([Landroid/net/Uri;Landroid/os/Bundle;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;Ljava/lang/Object;)V

    return-void
.end method
