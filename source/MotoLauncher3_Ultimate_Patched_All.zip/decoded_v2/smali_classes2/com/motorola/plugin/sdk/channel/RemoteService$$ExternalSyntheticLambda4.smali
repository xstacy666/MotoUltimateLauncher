.class public final synthetic Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic f$0:Lcom/motorola/plugin/sdk/channel/RemoteService;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/plugin/sdk/channel/RemoteService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda4;->f$0:Lcom/motorola/plugin/sdk/channel/RemoteService;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/motorola/plugin/sdk/channel/RemoteService$$ExternalSyntheticLambda4;->f$0:Lcom/motorola/plugin/sdk/channel/RemoteService;

    check-cast p1, Lcom/motorola/plugin/sdk/channel/IRemoteCallback;

    invoke-static {p0, p1}, Lcom/motorola/plugin/sdk/channel/RemoteService;->$r8$lambda$93VbG-EnUALCHrK0817CJOqFcxA(Lcom/motorola/plugin/sdk/channel/RemoteService;Lcom/motorola/plugin/sdk/channel/IRemoteCallback;)V

    return-void
.end method
