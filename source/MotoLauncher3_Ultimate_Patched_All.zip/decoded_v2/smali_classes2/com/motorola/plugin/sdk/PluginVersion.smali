.class public Lcom/motorola/plugin/sdk/PluginVersion;
.super Ljava/lang/Object;
.source "PluginVersion.java"


# static fields
.field public static final VERSION_CURRENT:I = 0xc1d


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
