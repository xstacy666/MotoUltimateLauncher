.class public final Lcom/motorola/plugin/sdk/BuildConfig;
.super Ljava/lang/Object;
.source "BuildConfig.java"


# static fields
.field public static final BUILD_TYPE:Ljava/lang/String; = "release"

.field public static final DEBUG:Z = false

.field public static final LIBRARY_PACKAGE_NAME:Ljava/lang/String; = "com.motorola.plugin.sdk"

.field public static final VERSION_CODE:I = 0xc1d

.field public static final VERSION_NAME:Ljava/lang/String; = "3.1.1-1"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
