.class public interface abstract annotation Lcom/motorola/plugin/sdk/annotations/Dimension$DimensionUnit;
.super Ljava/lang/Object;
.source "Dimension.java"

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->SOURCE:Ljava/lang/annotation/RetentionPolicy;
.end annotation
