.class public interface abstract Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteChannelTransferCallback;
.super Ljava/lang/Object;
.source "IRemoteChannel.java"

# interfaces
.implements Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;
.implements Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteError;
