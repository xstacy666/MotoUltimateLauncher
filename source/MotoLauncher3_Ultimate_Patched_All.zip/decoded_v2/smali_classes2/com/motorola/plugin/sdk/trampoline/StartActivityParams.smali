.class public Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;
.super Ljava/lang/Object;
.source "StartActivityParams.java"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;


# instance fields
.field public extraFlags:I

.field public fillInIntent:Landroid/content/Intent;

.field public flagsMask:I

.field public flagsValues:I

.field public intent:Landroid/content/Intent;

.field public intentSender:Landroid/content/IntentSender;

.field public options:Landroid/os/Bundle;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 21
    new-instance v0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;

    invoke-direct {v0}, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;-><init>()V

    sput-object v0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(Landroid/app/PendingIntent;)V
    .locals 2

    .line 50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 33
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;

    .line 36
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    .line 38
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    const/4 v1, 0x0

    .line 40
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    .line 41
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    .line 42
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    .line 43
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    if-nez p1, :cond_0

    goto :goto_0

    .line 51
    :cond_0
    invoke-virtual {p1}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object v0

    :goto_0
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    return-void
.end method

.method public constructor <init>(Landroid/content/Intent;)V
    .locals 2

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 36
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    .line 38
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    const/4 v1, 0x0

    .line 40
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    .line 41
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    .line 42
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    .line 43
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    .line 47
    iput-object p1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;

    return-void
.end method

.method private constructor <init>(Landroid/os/Parcel;)V
    .locals 2

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 33
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;

    .line 36
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    .line 38
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    const/4 v1, 0x0

    .line 40
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    .line 41
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    .line 42
    iput v1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    .line 43
    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    .line 55
    const-class v0, Landroid/content/Intent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;

    .line 57
    const-class v0, Landroid/content/IntentSender;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/IntentSender;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    .line 58
    const-class v0, Landroid/content/Intent;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Landroid/content/Intent;

    iput-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    .line 59
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    .line 60
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    .line 61
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    .line 63
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Parcel;Lcom/motorola/plugin/sdk/trampoline/StartActivityParams$1;)V
    .locals 0

    .line 19
    invoke-direct {p0, p1}, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;-><init>(Landroid/os/Parcel;)V

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 0

    .line 0
    const/4 p0, 0x0

    return p0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    .line 73
    iget-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intent:Landroid/content/Intent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 75
    iget-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->intentSender:Landroid/content/IntentSender;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 76
    iget-object v0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->fillInIntent:Landroid/content/Intent;

    invoke-virtual {p1, v0, p2}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    .line 77
    iget p2, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsMask:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    .line 78
    iget p2, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->flagsValues:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    .line 79
    iget p2, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->extraFlags:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    .line 81
    iget-object p0, p0, Lcom/motorola/plugin/sdk/trampoline/StartActivityParams;->options:Landroid/os/Bundle;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    return-void
.end method
