.class public final Lcom/motorola/plugin/sdk/R$integer;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_config_activityDefaultDur:I

.field public static abc_config_activityShortDur:I

.field public static angle_rtl_180:I

.field public static app_bar_elevation_anim_duration:I

.field public static assistant_gesture_corner_deg_threshold:I

.field public static assistant_gesture_min_time_threshold:I

.field public static bottom_sheet_slide_duration:I

.field public static cancel_button_image_alpha:I

.field public static cast_search_bar_version:I

.field public static config_allAppsCloseDuration:I

.field public static config_allAppsOpenDuration:I

.field public static config_bottomSheetCloseDuration:I

.field public static config_bottomSheetOpenDuration:I

.field public static config_caretAnimationDuration:I

.field public static config_dragOutlineFadeTime:I

.field public static config_dragOutlineMaxAlpha:I

.field public static config_dropAnimMaxDist:I

.field public static config_dropAnimMaxDuration:I

.field public static config_dropAnimMinDuration:I

.field public static config_folderDelay:I

.field public static config_keyboardTaskFocusSnapAnimationDuration:I

.field public static config_materialFolderExpandDuration:I

.field public static config_pageSnapAnimationDuration:I

.field public static config_popupArrowOpenCloseDuration:I

.field public static config_popupOpenCloseDuration:I

.field public static config_removeNotificationViewDuration:I

.field public static config_tooltipAnimTime:I

.field public static design_snackbar_text_max_lines:I

.field public static design_tab_indicator_anim_duration_ms:I

.field public static folder_name_max_length:I

.field public static gesture_tutorial_extra_conversations_visibility:I

.field public static gesture_tutorial_extra_messages_visibility:I

.field public static gesture_tutorial_webpage_extra_lines_visibility:I

.field public static hide_password_duration:I

.field public static home_screen_style_default:I

.field public static icon_size_default_progress:I

.field public static m3_badge_max_number:I

.field public static m3_btn_anim_delay_ms:I

.field public static m3_btn_anim_duration_ms:I

.field public static m3_card_anim_delay_ms:I

.field public static m3_card_anim_duration_ms:I

.field public static m3_chip_anim_duration:I

.field public static m3_sys_motion_duration_extra_long1:I

.field public static m3_sys_motion_duration_extra_long2:I

.field public static m3_sys_motion_duration_extra_long3:I

.field public static m3_sys_motion_duration_extra_long4:I

.field public static m3_sys_motion_duration_long1:I

.field public static m3_sys_motion_duration_long2:I

.field public static m3_sys_motion_duration_long3:I

.field public static m3_sys_motion_duration_long4:I

.field public static m3_sys_motion_duration_medium1:I

.field public static m3_sys_motion_duration_medium2:I

.field public static m3_sys_motion_duration_medium3:I

.field public static m3_sys_motion_duration_medium4:I

.field public static m3_sys_motion_duration_short1:I

.field public static m3_sys_motion_duration_short2:I

.field public static m3_sys_motion_duration_short3:I

.field public static m3_sys_motion_duration_short4:I

.field public static m3_sys_motion_path:I

.field public static m3_sys_shape_corner_extra_large_corner_family:I

.field public static m3_sys_shape_corner_extra_small_corner_family:I

.field public static m3_sys_shape_corner_full_corner_family:I

.field public static m3_sys_shape_corner_large_corner_family:I

.field public static m3_sys_shape_corner_medium_corner_family:I

.field public static m3_sys_shape_corner_small_corner_family:I

.field public static material_motion_duration_long_1:I

.field public static material_motion_duration_long_2:I

.field public static material_motion_duration_medium_1:I

.field public static material_motion_duration_medium_2:I

.field public static material_motion_duration_short_1:I

.field public static material_motion_duration_short_2:I

.field public static material_motion_path:I

.field public static max_depth_blur_radius:I

.field public static min_width_split:I

.field public static mtrl_badge_max_character_count:I

.field public static mtrl_btn_anim_delay_ms:I

.field public static mtrl_btn_anim_duration_ms:I

.field public static mtrl_calendar_header_orientation:I

.field public static mtrl_calendar_selection_text_lines:I

.field public static mtrl_calendar_year_selector_span:I

.field public static mtrl_card_anim_delay_ms:I

.field public static mtrl_card_anim_duration_ms:I

.field public static mtrl_chip_anim_duration:I

.field public static mtrl_switch_thumb_motion_duration:I

.field public static mtrl_switch_thumb_post_morphing_duration:I

.field public static mtrl_switch_thumb_pre_morphing_duration:I

.field public static mtrl_switch_thumb_pressed_duration:I

.field public static mtrl_switch_thumb_viewport_center_coordinate:I

.field public static mtrl_switch_thumb_viewport_size:I

.field public static mtrl_switch_track_viewport_height:I

.field public static mtrl_switch_track_viewport_width:I

.field public static mtrl_tab_indicator_anim_duration_ms:I

.field public static mtrl_view_gone:I

.field public static mtrl_view_invisible:I

.field public static mtrl_view_visible:I

.field public static override_long_press_navi_duration:I

.field public static preferences_detail_pane_weight:I

.field public static preferences_header_pane_weight:I

.field public static recent_touch_slop_scale:I

.field public static recentsIconCacheSize:I

.field public static recentsIconCacheSize_low_ram:I

.field public static recentsScrollHapticMinGapMillis:I

.field public static recentsThumbnailCacheSize:I

.field public static recentsThumbnailCacheSize_low_ram:I

.field public static show_password_duration:I

.field public static status_bar_notification_info_maxnum:I

.field public static taskbar_background_duration:I

.field public static transition_anim_scale:I

.field public static widget_cell_add_button_font_weight:I

.field public static widget_cell_description_font_weight:I

.field public static widget_cell_dims_font_weight:I

.field public static widget_cell_title_font_weight:I

.field public static widget_picker_header_app_subtitle_font_weight:I

.field public static widget_picker_header_app_title_font_weight:I

.field public static workspace_touch_slop_scale:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 20147
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
