.class public interface abstract Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteError;
.super Ljava/lang/Object;
.source "IRemoteChannel.java"


# annotations
.annotation runtime Ljava/lang/FunctionalInterface;
.end annotation


# virtual methods
.method public abstract onRemoteError(Ljava/lang/Throwable;)V
.end method
