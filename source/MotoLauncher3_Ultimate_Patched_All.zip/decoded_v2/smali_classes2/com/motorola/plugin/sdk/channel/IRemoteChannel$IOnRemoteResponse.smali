.class public interface abstract Lcom/motorola/plugin/sdk/channel/IRemoteChannel$IOnRemoteResponse;
.super Ljava/lang/Object;
.source "IRemoteChannel.java"


# annotations
.annotation runtime Ljava/lang/FunctionalInterface;
.end annotation


# virtual methods
.method public abstract onRemoteResponse(Landroid/os/Bundle;)V
.end method
