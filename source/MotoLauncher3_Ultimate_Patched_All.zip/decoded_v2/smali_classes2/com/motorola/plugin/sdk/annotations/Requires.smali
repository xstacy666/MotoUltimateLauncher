.class public interface abstract annotation Lcom/motorola/plugin/sdk/annotations/Requires;
.super Ljava/lang/Object;
.source "Requires.java"

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime Ljava/lang/annotation/Repeatable;
    value = Lcom/motorola/plugin/sdk/annotations/Requirements;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation


# virtual methods
.method public abstract target()Ljava/lang/Class;
.end method

.method public abstract version()I
.end method
