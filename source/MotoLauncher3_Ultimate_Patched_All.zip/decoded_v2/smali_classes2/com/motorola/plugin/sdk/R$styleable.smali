.class public final Lcom/motorola/plugin/sdk/R$styleable;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final ActionBar:[I

.field public static final ActionBarLayout:[I

.field public static ActionBarLayout_android_layout_gravity:I

.field public static ActionBar_background:I

.field public static ActionBar_backgroundSplit:I

.field public static ActionBar_backgroundStacked:I

.field public static ActionBar_contentInsetEnd:I

.field public static ActionBar_contentInsetEndWithActions:I

.field public static ActionBar_contentInsetLeft:I

.field public static ActionBar_contentInsetRight:I

.field public static ActionBar_contentInsetStart:I

.field public static ActionBar_contentInsetStartWithNavigation:I

.field public static ActionBar_customNavigationLayout:I

.field public static ActionBar_displayOptions:I

.field public static ActionBar_divider:I

.field public static ActionBar_elevation:I

.field public static ActionBar_height:I

.field public static ActionBar_hideOnContentScroll:I

.field public static ActionBar_homeAsUpIndicator:I

.field public static ActionBar_homeLayout:I

.field public static ActionBar_icon:I

.field public static ActionBar_indeterminateProgressStyle:I

.field public static ActionBar_itemPadding:I

.field public static ActionBar_logo:I

.field public static ActionBar_navigationMode:I

.field public static ActionBar_popupTheme:I

.field public static ActionBar_progressBarPadding:I

.field public static ActionBar_progressBarStyle:I

.field public static ActionBar_subtitle:I

.field public static ActionBar_subtitleTextStyle:I

.field public static ActionBar_title:I

.field public static ActionBar_titleTextStyle:I

.field public static final ActionMenuItemView:[I

.field public static ActionMenuItemView_android_minWidth:I

.field public static final ActionMenuView:[I

.field public static final ActionMode:[I

.field public static ActionMode_background:I

.field public static ActionMode_backgroundSplit:I

.field public static ActionMode_closeItemLayout:I

.field public static ActionMode_height:I

.field public static ActionMode_subtitleTextStyle:I

.field public static ActionMode_titleTextStyle:I

.field public static final ActivityChooserView:[I

.field public static ActivityChooserView_expandActivityOverflowButtonDrawable:I

.field public static ActivityChooserView_initialActivityCount:I

.field public static final ActivityFilter:[I

.field public static ActivityFilter_activityAction:I

.field public static ActivityFilter_activityName:I

.field public static final ActivityRule:[I

.field public static ActivityRule_alwaysExpand:I

.field public static ActivityRule_tag:I

.field public static final AlertDialog:[I

.field public static AlertDialog_android_layout:I

.field public static AlertDialog_buttonIconDimen:I

.field public static AlertDialog_buttonPanelSideLayout:I

.field public static AlertDialog_listItemLayout:I

.field public static AlertDialog_listLayout:I

.field public static AlertDialog_multiChoiceItemLayout:I

.field public static AlertDialog_showTitle:I

.field public static AlertDialog_singleChoiceItemLayout:I

.field public static final AllAppsSpec:[I

.field public static AllAppsSpec_dimensionType:I

.field public static AllAppsSpec_maxAvailableSize:I

.field public static final AllAppsStyle:[I

.field public static AllAppsStyle_horizontalPadding:I

.field public static final AllSetLinkSpan:[I

.field public static AllSetLinkSpan_android_fontFamily:I

.field public static AllSetLinkSpan_android_textSize:I

.field public static final AnimatedStateListDrawableCompat:[I

.field public static AnimatedStateListDrawableCompat_android_constantSize:I

.field public static AnimatedStateListDrawableCompat_android_dither:I

.field public static AnimatedStateListDrawableCompat_android_enterFadeDuration:I

.field public static AnimatedStateListDrawableCompat_android_exitFadeDuration:I

.field public static AnimatedStateListDrawableCompat_android_variablePadding:I

.field public static AnimatedStateListDrawableCompat_android_visible:I

.field public static final AnimatedStateListDrawableItem:[I

.field public static AnimatedStateListDrawableItem_android_drawable:I

.field public static AnimatedStateListDrawableItem_android_id:I

.field public static final AnimatedStateListDrawableTransition:[I

.field public static AnimatedStateListDrawableTransition_android_drawable:I

.field public static AnimatedStateListDrawableTransition_android_fromId:I

.field public static AnimatedStateListDrawableTransition_android_reversible:I

.field public static AnimatedStateListDrawableTransition_android_toId:I

.field public static final AppBarLayout:[I

.field public static final AppBarLayoutStates:[I

.field public static AppBarLayoutStates_state_collapsed:I

.field public static AppBarLayoutStates_state_collapsible:I

.field public static AppBarLayoutStates_state_liftable:I

.field public static AppBarLayoutStates_state_lifted:I

.field public static final AppBarLayout_Layout:[I

.field public static AppBarLayout_Layout_layout_scrollEffect:I

.field public static AppBarLayout_Layout_layout_scrollFlags:I

.field public static AppBarLayout_Layout_layout_scrollInterpolator:I

.field public static AppBarLayout_android_background:I

.field public static AppBarLayout_android_keyboardNavigationCluster:I

.field public static AppBarLayout_android_touchscreenBlocksFocus:I

.field public static AppBarLayout_elevation:I

.field public static AppBarLayout_expanded:I

.field public static AppBarLayout_liftOnScroll:I

.field public static AppBarLayout_liftOnScrollColor:I

.field public static AppBarLayout_liftOnScrollTargetViewId:I

.field public static AppBarLayout_statusBarForeground:I

.field public static final AppCompatEmojiHelper:[I

.field public static final AppCompatImageView:[I

.field public static AppCompatImageView_android_src:I

.field public static AppCompatImageView_srcCompat:I

.field public static AppCompatImageView_tint:I

.field public static AppCompatImageView_tintMode:I

.field public static final AppCompatSeekBar:[I

.field public static AppCompatSeekBar_android_thumb:I

.field public static AppCompatSeekBar_tickMark:I

.field public static AppCompatSeekBar_tickMarkTint:I

.field public static AppCompatSeekBar_tickMarkTintMode:I

.field public static final AppCompatTextHelper:[I

.field public static AppCompatTextHelper_android_drawableBottom:I

.field public static AppCompatTextHelper_android_drawableEnd:I

.field public static AppCompatTextHelper_android_drawableLeft:I

.field public static AppCompatTextHelper_android_drawableRight:I

.field public static AppCompatTextHelper_android_drawableStart:I

.field public static AppCompatTextHelper_android_drawableTop:I

.field public static AppCompatTextHelper_android_textAppearance:I

.field public static final AppCompatTextView:[I

.field public static AppCompatTextView_android_textAppearance:I

.field public static AppCompatTextView_autoSizeMaxTextSize:I

.field public static AppCompatTextView_autoSizeMinTextSize:I

.field public static AppCompatTextView_autoSizePresetSizes:I

.field public static AppCompatTextView_autoSizeStepGranularity:I

.field public static AppCompatTextView_autoSizeTextType:I

.field public static AppCompatTextView_drawableBottomCompat:I

.field public static AppCompatTextView_drawableEndCompat:I

.field public static AppCompatTextView_drawableLeftCompat:I

.field public static AppCompatTextView_drawableRightCompat:I

.field public static AppCompatTextView_drawableStartCompat:I

.field public static AppCompatTextView_drawableTint:I

.field public static AppCompatTextView_drawableTintMode:I

.field public static AppCompatTextView_drawableTopCompat:I

.field public static AppCompatTextView_emojiCompatEnabled:I

.field public static AppCompatTextView_firstBaselineToTopHeight:I

.field public static AppCompatTextView_fontFamily:I

.field public static AppCompatTextView_fontVariationSettings:I

.field public static AppCompatTextView_lastBaselineToBottomHeight:I

.field public static AppCompatTextView_lineHeight:I

.field public static AppCompatTextView_textAllCaps:I

.field public static AppCompatTextView_textLocale:I

.field public static final AppCompatTheme:[I

.field public static AppCompatTheme_actionBarDivider:I

.field public static AppCompatTheme_actionBarItemBackground:I

.field public static AppCompatTheme_actionBarPopupTheme:I

.field public static AppCompatTheme_actionBarSize:I

.field public static AppCompatTheme_actionBarSplitStyle:I

.field public static AppCompatTheme_actionBarStyle:I

.field public static AppCompatTheme_actionBarTabBarStyle:I

.field public static AppCompatTheme_actionBarTabStyle:I

.field public static AppCompatTheme_actionBarTabTextStyle:I

.field public static AppCompatTheme_actionBarTheme:I

.field public static AppCompatTheme_actionBarWidgetTheme:I

.field public static AppCompatTheme_actionButtonStyle:I

.field public static AppCompatTheme_actionDropDownStyle:I

.field public static AppCompatTheme_actionMenuTextAppearance:I

.field public static AppCompatTheme_actionMenuTextColor:I

.field public static AppCompatTheme_actionModeBackground:I

.field public static AppCompatTheme_actionModeCloseButtonStyle:I

.field public static AppCompatTheme_actionModeCloseContentDescription:I

.field public static AppCompatTheme_actionModeCloseDrawable:I

.field public static AppCompatTheme_actionModeCopyDrawable:I

.field public static AppCompatTheme_actionModeCutDrawable:I

.field public static AppCompatTheme_actionModeFindDrawable:I

.field public static AppCompatTheme_actionModePasteDrawable:I

.field public static AppCompatTheme_actionModePopupWindowStyle:I

.field public static AppCompatTheme_actionModeSelectAllDrawable:I

.field public static AppCompatTheme_actionModeShareDrawable:I

.field public static AppCompatTheme_actionModeSplitBackground:I

.field public static AppCompatTheme_actionModeStyle:I

.field public static AppCompatTheme_actionModeTheme:I

.field public static AppCompatTheme_actionModeWebSearchDrawable:I

.field public static AppCompatTheme_actionOverflowButtonStyle:I

.field public static AppCompatTheme_actionOverflowMenuStyle:I

.field public static AppCompatTheme_activityChooserViewStyle:I

.field public static AppCompatTheme_alertDialogButtonGroupStyle:I

.field public static AppCompatTheme_alertDialogCenterButtons:I

.field public static AppCompatTheme_alertDialogStyle:I

.field public static AppCompatTheme_alertDialogTheme:I

.field public static AppCompatTheme_android_windowAnimationStyle:I

.field public static AppCompatTheme_android_windowIsFloating:I

.field public static AppCompatTheme_autoCompleteTextViewStyle:I

.field public static AppCompatTheme_borderlessButtonStyle:I

.field public static AppCompatTheme_buttonBarButtonStyle:I

.field public static AppCompatTheme_buttonBarNegativeButtonStyle:I

.field public static AppCompatTheme_buttonBarNeutralButtonStyle:I

.field public static AppCompatTheme_buttonBarPositiveButtonStyle:I

.field public static AppCompatTheme_buttonBarStyle:I

.field public static AppCompatTheme_buttonStyle:I

.field public static AppCompatTheme_buttonStyleSmall:I

.field public static AppCompatTheme_checkboxStyle:I

.field public static AppCompatTheme_checkedTextViewStyle:I

.field public static AppCompatTheme_colorAccent:I

.field public static AppCompatTheme_colorBackgroundFloating:I

.field public static AppCompatTheme_colorButtonNormal:I

.field public static AppCompatTheme_colorControlActivated:I

.field public static AppCompatTheme_colorControlHighlight:I

.field public static AppCompatTheme_colorControlNormal:I

.field public static AppCompatTheme_colorError:I

.field public static AppCompatTheme_colorPrimary:I

.field public static AppCompatTheme_colorPrimaryDark:I

.field public static AppCompatTheme_colorSwitchThumbNormal:I

.field public static AppCompatTheme_controlBackground:I

.field public static AppCompatTheme_dialogCornerRadius:I

.field public static AppCompatTheme_dialogPreferredPadding:I

.field public static AppCompatTheme_dialogTheme:I

.field public static AppCompatTheme_dividerHorizontal:I

.field public static AppCompatTheme_dividerVertical:I

.field public static AppCompatTheme_dropDownListViewStyle:I

.field public static AppCompatTheme_dropdownListPreferredItemHeight:I

.field public static AppCompatTheme_editTextBackground:I

.field public static AppCompatTheme_editTextColor:I

.field public static AppCompatTheme_editTextStyle:I

.field public static AppCompatTheme_homeAsUpIndicator:I

.field public static AppCompatTheme_imageButtonStyle:I

.field public static AppCompatTheme_listChoiceBackgroundIndicator:I

.field public static AppCompatTheme_listChoiceIndicatorMultipleAnimated:I

.field public static AppCompatTheme_listChoiceIndicatorSingleAnimated:I

.field public static AppCompatTheme_listDividerAlertDialog:I

.field public static AppCompatTheme_listMenuViewStyle:I

.field public static AppCompatTheme_listPopupWindowStyle:I

.field public static AppCompatTheme_listPreferredItemHeight:I

.field public static AppCompatTheme_listPreferredItemHeightLarge:I

.field public static AppCompatTheme_listPreferredItemHeightSmall:I

.field public static AppCompatTheme_listPreferredItemPaddingEnd:I

.field public static AppCompatTheme_listPreferredItemPaddingLeft:I

.field public static AppCompatTheme_listPreferredItemPaddingRight:I

.field public static AppCompatTheme_listPreferredItemPaddingStart:I

.field public static AppCompatTheme_panelBackground:I

.field public static AppCompatTheme_panelMenuListTheme:I

.field public static AppCompatTheme_panelMenuListWidth:I

.field public static AppCompatTheme_popupMenuStyle:I

.field public static AppCompatTheme_popupWindowStyle:I

.field public static AppCompatTheme_radioButtonStyle:I

.field public static AppCompatTheme_ratingBarStyle:I

.field public static AppCompatTheme_ratingBarStyleIndicator:I

.field public static AppCompatTheme_ratingBarStyleSmall:I

.field public static AppCompatTheme_searchViewStyle:I

.field public static AppCompatTheme_seekBarStyle:I

.field public static AppCompatTheme_selectableItemBackground:I

.field public static AppCompatTheme_selectableItemBackgroundBorderless:I

.field public static AppCompatTheme_spinnerDropDownItemStyle:I

.field public static AppCompatTheme_spinnerStyle:I

.field public static AppCompatTheme_switchStyle:I

.field public static AppCompatTheme_textAppearanceLargePopupMenu:I

.field public static AppCompatTheme_textAppearanceListItem:I

.field public static AppCompatTheme_textAppearanceListItemSecondary:I

.field public static AppCompatTheme_textAppearanceListItemSmall:I

.field public static AppCompatTheme_textAppearancePopupMenuHeader:I

.field public static AppCompatTheme_textAppearanceSearchResultSubtitle:I

.field public static AppCompatTheme_textAppearanceSearchResultTitle:I

.field public static AppCompatTheme_textAppearanceSmallPopupMenu:I

.field public static AppCompatTheme_textColorAlertDialogListItem:I

.field public static AppCompatTheme_textColorSearchUrl:I

.field public static AppCompatTheme_toolbarNavigationButtonStyle:I

.field public static AppCompatTheme_toolbarStyle:I

.field public static AppCompatTheme_tooltipForegroundColor:I

.field public static AppCompatTheme_tooltipFrameBackground:I

.field public static AppCompatTheme_viewInflaterClass:I

.field public static AppCompatTheme_windowActionBar:I

.field public static AppCompatTheme_windowActionBarOverlay:I

.field public static AppCompatTheme_windowActionModeOverlay:I

.field public static AppCompatTheme_windowFixedHeightMajor:I

.field public static AppCompatTheme_windowFixedHeightMinor:I

.field public static AppCompatTheme_windowFixedWidthMajor:I

.field public static AppCompatTheme_windowFixedWidthMinor:I

.field public static AppCompatTheme_windowMinWidthMajor:I

.field public static AppCompatTheme_windowMinWidthMinor:I

.field public static AppCompatTheme_windowNoTitle:I

.field public static final ArrowTipView:[I

.field public static ArrowTipView_arrowTipBackground:I

.field public static ArrowTipView_arrowTipTextColor:I

.field public static final BackgroundStyle:[I

.field public static BackgroundStyle_android_selectableItemBackground:I

.field public static BackgroundStyle_selectableItemBackground:I

.field public static final Badge:[I

.field public static Badge_autoAdjustToWithinGrandparentBounds:I

.field public static Badge_backgroundColor:I

.field public static Badge_badgeFixedEdge:I

.field public static Badge_badgeGravity:I

.field public static Badge_badgeHeight:I

.field public static Badge_badgeRadius:I

.field public static Badge_badgeShapeAppearance:I

.field public static Badge_badgeShapeAppearanceOverlay:I

.field public static Badge_badgeText:I

.field public static Badge_badgeTextAppearance:I

.field public static Badge_badgeTextColor:I

.field public static Badge_badgeVerticalPadding:I

.field public static Badge_badgeWidePadding:I

.field public static Badge_badgeWidth:I

.field public static Badge_badgeWithTextHeight:I

.field public static Badge_badgeWithTextRadius:I

.field public static Badge_badgeWithTextShapeAppearance:I

.field public static Badge_badgeWithTextShapeAppearanceOverlay:I

.field public static Badge_badgeWithTextWidth:I

.field public static Badge_horizontalOffset:I

.field public static Badge_horizontalOffsetWithText:I

.field public static Badge_largeFontVerticalOffsetAdjustment:I

.field public static Badge_maxCharacterCount:I

.field public static Badge_maxNumber:I

.field public static Badge_number:I

.field public static Badge_offsetAlignmentMode:I

.field public static Badge_verticalOffset:I

.field public static Badge_verticalOffsetWithText:I

.field public static final BaseProgressIndicator:[I

.field public static BaseProgressIndicator_android_indeterminate:I

.field public static BaseProgressIndicator_hideAnimationBehavior:I

.field public static BaseProgressIndicator_indeterminateAnimatorDurationScale:I

.field public static BaseProgressIndicator_indicatorColor:I

.field public static BaseProgressIndicator_indicatorTrackGapSize:I

.field public static BaseProgressIndicator_minHideDelay:I

.field public static BaseProgressIndicator_showAnimationBehavior:I

.field public static BaseProgressIndicator_showDelay:I

.field public static BaseProgressIndicator_trackColor:I

.field public static BaseProgressIndicator_trackCornerRadius:I

.field public static BaseProgressIndicator_trackThickness:I

.field public static BaseProgressIndicator_waveAmplitude:I

.field public static BaseProgressIndicator_waveSpeed:I

.field public static BaseProgressIndicator_wavelength:I

.field public static BaseProgressIndicator_wavelengthDeterminate:I

.field public static BaseProgressIndicator_wavelengthIndeterminate:I

.field public static final BottomAppBar:[I

.field public static BottomAppBar_addElevationShadow:I

.field public static BottomAppBar_backgroundTint:I

.field public static BottomAppBar_elevation:I

.field public static BottomAppBar_fabAlignmentMode:I

.field public static BottomAppBar_fabAlignmentModeEndMargin:I

.field public static BottomAppBar_fabAnchorMode:I

.field public static BottomAppBar_fabAnimationMode:I

.field public static BottomAppBar_fabCradleMargin:I

.field public static BottomAppBar_fabCradleRoundedCornerRadius:I

.field public static BottomAppBar_fabCradleVerticalOffset:I

.field public static BottomAppBar_hideOnScroll:I

.field public static BottomAppBar_menuAlignmentMode:I

.field public static BottomAppBar_navigationIconTint:I

.field public static BottomAppBar_paddingBottomSystemWindowInsets:I

.field public static BottomAppBar_paddingLeftSystemWindowInsets:I

.field public static BottomAppBar_paddingRightSystemWindowInsets:I

.field public static BottomAppBar_removeEmbeddedFabElevation:I

.field public static final BottomNavigationView:[I

.field public static BottomNavigationView_android_minHeight:I

.field public static BottomNavigationView_compatShadowEnabled:I

.field public static BottomNavigationView_itemHorizontalTranslationEnabled:I

.field public static BottomNavigationView_shapeAppearance:I

.field public static BottomNavigationView_shapeAppearanceOverlay:I

.field public static final BottomSheetBehavior_Layout:[I

.field public static BottomSheetBehavior_Layout_android_elevation:I

.field public static BottomSheetBehavior_Layout_android_maxHeight:I

.field public static BottomSheetBehavior_Layout_android_maxWidth:I

.field public static BottomSheetBehavior_Layout_backgroundTint:I

.field public static BottomSheetBehavior_Layout_behavior_draggable:I

.field public static BottomSheetBehavior_Layout_behavior_draggableOnNestedScroll:I

.field public static BottomSheetBehavior_Layout_behavior_expandedOffset:I

.field public static BottomSheetBehavior_Layout_behavior_fitToContents:I

.field public static BottomSheetBehavior_Layout_behavior_halfExpandedRatio:I

.field public static BottomSheetBehavior_Layout_behavior_hideable:I

.field public static BottomSheetBehavior_Layout_behavior_peekHeight:I

.field public static BottomSheetBehavior_Layout_behavior_saveFlags:I

.field public static BottomSheetBehavior_Layout_behavior_significantVelocityThreshold:I

.field public static BottomSheetBehavior_Layout_behavior_skipCollapsed:I

.field public static BottomSheetBehavior_Layout_gestureInsetBottomIgnored:I

.field public static BottomSheetBehavior_Layout_marginLeftSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_marginRightSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_marginTopSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_paddingBottomSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_paddingLeftSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_paddingRightSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_paddingTopSystemWindowInsets:I

.field public static BottomSheetBehavior_Layout_shapeAppearance:I

.field public static BottomSheetBehavior_Layout_shapeAppearanceOverlay:I

.field public static BottomSheetBehavior_Layout_shouldRemoveExpandedCorners:I

.field public static final BubbleTextView:[I

.field public static BubbleTextView_centerVertically:I

.field public static BubbleTextView_iconDisplay:I

.field public static BubbleTextView_iconSizeOverride:I

.field public static BubbleTextView_layoutHorizontal:I

.field public static final ButtonBarLayout:[I

.field public static ButtonBarLayout_allowStacking:I

.field public static final Capability:[I

.field public static Capability_queryPatterns:I

.field public static Capability_shortcutMatchRequired:I

.field public static final CardView:[I

.field public static CardView_android_minHeight:I

.field public static CardView_android_minWidth:I

.field public static CardView_cardBackgroundColor:I

.field public static CardView_cardCornerRadius:I

.field public static CardView_cardElevation:I

.field public static CardView_cardMaxElevation:I

.field public static CardView_cardPreventCornerOverlap:I

.field public static CardView_cardUseCompatPadding:I

.field public static CardView_contentPadding:I

.field public static CardView_contentPaddingBottom:I

.field public static CardView_contentPaddingLeft:I

.field public static CardView_contentPaddingRight:I

.field public static CardView_contentPaddingTop:I

.field public static final Carousel:[I

.field public static Carousel_carousel_alignment:I

.field public static Carousel_carousel_backwardTransition:I

.field public static Carousel_carousel_emptyViewsBehavior:I

.field public static Carousel_carousel_firstView:I

.field public static Carousel_carousel_forwardTransition:I

.field public static Carousel_carousel_infinite:I

.field public static Carousel_carousel_nextState:I

.field public static Carousel_carousel_previousState:I

.field public static Carousel_carousel_touchUpMode:I

.field public static Carousel_carousel_touchUp_dampeningFactor:I

.field public static Carousel_carousel_touchUp_velocityThreshold:I

.field public static final CellLayout:[I

.field public static CellLayout_containerType:I

.field public static final CellSpec:[I

.field public static CellSpec_dimensionType:I

.field public static CellSpec_maxAvailableSize:I

.field public static final CellStyle:[I

.field public static CellStyle_iconDrawablePadding:I

.field public static final CheckBoxPreference:[I

.field public static CheckBoxPreference_android_disableDependentsState:I

.field public static CheckBoxPreference_android_summaryOff:I

.field public static CheckBoxPreference_android_summaryOn:I

.field public static CheckBoxPreference_disableDependentsState:I

.field public static CheckBoxPreference_summaryOff:I

.field public static CheckBoxPreference_summaryOn:I

.field public static final CheckedTextView:[I

.field public static CheckedTextView_android_checkMark:I

.field public static CheckedTextView_checkMarkCompat:I

.field public static CheckedTextView_checkMarkTint:I

.field public static CheckedTextView_checkMarkTintMode:I

.field public static final Chip:[I

.field public static final ChipGroup:[I

.field public static ChipGroup_checkedChip:I

.field public static ChipGroup_chipSpacing:I

.field public static ChipGroup_chipSpacingHorizontal:I

.field public static ChipGroup_chipSpacingVertical:I

.field public static ChipGroup_selectionRequired:I

.field public static ChipGroup_singleLine:I

.field public static ChipGroup_singleSelection:I

.field public static Chip_android_checkable:I

.field public static Chip_android_ellipsize:I

.field public static Chip_android_maxWidth:I

.field public static Chip_android_text:I

.field public static Chip_android_textAppearance:I

.field public static Chip_android_textColor:I

.field public static Chip_android_textSize:I

.field public static Chip_checkedIcon:I

.field public static Chip_checkedIconEnabled:I

.field public static Chip_checkedIconTint:I

.field public static Chip_checkedIconVisible:I

.field public static Chip_chipBackgroundColor:I

.field public static Chip_chipCornerRadius:I

.field public static Chip_chipEndPadding:I

.field public static Chip_chipIcon:I

.field public static Chip_chipIconEnabled:I

.field public static Chip_chipIconSize:I

.field public static Chip_chipIconTint:I

.field public static Chip_chipIconVisible:I

.field public static Chip_chipMinHeight:I

.field public static Chip_chipMinTouchTargetSize:I

.field public static Chip_chipStartPadding:I

.field public static Chip_chipStrokeColor:I

.field public static Chip_chipStrokeWidth:I

.field public static Chip_chipSurfaceColor:I

.field public static Chip_closeIcon:I

.field public static Chip_closeIconEnabled:I

.field public static Chip_closeIconEndPadding:I

.field public static Chip_closeIconSize:I

.field public static Chip_closeIconStartPadding:I

.field public static Chip_closeIconTint:I

.field public static Chip_closeIconVisible:I

.field public static Chip_ensureMinTouchTargetSize:I

.field public static Chip_hideMotionSpec:I

.field public static Chip_iconEndPadding:I

.field public static Chip_iconStartPadding:I

.field public static Chip_rippleColor:I

.field public static Chip_shapeAppearance:I

.field public static Chip_shapeAppearanceOverlay:I

.field public static Chip_showMotionSpec:I

.field public static Chip_textEndPadding:I

.field public static Chip_textStartPadding:I

.field public static final CircularProgressIndicator:[I

.field public static CircularProgressIndicator_indeterminateAnimationTypeCircular:I

.field public static CircularProgressIndicator_indeterminateTrackVisible:I

.field public static CircularProgressIndicator_indicatorDirectionCircular:I

.field public static CircularProgressIndicator_indicatorInset:I

.field public static CircularProgressIndicator_indicatorSize:I

.field public static final ClearAllButton:[I

.field public static ClearAllButton_focusBorderColor:I

.field public static final ClockFaceView:[I

.field public static ClockFaceView_clockFaceBackgroundColor:I

.field public static ClockFaceView_clockNumberTextColor:I

.field public static final ClockHandView:[I

.field public static ClockHandView_clockHandColor:I

.field public static ClockHandView_materialCircleRadius:I

.field public static ClockHandView_selectorSize:I

.field public static final CollapsableTextView:[I

.field public static CollapsableTextView_android_gravity:I

.field public static CollapsableTextView_android_minLines:I

.field public static CollapsableTextView_isCollapsable:I

.field public static final CollapsingToolbarLayout:[I

.field public static final CollapsingToolbarLayout_Layout:[I

.field public static CollapsingToolbarLayout_Layout_layout_collapseMode:I

.field public static CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier:I

.field public static CollapsingToolbarLayout_collapsedTitleGravity:I

.field public static CollapsingToolbarLayout_collapsedTitleTextAppearance:I

.field public static CollapsingToolbarLayout_collapsedTitleTextColor:I

.field public static CollapsingToolbarLayout_contentScrim:I

.field public static CollapsingToolbarLayout_expandedTitleGravity:I

.field public static CollapsingToolbarLayout_expandedTitleMargin:I

.field public static CollapsingToolbarLayout_expandedTitleMarginBottom:I

.field public static CollapsingToolbarLayout_expandedTitleMarginEnd:I

.field public static CollapsingToolbarLayout_expandedTitleMarginStart:I

.field public static CollapsingToolbarLayout_expandedTitleMarginTop:I

.field public static CollapsingToolbarLayout_expandedTitleTextAppearance:I

.field public static CollapsingToolbarLayout_expandedTitleTextColor:I

.field public static CollapsingToolbarLayout_extraMultilineHeightEnabled:I

.field public static CollapsingToolbarLayout_forceApplySystemWindowInsetTop:I

.field public static CollapsingToolbarLayout_maxLines:I

.field public static CollapsingToolbarLayout_scrimAnimationDuration:I

.field public static CollapsingToolbarLayout_scrimVisibleHeightTrigger:I

.field public static CollapsingToolbarLayout_statusBarScrim:I

.field public static CollapsingToolbarLayout_title:I

.field public static CollapsingToolbarLayout_titleCollapseMode:I

.field public static CollapsingToolbarLayout_titleEnabled:I

.field public static CollapsingToolbarLayout_titlePositionInterpolator:I

.field public static CollapsingToolbarLayout_titleTextEllipsize:I

.field public static CollapsingToolbarLayout_toolbarId:I

.field public static final ColorStateListItem:[I

.field public static ColorStateListItem_alpha:I

.field public static ColorStateListItem_android_alpha:I

.field public static ColorStateListItem_android_color:I

.field public static ColorStateListItem_android_lStar:I

.field public static ColorStateListItem_lStar:I

.field public static final CompoundButton:[I

.field public static CompoundButton_android_button:I

.field public static CompoundButton_buttonCompat:I

.field public static CompoundButton_buttonTint:I

.field public static CompoundButton_buttonTintMode:I

.field public static final Constraint:[I

.field public static final ConstraintLayout_Layout:[I

.field public static ConstraintLayout_Layout_android_elevation:I

.field public static ConstraintLayout_Layout_android_layout_height:I

.field public static ConstraintLayout_Layout_android_layout_margin:I

.field public static ConstraintLayout_Layout_android_layout_marginBottom:I

.field public static ConstraintLayout_Layout_android_layout_marginEnd:I

.field public static ConstraintLayout_Layout_android_layout_marginHorizontal:I

.field public static ConstraintLayout_Layout_android_layout_marginLeft:I

.field public static ConstraintLayout_Layout_android_layout_marginRight:I

.field public static ConstraintLayout_Layout_android_layout_marginStart:I

.field public static ConstraintLayout_Layout_android_layout_marginTop:I

.field public static ConstraintLayout_Layout_android_layout_marginVertical:I

.field public static ConstraintLayout_Layout_android_layout_width:I

.field public static ConstraintLayout_Layout_android_maxHeight:I

.field public static ConstraintLayout_Layout_android_maxWidth:I

.field public static ConstraintLayout_Layout_android_minHeight:I

.field public static ConstraintLayout_Layout_android_minWidth:I

.field public static ConstraintLayout_Layout_android_orientation:I

.field public static ConstraintLayout_Layout_android_padding:I

.field public static ConstraintLayout_Layout_android_paddingBottom:I

.field public static ConstraintLayout_Layout_android_paddingEnd:I

.field public static ConstraintLayout_Layout_android_paddingLeft:I

.field public static ConstraintLayout_Layout_android_paddingRight:I

.field public static ConstraintLayout_Layout_android_paddingStart:I

.field public static ConstraintLayout_Layout_android_paddingTop:I

.field public static ConstraintLayout_Layout_android_visibility:I

.field public static ConstraintLayout_Layout_barrierAllowsGoneWidgets:I

.field public static ConstraintLayout_Layout_barrierDirection:I

.field public static ConstraintLayout_Layout_barrierMargin:I

.field public static ConstraintLayout_Layout_chainUseRtl:I

.field public static ConstraintLayout_Layout_circularflow_angles:I

.field public static ConstraintLayout_Layout_circularflow_defaultAngle:I

.field public static ConstraintLayout_Layout_circularflow_defaultRadius:I

.field public static ConstraintLayout_Layout_circularflow_radiusInDP:I

.field public static ConstraintLayout_Layout_circularflow_viewCenter:I

.field public static ConstraintLayout_Layout_constraintSet:I

.field public static ConstraintLayout_Layout_constraint_referenced_ids:I

.field public static ConstraintLayout_Layout_constraint_referenced_tags:I

.field public static ConstraintLayout_Layout_flow_firstHorizontalBias:I

.field public static ConstraintLayout_Layout_flow_firstHorizontalStyle:I

.field public static ConstraintLayout_Layout_flow_firstVerticalBias:I

.field public static ConstraintLayout_Layout_flow_firstVerticalStyle:I

.field public static ConstraintLayout_Layout_flow_horizontalAlign:I

.field public static ConstraintLayout_Layout_flow_horizontalBias:I

.field public static ConstraintLayout_Layout_flow_horizontalGap:I

.field public static ConstraintLayout_Layout_flow_horizontalStyle:I

.field public static ConstraintLayout_Layout_flow_lastHorizontalBias:I

.field public static ConstraintLayout_Layout_flow_lastHorizontalStyle:I

.field public static ConstraintLayout_Layout_flow_lastVerticalBias:I

.field public static ConstraintLayout_Layout_flow_lastVerticalStyle:I

.field public static ConstraintLayout_Layout_flow_maxElementsWrap:I

.field public static ConstraintLayout_Layout_flow_verticalAlign:I

.field public static ConstraintLayout_Layout_flow_verticalBias:I

.field public static ConstraintLayout_Layout_flow_verticalGap:I

.field public static ConstraintLayout_Layout_flow_verticalStyle:I

.field public static ConstraintLayout_Layout_flow_wrapMode:I

.field public static ConstraintLayout_Layout_guidelineUseRtl:I

.field public static ConstraintLayout_Layout_layoutDescription:I

.field public static ConstraintLayout_Layout_layout_constrainedHeight:I

.field public static ConstraintLayout_Layout_layout_constrainedWidth:I

.field public static ConstraintLayout_Layout_layout_constraintBaseline_creator:I

.field public static ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf:I

.field public static ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf:I

.field public static ConstraintLayout_Layout_layout_constraintBaseline_toTopOf:I

.field public static ConstraintLayout_Layout_layout_constraintBottom_creator:I

.field public static ConstraintLayout_Layout_layout_constraintBottom_toBottomOf:I

.field public static ConstraintLayout_Layout_layout_constraintBottom_toTopOf:I

.field public static ConstraintLayout_Layout_layout_constraintCircle:I

.field public static ConstraintLayout_Layout_layout_constraintCircleAngle:I

.field public static ConstraintLayout_Layout_layout_constraintCircleRadius:I

.field public static ConstraintLayout_Layout_layout_constraintDimensionRatio:I

.field public static ConstraintLayout_Layout_layout_constraintEnd_toEndOf:I

.field public static ConstraintLayout_Layout_layout_constraintEnd_toStartOf:I

.field public static ConstraintLayout_Layout_layout_constraintGuide_begin:I

.field public static ConstraintLayout_Layout_layout_constraintGuide_end:I

.field public static ConstraintLayout_Layout_layout_constraintGuide_percent:I

.field public static ConstraintLayout_Layout_layout_constraintHeight:I

.field public static ConstraintLayout_Layout_layout_constraintHeight_default:I

.field public static ConstraintLayout_Layout_layout_constraintHeight_max:I

.field public static ConstraintLayout_Layout_layout_constraintHeight_min:I

.field public static ConstraintLayout_Layout_layout_constraintHeight_percent:I

.field public static ConstraintLayout_Layout_layout_constraintHorizontal_bias:I

.field public static ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle:I

.field public static ConstraintLayout_Layout_layout_constraintHorizontal_weight:I

.field public static ConstraintLayout_Layout_layout_constraintLeft_creator:I

.field public static ConstraintLayout_Layout_layout_constraintLeft_toLeftOf:I

.field public static ConstraintLayout_Layout_layout_constraintLeft_toRightOf:I

.field public static ConstraintLayout_Layout_layout_constraintRight_creator:I

.field public static ConstraintLayout_Layout_layout_constraintRight_toLeftOf:I

.field public static ConstraintLayout_Layout_layout_constraintRight_toRightOf:I

.field public static ConstraintLayout_Layout_layout_constraintStart_toEndOf:I

.field public static ConstraintLayout_Layout_layout_constraintStart_toStartOf:I

.field public static ConstraintLayout_Layout_layout_constraintTag:I

.field public static ConstraintLayout_Layout_layout_constraintTop_creator:I

.field public static ConstraintLayout_Layout_layout_constraintTop_toBottomOf:I

.field public static ConstraintLayout_Layout_layout_constraintTop_toTopOf:I

.field public static ConstraintLayout_Layout_layout_constraintVertical_bias:I

.field public static ConstraintLayout_Layout_layout_constraintVertical_chainStyle:I

.field public static ConstraintLayout_Layout_layout_constraintVertical_weight:I

.field public static ConstraintLayout_Layout_layout_constraintWidth:I

.field public static ConstraintLayout_Layout_layout_constraintWidth_default:I

.field public static ConstraintLayout_Layout_layout_constraintWidth_max:I

.field public static ConstraintLayout_Layout_layout_constraintWidth_min:I

.field public static ConstraintLayout_Layout_layout_constraintWidth_percent:I

.field public static ConstraintLayout_Layout_layout_editor_absoluteX:I

.field public static ConstraintLayout_Layout_layout_editor_absoluteY:I

.field public static ConstraintLayout_Layout_layout_goneMarginBaseline:I

.field public static ConstraintLayout_Layout_layout_goneMarginBottom:I

.field public static ConstraintLayout_Layout_layout_goneMarginEnd:I

.field public static ConstraintLayout_Layout_layout_goneMarginLeft:I

.field public static ConstraintLayout_Layout_layout_goneMarginRight:I

.field public static ConstraintLayout_Layout_layout_goneMarginStart:I

.field public static ConstraintLayout_Layout_layout_goneMarginTop:I

.field public static ConstraintLayout_Layout_layout_marginBaseline:I

.field public static ConstraintLayout_Layout_layout_optimizationLevel:I

.field public static ConstraintLayout_Layout_layout_wrapBehaviorInParent:I

.field public static final ConstraintLayout_ReactiveGuide:[I

.field public static ConstraintLayout_ReactiveGuide_reactiveGuide_animateChange:I

.field public static ConstraintLayout_ReactiveGuide_reactiveGuide_applyToAllConstraintSets:I

.field public static ConstraintLayout_ReactiveGuide_reactiveGuide_applyToConstraintSet:I

.field public static ConstraintLayout_ReactiveGuide_reactiveGuide_valueId:I

.field public static final ConstraintLayout_placeholder:[I

.field public static ConstraintLayout_placeholder_content:I

.field public static ConstraintLayout_placeholder_placeholder_emptyVisibility:I

.field public static final ConstraintOverride:[I

.field public static ConstraintOverride_android_alpha:I

.field public static ConstraintOverride_android_elevation:I

.field public static ConstraintOverride_android_id:I

.field public static ConstraintOverride_android_layout_height:I

.field public static ConstraintOverride_android_layout_marginBottom:I

.field public static ConstraintOverride_android_layout_marginEnd:I

.field public static ConstraintOverride_android_layout_marginLeft:I

.field public static ConstraintOverride_android_layout_marginRight:I

.field public static ConstraintOverride_android_layout_marginStart:I

.field public static ConstraintOverride_android_layout_marginTop:I

.field public static ConstraintOverride_android_layout_width:I

.field public static ConstraintOverride_android_maxHeight:I

.field public static ConstraintOverride_android_maxWidth:I

.field public static ConstraintOverride_android_minHeight:I

.field public static ConstraintOverride_android_minWidth:I

.field public static ConstraintOverride_android_orientation:I

.field public static ConstraintOverride_android_rotation:I

.field public static ConstraintOverride_android_rotationX:I

.field public static ConstraintOverride_android_rotationY:I

.field public static ConstraintOverride_android_scaleX:I

.field public static ConstraintOverride_android_scaleY:I

.field public static ConstraintOverride_android_transformPivotX:I

.field public static ConstraintOverride_android_transformPivotY:I

.field public static ConstraintOverride_android_translationX:I

.field public static ConstraintOverride_android_translationY:I

.field public static ConstraintOverride_android_translationZ:I

.field public static ConstraintOverride_android_visibility:I

.field public static ConstraintOverride_animateCircleAngleTo:I

.field public static ConstraintOverride_animateRelativeTo:I

.field public static ConstraintOverride_barrierAllowsGoneWidgets:I

.field public static ConstraintOverride_barrierDirection:I

.field public static ConstraintOverride_barrierMargin:I

.field public static ConstraintOverride_chainUseRtl:I

.field public static ConstraintOverride_constraint_referenced_ids:I

.field public static ConstraintOverride_drawPath:I

.field public static ConstraintOverride_flow_firstHorizontalBias:I

.field public static ConstraintOverride_flow_firstHorizontalStyle:I

.field public static ConstraintOverride_flow_firstVerticalBias:I

.field public static ConstraintOverride_flow_firstVerticalStyle:I

.field public static ConstraintOverride_flow_horizontalAlign:I

.field public static ConstraintOverride_flow_horizontalBias:I

.field public static ConstraintOverride_flow_horizontalGap:I

.field public static ConstraintOverride_flow_horizontalStyle:I

.field public static ConstraintOverride_flow_lastHorizontalBias:I

.field public static ConstraintOverride_flow_lastHorizontalStyle:I

.field public static ConstraintOverride_flow_lastVerticalBias:I

.field public static ConstraintOverride_flow_lastVerticalStyle:I

.field public static ConstraintOverride_flow_maxElementsWrap:I

.field public static ConstraintOverride_flow_verticalAlign:I

.field public static ConstraintOverride_flow_verticalBias:I

.field public static ConstraintOverride_flow_verticalGap:I

.field public static ConstraintOverride_flow_verticalStyle:I

.field public static ConstraintOverride_flow_wrapMode:I

.field public static ConstraintOverride_guidelineUseRtl:I

.field public static ConstraintOverride_layout_constrainedHeight:I

.field public static ConstraintOverride_layout_constrainedWidth:I

.field public static ConstraintOverride_layout_constraintBaseline_creator:I

.field public static ConstraintOverride_layout_constraintBottom_creator:I

.field public static ConstraintOverride_layout_constraintCircleAngle:I

.field public static ConstraintOverride_layout_constraintCircleRadius:I

.field public static ConstraintOverride_layout_constraintDimensionRatio:I

.field public static ConstraintOverride_layout_constraintGuide_begin:I

.field public static ConstraintOverride_layout_constraintGuide_end:I

.field public static ConstraintOverride_layout_constraintGuide_percent:I

.field public static ConstraintOverride_layout_constraintHeight:I

.field public static ConstraintOverride_layout_constraintHeight_default:I

.field public static ConstraintOverride_layout_constraintHeight_max:I

.field public static ConstraintOverride_layout_constraintHeight_min:I

.field public static ConstraintOverride_layout_constraintHeight_percent:I

.field public static ConstraintOverride_layout_constraintHorizontal_bias:I

.field public static ConstraintOverride_layout_constraintHorizontal_chainStyle:I

.field public static ConstraintOverride_layout_constraintHorizontal_weight:I

.field public static ConstraintOverride_layout_constraintLeft_creator:I

.field public static ConstraintOverride_layout_constraintRight_creator:I

.field public static ConstraintOverride_layout_constraintTag:I

.field public static ConstraintOverride_layout_constraintTop_creator:I

.field public static ConstraintOverride_layout_constraintVertical_bias:I

.field public static ConstraintOverride_layout_constraintVertical_chainStyle:I

.field public static ConstraintOverride_layout_constraintVertical_weight:I

.field public static ConstraintOverride_layout_constraintWidth:I

.field public static ConstraintOverride_layout_constraintWidth_default:I

.field public static ConstraintOverride_layout_constraintWidth_max:I

.field public static ConstraintOverride_layout_constraintWidth_min:I

.field public static ConstraintOverride_layout_constraintWidth_percent:I

.field public static ConstraintOverride_layout_editor_absoluteX:I

.field public static ConstraintOverride_layout_editor_absoluteY:I

.field public static ConstraintOverride_layout_goneMarginBaseline:I

.field public static ConstraintOverride_layout_goneMarginBottom:I

.field public static ConstraintOverride_layout_goneMarginEnd:I

.field public static ConstraintOverride_layout_goneMarginLeft:I

.field public static ConstraintOverride_layout_goneMarginRight:I

.field public static ConstraintOverride_layout_goneMarginStart:I

.field public static ConstraintOverride_layout_goneMarginTop:I

.field public static ConstraintOverride_layout_marginBaseline:I

.field public static ConstraintOverride_layout_wrapBehaviorInParent:I

.field public static ConstraintOverride_motionProgress:I

.field public static ConstraintOverride_motionStagger:I

.field public static ConstraintOverride_motionTarget:I

.field public static ConstraintOverride_pathMotionArc:I

.field public static ConstraintOverride_pivotAnchor:I

.field public static ConstraintOverride_polarRelativeTo:I

.field public static ConstraintOverride_quantizeMotionInterpolator:I

.field public static ConstraintOverride_quantizeMotionPhase:I

.field public static ConstraintOverride_quantizeMotionSteps:I

.field public static ConstraintOverride_transformPivotTarget:I

.field public static ConstraintOverride_transitionEasing:I

.field public static ConstraintOverride_transitionPathRotate:I

.field public static ConstraintOverride_visibilityMode:I

.field public static final ConstraintSet:[I

.field public static ConstraintSet_android_alpha:I

.field public static ConstraintSet_android_elevation:I

.field public static ConstraintSet_android_id:I

.field public static ConstraintSet_android_layout_height:I

.field public static ConstraintSet_android_layout_marginBottom:I

.field public static ConstraintSet_android_layout_marginEnd:I

.field public static ConstraintSet_android_layout_marginLeft:I

.field public static ConstraintSet_android_layout_marginRight:I

.field public static ConstraintSet_android_layout_marginStart:I

.field public static ConstraintSet_android_layout_marginTop:I

.field public static ConstraintSet_android_layout_width:I

.field public static ConstraintSet_android_maxHeight:I

.field public static ConstraintSet_android_maxWidth:I

.field public static ConstraintSet_android_minHeight:I

.field public static ConstraintSet_android_minWidth:I

.field public static ConstraintSet_android_orientation:I

.field public static ConstraintSet_android_pivotX:I

.field public static ConstraintSet_android_pivotY:I

.field public static ConstraintSet_android_rotation:I

.field public static ConstraintSet_android_rotationX:I

.field public static ConstraintSet_android_rotationY:I

.field public static ConstraintSet_android_scaleX:I

.field public static ConstraintSet_android_scaleY:I

.field public static ConstraintSet_android_transformPivotX:I

.field public static ConstraintSet_android_transformPivotY:I

.field public static ConstraintSet_android_translationX:I

.field public static ConstraintSet_android_translationY:I

.field public static ConstraintSet_android_translationZ:I

.field public static ConstraintSet_android_visibility:I

.field public static ConstraintSet_animateCircleAngleTo:I

.field public static ConstraintSet_animateRelativeTo:I

.field public static ConstraintSet_barrierAllowsGoneWidgets:I

.field public static ConstraintSet_barrierDirection:I

.field public static ConstraintSet_barrierMargin:I

.field public static ConstraintSet_chainUseRtl:I

.field public static ConstraintSet_constraintRotate:I

.field public static ConstraintSet_constraint_referenced_ids:I

.field public static ConstraintSet_constraint_referenced_tags:I

.field public static ConstraintSet_deriveConstraintsFrom:I

.field public static ConstraintSet_drawPath:I

.field public static ConstraintSet_flow_firstHorizontalBias:I

.field public static ConstraintSet_flow_firstHorizontalStyle:I

.field public static ConstraintSet_flow_firstVerticalBias:I

.field public static ConstraintSet_flow_firstVerticalStyle:I

.field public static ConstraintSet_flow_horizontalAlign:I

.field public static ConstraintSet_flow_horizontalBias:I

.field public static ConstraintSet_flow_horizontalGap:I

.field public static ConstraintSet_flow_horizontalStyle:I

.field public static ConstraintSet_flow_lastHorizontalBias:I

.field public static ConstraintSet_flow_lastHorizontalStyle:I

.field public static ConstraintSet_flow_lastVerticalBias:I

.field public static ConstraintSet_flow_lastVerticalStyle:I

.field public static ConstraintSet_flow_maxElementsWrap:I

.field public static ConstraintSet_flow_verticalAlign:I

.field public static ConstraintSet_flow_verticalBias:I

.field public static ConstraintSet_flow_verticalGap:I

.field public static ConstraintSet_flow_verticalStyle:I

.field public static ConstraintSet_flow_wrapMode:I

.field public static ConstraintSet_guidelineUseRtl:I

.field public static ConstraintSet_layout_constrainedHeight:I

.field public static ConstraintSet_layout_constrainedWidth:I

.field public static ConstraintSet_layout_constraintBaseline_creator:I

.field public static ConstraintSet_layout_constraintBaseline_toBaselineOf:I

.field public static ConstraintSet_layout_constraintBaseline_toBottomOf:I

.field public static ConstraintSet_layout_constraintBaseline_toTopOf:I

.field public static ConstraintSet_layout_constraintBottom_creator:I

.field public static ConstraintSet_layout_constraintBottom_toBottomOf:I

.field public static ConstraintSet_layout_constraintBottom_toTopOf:I

.field public static ConstraintSet_layout_constraintCircle:I

.field public static ConstraintSet_layout_constraintCircleAngle:I

.field public static ConstraintSet_layout_constraintCircleRadius:I

.field public static ConstraintSet_layout_constraintDimensionRatio:I

.field public static ConstraintSet_layout_constraintEnd_toEndOf:I

.field public static ConstraintSet_layout_constraintEnd_toStartOf:I

.field public static ConstraintSet_layout_constraintGuide_begin:I

.field public static ConstraintSet_layout_constraintGuide_end:I

.field public static ConstraintSet_layout_constraintGuide_percent:I

.field public static ConstraintSet_layout_constraintHeight_default:I

.field public static ConstraintSet_layout_constraintHeight_max:I

.field public static ConstraintSet_layout_constraintHeight_min:I

.field public static ConstraintSet_layout_constraintHeight_percent:I

.field public static ConstraintSet_layout_constraintHorizontal_bias:I

.field public static ConstraintSet_layout_constraintHorizontal_chainStyle:I

.field public static ConstraintSet_layout_constraintHorizontal_weight:I

.field public static ConstraintSet_layout_constraintLeft_creator:I

.field public static ConstraintSet_layout_constraintLeft_toLeftOf:I

.field public static ConstraintSet_layout_constraintLeft_toRightOf:I

.field public static ConstraintSet_layout_constraintRight_creator:I

.field public static ConstraintSet_layout_constraintRight_toLeftOf:I

.field public static ConstraintSet_layout_constraintRight_toRightOf:I

.field public static ConstraintSet_layout_constraintStart_toEndOf:I

.field public static ConstraintSet_layout_constraintStart_toStartOf:I

.field public static ConstraintSet_layout_constraintTag:I

.field public static ConstraintSet_layout_constraintTop_creator:I

.field public static ConstraintSet_layout_constraintTop_toBottomOf:I

.field public static ConstraintSet_layout_constraintTop_toTopOf:I

.field public static ConstraintSet_layout_constraintVertical_bias:I

.field public static ConstraintSet_layout_constraintVertical_chainStyle:I

.field public static ConstraintSet_layout_constraintVertical_weight:I

.field public static ConstraintSet_layout_constraintWidth_default:I

.field public static ConstraintSet_layout_constraintWidth_max:I

.field public static ConstraintSet_layout_constraintWidth_min:I

.field public static ConstraintSet_layout_constraintWidth_percent:I

.field public static ConstraintSet_layout_editor_absoluteX:I

.field public static ConstraintSet_layout_editor_absoluteY:I

.field public static ConstraintSet_layout_goneMarginBaseline:I

.field public static ConstraintSet_layout_goneMarginBottom:I

.field public static ConstraintSet_layout_goneMarginEnd:I

.field public static ConstraintSet_layout_goneMarginLeft:I

.field public static ConstraintSet_layout_goneMarginRight:I

.field public static ConstraintSet_layout_goneMarginStart:I

.field public static ConstraintSet_layout_goneMarginTop:I

.field public static ConstraintSet_layout_marginBaseline:I

.field public static ConstraintSet_layout_wrapBehaviorInParent:I

.field public static ConstraintSet_motionProgress:I

.field public static ConstraintSet_motionStagger:I

.field public static ConstraintSet_pathMotionArc:I

.field public static ConstraintSet_pivotAnchor:I

.field public static ConstraintSet_polarRelativeTo:I

.field public static ConstraintSet_quantizeMotionSteps:I

.field public static ConstraintSet_stateLabels:I

.field public static ConstraintSet_transitionEasing:I

.field public static ConstraintSet_transitionPathRotate:I

.field public static Constraint_android_alpha:I

.field public static Constraint_android_elevation:I

.field public static Constraint_android_id:I

.field public static Constraint_android_layout_height:I

.field public static Constraint_android_layout_marginBottom:I

.field public static Constraint_android_layout_marginEnd:I

.field public static Constraint_android_layout_marginLeft:I

.field public static Constraint_android_layout_marginRight:I

.field public static Constraint_android_layout_marginStart:I

.field public static Constraint_android_layout_marginTop:I

.field public static Constraint_android_layout_width:I

.field public static Constraint_android_maxHeight:I

.field public static Constraint_android_maxWidth:I

.field public static Constraint_android_minHeight:I

.field public static Constraint_android_minWidth:I

.field public static Constraint_android_orientation:I

.field public static Constraint_android_rotation:I

.field public static Constraint_android_rotationX:I

.field public static Constraint_android_rotationY:I

.field public static Constraint_android_scaleX:I

.field public static Constraint_android_scaleY:I

.field public static Constraint_android_transformPivotX:I

.field public static Constraint_android_transformPivotY:I

.field public static Constraint_android_translationX:I

.field public static Constraint_android_translationY:I

.field public static Constraint_android_translationZ:I

.field public static Constraint_android_visibility:I

.field public static Constraint_animateCircleAngleTo:I

.field public static Constraint_animateRelativeTo:I

.field public static Constraint_barrierAllowsGoneWidgets:I

.field public static Constraint_barrierDirection:I

.field public static Constraint_barrierMargin:I

.field public static Constraint_chainUseRtl:I

.field public static Constraint_constraint_referenced_ids:I

.field public static Constraint_constraint_referenced_tags:I

.field public static Constraint_drawPath:I

.field public static Constraint_flow_firstHorizontalBias:I

.field public static Constraint_flow_firstHorizontalStyle:I

.field public static Constraint_flow_firstVerticalBias:I

.field public static Constraint_flow_firstVerticalStyle:I

.field public static Constraint_flow_horizontalAlign:I

.field public static Constraint_flow_horizontalBias:I

.field public static Constraint_flow_horizontalGap:I

.field public static Constraint_flow_horizontalStyle:I

.field public static Constraint_flow_lastHorizontalBias:I

.field public static Constraint_flow_lastHorizontalStyle:I

.field public static Constraint_flow_lastVerticalBias:I

.field public static Constraint_flow_lastVerticalStyle:I

.field public static Constraint_flow_maxElementsWrap:I

.field public static Constraint_flow_verticalAlign:I

.field public static Constraint_flow_verticalBias:I

.field public static Constraint_flow_verticalGap:I

.field public static Constraint_flow_verticalStyle:I

.field public static Constraint_flow_wrapMode:I

.field public static Constraint_guidelineUseRtl:I

.field public static Constraint_layout_constrainedHeight:I

.field public static Constraint_layout_constrainedWidth:I

.field public static Constraint_layout_constraintBaseline_creator:I

.field public static Constraint_layout_constraintBaseline_toBaselineOf:I

.field public static Constraint_layout_constraintBaseline_toBottomOf:I

.field public static Constraint_layout_constraintBaseline_toTopOf:I

.field public static Constraint_layout_constraintBottom_creator:I

.field public static Constraint_layout_constraintBottom_toBottomOf:I

.field public static Constraint_layout_constraintBottom_toTopOf:I

.field public static Constraint_layout_constraintCircle:I

.field public static Constraint_layout_constraintCircleAngle:I

.field public static Constraint_layout_constraintCircleRadius:I

.field public static Constraint_layout_constraintDimensionRatio:I

.field public static Constraint_layout_constraintEnd_toEndOf:I

.field public static Constraint_layout_constraintEnd_toStartOf:I

.field public static Constraint_layout_constraintGuide_begin:I

.field public static Constraint_layout_constraintGuide_end:I

.field public static Constraint_layout_constraintGuide_percent:I

.field public static Constraint_layout_constraintHeight:I

.field public static Constraint_layout_constraintHeight_default:I

.field public static Constraint_layout_constraintHeight_max:I

.field public static Constraint_layout_constraintHeight_min:I

.field public static Constraint_layout_constraintHeight_percent:I

.field public static Constraint_layout_constraintHorizontal_bias:I

.field public static Constraint_layout_constraintHorizontal_chainStyle:I

.field public static Constraint_layout_constraintHorizontal_weight:I

.field public static Constraint_layout_constraintLeft_creator:I

.field public static Constraint_layout_constraintLeft_toLeftOf:I

.field public static Constraint_layout_constraintLeft_toRightOf:I

.field public static Constraint_layout_constraintRight_creator:I

.field public static Constraint_layout_constraintRight_toLeftOf:I

.field public static Constraint_layout_constraintRight_toRightOf:I

.field public static Constraint_layout_constraintStart_toEndOf:I

.field public static Constraint_layout_constraintStart_toStartOf:I

.field public static Constraint_layout_constraintTag:I

.field public static Constraint_layout_constraintTop_creator:I

.field public static Constraint_layout_constraintTop_toBottomOf:I

.field public static Constraint_layout_constraintTop_toTopOf:I

.field public static Constraint_layout_constraintVertical_bias:I

.field public static Constraint_layout_constraintVertical_chainStyle:I

.field public static Constraint_layout_constraintVertical_weight:I

.field public static Constraint_layout_constraintWidth:I

.field public static Constraint_layout_constraintWidth_default:I

.field public static Constraint_layout_constraintWidth_max:I

.field public static Constraint_layout_constraintWidth_min:I

.field public static Constraint_layout_constraintWidth_percent:I

.field public static Constraint_layout_editor_absoluteX:I

.field public static Constraint_layout_editor_absoluteY:I

.field public static Constraint_layout_goneMarginBaseline:I

.field public static Constraint_layout_goneMarginBottom:I

.field public static Constraint_layout_goneMarginEnd:I

.field public static Constraint_layout_goneMarginLeft:I

.field public static Constraint_layout_goneMarginRight:I

.field public static Constraint_layout_goneMarginStart:I

.field public static Constraint_layout_goneMarginTop:I

.field public static Constraint_layout_marginBaseline:I

.field public static Constraint_layout_wrapBehaviorInParent:I

.field public static Constraint_motionProgress:I

.field public static Constraint_motionStagger:I

.field public static Constraint_pathMotionArc:I

.field public static Constraint_pivotAnchor:I

.field public static Constraint_polarRelativeTo:I

.field public static Constraint_quantizeMotionInterpolator:I

.field public static Constraint_quantizeMotionPhase:I

.field public static Constraint_quantizeMotionSteps:I

.field public static Constraint_transformPivotTarget:I

.field public static Constraint_transitionEasing:I

.field public static Constraint_transitionPathRotate:I

.field public static Constraint_visibilityMode:I

.field public static final CoordinatorLayout:[I

.field public static final CoordinatorLayout_Layout:[I

.field public static CoordinatorLayout_Layout_android_layout_gravity:I

.field public static CoordinatorLayout_Layout_layout_anchor:I

.field public static CoordinatorLayout_Layout_layout_anchorGravity:I

.field public static CoordinatorLayout_Layout_layout_behavior:I

.field public static CoordinatorLayout_Layout_layout_dodgeInsetEdges:I

.field public static CoordinatorLayout_Layout_layout_insetEdge:I

.field public static CoordinatorLayout_Layout_layout_keyline:I

.field public static CoordinatorLayout_keylines:I

.field public static CoordinatorLayout_statusBarBackground:I

.field public static final CustomAttribute:[I

.field public static CustomAttribute_attributeName:I

.field public static CustomAttribute_customBoolean:I

.field public static CustomAttribute_customColorDrawableValue:I

.field public static CustomAttribute_customColorValue:I

.field public static CustomAttribute_customDimension:I

.field public static CustomAttribute_customFloatValue:I

.field public static CustomAttribute_customIntegerValue:I

.field public static CustomAttribute_customPixelDimension:I

.field public static CustomAttribute_customReference:I

.field public static CustomAttribute_customStringValue:I

.field public static CustomAttribute_methodName:I

.field public static final DevicePadding:[I

.field public static final DevicePaddingFormula:[I

.field public static DevicePaddingFormula_a:I

.field public static DevicePaddingFormula_b:I

.field public static DevicePaddingFormula_c:I

.field public static DevicePadding_maxEmptySpace:I

.field public static final DialogPreference:[I

.field public static DialogPreference_android_dialogIcon:I

.field public static DialogPreference_android_dialogLayout:I

.field public static DialogPreference_android_dialogMessage:I

.field public static DialogPreference_android_dialogTitle:I

.field public static DialogPreference_android_negativeButtonText:I

.field public static DialogPreference_android_positiveButtonText:I

.field public static DialogPreference_dialogIcon:I

.field public static DialogPreference_dialogLayout:I

.field public static DialogPreference_dialogMessage:I

.field public static DialogPreference_dialogTitle:I

.field public static DialogPreference_negativeButtonText:I

.field public static DialogPreference_positiveButtonText:I

.field public static final DividerAttributes:[I

.field public static DividerAttributes_dragRangeMaxRatio:I

.field public static DividerAttributes_dragRangeMinRatio:I

.field public static DividerAttributes_embeddingDividerColor:I

.field public static DividerAttributes_embeddingDividerType:I

.field public static DividerAttributes_embeddingDividerWidthDp:I

.field public static DividerAttributes_isDraggingToFullscreenAllowed:I

.field public static final DoubleShadowAttrDeclare:[I

.field public static DoubleShadowAttrDeclare_ambientShadowAlpha:I

.field public static DoubleShadowAttrDeclare_ambientShadowBlur:I

.field public static DoubleShadowAttrDeclare_ambientShadowOffsetX:I

.field public static DoubleShadowAttrDeclare_ambientShadowOffsetY:I

.field public static DoubleShadowAttrDeclare_keyShadowAlpha:I

.field public static DoubleShadowAttrDeclare_keyShadowBlur:I

.field public static DoubleShadowAttrDeclare_keyShadowOffsetX:I

.field public static DoubleShadowAttrDeclare_keyShadowOffsetY:I

.field public static final DoubleShadowTextClock:[I

.field public static DoubleShadowTextClock_ambientShadowAlpha:I

.field public static DoubleShadowTextClock_ambientShadowBlur:I

.field public static DoubleShadowTextClock_ambientShadowOffsetX:I

.field public static DoubleShadowTextClock_ambientShadowOffsetY:I

.field public static DoubleShadowTextClock_keyShadowAlpha:I

.field public static DoubleShadowTextClock_keyShadowBlur:I

.field public static DoubleShadowTextClock_keyShadowOffsetX:I

.field public static DoubleShadowTextClock_keyShadowOffsetY:I

.field public static DoubleShadowTextClock_removeTextDescent:I

.field public static DoubleShadowTextClock_textDescentExtraPadding:I

.field public static final DoubleShadowTextView:[I

.field public static DoubleShadowTextView_ambientShadowAlpha:I

.field public static DoubleShadowTextView_ambientShadowBlur:I

.field public static DoubleShadowTextView_ambientShadowOffsetX:I

.field public static DoubleShadowTextView_ambientShadowOffsetY:I

.field public static DoubleShadowTextView_drawableIconInsetSize:I

.field public static DoubleShadowTextView_drawableIconSize:I

.field public static DoubleShadowTextView_keyShadowAlpha:I

.field public static DoubleShadowTextView_keyShadowBlur:I

.field public static DoubleShadowTextView_keyShadowOffsetX:I

.field public static DoubleShadowTextView_keyShadowOffsetY:I

.field public static final DrawerArrowToggle:[I

.field public static DrawerArrowToggle_arrowHeadLength:I

.field public static DrawerArrowToggle_arrowShaftLength:I

.field public static DrawerArrowToggle_barLength:I

.field public static DrawerArrowToggle_color:I

.field public static DrawerArrowToggle_drawableSize:I

.field public static DrawerArrowToggle_gapBetweenBars:I

.field public static DrawerArrowToggle_spinBars:I

.field public static DrawerArrowToggle_thickness:I

.field public static final DrawerLayout:[I

.field public static DrawerLayout_elevation:I

.field public static final EditTextPreference:[I

.field public static EditTextPreference_useSimpleSummaryProvider:I

.field public static final ExtendedFloatingActionButton:[I

.field public static final ExtendedFloatingActionButton_Behavior_Layout:[I

.field public static ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide:I

.field public static ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink:I

.field public static ExtendedFloatingActionButton_collapsedSize:I

.field public static ExtendedFloatingActionButton_elevation:I

.field public static ExtendedFloatingActionButton_extendMotionSpec:I

.field public static ExtendedFloatingActionButton_extendStrategy:I

.field public static ExtendedFloatingActionButton_hideMotionSpec:I

.field public static ExtendedFloatingActionButton_showMotionSpec:I

.field public static ExtendedFloatingActionButton_shrinkMotionSpec:I

.field public static final Extra:[I

.field public static Extra_key:I

.field public static Extra_value:I

.field public static final Favorite:[I

.field public static Favorite_className:I

.field public static Favorite_container:I

.field public static Favorite_icon:I

.field public static Favorite_packageName:I

.field public static Favorite_screen:I

.field public static Favorite_spanX:I

.field public static Favorite_spanY:I

.field public static Favorite_title:I

.field public static Favorite_uri:I

.field public static Favorite_x:I

.field public static Favorite_y:I

.field public static final FloatingActionButton:[I

.field public static final FloatingActionButton_Behavior_Layout:[I

.field public static FloatingActionButton_Behavior_Layout_behavior_autoHide:I

.field public static FloatingActionButton_android_enabled:I

.field public static FloatingActionButton_backgroundTint:I

.field public static FloatingActionButton_backgroundTintMode:I

.field public static FloatingActionButton_borderWidth:I

.field public static FloatingActionButton_elevation:I

.field public static FloatingActionButton_ensureMinTouchTargetSize:I

.field public static FloatingActionButton_fabCustomSize:I

.field public static FloatingActionButton_fabSize:I

.field public static FloatingActionButton_hideMotionSpec:I

.field public static FloatingActionButton_hoveredFocusedTranslationZ:I

.field public static FloatingActionButton_maxImageSize:I

.field public static FloatingActionButton_pressedTranslationZ:I

.field public static FloatingActionButton_rippleColor:I

.field public static FloatingActionButton_shapeAppearance:I

.field public static FloatingActionButton_shapeAppearanceOverlay:I

.field public static FloatingActionButton_showMotionSpec:I

.field public static FloatingActionButton_useCompatPadding:I

.field public static final FloatingToolbar:[I

.field public static FloatingToolbar_backgroundTint:I

.field public static final FlowLayout:[I

.field public static FlowLayout_horizontalItemSpacing:I

.field public static FlowLayout_lineSpacing:I

.field public static final FolderIconPreview:[I

.field public static FolderIconPreview_allAppsFolderPreviewColor:I

.field public static FolderIconPreview_folderIconBorderColor:I

.field public static FolderIconPreview_folderPreviewColor:I

.field public static final FolderSpec:[I

.field public static FolderSpec_dimensionType:I

.field public static FolderSpec_maxAvailableSize:I

.field public static final FolderStyle:[I

.field public static FolderStyle_folderBorderSpace:I

.field public static FolderStyle_folderCellHeight:I

.field public static FolderStyle_folderCellWidth:I

.field public static FolderStyle_folderFooterHeight:I

.field public static FolderStyle_folderTopPadding:I

.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static FontFamilyFont_android_font:I

.field public static FontFamilyFont_android_fontStyle:I

.field public static FontFamilyFont_android_fontVariationSettings:I

.field public static FontFamilyFont_android_fontWeight:I

.field public static FontFamilyFont_android_ttcIndex:I

.field public static FontFamilyFont_font:I

.field public static FontFamilyFont_fontStyle:I

.field public static FontFamilyFont_fontVariationSettings:I

.field public static FontFamilyFont_fontWeight:I

.field public static FontFamilyFont_ttcIndex:I

.field public static FontFamily_fontProviderAuthority:I

.field public static FontFamily_fontProviderCerts:I

.field public static FontFamily_fontProviderFallbackQuery:I

.field public static FontFamily_fontProviderFetchStrategy:I

.field public static FontFamily_fontProviderFetchTimeout:I

.field public static FontFamily_fontProviderPackage:I

.field public static FontFamily_fontProviderQuery:I

.field public static FontFamily_fontProviderSystemFontFamily:I

.field public static final ForegroundLinearLayout:[I

.field public static ForegroundLinearLayout_android_foreground:I

.field public static ForegroundLinearLayout_android_foregroundGravity:I

.field public static ForegroundLinearLayout_foregroundInsidePadding:I

.field public static final Fragment:[I

.field public static final FragmentContainerView:[I

.field public static FragmentContainerView_android_name:I

.field public static FragmentContainerView_android_tag:I

.field public static Fragment_android_id:I

.field public static Fragment_android_name:I

.field public static Fragment_android_tag:I

.field public static final GradientColor:[I

.field public static final GradientColorItem:[I

.field public static GradientColorItem_android_color:I

.field public static GradientColorItem_android_offset:I

.field public static GradientColor_android_centerColor:I

.field public static GradientColor_android_centerX:I

.field public static GradientColor_android_centerY:I

.field public static GradientColor_android_endColor:I

.field public static GradientColor_android_endX:I

.field public static GradientColor_android_endY:I

.field public static GradientColor_android_gradientRadius:I

.field public static GradientColor_android_startColor:I

.field public static GradientColor_android_startX:I

.field public static GradientColor_android_startY:I

.field public static GradientColor_android_tileMode:I

.field public static GradientColor_android_type:I

.field public static final Grid:[I

.field public static final GridDisplayOption:[I

.field public static GridDisplayOption_allAppsCellSpecsId:I

.field public static GridDisplayOption_allAppsCellSpecsTwoPanelId:I

.field public static GridDisplayOption_allAppsSpecsId:I

.field public static GridDisplayOption_allAppsSpecsTwoPanelId:I

.field public static GridDisplayOption_allAppsStyle:I

.field public static GridDisplayOption_cellStyle:I

.field public static GridDisplayOption_dbFile:I

.field public static GridDisplayOption_defaultLayoutId:I

.field public static GridDisplayOption_demoModeLayoutId:I

.field public static GridDisplayOption_deviceCategory:I

.field public static GridDisplayOption_devicePaddingId:I

.field public static GridDisplayOption_folderSpecsId:I

.field public static GridDisplayOption_folderSpecsTwoPanelId:I

.field public static GridDisplayOption_folderStyle:I

.field public static GridDisplayOption_hotseatBorderSpace:I

.field public static GridDisplayOption_hotseatBorderSpaceLandscape:I

.field public static GridDisplayOption_hotseatSpecsId:I

.field public static GridDisplayOption_hotseatSpecsTwoPanelId:I

.field public static GridDisplayOption_inlineNavButtonsEndSpacing:I

.field public static GridDisplayOption_inlineQsb:I

.field public static GridDisplayOption_isScalable:I

.field public static GridDisplayOption_name:I

.field public static GridDisplayOption_numAllAppsColumns:I

.field public static GridDisplayOption_numAllAppsRowsForCellHeightCalculation:I

.field public static GridDisplayOption_numColumns:I

.field public static GridDisplayOption_numExtendedAllAppsColumns:I

.field public static GridDisplayOption_numExtendedHotseatIcons:I

.field public static GridDisplayOption_numFolderColumns:I

.field public static GridDisplayOption_numFolderColumnsLandscape:I

.field public static GridDisplayOption_numFolderColumnsTwoPanelLandscape:I

.field public static GridDisplayOption_numFolderColumnsTwoPanelPortrait:I

.field public static GridDisplayOption_numFolderRows:I

.field public static GridDisplayOption_numFolderRowsLandscape:I

.field public static GridDisplayOption_numFolderRowsTwoPanelLandscape:I

.field public static GridDisplayOption_numFolderRowsTwoPanelPortrait:I

.field public static GridDisplayOption_numHotseatIcons:I

.field public static GridDisplayOption_numRows:I

.field public static GridDisplayOption_numSearchContainerColumns:I

.field public static GridDisplayOption_numShrunkenHotseatIcons:I

.field public static GridDisplayOption_workspaceCellSpecsId:I

.field public static GridDisplayOption_workspaceCellSpecsTwoPanelId:I

.field public static GridDisplayOption_workspaceSpecsId:I

.field public static GridDisplayOption_workspaceSpecsTwoPanelId:I

.field public static Grid_grid_columnWeights:I

.field public static Grid_grid_columns:I

.field public static Grid_grid_horizontalGaps:I

.field public static Grid_grid_orientation:I

.field public static Grid_grid_rowWeights:I

.field public static Grid_grid_rows:I

.field public static Grid_grid_skips:I

.field public static Grid_grid_spans:I

.field public static Grid_grid_useRtl:I

.field public static Grid_grid_validateInputs:I

.field public static Grid_grid_verticalGaps:I

.field public static final HotseatSpec:[I

.field public static HotseatSpec_dimensionType:I

.field public static HotseatSpec_maxAvailableSize:I

.field public static final IconPersonalized:[I

.field public static IconPersonalized_sliderColor:I

.field public static IconPersonalized_sliderRadius:I

.field public static final ImageFilterView:[I

.field public static ImageFilterView_altSrc:I

.field public static ImageFilterView_blendSrc:I

.field public static ImageFilterView_brightness:I

.field public static ImageFilterView_contrast:I

.field public static ImageFilterView_crossfade:I

.field public static ImageFilterView_imagePanX:I

.field public static ImageFilterView_imagePanY:I

.field public static ImageFilterView_imageRotate:I

.field public static ImageFilterView_imageZoom:I

.field public static ImageFilterView_overlay:I

.field public static ImageFilterView_round:I

.field public static ImageFilterView_roundPercent:I

.field public static ImageFilterView_saturation:I

.field public static ImageFilterView_warmth:I

.field public static final Include:[I

.field public static Include_folderItems:I

.field public static Include_workspace:I

.field public static final Insets:[I

.field public static Insets_marginLeftSystemWindowInsets:I

.field public static Insets_marginRightSystemWindowInsets:I

.field public static Insets_marginTopSystemWindowInsets:I

.field public static Insets_paddingBottomSystemWindowInsets:I

.field public static Insets_paddingLeftSystemWindowInsets:I

.field public static Insets_paddingRightSystemWindowInsets:I

.field public static Insets_paddingStartSystemWindowInsets:I

.field public static Insets_paddingTopSystemWindowInsets:I

.field public static final InsettableFrameLayout_Layout:[I

.field public static InsettableFrameLayout_Layout_layout_ignoreInsets:I

.field public static final KeyAttribute:[I

.field public static KeyAttribute_android_alpha:I

.field public static KeyAttribute_android_elevation:I

.field public static KeyAttribute_android_rotation:I

.field public static KeyAttribute_android_rotationX:I

.field public static KeyAttribute_android_rotationY:I

.field public static KeyAttribute_android_scaleX:I

.field public static KeyAttribute_android_scaleY:I

.field public static KeyAttribute_android_transformPivotX:I

.field public static KeyAttribute_android_transformPivotY:I

.field public static KeyAttribute_android_translationX:I

.field public static KeyAttribute_android_translationY:I

.field public static KeyAttribute_android_translationZ:I

.field public static KeyAttribute_curveFit:I

.field public static KeyAttribute_framePosition:I

.field public static KeyAttribute_motionProgress:I

.field public static KeyAttribute_motionTarget:I

.field public static KeyAttribute_transformPivotTarget:I

.field public static KeyAttribute_transitionEasing:I

.field public static KeyAttribute_transitionPathRotate:I

.field public static final KeyCycle:[I

.field public static KeyCycle_android_alpha:I

.field public static KeyCycle_android_elevation:I

.field public static KeyCycle_android_rotation:I

.field public static KeyCycle_android_rotationX:I

.field public static KeyCycle_android_rotationY:I

.field public static KeyCycle_android_scaleX:I

.field public static KeyCycle_android_scaleY:I

.field public static KeyCycle_android_translationX:I

.field public static KeyCycle_android_translationY:I

.field public static KeyCycle_android_translationZ:I

.field public static KeyCycle_curveFit:I

.field public static KeyCycle_framePosition:I

.field public static KeyCycle_motionProgress:I

.field public static KeyCycle_motionTarget:I

.field public static KeyCycle_transitionEasing:I

.field public static KeyCycle_transitionPathRotate:I

.field public static KeyCycle_waveOffset:I

.field public static KeyCycle_wavePeriod:I

.field public static KeyCycle_wavePhase:I

.field public static KeyCycle_waveShape:I

.field public static KeyCycle_waveVariesBy:I

.field public static final KeyFrame:[I

.field public static final KeyFramesAcceleration:[I

.field public static final KeyFramesVelocity:[I

.field public static final KeyPosition:[I

.field public static KeyPosition_curveFit:I

.field public static KeyPosition_drawPath:I

.field public static KeyPosition_framePosition:I

.field public static KeyPosition_keyPositionType:I

.field public static KeyPosition_motionTarget:I

.field public static KeyPosition_pathMotionArc:I

.field public static KeyPosition_percentHeight:I

.field public static KeyPosition_percentWidth:I

.field public static KeyPosition_percentX:I

.field public static KeyPosition_percentY:I

.field public static KeyPosition_sizePercent:I

.field public static KeyPosition_transitionEasing:I

.field public static final KeyTimeCycle:[I

.field public static KeyTimeCycle_android_alpha:I

.field public static KeyTimeCycle_android_elevation:I

.field public static KeyTimeCycle_android_rotation:I

.field public static KeyTimeCycle_android_rotationX:I

.field public static KeyTimeCycle_android_rotationY:I

.field public static KeyTimeCycle_android_scaleX:I

.field public static KeyTimeCycle_android_scaleY:I

.field public static KeyTimeCycle_android_translationX:I

.field public static KeyTimeCycle_android_translationY:I

.field public static KeyTimeCycle_android_translationZ:I

.field public static KeyTimeCycle_curveFit:I

.field public static KeyTimeCycle_framePosition:I

.field public static KeyTimeCycle_motionProgress:I

.field public static KeyTimeCycle_motionTarget:I

.field public static KeyTimeCycle_transitionEasing:I

.field public static KeyTimeCycle_transitionPathRotate:I

.field public static KeyTimeCycle_waveDecay:I

.field public static KeyTimeCycle_waveOffset:I

.field public static KeyTimeCycle_wavePeriod:I

.field public static KeyTimeCycle_wavePhase:I

.field public static KeyTimeCycle_waveShape:I

.field public static final KeyTrigger:[I

.field public static KeyTrigger_framePosition:I

.field public static KeyTrigger_motionTarget:I

.field public static KeyTrigger_motion_postLayoutCollision:I

.field public static KeyTrigger_motion_triggerOnCollision:I

.field public static KeyTrigger_onCross:I

.field public static KeyTrigger_onNegativeCross:I

.field public static KeyTrigger_onPositiveCross:I

.field public static KeyTrigger_triggerId:I

.field public static KeyTrigger_triggerReceiver:I

.field public static KeyTrigger_triggerSlack:I

.field public static KeyTrigger_viewTransitionOnCross:I

.field public static KeyTrigger_viewTransitionOnNegativeCross:I

.field public static KeyTrigger_viewTransitionOnPositiveCross:I

.field public static final Layout:[I

.field public static Layout_android_layout_height:I

.field public static Layout_android_layout_marginBottom:I

.field public static Layout_android_layout_marginEnd:I

.field public static Layout_android_layout_marginLeft:I

.field public static Layout_android_layout_marginRight:I

.field public static Layout_android_layout_marginStart:I

.field public static Layout_android_layout_marginTop:I

.field public static Layout_android_layout_width:I

.field public static Layout_android_orientation:I

.field public static Layout_barrierAllowsGoneWidgets:I

.field public static Layout_barrierDirection:I

.field public static Layout_barrierMargin:I

.field public static Layout_chainUseRtl:I

.field public static Layout_constraint_referenced_ids:I

.field public static Layout_constraint_referenced_tags:I

.field public static Layout_guidelineUseRtl:I

.field public static Layout_layout_constrainedHeight:I

.field public static Layout_layout_constrainedWidth:I

.field public static Layout_layout_constraintBaseline_creator:I

.field public static Layout_layout_constraintBaseline_toBaselineOf:I

.field public static Layout_layout_constraintBaseline_toBottomOf:I

.field public static Layout_layout_constraintBaseline_toTopOf:I

.field public static Layout_layout_constraintBottom_creator:I

.field public static Layout_layout_constraintBottom_toBottomOf:I

.field public static Layout_layout_constraintBottom_toTopOf:I

.field public static Layout_layout_constraintCircle:I

.field public static Layout_layout_constraintCircleAngle:I

.field public static Layout_layout_constraintCircleRadius:I

.field public static Layout_layout_constraintDimensionRatio:I

.field public static Layout_layout_constraintEnd_toEndOf:I

.field public static Layout_layout_constraintEnd_toStartOf:I

.field public static Layout_layout_constraintGuide_begin:I

.field public static Layout_layout_constraintGuide_end:I

.field public static Layout_layout_constraintGuide_percent:I

.field public static Layout_layout_constraintHeight:I

.field public static Layout_layout_constraintHeight_default:I

.field public static Layout_layout_constraintHeight_max:I

.field public static Layout_layout_constraintHeight_min:I

.field public static Layout_layout_constraintHeight_percent:I

.field public static Layout_layout_constraintHorizontal_bias:I

.field public static Layout_layout_constraintHorizontal_chainStyle:I

.field public static Layout_layout_constraintHorizontal_weight:I

.field public static Layout_layout_constraintLeft_creator:I

.field public static Layout_layout_constraintLeft_toLeftOf:I

.field public static Layout_layout_constraintLeft_toRightOf:I

.field public static Layout_layout_constraintRight_creator:I

.field public static Layout_layout_constraintRight_toLeftOf:I

.field public static Layout_layout_constraintRight_toRightOf:I

.field public static Layout_layout_constraintStart_toEndOf:I

.field public static Layout_layout_constraintStart_toStartOf:I

.field public static Layout_layout_constraintTop_creator:I

.field public static Layout_layout_constraintTop_toBottomOf:I

.field public static Layout_layout_constraintTop_toTopOf:I

.field public static Layout_layout_constraintVertical_bias:I

.field public static Layout_layout_constraintVertical_chainStyle:I

.field public static Layout_layout_constraintVertical_weight:I

.field public static Layout_layout_constraintWidth:I

.field public static Layout_layout_constraintWidth_default:I

.field public static Layout_layout_constraintWidth_max:I

.field public static Layout_layout_constraintWidth_min:I

.field public static Layout_layout_constraintWidth_percent:I

.field public static Layout_layout_editor_absoluteX:I

.field public static Layout_layout_editor_absoluteY:I

.field public static Layout_layout_goneMarginBaseline:I

.field public static Layout_layout_goneMarginBottom:I

.field public static Layout_layout_goneMarginEnd:I

.field public static Layout_layout_goneMarginLeft:I

.field public static Layout_layout_goneMarginRight:I

.field public static Layout_layout_goneMarginStart:I

.field public static Layout_layout_goneMarginTop:I

.field public static Layout_layout_marginBaseline:I

.field public static Layout_layout_wrapBehaviorInParent:I

.field public static Layout_maxHeight:I

.field public static Layout_maxWidth:I

.field public static Layout_minHeight:I

.field public static Layout_minWidth:I

.field public static final LinearLayoutCompat:[I

.field public static final LinearLayoutCompat_Layout:[I

.field public static LinearLayoutCompat_Layout_android_layout_gravity:I

.field public static LinearLayoutCompat_Layout_android_layout_height:I

.field public static LinearLayoutCompat_Layout_android_layout_weight:I

.field public static LinearLayoutCompat_Layout_android_layout_width:I

.field public static LinearLayoutCompat_android_baselineAligned:I

.field public static LinearLayoutCompat_android_baselineAlignedChildIndex:I

.field public static LinearLayoutCompat_android_gravity:I

.field public static LinearLayoutCompat_android_orientation:I

.field public static LinearLayoutCompat_android_weightSum:I

.field public static LinearLayoutCompat_divider:I

.field public static LinearLayoutCompat_dividerPadding:I

.field public static LinearLayoutCompat_measureWithLargestChild:I

.field public static LinearLayoutCompat_showDividers:I

.field public static final LinearProgressIndicator:[I

.field public static LinearProgressIndicator_indeterminateAnimationType:I

.field public static LinearProgressIndicator_indicatorDirectionLinear:I

.field public static LinearProgressIndicator_trackStopIndicatorSize:I

.field public static final ListPopupWindow:[I

.field public static ListPopupWindow_android_dropDownHorizontalOffset:I

.field public static ListPopupWindow_android_dropDownVerticalOffset:I

.field public static final ListPreference:[I

.field public static ListPreference_android_entries:I

.field public static ListPreference_android_entryValues:I

.field public static ListPreference_entries:I

.field public static ListPreference_entryValues:I

.field public static ListPreference_useSimpleSummaryProvider:I

.field public static final LoadingIndicator:[I

.field public static LoadingIndicator_containerColor:I

.field public static LoadingIndicator_containerHeight:I

.field public static LoadingIndicator_containerWidth:I

.field public static LoadingIndicator_indicatorColor:I

.field public static LoadingIndicator_indicatorSize:I

.field public static final LoggablePref:[I

.field public static LoggablePref_android_defaultValue:I

.field public static LoggablePref_android_key:I

.field public static LoggablePref_logIdOff:I

.field public static LoggablePref_logIdOn:I

.field public static final LottieAnimationView:[I

.field public static LottieAnimationView_lottie_asyncUpdates:I

.field public static LottieAnimationView_lottie_autoPlay:I

.field public static LottieAnimationView_lottie_cacheComposition:I

.field public static LottieAnimationView_lottie_clipTextToBoundingBox:I

.field public static LottieAnimationView_lottie_clipToCompositionBounds:I

.field public static LottieAnimationView_lottie_colorFilter:I

.field public static LottieAnimationView_lottie_defaultFontFileExtension:I

.field public static LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove:I

.field public static LottieAnimationView_lottie_fallbackRes:I

.field public static LottieAnimationView_lottie_fileName:I

.field public static LottieAnimationView_lottie_ignoreDisabledSystemAnimations:I

.field public static LottieAnimationView_lottie_imageAssetsFolder:I

.field public static LottieAnimationView_lottie_loop:I

.field public static LottieAnimationView_lottie_progress:I

.field public static LottieAnimationView_lottie_rawRes:I

.field public static LottieAnimationView_lottie_renderMode:I

.field public static LottieAnimationView_lottie_repeatCount:I

.field public static LottieAnimationView_lottie_repeatMode:I

.field public static LottieAnimationView_lottie_scale:I

.field public static LottieAnimationView_lottie_speed:I

.field public static LottieAnimationView_lottie_url:I

.field public static LottieAnimationView_lottie_useCompositionFrameRate:I

.field public static final MaterialAlertDialog:[I

.field public static final MaterialAlertDialogTheme:[I

.field public static MaterialAlertDialogTheme_materialAlertDialogBodyTextStyle:I

.field public static MaterialAlertDialogTheme_materialAlertDialogButtonSpacerVisibility:I

.field public static MaterialAlertDialogTheme_materialAlertDialogTheme:I

.field public static MaterialAlertDialogTheme_materialAlertDialogTitleIconStyle:I

.field public static MaterialAlertDialogTheme_materialAlertDialogTitlePanelStyle:I

.field public static MaterialAlertDialogTheme_materialAlertDialogTitleTextStyle:I

.field public static MaterialAlertDialog_backgroundInsetBottom:I

.field public static MaterialAlertDialog_backgroundInsetEnd:I

.field public static MaterialAlertDialog_backgroundInsetStart:I

.field public static MaterialAlertDialog_backgroundInsetTop:I

.field public static MaterialAlertDialog_backgroundTint:I

.field public static final MaterialAutoCompleteTextView:[I

.field public static MaterialAutoCompleteTextView_android_inputType:I

.field public static MaterialAutoCompleteTextView_android_popupElevation:I

.field public static MaterialAutoCompleteTextView_dropDownBackgroundTint:I

.field public static MaterialAutoCompleteTextView_simpleItemLayout:I

.field public static MaterialAutoCompleteTextView_simpleItemSelectedColor:I

.field public static MaterialAutoCompleteTextView_simpleItemSelectedRippleColor:I

.field public static MaterialAutoCompleteTextView_simpleItems:I

.field public static final MaterialButton:[I

.field public static final MaterialButtonGroup:[I

.field public static MaterialButtonGroup_android_enabled:I

.field public static MaterialButtonGroup_android_spacing:I

.field public static MaterialButtonGroup_buttonSizeChange:I

.field public static MaterialButtonGroup_innerCornerSize:I

.field public static MaterialButtonGroup_shapeAppearance:I

.field public static MaterialButtonGroup_shapeAppearanceOverlay:I

.field public static final MaterialButtonToggleGroup:[I

.field public static MaterialButtonToggleGroup_android_enabled:I

.field public static MaterialButtonToggleGroup_android_spacing:I

.field public static MaterialButtonToggleGroup_checkedButton:I

.field public static MaterialButtonToggleGroup_innerCornerSize:I

.field public static MaterialButtonToggleGroup_selectionRequired:I

.field public static MaterialButtonToggleGroup_shapeAppearance:I

.field public static MaterialButtonToggleGroup_shapeAppearanceOverlay:I

.field public static MaterialButtonToggleGroup_singleSelection:I

.field public static MaterialButton_android_background:I

.field public static MaterialButton_android_checkable:I

.field public static MaterialButton_android_insetBottom:I

.field public static MaterialButton_android_insetLeft:I

.field public static MaterialButton_android_insetRight:I

.field public static MaterialButton_android_insetTop:I

.field public static MaterialButton_backgroundTint:I

.field public static MaterialButton_backgroundTintMode:I

.field public static MaterialButton_cornerRadius:I

.field public static MaterialButton_elevation:I

.field public static MaterialButton_icon:I

.field public static MaterialButton_iconGravity:I

.field public static MaterialButton_iconPadding:I

.field public static MaterialButton_iconSize:I

.field public static MaterialButton_iconTint:I

.field public static MaterialButton_iconTintMode:I

.field public static MaterialButton_rippleColor:I

.field public static MaterialButton_shapeAppearance:I

.field public static MaterialButton_shapeAppearanceOverlay:I

.field public static MaterialButton_strokeColor:I

.field public static MaterialButton_strokeWidth:I

.field public static MaterialButton_toggleCheckedStateOnClick:I

.field public static final MaterialCalendar:[I

.field public static final MaterialCalendarItem:[I

.field public static MaterialCalendarItem_android_insetBottom:I

.field public static MaterialCalendarItem_android_insetLeft:I

.field public static MaterialCalendarItem_android_insetRight:I

.field public static MaterialCalendarItem_android_insetTop:I

.field public static MaterialCalendarItem_itemFillColor:I

.field public static MaterialCalendarItem_itemShapeAppearance:I

.field public static MaterialCalendarItem_itemShapeAppearanceOverlay:I

.field public static MaterialCalendarItem_itemStrokeColor:I

.field public static MaterialCalendarItem_itemStrokeWidth:I

.field public static MaterialCalendarItem_itemTextColor:I

.field public static MaterialCalendar_android_windowFullscreen:I

.field public static MaterialCalendar_backgroundTint:I

.field public static MaterialCalendar_dayInvalidStyle:I

.field public static MaterialCalendar_daySelectedStyle:I

.field public static MaterialCalendar_dayStyle:I

.field public static MaterialCalendar_dayTodayStyle:I

.field public static MaterialCalendar_nestedScrollable:I

.field public static MaterialCalendar_rangeFillColor:I

.field public static MaterialCalendar_yearSelectedStyle:I

.field public static MaterialCalendar_yearStyle:I

.field public static MaterialCalendar_yearTodayStyle:I

.field public static final MaterialCardView:[I

.field public static MaterialCardView_android_checkable:I

.field public static MaterialCardView_cardForegroundColor:I

.field public static MaterialCardView_checkedIcon:I

.field public static MaterialCardView_checkedIconGravity:I

.field public static MaterialCardView_checkedIconMargin:I

.field public static MaterialCardView_checkedIconSize:I

.field public static MaterialCardView_checkedIconTint:I

.field public static MaterialCardView_rippleColor:I

.field public static MaterialCardView_shapeAppearance:I

.field public static MaterialCardView_shapeAppearanceOverlay:I

.field public static MaterialCardView_state_dragged:I

.field public static MaterialCardView_strokeColor:I

.field public static MaterialCardView_strokeWidth:I

.field public static final MaterialCheckBox:[I

.field public static final MaterialCheckBoxStates:[I

.field public static MaterialCheckBoxStates_state_error:I

.field public static MaterialCheckBoxStates_state_indeterminate:I

.field public static MaterialCheckBox_android_button:I

.field public static MaterialCheckBox_buttonCompat:I

.field public static MaterialCheckBox_buttonIcon:I

.field public static MaterialCheckBox_buttonIconTint:I

.field public static MaterialCheckBox_buttonIconTintMode:I

.field public static MaterialCheckBox_buttonTint:I

.field public static MaterialCheckBox_centerIfNoTextEnabled:I

.field public static MaterialCheckBox_checkedState:I

.field public static MaterialCheckBox_errorAccessibilityLabel:I

.field public static MaterialCheckBox_errorShown:I

.field public static MaterialCheckBox_useMaterialThemeColors:I

.field public static final MaterialDivider:[I

.field public static MaterialDivider_dividerColor:I

.field public static MaterialDivider_dividerInsetEnd:I

.field public static MaterialDivider_dividerInsetStart:I

.field public static MaterialDivider_dividerThickness:I

.field public static MaterialDivider_lastItemDecorated:I

.field public static final MaterialRadioButton:[I

.field public static MaterialRadioButton_buttonTint:I

.field public static MaterialRadioButton_useMaterialThemeColors:I

.field public static final MaterialShape:[I

.field public static MaterialShape_shapeAppearance:I

.field public static MaterialShape_shapeAppearanceOverlay:I

.field public static final MaterialSwitch:[I

.field public static MaterialSwitch_thumbIcon:I

.field public static MaterialSwitch_thumbIconSize:I

.field public static MaterialSwitch_thumbIconTint:I

.field public static MaterialSwitch_thumbIconTintMode:I

.field public static MaterialSwitch_trackDecoration:I

.field public static MaterialSwitch_trackDecorationTint:I

.field public static MaterialSwitch_trackDecorationTintMode:I

.field public static final MaterialTextAppearance:[I

.field public static MaterialTextAppearance_android_fontVariationSettings:I

.field public static MaterialTextAppearance_android_letterSpacing:I

.field public static MaterialTextAppearance_android_lineHeight:I

.field public static MaterialTextAppearance_fontVariationSettings:I

.field public static MaterialTextAppearance_lineHeight:I

.field public static final MaterialTextView:[I

.field public static MaterialTextView_android_lineHeight:I

.field public static MaterialTextView_android_textAppearance:I

.field public static MaterialTextView_lineHeight:I

.field public static final MaterialTimePicker:[I

.field public static MaterialTimePicker_backgroundTint:I

.field public static MaterialTimePicker_clockIcon:I

.field public static MaterialTimePicker_keyboardIcon:I

.field public static final MaterialToolbar:[I

.field public static MaterialToolbar_logoAdjustViewBounds:I

.field public static MaterialToolbar_logoScaleType:I

.field public static MaterialToolbar_navigationIconTint:I

.field public static MaterialToolbar_subtitleCentered:I

.field public static MaterialToolbar_titleCentered:I

.field public static final MenuGroup:[I

.field public static MenuGroup_android_checkableBehavior:I

.field public static MenuGroup_android_enabled:I

.field public static MenuGroup_android_id:I

.field public static MenuGroup_android_menuCategory:I

.field public static MenuGroup_android_orderInCategory:I

.field public static MenuGroup_android_visible:I

.field public static final MenuItem:[I

.field public static MenuItem_actionLayout:I

.field public static MenuItem_actionProviderClass:I

.field public static MenuItem_actionViewClass:I

.field public static MenuItem_alphabeticModifiers:I

.field public static MenuItem_android_alphabeticShortcut:I

.field public static MenuItem_android_checkable:I

.field public static MenuItem_android_checked:I

.field public static MenuItem_android_enabled:I

.field public static MenuItem_android_icon:I

.field public static MenuItem_android_id:I

.field public static MenuItem_android_menuCategory:I

.field public static MenuItem_android_numericShortcut:I

.field public static MenuItem_android_onClick:I

.field public static MenuItem_android_orderInCategory:I

.field public static MenuItem_android_title:I

.field public static MenuItem_android_titleCondensed:I

.field public static MenuItem_android_visible:I

.field public static MenuItem_contentDescription:I

.field public static MenuItem_iconTint:I

.field public static MenuItem_iconTintMode:I

.field public static MenuItem_numericModifiers:I

.field public static MenuItem_showAsAction:I

.field public static MenuItem_tooltipText:I

.field public static final MenuView:[I

.field public static MenuView_android_headerBackground:I

.field public static MenuView_android_horizontalDivider:I

.field public static MenuView_android_itemBackground:I

.field public static MenuView_android_itemIconDisabledAlpha:I

.field public static MenuView_android_itemTextAppearance:I

.field public static MenuView_android_verticalDivider:I

.field public static MenuView_android_windowAnimationStyle:I

.field public static MenuView_preserveIconSpacing:I

.field public static MenuView_subMenuArrow:I

.field public static final MockView:[I

.field public static MockView_mock_diagonalsColor:I

.field public static MockView_mock_label:I

.field public static MockView_mock_labelBackgroundColor:I

.field public static MockView_mock_labelColor:I

.field public static MockView_mock_showDiagonals:I

.field public static MockView_mock_showLabel:I

.field public static final Motion:[I

.field public static final MotionEffect:[I

.field public static MotionEffect_motionEffect_alpha:I

.field public static MotionEffect_motionEffect_end:I

.field public static MotionEffect_motionEffect_move:I

.field public static MotionEffect_motionEffect_start:I

.field public static MotionEffect_motionEffect_strict:I

.field public static MotionEffect_motionEffect_translationX:I

.field public static MotionEffect_motionEffect_translationY:I

.field public static MotionEffect_motionEffect_viewTransition:I

.field public static final MotionHelper:[I

.field public static MotionHelper_onHide:I

.field public static MotionHelper_onShow:I

.field public static final MotionLabel:[I

.field public static MotionLabel_android_autoSizeTextType:I

.field public static MotionLabel_android_fontFamily:I

.field public static MotionLabel_android_gravity:I

.field public static MotionLabel_android_shadowRadius:I

.field public static MotionLabel_android_text:I

.field public static MotionLabel_android_textColor:I

.field public static MotionLabel_android_textSize:I

.field public static MotionLabel_android_textStyle:I

.field public static MotionLabel_android_typeface:I

.field public static MotionLabel_borderRound:I

.field public static MotionLabel_borderRoundPercent:I

.field public static MotionLabel_scaleFromTextSize:I

.field public static MotionLabel_textBackground:I

.field public static MotionLabel_textBackgroundPanX:I

.field public static MotionLabel_textBackgroundPanY:I

.field public static MotionLabel_textBackgroundRotate:I

.field public static MotionLabel_textBackgroundZoom:I

.field public static MotionLabel_textOutlineColor:I

.field public static MotionLabel_textOutlineThickness:I

.field public static MotionLabel_textPanX:I

.field public static MotionLabel_textPanY:I

.field public static MotionLabel_textureBlurFactor:I

.field public static MotionLabel_textureEffect:I

.field public static MotionLabel_textureHeight:I

.field public static MotionLabel_textureWidth:I

.field public static final MotionLayout:[I

.field public static MotionLayout_applyMotionScene:I

.field public static MotionLayout_currentState:I

.field public static MotionLayout_layoutDescription:I

.field public static MotionLayout_motionDebug:I

.field public static MotionLayout_motionProgress:I

.field public static MotionLayout_showPaths:I

.field public static final MotionScene:[I

.field public static MotionScene_defaultDuration:I

.field public static MotionScene_layoutDuringTransition:I

.field public static final MotionTelltales:[I

.field public static MotionTelltales_telltales_tailColor:I

.field public static MotionTelltales_telltales_tailScale:I

.field public static MotionTelltales_telltales_velocityMode:I

.field public static Motion_animateCircleAngleTo:I

.field public static Motion_animateRelativeTo:I

.field public static Motion_drawPath:I

.field public static Motion_motionPathRotate:I

.field public static Motion_motionStagger:I

.field public static Motion_pathMotionArc:I

.field public static Motion_quantizeMotionInterpolator:I

.field public static Motion_quantizeMotionPhase:I

.field public static Motion_quantizeMotionSteps:I

.field public static Motion_transitionEasing:I

.field public static final MotoButtonBarLayout:[I

.field public static MotoButtonBarLayout_allowStacking:I

.field public static final MultiSelectListPreference:[I

.field public static MultiSelectListPreference_android_entries:I

.field public static MultiSelectListPreference_android_entryValues:I

.field public static MultiSelectListPreference_entries:I

.field public static MultiSelectListPreference_entryValues:I

.field public static final NavigationBarActiveIndicator:[I

.field public static NavigationBarActiveIndicator_android_color:I

.field public static NavigationBarActiveIndicator_android_height:I

.field public static NavigationBarActiveIndicator_android_width:I

.field public static NavigationBarActiveIndicator_expandedHeight:I

.field public static NavigationBarActiveIndicator_expandedMarginHorizontal:I

.field public static NavigationBarActiveIndicator_expandedWidth:I

.field public static NavigationBarActiveIndicator_marginHorizontal:I

.field public static NavigationBarActiveIndicator_shapeAppearance:I

.field public static final NavigationBarView:[I

.field public static NavigationBarView_activeIndicatorLabelPadding:I

.field public static NavigationBarView_backgroundTint:I

.field public static NavigationBarView_elevation:I

.field public static NavigationBarView_horizontalItemTextAppearanceActive:I

.field public static NavigationBarView_horizontalItemTextAppearanceInactive:I

.field public static NavigationBarView_iconLabelHorizontalSpacing:I

.field public static NavigationBarView_itemActiveIndicatorStyle:I

.field public static NavigationBarView_itemBackground:I

.field public static NavigationBarView_itemGravity:I

.field public static NavigationBarView_itemIconGravity:I

.field public static NavigationBarView_itemIconSize:I

.field public static NavigationBarView_itemIconTint:I

.field public static NavigationBarView_itemPaddingBottom:I

.field public static NavigationBarView_itemPaddingTop:I

.field public static NavigationBarView_itemRippleColor:I

.field public static NavigationBarView_itemTextAppearanceActive:I

.field public static NavigationBarView_itemTextAppearanceActiveBoldEnabled:I

.field public static NavigationBarView_itemTextAppearanceInactive:I

.field public static NavigationBarView_itemTextColor:I

.field public static NavigationBarView_labelVisibilityMode:I

.field public static NavigationBarView_measureBottomPaddingFromLabelBaseline:I

.field public static NavigationBarView_menu:I

.field public static final NavigationRailView:[I

.field public static NavigationRailView_contentMarginTop:I

.field public static NavigationRailView_expanded:I

.field public static NavigationRailView_headerLayout:I

.field public static NavigationRailView_headerMarginBottom:I

.field public static NavigationRailView_itemMinHeight:I

.field public static NavigationRailView_itemSpacing:I

.field public static NavigationRailView_menuGravity:I

.field public static NavigationRailView_paddingBottomSystemWindowInsets:I

.field public static NavigationRailView_paddingStartSystemWindowInsets:I

.field public static NavigationRailView_paddingTopSystemWindowInsets:I

.field public static NavigationRailView_scrollingEnabled:I

.field public static NavigationRailView_shapeAppearance:I

.field public static NavigationRailView_shapeAppearanceOverlay:I

.field public static final NavigationView:[I

.field public static NavigationView_android_background:I

.field public static NavigationView_android_fitsSystemWindows:I

.field public static NavigationView_android_layout_gravity:I

.field public static NavigationView_android_maxWidth:I

.field public static NavigationView_bottomInsetScrimEnabled:I

.field public static NavigationView_dividerInsetEnd:I

.field public static NavigationView_dividerInsetStart:I

.field public static NavigationView_drawerLayoutCornerSize:I

.field public static NavigationView_elevation:I

.field public static NavigationView_endInsetScrimEnabled:I

.field public static NavigationView_headerLayout:I

.field public static NavigationView_itemBackground:I

.field public static NavigationView_itemHorizontalPadding:I

.field public static NavigationView_itemIconPadding:I

.field public static NavigationView_itemIconSize:I

.field public static NavigationView_itemIconTint:I

.field public static NavigationView_itemMaxLines:I

.field public static NavigationView_itemRippleColor:I

.field public static NavigationView_itemShapeAppearance:I

.field public static NavigationView_itemShapeAppearanceOverlay:I

.field public static NavigationView_itemShapeFillColor:I

.field public static NavigationView_itemShapeInsetBottom:I

.field public static NavigationView_itemShapeInsetEnd:I

.field public static NavigationView_itemShapeInsetStart:I

.field public static NavigationView_itemShapeInsetTop:I

.field public static NavigationView_itemTextAppearance:I

.field public static NavigationView_itemTextAppearanceActiveBoldEnabled:I

.field public static NavigationView_itemTextColor:I

.field public static NavigationView_itemVerticalPadding:I

.field public static NavigationView_menu:I

.field public static NavigationView_shapeAppearance:I

.field public static NavigationView_shapeAppearanceOverlay:I

.field public static NavigationView_startInsetScrimEnabled:I

.field public static NavigationView_subheaderColor:I

.field public static NavigationView_subheaderInsetEnd:I

.field public static NavigationView_subheaderInsetStart:I

.field public static NavigationView_subheaderTextAppearance:I

.field public static NavigationView_topInsetScrimEnabled:I

.field public static final OnClick:[I

.field public static OnClick_clickAction:I

.field public static OnClick_targetId:I

.field public static final OnSwipe:[I

.field public static OnSwipe_autoCompleteMode:I

.field public static OnSwipe_dragDirection:I

.field public static OnSwipe_dragScale:I

.field public static OnSwipe_dragThreshold:I

.field public static OnSwipe_limitBoundsTo:I

.field public static OnSwipe_maxAcceleration:I

.field public static OnSwipe_maxVelocity:I

.field public static OnSwipe_moveWhenScrollAtTop:I

.field public static OnSwipe_nestedScrollFlags:I

.field public static OnSwipe_onTouchUp:I

.field public static OnSwipe_rotationCenterId:I

.field public static OnSwipe_springBoundary:I

.field public static OnSwipe_springDamping:I

.field public static OnSwipe_springMass:I

.field public static OnSwipe_springStiffness:I

.field public static OnSwipe_springStopThreshold:I

.field public static OnSwipe_touchAnchorId:I

.field public static OnSwipe_touchAnchorSide:I

.field public static OnSwipe_touchRegionId:I

.field public static final PagedView:[I

.field public static PagedView_pageIndicator:I

.field public static final PersonalWorkSlidingTabStrip:[I

.field public static PersonalWorkSlidingTabStrip_alignOnIcon:I

.field public static final PopupWindow:[I

.field public static final PopupWindowBackgroundState:[I

.field public static PopupWindowBackgroundState_state_above_anchor:I

.field public static PopupWindow_android_popupAnimationStyle:I

.field public static PopupWindow_android_popupBackground:I

.field public static PopupWindow_overlapAnchor:I

.field public static final Preference:[I

.field public static final PreferenceFragment:[I

.field public static final PreferenceFragmentCompat:[I

.field public static PreferenceFragmentCompat_allowDividerAfterLastItem:I

.field public static PreferenceFragmentCompat_android_divider:I

.field public static PreferenceFragmentCompat_android_dividerHeight:I

.field public static PreferenceFragmentCompat_android_layout:I

.field public static PreferenceFragment_allowDividerAfterLastItem:I

.field public static PreferenceFragment_android_divider:I

.field public static PreferenceFragment_android_dividerHeight:I

.field public static PreferenceFragment_android_layout:I

.field public static final PreferenceGroup:[I

.field public static PreferenceGroup_android_orderingFromXml:I

.field public static PreferenceGroup_initialExpandedChildrenCount:I

.field public static PreferenceGroup_orderingFromXml:I

.field public static final PreferenceImageView:[I

.field public static PreferenceImageView_android_maxHeight:I

.field public static PreferenceImageView_android_maxWidth:I

.field public static PreferenceImageView_maxHeight:I

.field public static PreferenceImageView_maxWidth:I

.field public static final PreferenceTheme:[I

.field public static PreferenceTheme_checkBoxPreferenceStyle:I

.field public static PreferenceTheme_dialogPreferenceStyle:I

.field public static PreferenceTheme_dropdownPreferenceStyle:I

.field public static PreferenceTheme_editTextPreferenceStyle:I

.field public static PreferenceTheme_preferenceCategoryStyle:I

.field public static PreferenceTheme_preferenceCategoryTitleTextAppearance:I

.field public static PreferenceTheme_preferenceCategoryTitleTextColor:I

.field public static PreferenceTheme_preferenceFragmentCompatStyle:I

.field public static PreferenceTheme_preferenceFragmentListStyle:I

.field public static PreferenceTheme_preferenceFragmentStyle:I

.field public static PreferenceTheme_preferenceInformationStyle:I

.field public static PreferenceTheme_preferenceScreenStyle:I

.field public static PreferenceTheme_preferenceStyle:I

.field public static PreferenceTheme_preferenceTheme:I

.field public static PreferenceTheme_seekBarPreferenceStyle:I

.field public static PreferenceTheme_switchPreferenceCompatStyle:I

.field public static PreferenceTheme_switchPreferenceStyle:I

.field public static Preference_allowDividerAbove:I

.field public static Preference_allowDividerBelow:I

.field public static Preference_android_defaultValue:I

.field public static Preference_android_dependency:I

.field public static Preference_android_enabled:I

.field public static Preference_android_fragment:I

.field public static Preference_android_icon:I

.field public static Preference_android_iconSpaceReserved:I

.field public static Preference_android_key:I

.field public static Preference_android_layout:I

.field public static Preference_android_order:I

.field public static Preference_android_persistent:I

.field public static Preference_android_selectable:I

.field public static Preference_android_shouldDisableView:I

.field public static Preference_android_singleLineTitle:I

.field public static Preference_android_summary:I

.field public static Preference_android_title:I

.field public static Preference_android_widgetLayout:I

.field public static Preference_defaultValue:I

.field public static Preference_dependency:I

.field public static Preference_enableCopying:I

.field public static Preference_enabled:I

.field public static Preference_fragment:I

.field public static Preference_icon:I

.field public static Preference_iconSpaceReserved:I

.field public static Preference_isPreferenceVisible:I

.field public static Preference_key:I

.field public static Preference_layout:I

.field public static Preference_order:I

.field public static Preference_persistent:I

.field public static Preference_selectable:I

.field public static Preference_shouldDisableView:I

.field public static Preference_singleLineTitle:I

.field public static Preference_summary:I

.field public static Preference_title:I

.field public static Preference_widgetLayout:I

.field public static final PreviewFragment:[I

.field public static PreviewFragment_android_id:I

.field public static PreviewFragment_android_name:I

.field public static final ProfileDisplayOption:[I

.field public static ProfileDisplayOption_allAppsBorderSpace:I

.field public static ProfileDisplayOption_allAppsBorderSpaceHorizontal:I

.field public static ProfileDisplayOption_allAppsBorderSpaceLandscape:I

.field public static ProfileDisplayOption_allAppsBorderSpaceLandscapeHorizontal:I

.field public static ProfileDisplayOption_allAppsBorderSpaceLandscapeVertical:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscape:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscapeHorizontal:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscapeVertical:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortrait:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortraitHorizontal:I

.field public static ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortraitVertical:I

.field public static ProfileDisplayOption_allAppsBorderSpaceVertical:I

.field public static ProfileDisplayOption_allAppsCellHeight:I

.field public static ProfileDisplayOption_allAppsCellHeightLandscape:I

.field public static ProfileDisplayOption_allAppsCellHeightTwoPanelLandscape:I

.field public static ProfileDisplayOption_allAppsCellHeightTwoPanelPortrait:I

.field public static ProfileDisplayOption_allAppsCellWidth:I

.field public static ProfileDisplayOption_allAppsCellWidthLandscape:I

.field public static ProfileDisplayOption_allAppsCellWidthTwoPanelLandscape:I

.field public static ProfileDisplayOption_allAppsCellWidthTwoPanelPortrait:I

.field public static ProfileDisplayOption_allAppsIconSize:I

.field public static ProfileDisplayOption_allAppsIconSizeLandscape:I

.field public static ProfileDisplayOption_allAppsIconSizeTwoPanelLandscape:I

.field public static ProfileDisplayOption_allAppsIconSizeTwoPanelPortrait:I

.field public static ProfileDisplayOption_allAppsIconTextSize:I

.field public static ProfileDisplayOption_allAppsIconTextSizeTwoPanelLandscape:I

.field public static ProfileDisplayOption_allAppsIconTextSizeTwoPanelPortrait:I

.field public static ProfileDisplayOption_borderSpace:I

.field public static ProfileDisplayOption_borderSpaceHorizontal:I

.field public static ProfileDisplayOption_borderSpaceLandscape:I

.field public static ProfileDisplayOption_borderSpaceLandscapeHorizontal:I

.field public static ProfileDisplayOption_borderSpaceLandscapeVertical:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelLandscape:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelLandscapeHorizontal:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelLandscapeVertical:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelPortrait:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelPortraitHorizontal:I

.field public static ProfileDisplayOption_borderSpaceTwoPanelPortraitVertical:I

.field public static ProfileDisplayOption_borderSpaceVertical:I

.field public static ProfileDisplayOption_canBeDefault:I

.field public static ProfileDisplayOption_horizontalMargin:I

.field public static ProfileDisplayOption_horizontalMarginLandscape:I

.field public static ProfileDisplayOption_horizontalMarginTwoPanelLandscape:I

.field public static ProfileDisplayOption_horizontalMarginTwoPanelPortrait:I

.field public static ProfileDisplayOption_hotseatBarBottomSpace:I

.field public static ProfileDisplayOption_hotseatBarBottomSpaceLandscape:I

.field public static ProfileDisplayOption_hotseatBarBottomSpaceTwoPanelLandscape:I

.field public static ProfileDisplayOption_hotseatBarBottomSpaceTwoPanelPortrait:I

.field public static ProfileDisplayOption_hotseatQsbSpace:I

.field public static ProfileDisplayOption_hotseatQsbSpaceLandscape:I

.field public static ProfileDisplayOption_hotseatQsbSpaceTwoPanelLandscape:I

.field public static ProfileDisplayOption_hotseatQsbSpaceTwoPanelPortrait:I

.field public static ProfileDisplayOption_iconImageSize:I

.field public static ProfileDisplayOption_iconPaddings:I

.field public static ProfileDisplayOption_iconSizeLandscape:I

.field public static ProfileDisplayOption_iconSizeTwoPanelLandscape:I

.field public static ProfileDisplayOption_iconSizeTwoPanelPortrait:I

.field public static ProfileDisplayOption_iconTextSize:I

.field public static ProfileDisplayOption_iconTextSizeLandscape:I

.field public static ProfileDisplayOption_iconTextSizeTwoPanelLandscape:I

.field public static ProfileDisplayOption_iconTextSizeTwoPanelPortrait:I

.field public static ProfileDisplayOption_minCellHeight:I

.field public static ProfileDisplayOption_minCellHeightLandscape:I

.field public static ProfileDisplayOption_minCellHeightTwoPanelLandscape:I

.field public static ProfileDisplayOption_minCellHeightTwoPanelPortrait:I

.field public static ProfileDisplayOption_minCellWidth:I

.field public static ProfileDisplayOption_minCellWidthLandscape:I

.field public static ProfileDisplayOption_minCellWidthTwoPanelLandscape:I

.field public static ProfileDisplayOption_minCellWidthTwoPanelPortrait:I

.field public static ProfileDisplayOption_minHeightDps:I

.field public static ProfileDisplayOption_minWidthDps:I

.field public static ProfileDisplayOption_name:I

.field public static ProfileDisplayOption_startAlignTaskbar:I

.field public static ProfileDisplayOption_startAlignTaskbarLandscape:I

.field public static ProfileDisplayOption_startAlignTaskbarTwoPanelLandscape:I

.field public static ProfileDisplayOption_startAlignTaskbarTwoPanelPortrait:I

.field public static ProfileDisplayOption_transientTaskbarIconSize:I

.field public static ProfileDisplayOption_transientTaskbarIconSizeLandscape:I

.field public static ProfileDisplayOption_transientTaskbarIconSizeTwoPanelLandscape:I

.field public static ProfileDisplayOption_transientTaskbarIconSizeTwoPanelPortrait:I

.field public static final PropertySet:[I

.field public static PropertySet_android_alpha:I

.field public static PropertySet_android_visibility:I

.field public static PropertySet_layout_constraintTag:I

.field public static PropertySet_motionProgress:I

.field public static PropertySet_visibilityMode:I

.field public static final RadialViewGroup:[I

.field public static RadialViewGroup_materialCircleRadius:I

.field public static final RangeSlider:[I

.field public static RangeSlider_minSeparation:I

.field public static RangeSlider_values:I

.field public static final RecycleListView:[I

.field public static RecycleListView_paddingBottomNoButtons:I

.field public static RecycleListView_paddingTopNoTitle:I

.field public static final RecyclerView:[I

.field public static final RecyclerViewFastScroller:[I

.field public static RecyclerViewFastScroller_canThumbDetach:I

.field public static RecyclerView_android_clipToPadding:I

.field public static RecyclerView_android_descendantFocusability:I

.field public static RecyclerView_android_orientation:I

.field public static RecyclerView_fastScrollEnabled:I

.field public static RecyclerView_fastScrollHorizontalThumbDrawable:I

.field public static RecyclerView_fastScrollHorizontalTrackDrawable:I

.field public static RecyclerView_fastScrollVerticalThumbDrawable:I

.field public static RecyclerView_fastScrollVerticalTrackDrawable:I

.field public static RecyclerView_layoutManager:I

.field public static RecyclerView_reverseLayout:I

.field public static RecyclerView_spanCount:I

.field public static RecyclerView_stackFromEnd:I

.field public static final ResponsiveSpec:[I

.field public static final ResponsiveSpecGroup:[I

.field public static ResponsiveSpecGroup_maxAspectRatio:I

.field public static ResponsiveSpec_dimensionType:I

.field public static ResponsiveSpec_maxAvailableSize:I

.field public static final RootSandboxLayout:[I

.field public static RootSandboxLayout_onSurfaceBack:I

.field public static RootSandboxLayout_onSurfaceHome:I

.field public static RootSandboxLayout_onSurfaceOverview:I

.field public static RootSandboxLayout_secondaryBack:I

.field public static RootSandboxLayout_secondaryHome:I

.field public static RootSandboxLayout_secondaryOverview:I

.field public static RootSandboxLayout_surfaceBack:I

.field public static RootSandboxLayout_surfaceContainer:I

.field public static RootSandboxLayout_surfaceHome:I

.field public static RootSandboxLayout_surfaceOverview:I

.field public static RootSandboxLayout_tutorialSubtitle:I

.field public static final RoundedImageView:[I

.field public static RoundedImageView_cornerRadius:I

.field public static RoundedImageView_placeholderBg:I

.field public static RoundedImageView_shape:I

.field public static final RowStyle:[I

.field public static RowStyle_actionDividerHeight:I

.field public static RowStyle_bottomDividerEndPadding:I

.field public static RowStyle_bottomDividerStartPadding:I

.field public static RowStyle_contentEndPadding:I

.field public static RowStyle_contentStartPadding:I

.field public static RowStyle_disableRecyclerViewItemAnimator:I

.field public static RowStyle_endItemEndPadding:I

.field public static RowStyle_endItemStartPadding:I

.field public static RowStyle_iconSize:I

.field public static RowStyle_imageSize:I

.field public static RowStyle_progressBarEndPadding:I

.field public static RowStyle_progressBarInlineWidth:I

.field public static RowStyle_progressBarStartPadding:I

.field public static RowStyle_seekBarInlineWidth:I

.field public static RowStyle_subContentEndPadding:I

.field public static RowStyle_subContentStartPadding:I

.field public static RowStyle_subtitleColor:I

.field public static RowStyle_textActionPadding:I

.field public static RowStyle_tintColor:I

.field public static RowStyle_titleColor:I

.field public static RowStyle_titleEndPadding:I

.field public static RowStyle_titleItemEndPadding:I

.field public static RowStyle_titleItemStartPadding:I

.field public static RowStyle_titleStartPadding:I

.field public static final ScrimInsetsFrameLayout:[I

.field public static ScrimInsetsFrameLayout_insetForeground:I

.field public static final ScrollingViewBehavior_Layout:[I

.field public static ScrollingViewBehavior_Layout_behavior_overlapTop:I

.field public static final SearchBar:[I

.field public static SearchBar_android_hint:I

.field public static SearchBar_android_text:I

.field public static SearchBar_android_textAppearance:I

.field public static SearchBar_backgroundTint:I

.field public static SearchBar_defaultMarginsEnabled:I

.field public static SearchBar_defaultScrollFlagsEnabled:I

.field public static SearchBar_elevation:I

.field public static SearchBar_forceDefaultNavigationOnClickListener:I

.field public static SearchBar_hideNavigationIcon:I

.field public static SearchBar_navigationIconTint:I

.field public static SearchBar_strokeColor:I

.field public static SearchBar_strokeWidth:I

.field public static SearchBar_tintNavigationIcon:I

.field public static final SearchResultSuggestion:[I

.field public static SearchResultSuggestion_customIcon:I

.field public static SearchResultSuggestion_matchTextInsetWithQuery:I

.field public static final SearchView:[I

.field public static SearchView_android_focusable:I

.field public static SearchView_android_hint:I

.field public static SearchView_android_imeOptions:I

.field public static SearchView_android_inputType:I

.field public static SearchView_android_maxWidth:I

.field public static SearchView_android_text:I

.field public static SearchView_android_textAppearance:I

.field public static SearchView_animateMenuItems:I

.field public static SearchView_animateNavigationIcon:I

.field public static SearchView_autoShowKeyboard:I

.field public static SearchView_backHandlingEnabled:I

.field public static SearchView_backgroundTint:I

.field public static SearchView_closeIcon:I

.field public static SearchView_commitIcon:I

.field public static SearchView_defaultQueryHint:I

.field public static SearchView_goIcon:I

.field public static SearchView_headerLayout:I

.field public static SearchView_hideNavigationIcon:I

.field public static SearchView_iconifiedByDefault:I

.field public static SearchView_layout:I

.field public static SearchView_queryBackground:I

.field public static SearchView_queryHint:I

.field public static SearchView_searchHintIcon:I

.field public static SearchView_searchIcon:I

.field public static SearchView_searchPrefixText:I

.field public static SearchView_submitBackground:I

.field public static SearchView_suggestionRowLayout:I

.field public static SearchView_useDrawerArrowDrawable:I

.field public static SearchView_voiceIcon:I

.field public static final SeekBarPreference:[I

.field public static SeekBarPreference_adjustable:I

.field public static SeekBarPreference_android_layout:I

.field public static SeekBarPreference_android_max:I

.field public static SeekBarPreference_min:I

.field public static SeekBarPreference_seekBarIncrement:I

.field public static SeekBarPreference_showSeekBarValue:I

.field public static SeekBarPreference_updatesContinuously:I

.field public static final ShadowDrawable:[I

.field public static ShadowDrawable_android_elevation:I

.field public static ShadowDrawable_android_shadowColor:I

.field public static ShadowDrawable_android_src:I

.field public static ShadowDrawable_darkTintColor:I

.field public static final ShadowInfo:[I

.field public static ShadowInfo_ambientShadowBlur:I

.field public static ShadowInfo_ambientShadowColor:I

.field public static ShadowInfo_keyShadowBlur:I

.field public static ShadowInfo_keyShadowColor:I

.field public static ShadowInfo_keyShadowOffsetX:I

.field public static ShadowInfo_keyShadowOffsetY:I

.field public static final ShadowLayout:[I

.field public static ShadowLayout_offsetX:I

.field public static ShadowLayout_offsetY:I

.field public static ShadowLayout_shadowColor:I

.field public static ShadowLayout_shadowCornerRadius:I

.field public static ShadowLayout_shadowRadius:I

.field public static ShadowLayout_showInBottom:I

.field public static ShadowLayout_showInLeft:I

.field public static ShadowLayout_showInRight:I

.field public static ShadowLayout_showInTop:I

.field public static final ShapeAppearance:[I

.field public static ShapeAppearance_cornerFamily:I

.field public static ShapeAppearance_cornerFamilyBottomLeft:I

.field public static ShapeAppearance_cornerFamilyBottomRight:I

.field public static ShapeAppearance_cornerFamilyTopLeft:I

.field public static ShapeAppearance_cornerFamilyTopRight:I

.field public static ShapeAppearance_cornerSize:I

.field public static ShapeAppearance_cornerSizeBottomLeft:I

.field public static ShapeAppearance_cornerSizeBottomRight:I

.field public static ShapeAppearance_cornerSizeTopLeft:I

.field public static ShapeAppearance_cornerSizeTopRight:I

.field public static final ShapeableImageView:[I

.field public static ShapeableImageView_contentPadding:I

.field public static ShapeableImageView_contentPaddingBottom:I

.field public static ShapeableImageView_contentPaddingEnd:I

.field public static ShapeableImageView_contentPaddingLeft:I

.field public static ShapeableImageView_contentPaddingRight:I

.field public static ShapeableImageView_contentPaddingStart:I

.field public static ShapeableImageView_contentPaddingTop:I

.field public static ShapeableImageView_shapeAppearance:I

.field public static ShapeableImageView_shapeAppearanceOverlay:I

.field public static ShapeableImageView_strokeColor:I

.field public static ShapeableImageView_strokeWidth:I

.field public static final SideSheetBehavior_Layout:[I

.field public static SideSheetBehavior_Layout_android_elevation:I

.field public static SideSheetBehavior_Layout_android_maxHeight:I

.field public static SideSheetBehavior_Layout_android_maxWidth:I

.field public static SideSheetBehavior_Layout_backgroundTint:I

.field public static SideSheetBehavior_Layout_behavior_draggable:I

.field public static SideSheetBehavior_Layout_coplanarSiblingViewId:I

.field public static SideSheetBehavior_Layout_shapeAppearance:I

.field public static SideSheetBehavior_Layout_shapeAppearanceOverlay:I

.field public static final SizeSpec:[I

.field public static SizeSpec_fixedSize:I

.field public static SizeSpec_matchWorkspace:I

.field public static SizeSpec_maxSize:I

.field public static SizeSpec_ofAvailableSpace:I

.field public static SizeSpec_ofRemainderSpace:I

.field public static final SliceView:[I

.field public static SliceView_expandToAvailableHeight:I

.field public static SliceView_gridBottomPadding:I

.field public static SliceView_gridSubtitleSize:I

.field public static SliceView_gridTextVerticalPadding:I

.field public static SliceView_gridTitleSize:I

.field public static SliceView_gridTopPadding:I

.field public static SliceView_headerSubtitleSize:I

.field public static SliceView_headerTextVerticalPadding:I

.field public static SliceView_headerTitleSize:I

.field public static SliceView_hideHeaderRow:I

.field public static SliceView_imageCornerRadius:I

.field public static SliceView_rowInlineRangeHeight:I

.field public static SliceView_rowMaxHeight:I

.field public static SliceView_rowMinHeight:I

.field public static SliceView_rowRangeHeight:I

.field public static SliceView_rowRangeSingleTextHeight:I

.field public static SliceView_rowStyle:I

.field public static SliceView_subtitleColor:I

.field public static SliceView_subtitleSize:I

.field public static SliceView_textVerticalPadding:I

.field public static SliceView_tintColor:I

.field public static SliceView_titleColor:I

.field public static SliceView_titleSize:I

.field public static final Slider:[I

.field public static Slider_android_enabled:I

.field public static Slider_android_orientation:I

.field public static Slider_android_stepSize:I

.field public static Slider_android_value:I

.field public static Slider_android_valueFrom:I

.field public static Slider_android_valueTo:I

.field public static Slider_haloColor:I

.field public static Slider_haloRadius:I

.field public static Slider_labelBehavior:I

.field public static Slider_labelStyle:I

.field public static Slider_minTouchTargetSize:I

.field public static Slider_thumbColor:I

.field public static Slider_thumbElevation:I

.field public static Slider_thumbHeight:I

.field public static Slider_thumbRadius:I

.field public static Slider_thumbStrokeColor:I

.field public static Slider_thumbStrokeWidth:I

.field public static Slider_thumbTrackGapSize:I

.field public static Slider_thumbWidth:I

.field public static Slider_tickColor:I

.field public static Slider_tickColorActive:I

.field public static Slider_tickColorInactive:I

.field public static Slider_tickRadiusActive:I

.field public static Slider_tickRadiusInactive:I

.field public static Slider_tickVisible:I

.field public static Slider_trackColor:I

.field public static Slider_trackColorActive:I

.field public static Slider_trackColorInactive:I

.field public static Slider_trackCornerSize:I

.field public static Slider_trackHeight:I

.field public static Slider_trackIconActiveColor:I

.field public static Slider_trackIconActiveEnd:I

.field public static Slider_trackIconActiveStart:I

.field public static Slider_trackIconInactiveColor:I

.field public static Slider_trackIconInactiveEnd:I

.field public static Slider_trackIconInactiveStart:I

.field public static Slider_trackIconSize:I

.field public static Slider_trackInsideCornerSize:I

.field public static Slider_trackStopIndicatorSize:I

.field public static final SlidingPaneLayout:[I

.field public static final SlidingPaneLayout_Layout:[I

.field public static SlidingPaneLayout_Layout_android_layout_weight:I

.field public static SlidingPaneLayout_isChildClippingToResizeDividerEnabled:I

.field public static SlidingPaneLayout_isOverlappingEnabled:I

.field public static SlidingPaneLayout_isUserResizingEnabled:I

.field public static SlidingPaneLayout_userResizeBehavior:I

.field public static SlidingPaneLayout_userResizingDividerDrawable:I

.field public static final Snackbar:[I

.field public static final SnackbarLayout:[I

.field public static SnackbarLayout_actionTextColorAlpha:I

.field public static SnackbarLayout_android_maxWidth:I

.field public static SnackbarLayout_animationMode:I

.field public static SnackbarLayout_backgroundOverlayColorAlpha:I

.field public static SnackbarLayout_backgroundTint:I

.field public static SnackbarLayout_backgroundTintMode:I

.field public static SnackbarLayout_elevation:I

.field public static SnackbarLayout_maxActionInlineWidth:I

.field public static SnackbarLayout_shapeAppearance:I

.field public static SnackbarLayout_shapeAppearanceOverlay:I

.field public static Snackbar_snackbarButtonStyle:I

.field public static Snackbar_snackbarStyle:I

.field public static Snackbar_snackbarTextViewStyle:I

.field public static final Spinner:[I

.field public static Spinner_android_dropDownWidth:I

.field public static Spinner_android_entries:I

.field public static Spinner_android_popupBackground:I

.field public static Spinner_android_prompt:I

.field public static Spinner_popupTheme:I

.field public static final SplitPairFilter:[I

.field public static SplitPairFilter_primaryActivityName:I

.field public static SplitPairFilter_secondaryActivityAction:I

.field public static SplitPairFilter_secondaryActivityName:I

.field public static final SplitPairRule:[I

.field public static SplitPairRule_animationBackgroundColor:I

.field public static SplitPairRule_clearTop:I

.field public static SplitPairRule_finishPrimaryWithSecondary:I

.field public static SplitPairRule_finishSecondaryWithPrimary:I

.field public static SplitPairRule_splitChangeAnimation:I

.field public static SplitPairRule_splitCloseAnimation:I

.field public static SplitPairRule_splitLayoutDirection:I

.field public static SplitPairRule_splitMaxAspectRatioInLandscape:I

.field public static SplitPairRule_splitMaxAspectRatioInPortrait:I

.field public static SplitPairRule_splitMinHeightDp:I

.field public static SplitPairRule_splitMinSmallestWidthDp:I

.field public static SplitPairRule_splitMinWidthDp:I

.field public static SplitPairRule_splitOpenAnimation:I

.field public static SplitPairRule_splitRatio:I

.field public static SplitPairRule_tag:I

.field public static final SplitPlaceholderRule:[I

.field public static SplitPlaceholderRule_animationBackgroundColor:I

.field public static SplitPlaceholderRule_finishPrimaryWithPlaceholder:I

.field public static SplitPlaceholderRule_placeholderActivityName:I

.field public static SplitPlaceholderRule_splitChangeAnimation:I

.field public static SplitPlaceholderRule_splitCloseAnimation:I

.field public static SplitPlaceholderRule_splitLayoutDirection:I

.field public static SplitPlaceholderRule_splitMaxAspectRatioInLandscape:I

.field public static SplitPlaceholderRule_splitMaxAspectRatioInPortrait:I

.field public static SplitPlaceholderRule_splitMinHeightDp:I

.field public static SplitPlaceholderRule_splitMinSmallestWidthDp:I

.field public static SplitPlaceholderRule_splitMinWidthDp:I

.field public static SplitPlaceholderRule_splitOpenAnimation:I

.field public static SplitPlaceholderRule_splitRatio:I

.field public static SplitPlaceholderRule_stickyPlaceholder:I

.field public static SplitPlaceholderRule_tag:I

.field public static final State:[I

.field public static final StateListDrawable:[I

.field public static final StateListDrawableItem:[I

.field public static StateListDrawableItem_android_drawable:I

.field public static StateListDrawable_android_constantSize:I

.field public static StateListDrawable_android_dither:I

.field public static StateListDrawable_android_enterFadeDuration:I

.field public static StateListDrawable_android_exitFadeDuration:I

.field public static StateListDrawable_android_variablePadding:I

.field public static StateListDrawable_android_visible:I

.field public static final StateListSizeChange:[I

.field public static StateListSizeChange_widthChange:I

.field public static final StateSet:[I

.field public static StateSet_defaultState:I

.field public static State_android_id:I

.field public static State_constraints:I

.field public static final StickyScroller_Layout:[I

.field public static StickyScroller_Layout_layout_sticky:I

.field public static final SwitchCompat:[I

.field public static SwitchCompat_android_textOff:I

.field public static SwitchCompat_android_textOn:I

.field public static SwitchCompat_android_thumb:I

.field public static SwitchCompat_showText:I

.field public static SwitchCompat_splitTrack:I

.field public static SwitchCompat_switchMinWidth:I

.field public static SwitchCompat_switchPadding:I

.field public static SwitchCompat_switchTextAppearance:I

.field public static SwitchCompat_thumbTextPadding:I

.field public static SwitchCompat_thumbTint:I

.field public static SwitchCompat_thumbTintMode:I

.field public static SwitchCompat_track:I

.field public static SwitchCompat_trackTint:I

.field public static SwitchCompat_trackTintMode:I

.field public static final SwitchMaterial:[I

.field public static SwitchMaterial_useMaterialThemeColors:I

.field public static final SwitchPreference:[I

.field public static final SwitchPreferenceCompat:[I

.field public static SwitchPreferenceCompat_android_disableDependentsState:I

.field public static SwitchPreferenceCompat_android_summaryOff:I

.field public static SwitchPreferenceCompat_android_summaryOn:I

.field public static SwitchPreferenceCompat_android_switchTextOff:I

.field public static SwitchPreferenceCompat_android_switchTextOn:I

.field public static SwitchPreferenceCompat_disableDependentsState:I

.field public static SwitchPreferenceCompat_summaryOff:I

.field public static SwitchPreferenceCompat_summaryOn:I

.field public static SwitchPreferenceCompat_switchTextOff:I

.field public static SwitchPreferenceCompat_switchTextOn:I

.field public static SwitchPreference_android_disableDependentsState:I

.field public static SwitchPreference_android_summaryOff:I

.field public static SwitchPreference_android_summaryOn:I

.field public static SwitchPreference_android_switchTextOff:I

.field public static SwitchPreference_android_switchTextOn:I

.field public static SwitchPreference_disableDependentsState:I

.field public static SwitchPreference_summaryOff:I

.field public static SwitchPreference_summaryOn:I

.field public static SwitchPreference_switchTextOff:I

.field public static SwitchPreference_switchTextOn:I

.field public static final TabItem:[I

.field public static TabItem_android_icon:I

.field public static TabItem_android_layout:I

.field public static TabItem_android_text:I

.field public static final TabLayout:[I

.field public static TabLayout_tabBackground:I

.field public static TabLayout_tabContentStart:I

.field public static TabLayout_tabGravity:I

.field public static TabLayout_tabIconTint:I

.field public static TabLayout_tabIconTintMode:I

.field public static TabLayout_tabIndicator:I

.field public static TabLayout_tabIndicatorAnimationDuration:I

.field public static TabLayout_tabIndicatorAnimationMode:I

.field public static TabLayout_tabIndicatorColor:I

.field public static TabLayout_tabIndicatorFullWidth:I

.field public static TabLayout_tabIndicatorGravity:I

.field public static TabLayout_tabIndicatorHeight:I

.field public static TabLayout_tabInlineLabel:I

.field public static TabLayout_tabMaxWidth:I

.field public static TabLayout_tabMinWidth:I

.field public static TabLayout_tabMode:I

.field public static TabLayout_tabPadding:I

.field public static TabLayout_tabPaddingBottom:I

.field public static TabLayout_tabPaddingEnd:I

.field public static TabLayout_tabPaddingStart:I

.field public static TabLayout_tabPaddingTop:I

.field public static TabLayout_tabRippleColor:I

.field public static TabLayout_tabSelectedTextAppearance:I

.field public static TabLayout_tabSelectedTextColor:I

.field public static TabLayout_tabTextAppearance:I

.field public static TabLayout_tabTextColor:I

.field public static TabLayout_tabUnboundedRipple:I

.field public static final TaskView:[I

.field public static TaskView_borderColor:I

.field public static TaskView_focusBorderColor:I

.field public static TaskView_hoverBorderColor:I

.field public static final TextAppearance:[I

.field public static TextAppearance_android_fontFamily:I

.field public static TextAppearance_android_shadowColor:I

.field public static TextAppearance_android_shadowDx:I

.field public static TextAppearance_android_shadowDy:I

.field public static TextAppearance_android_shadowRadius:I

.field public static TextAppearance_android_textColor:I

.field public static TextAppearance_android_textColorHint:I

.field public static TextAppearance_android_textColorLink:I

.field public static TextAppearance_android_textFontWeight:I

.field public static TextAppearance_android_textSize:I

.field public static TextAppearance_android_textStyle:I

.field public static TextAppearance_android_typeface:I

.field public static TextAppearance_fontFamily:I

.field public static TextAppearance_fontVariationSettings:I

.field public static TextAppearance_textAllCaps:I

.field public static TextAppearance_textLocale:I

.field public static final TextEffects:[I

.field public static TextEffects_android_fontFamily:I

.field public static TextEffects_android_shadowColor:I

.field public static TextEffects_android_shadowDx:I

.field public static TextEffects_android_shadowDy:I

.field public static TextEffects_android_shadowRadius:I

.field public static TextEffects_android_text:I

.field public static TextEffects_android_textSize:I

.field public static TextEffects_android_textStyle:I

.field public static TextEffects_android_typeface:I

.field public static TextEffects_borderRound:I

.field public static TextEffects_borderRoundPercent:I

.field public static TextEffects_textFillColor:I

.field public static TextEffects_textOutlineColor:I

.field public static TextEffects_textOutlineThickness:I

.field public static final TextInputEditText:[I

.field public static TextInputEditText_textInputLayoutFocusedRectEnabled:I

.field public static final TextInputLayout:[I

.field public static TextInputLayout_android_enabled:I

.field public static TextInputLayout_android_hint:I

.field public static TextInputLayout_android_maxEms:I

.field public static TextInputLayout_android_maxWidth:I

.field public static TextInputLayout_android_minEms:I

.field public static TextInputLayout_android_minWidth:I

.field public static TextInputLayout_android_textColorHint:I

.field public static TextInputLayout_boxBackgroundColor:I

.field public static TextInputLayout_boxBackgroundMode:I

.field public static TextInputLayout_boxCollapsedPaddingTop:I

.field public static TextInputLayout_boxCornerRadiusBottomEnd:I

.field public static TextInputLayout_boxCornerRadiusBottomStart:I

.field public static TextInputLayout_boxCornerRadiusTopEnd:I

.field public static TextInputLayout_boxCornerRadiusTopStart:I

.field public static TextInputLayout_boxStrokeColor:I

.field public static TextInputLayout_boxStrokeErrorColor:I

.field public static TextInputLayout_boxStrokeWidth:I

.field public static TextInputLayout_boxStrokeWidthFocused:I

.field public static TextInputLayout_counterEnabled:I

.field public static TextInputLayout_counterMaxLength:I

.field public static TextInputLayout_counterOverflowTextAppearance:I

.field public static TextInputLayout_counterOverflowTextColor:I

.field public static TextInputLayout_counterTextAppearance:I

.field public static TextInputLayout_counterTextColor:I

.field public static TextInputLayout_cursorColor:I

.field public static TextInputLayout_cursorErrorColor:I

.field public static TextInputLayout_endIconCheckable:I

.field public static TextInputLayout_endIconContentDescription:I

.field public static TextInputLayout_endIconDrawable:I

.field public static TextInputLayout_endIconMinSize:I

.field public static TextInputLayout_endIconMode:I

.field public static TextInputLayout_endIconScaleType:I

.field public static TextInputLayout_endIconTint:I

.field public static TextInputLayout_endIconTintMode:I

.field public static TextInputLayout_errorAccessibilityLiveRegion:I

.field public static TextInputLayout_errorContentDescription:I

.field public static TextInputLayout_errorEnabled:I

.field public static TextInputLayout_errorIconDrawable:I

.field public static TextInputLayout_errorIconTint:I

.field public static TextInputLayout_errorIconTintMode:I

.field public static TextInputLayout_errorTextAppearance:I

.field public static TextInputLayout_errorTextColor:I

.field public static TextInputLayout_expandedHintEnabled:I

.field public static TextInputLayout_helperText:I

.field public static TextInputLayout_helperTextEnabled:I

.field public static TextInputLayout_helperTextTextAppearance:I

.field public static TextInputLayout_helperTextTextColor:I

.field public static TextInputLayout_hintAnimationEnabled:I

.field public static TextInputLayout_hintEnabled:I

.field public static TextInputLayout_hintMaxLines:I

.field public static TextInputLayout_hintTextAppearance:I

.field public static TextInputLayout_hintTextColor:I

.field public static TextInputLayout_passwordToggleContentDescription:I

.field public static TextInputLayout_passwordToggleDrawable:I

.field public static TextInputLayout_passwordToggleEnabled:I

.field public static TextInputLayout_passwordToggleTint:I

.field public static TextInputLayout_passwordToggleTintMode:I

.field public static TextInputLayout_placeholderText:I

.field public static TextInputLayout_placeholderTextAppearance:I

.field public static TextInputLayout_placeholderTextColor:I

.field public static TextInputLayout_prefixText:I

.field public static TextInputLayout_prefixTextAppearance:I

.field public static TextInputLayout_prefixTextColor:I

.field public static TextInputLayout_shapeAppearance:I

.field public static TextInputLayout_shapeAppearanceOverlay:I

.field public static TextInputLayout_startIconCheckable:I

.field public static TextInputLayout_startIconContentDescription:I

.field public static TextInputLayout_startIconDrawable:I

.field public static TextInputLayout_startIconMinSize:I

.field public static TextInputLayout_startIconScaleType:I

.field public static TextInputLayout_startIconTint:I

.field public static TextInputLayout_startIconTintMode:I

.field public static TextInputLayout_suffixText:I

.field public static TextInputLayout_suffixTextAppearance:I

.field public static TextInputLayout_suffixTextColor:I

.field public static final ThemeEnforcement:[I

.field public static ThemeEnforcement_android_textAppearance:I

.field public static ThemeEnforcement_enforceMaterialTheme:I

.field public static ThemeEnforcement_enforceTextAppearance:I

.field public static final Toolbar:[I

.field public static Toolbar_android_gravity:I

.field public static Toolbar_android_minHeight:I

.field public static Toolbar_buttonGravity:I

.field public static Toolbar_collapseContentDescription:I

.field public static Toolbar_collapseIcon:I

.field public static Toolbar_contentInsetEnd:I

.field public static Toolbar_contentInsetEndWithActions:I

.field public static Toolbar_contentInsetLeft:I

.field public static Toolbar_contentInsetRight:I

.field public static Toolbar_contentInsetStart:I

.field public static Toolbar_contentInsetStartWithNavigation:I

.field public static Toolbar_logo:I

.field public static Toolbar_logoDescription:I

.field public static Toolbar_maxButtonHeight:I

.field public static Toolbar_menu:I

.field public static Toolbar_navigationContentDescription:I

.field public static Toolbar_navigationIcon:I

.field public static Toolbar_popupTheme:I

.field public static Toolbar_subtitle:I

.field public static Toolbar_subtitleTextAppearance:I

.field public static Toolbar_subtitleTextColor:I

.field public static Toolbar_title:I

.field public static Toolbar_titleMargin:I

.field public static Toolbar_titleMarginBottom:I

.field public static Toolbar_titleMarginEnd:I

.field public static Toolbar_titleMarginStart:I

.field public static Toolbar_titleMarginTop:I

.field public static Toolbar_titleMargins:I

.field public static Toolbar_titleTextAppearance:I

.field public static Toolbar_titleTextColor:I

.field public static final Tooltip:[I

.field public static Tooltip_android_layout_margin:I

.field public static Tooltip_android_minHeight:I

.field public static Tooltip_android_minWidth:I

.field public static Tooltip_android_padding:I

.field public static Tooltip_android_text:I

.field public static Tooltip_android_textAppearance:I

.field public static Tooltip_android_textColor:I

.field public static Tooltip_backgroundTint:I

.field public static Tooltip_showMarker:I

.field public static final Transform:[I

.field public static Transform_android_elevation:I

.field public static Transform_android_rotation:I

.field public static Transform_android_rotationX:I

.field public static Transform_android_rotationY:I

.field public static Transform_android_scaleX:I

.field public static Transform_android_scaleY:I

.field public static Transform_android_transformPivotX:I

.field public static Transform_android_transformPivotY:I

.field public static Transform_android_translationX:I

.field public static Transform_android_translationY:I

.field public static Transform_android_translationZ:I

.field public static Transform_transformPivotTarget:I

.field public static final Transition:[I

.field public static Transition_android_id:I

.field public static Transition_autoTransition:I

.field public static Transition_constraintSetEnd:I

.field public static Transition_constraintSetStart:I

.field public static Transition_duration:I

.field public static Transition_layoutDuringTransition:I

.field public static Transition_motionInterpolator:I

.field public static Transition_pathMotionArc:I

.field public static Transition_staggered:I

.field public static Transition_transitionDisable:I

.field public static Transition_transitionFlags:I

.field public static final Variant:[I

.field public static Variant_constraints:I

.field public static Variant_region_heightLessThan:I

.field public static Variant_region_heightMoreThan:I

.field public static Variant_region_widthLessThan:I

.field public static Variant_region_widthMoreThan:I

.field public static final View:[I

.field public static final ViewBackgroundHelper:[I

.field public static ViewBackgroundHelper_android_background:I

.field public static ViewBackgroundHelper_backgroundTint:I

.field public static ViewBackgroundHelper_backgroundTintMode:I

.field public static final ViewPager2:[I

.field public static ViewPager2_android_orientation:I

.field public static final ViewStubCompat:[I

.field public static ViewStubCompat_android_id:I

.field public static ViewStubCompat_android_inflatedId:I

.field public static ViewStubCompat_android_layout:I

.field public static final ViewTransition:[I

.field public static ViewTransition_SharedValue:I

.field public static ViewTransition_SharedValueId:I

.field public static ViewTransition_android_id:I

.field public static ViewTransition_clearsTag:I

.field public static ViewTransition_duration:I

.field public static ViewTransition_ifTagNotSet:I

.field public static ViewTransition_ifTagSet:I

.field public static ViewTransition_motionInterpolator:I

.field public static ViewTransition_motionTarget:I

.field public static ViewTransition_onStateTransition:I

.field public static ViewTransition_pathMotionArc:I

.field public static ViewTransition_setsTag:I

.field public static ViewTransition_transitionDisable:I

.field public static ViewTransition_upDuration:I

.field public static ViewTransition_viewTransitionMode:I

.field public static View_android_focusable:I

.field public static View_android_theme:I

.field public static View_paddingEnd:I

.field public static View_paddingStart:I

.field public static View_theme:I

.field public static final WidgetSections:[I

.field public static WidgetSections_alsoKeepInApp:I

.field public static WidgetSections_category:I

.field public static WidgetSections_provider:I

.field public static WidgetSections_sectionDrawable:I

.field public static WidgetSections_sectionTitle:I

.field public static final WidgetsListRowHeader:[I

.field public static WidgetsListRowHeader_appIconSize:I

.field public static WidgetsListRowHeader_collapsable:I

.field public static final WorkspaceSpec:[I

.field public static WorkspaceSpec_dimensionType:I

.field public static WorkspaceSpec_maxAvailableSize:I

.field public static final include:[I

.field public static include_constraintSet:I


# direct methods
.method static constructor <clinit>()V
    .locals 41

    const/4 v0, 0x0

    const/16 v1, 0x1d

    .line 24573
    new-array v2, v1, [I

    fill-array-data v2, :array_0

    sput-object v2, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar:[I

    .line 24594
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_background:I

    const/4 v2, 0x1

    .line 24609
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_backgroundSplit:I

    const/4 v3, 0x2

    .line 24624
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_backgroundStacked:I

    const/4 v4, 0x3

    .line 24637
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetEnd:I

    const/4 v5, 0x4

    .line 24650
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetEndWithActions:I

    const/4 v6, 0x5

    .line 24663
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetLeft:I

    const/4 v7, 0x6

    .line 24676
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetRight:I

    const/4 v8, 0x7

    .line 24689
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetStart:I

    const/16 v9, 0x8

    .line 24702
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_contentInsetStartWithNavigation:I

    const/16 v10, 0x9

    .line 24714
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_customNavigationLayout:I

    const/16 v11, 0xa

    .line 24736
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_displayOptions:I

    const/16 v12, 0xb

    .line 24748
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_divider:I

    const/16 v13, 0xc

    .line 24761
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_elevation:I

    const/16 v14, 0xd

    .line 24774
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_height:I

    const/16 v15, 0xe

    .line 24784
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_hideOnContentScroll:I

    const/16 v16, 0xf

    .line 24796
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_homeAsUpIndicator:I

    const/16 v17, 0x10

    .line 24808
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_homeLayout:I

    const/16 v18, 0x11

    .line 24820
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_icon:I

    const/16 v19, 0x12

    .line 24832
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_indeterminateProgressStyle:I

    const/16 v20, 0x13

    .line 24845
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_itemPadding:I

    const/16 v21, 0x14

    .line 24857
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_logo:I

    const/16 v22, 0x15

    .line 24875
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_navigationMode:I

    move/from16 v23, v2

    const/16 v2, 0x16

    .line 24887
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_popupTheme:I

    move/from16 v24, v3

    const/16 v3, 0x17

    .line 24900
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_progressBarPadding:I

    move/from16 v25, v4

    const/16 v4, 0x18

    .line 24912
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_progressBarStyle:I

    move/from16 v26, v5

    const/16 v5, 0x19

    .line 24922
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_subtitle:I

    const/16 v27, 0x1a

    .line 24934
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_subtitleTextStyle:I

    move/from16 v28, v6

    const/16 v6, 0x1b

    .line 24944
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_title:I

    move/from16 v29, v8

    const/16 v8, 0x1c

    .line 24956
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ActionBar_titleTextStyle:I

    .line 24968
    filled-new-array {v0}, [I

    move-result-object v30

    sput-object v30, Lcom/motorola/plugin/sdk/R$styleable;->ActionBarLayout:[I

    .line 24999
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActionBarLayout_android_layout_gravity:I

    .line 25011
    filled-new-array {v0}, [I

    move-result-object v30

    sput-object v30, Lcom/motorola/plugin/sdk/R$styleable;->ActionMenuItemView:[I

    .line 25026
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActionMenuItemView_android_minWidth:I

    move/from16 v30, v10

    .line 25027
    new-array v10, v0, [I

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->ActionMenuView:[I

    .line 25050
    new-array v10, v7, [I

    fill-array-data v10, :array_1

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode:[I

    .line 25065
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_background:I

    .line 25080
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_backgroundSplit:I

    .line 25092
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_closeItemLayout:I

    .line 25105
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_height:I

    .line 25117
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_subtitleTextStyle:I

    .line 25129
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ActionMode_titleTextStyle:I

    .line 25143
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->ActivityChooserView:[I

    .line 25157
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActivityChooserView_expandActivityOverflowButtonDrawable:I

    .line 25167
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ActivityChooserView_initialActivityCount:I

    .line 25181
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->ActivityFilter:[I

    .line 25193
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActivityFilter_activityAction:I

    .line 25203
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ActivityFilter_activityName:I

    .line 25217
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->ActivityRule:[I

    .line 25229
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ActivityRule_alwaysExpand:I

    .line 25239
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ActivityRule_tag:I

    .line 25265
    new-array v10, v9, [I

    fill-array-data v10, :array_2

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog:[I

    .line 25281
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_buttonIconDimen:I

    .line 25293
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_buttonPanelSideLayout:I

    .line 25305
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_listItemLayout:I

    .line 25317
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_listLayout:I

    .line 25329
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_multiChoiceItemLayout:I

    .line 25339
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_showTitle:I

    .line 25351
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_singleChoiceItemLayout:I

    .line 25363
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->AlertDialog_android_layout:I

    .line 25377
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AllAppsSpec:[I

    .line 25397
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AllAppsSpec_dimensionType:I

    .line 25410
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AllAppsSpec_maxAvailableSize:I

    .line 25422
    filled-new-array {v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AllAppsStyle:[I

    .line 25437
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AllAppsStyle_horizontalPadding:I

    .line 25451
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AllSetLinkSpan:[I

    .line 25463
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AllSetLinkSpan_android_fontFamily:I

    .line 25476
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AllSetLinkSpan_android_textSize:I

    .line 25498
    new-array v10, v7, [I

    fill-array-data v10, :array_3

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat:[I

    .line 25511
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_constantSize:I

    .line 25521
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_dither:I

    .line 25530
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_enterFadeDuration:I

    .line 25539
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_exitFadeDuration:I

    .line 25549
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_variablePadding:I

    .line 25559
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableCompat_android_visible:I

    .line 25573
    filled-new-array {v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableItem:[I

    .line 25587
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableItem_android_drawable:I

    .line 25599
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableItem_android_id:I

    .line 25617
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableTransition:[I

    .line 25631
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableTransition_android_drawable:I

    .line 25643
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableTransition_android_fromId:I

    .line 25653
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableTransition_android_reversible:I

    .line 25665
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AnimatedStateListDrawableTransition_android_toId:I

    const/16 v10, 0x9

    .line 25693
    new-array v10, v10, [I

    fill-array-data v10, :array_4

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout:[I

    .line 25710
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_elevation:I

    .line 25720
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_expanded:I

    .line 25730
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_liftOnScroll:I

    .line 25741
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_liftOnScrollColor:I

    .line 25753
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_liftOnScrollTargetViewId:I

    .line 25764
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_statusBarForeground:I

    .line 25779
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_android_background:I

    .line 25789
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_android_keyboardNavigationCluster:I

    .line 25799
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_android_touchscreenBlocksFocus:I

    .line 25817
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayoutStates:[I

    .line 25829
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayoutStates_state_collapsed:I

    .line 25839
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayoutStates_state_collapsible:I

    .line 25849
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayoutStates_state_liftable:I

    .line 25859
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayoutStates_state_lifted:I

    .line 25875
    filled-new-array {v0, v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_Layout:[I

    .line 25896
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_Layout_layout_scrollEffect:I

    .line 25929
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_Layout_layout_scrollFlags:I

    .line 25941
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppBarLayout_Layout_layout_scrollInterpolator:I

    .line 25942
    new-array v10, v0, [I

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatEmojiHelper:[I

    .line 25961
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatImageView:[I

    .line 25975
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatImageView_srcCompat:I

    .line 25986
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatImageView_tint:I

    .line 26012
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatImageView_tintMode:I

    .line 26027
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatImageView_android_src:I

    .line 26045
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v10

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatSeekBar:[I

    .line 26059
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatSeekBar_tickMark:I

    .line 26070
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatSeekBar_tickMarkTint:I

    .line 26096
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatSeekBar_tickMarkTintMode:I

    .line 26108
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatSeekBar_android_thumb:I

    const/4 v10, 0x7

    .line 26132
    new-array v10, v10, [I

    fill-array-data v10, :array_5

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper:[I

    .line 26150
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableBottom:I

    .line 26165
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableEnd:I

    .line 26180
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableLeft:I

    .line 26195
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableRight:I

    .line 26210
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableStart:I

    .line 26225
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_drawableTop:I

    .line 26237
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextHelper_android_textAppearance:I

    .line 26291
    new-array v10, v2, [I

    fill-array-data v10, :array_6

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView:[I

    .line 26311
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_autoSizeMaxTextSize:I

    .line 26324
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_autoSizeMinTextSize:I

    .line 26336
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_autoSizePresetSizes:I

    .line 26349
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_autoSizeStepGranularity:I

    .line 26367
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_autoSizeTextType:I

    .line 26379
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableBottomCompat:I

    .line 26391
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableEndCompat:I

    .line 26403
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableLeftCompat:I

    .line 26415
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableRightCompat:I

    .line 26427
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableStartCompat:I

    .line 26438
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableTint:I

    .line 26464
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableTintMode:I

    .line 26476
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_drawableTopCompat:I

    .line 26486
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_emojiCompatEnabled:I

    .line 26499
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_firstBaselineToTopHeight:I

    .line 26509
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_fontFamily:I

    .line 26519
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_fontVariationSettings:I

    .line 26532
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_lastBaselineToBottomHeight:I

    .line 26545
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_lineHeight:I

    .line 26559
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_textAllCaps:I

    .line 26569
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_textLocale:I

    .line 26581
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTextView_android_textAppearance:I

    const/16 v10, 0x7f

    .line 26845
    new-array v10, v10, [I

    fill-array-data v10, :array_7

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme:[I

    .line 26890
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarDivider:I

    .line 26902
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarItemBackground:I

    .line 26914
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarPopupTheme:I

    .line 26935
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarSize:I

    .line 26947
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarSplitStyle:I

    .line 26959
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarStyle:I

    .line 26971
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarTabBarStyle:I

    .line 26983
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarTabStyle:I

    .line 26995
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarTabTextStyle:I

    .line 27007
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarTheme:I

    .line 27019
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionBarWidgetTheme:I

    .line 27031
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionButtonStyle:I

    .line 27043
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionDropDownStyle:I

    .line 27055
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionMenuTextAppearance:I

    .line 27070
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionMenuTextColor:I

    .line 27082
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeBackground:I

    .line 27094
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeCloseButtonStyle:I

    .line 27104
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeCloseContentDescription:I

    .line 27116
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeCloseDrawable:I

    .line 27128
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeCopyDrawable:I

    .line 27140
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeCutDrawable:I

    .line 27152
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeFindDrawable:I

    .line 27164
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModePasteDrawable:I

    .line 27176
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModePopupWindowStyle:I

    .line 27188
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeSelectAllDrawable:I

    .line 27200
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeShareDrawable:I

    .line 27212
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeSplitBackground:I

    .line 27224
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeStyle:I

    .line 27236
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeTheme:I

    .line 27248
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionModeWebSearchDrawable:I

    const/16 v10, 0x1e

    .line 27260
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionOverflowButtonStyle:I

    const/16 v31, 0x1f

    .line 27272
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_actionOverflowMenuStyle:I

    const/16 v32, 0x20

    .line 27284
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_activityChooserViewStyle:I

    const/16 v33, 0x21

    .line 27296
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_alertDialogButtonGroupStyle:I

    const/16 v34, 0x22

    .line 27306
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_alertDialogCenterButtons:I

    const/16 v35, 0x23

    .line 27318
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_alertDialogStyle:I

    move/from16 v36, v12

    const/16 v12, 0x24

    .line 27330
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_alertDialogTheme:I

    const/16 v37, 0x25

    .line 27342
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_autoCompleteTextViewStyle:I

    move/from16 v38, v13

    const/16 v13, 0x26

    .line 27354
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_borderlessButtonStyle:I

    move/from16 v39, v14

    const/16 v14, 0x27

    .line 27366
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonBarButtonStyle:I

    const/16 v40, 0x28

    .line 27378
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonBarNegativeButtonStyle:I

    const/16 v40, 0x29

    .line 27390
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonBarNeutralButtonStyle:I

    const/16 v40, 0x2a

    .line 27402
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonBarPositiveButtonStyle:I

    const/16 v40, 0x2b

    .line 27414
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonBarStyle:I

    const/16 v40, 0x2c

    .line 27426
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonStyle:I

    const/16 v40, 0x2d

    .line 27438
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_buttonStyleSmall:I

    const/16 v40, 0x2e

    .line 27450
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_checkboxStyle:I

    const/16 v40, 0x2f

    .line 27462
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_checkedTextViewStyle:I

    const/16 v40, 0x30

    .line 27473
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorAccent:I

    const/16 v40, 0x31

    .line 27484
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorBackgroundFloating:I

    const/16 v40, 0x32

    .line 27495
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorButtonNormal:I

    const/16 v40, 0x33

    .line 27506
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorControlActivated:I

    const/16 v40, 0x34

    .line 27517
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorControlHighlight:I

    const/16 v40, 0x35

    .line 27528
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorControlNormal:I

    const/16 v40, 0x36

    .line 27543
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorError:I

    const/16 v40, 0x37

    .line 27554
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorPrimary:I

    const/16 v40, 0x38

    .line 27565
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorPrimaryDark:I

    const/16 v40, 0x39

    .line 27576
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_colorSwitchThumbNormal:I

    const/16 v40, 0x3a

    .line 27588
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_controlBackground:I

    const/16 v40, 0x3b

    .line 27601
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dialogCornerRadius:I

    const/16 v40, 0x3c

    .line 27614
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dialogPreferredPadding:I

    const/16 v40, 0x3d

    .line 27626
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dialogTheme:I

    const/16 v40, 0x3e

    .line 27638
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dividerHorizontal:I

    const/16 v40, 0x3f

    .line 27650
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dividerVertical:I

    const/16 v40, 0x40

    .line 27662
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dropDownListViewStyle:I

    const/16 v40, 0x41

    .line 27675
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_dropdownListPreferredItemHeight:I

    const/16 v40, 0x42

    .line 27687
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_editTextBackground:I

    const/16 v40, 0x43

    .line 27702
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_editTextColor:I

    const/16 v40, 0x44

    .line 27714
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_editTextStyle:I

    const/16 v40, 0x45

    .line 27726
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_homeAsUpIndicator:I

    const/16 v40, 0x46

    .line 27738
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_imageButtonStyle:I

    const/16 v40, 0x47

    .line 27750
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listChoiceBackgroundIndicator:I

    const/16 v40, 0x48

    .line 27762
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listChoiceIndicatorMultipleAnimated:I

    const/16 v40, 0x49

    .line 27774
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listChoiceIndicatorSingleAnimated:I

    const/16 v40, 0x4a

    .line 27786
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listDividerAlertDialog:I

    const/16 v40, 0x4b

    .line 27798
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listMenuViewStyle:I

    const/16 v40, 0x4c

    .line 27810
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPopupWindowStyle:I

    const/16 v40, 0x4d

    .line 27823
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemHeight:I

    const/16 v40, 0x4e

    .line 27836
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemHeightLarge:I

    const/16 v40, 0x4f

    .line 27849
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemHeightSmall:I

    const/16 v40, 0x50

    .line 27862
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemPaddingEnd:I

    const/16 v40, 0x51

    .line 27875
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemPaddingLeft:I

    const/16 v40, 0x52

    .line 27888
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemPaddingRight:I

    const/16 v40, 0x53

    .line 27901
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_listPreferredItemPaddingStart:I

    const/16 v40, 0x54

    .line 27913
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_panelBackground:I

    const/16 v40, 0x55

    .line 27925
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_panelMenuListTheme:I

    const/16 v40, 0x56

    .line 27938
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_panelMenuListWidth:I

    const/16 v40, 0x57

    .line 27950
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_popupMenuStyle:I

    const/16 v40, 0x58

    .line 27962
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_popupWindowStyle:I

    const/16 v40, 0x59

    .line 27974
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_radioButtonStyle:I

    const/16 v40, 0x5a

    .line 27986
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_ratingBarStyle:I

    const/16 v40, 0x5b

    .line 27998
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_ratingBarStyleIndicator:I

    const/16 v40, 0x5c

    .line 28010
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_ratingBarStyleSmall:I

    const/16 v40, 0x5d

    .line 28022
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_searchViewStyle:I

    const/16 v40, 0x5e

    .line 28034
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_seekBarStyle:I

    const/16 v40, 0x5f

    .line 28046
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_selectableItemBackground:I

    const/16 v40, 0x60

    .line 28058
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_selectableItemBackgroundBorderless:I

    const/16 v40, 0x61

    .line 28070
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_spinnerDropDownItemStyle:I

    const/16 v40, 0x62

    .line 28082
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_spinnerStyle:I

    const/16 v40, 0x63

    .line 28094
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_switchStyle:I

    const/16 v40, 0x64

    .line 28106
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceLargePopupMenu:I

    const/16 v40, 0x65

    .line 28118
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceListItem:I

    const/16 v40, 0x66

    .line 28130
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceListItemSecondary:I

    const/16 v40, 0x67

    .line 28142
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceListItemSmall:I

    const/16 v40, 0x68

    .line 28154
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearancePopupMenuHeader:I

    const/16 v40, 0x69

    .line 28166
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceSearchResultSubtitle:I

    const/16 v40, 0x6a

    .line 28178
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceSearchResultTitle:I

    const/16 v40, 0x6b

    .line 28190
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textAppearanceSmallPopupMenu:I

    const/16 v40, 0x6c

    .line 28205
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textColorAlertDialogListItem:I

    const/16 v40, 0x6d

    .line 28220
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_textColorSearchUrl:I

    const/16 v40, 0x6e

    .line 28232
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_toolbarNavigationButtonStyle:I

    const/16 v40, 0x6f

    .line 28244
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_toolbarStyle:I

    const/16 v40, 0x70

    .line 28259
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_tooltipForegroundColor:I

    const/16 v40, 0x71

    .line 28271
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_tooltipFrameBackground:I

    const/16 v40, 0x72

    .line 28281
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_viewInflaterClass:I

    const/16 v40, 0x73

    .line 28291
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowActionBar:I

    const/16 v40, 0x74

    .line 28301
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowActionBarOverlay:I

    const/16 v40, 0x75

    .line 28311
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowActionModeOverlay:I

    const/16 v40, 0x76

    .line 28328
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowFixedHeightMajor:I

    const/16 v40, 0x77

    .line 28345
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowFixedHeightMinor:I

    const/16 v40, 0x78

    .line 28362
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowFixedWidthMajor:I

    const/16 v40, 0x79

    .line 28379
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowFixedWidthMinor:I

    const/16 v40, 0x7a

    .line 28396
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowMinWidthMajor:I

    const/16 v40, 0x7b

    .line 28413
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowMinWidthMinor:I

    const/16 v40, 0x7c

    .line 28423
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_windowNoTitle:I

    const/16 v40, 0x7d

    .line 28435
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_android_windowAnimationStyle:I

    const/16 v40, 0x7e

    .line 28445
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->AppCompatTheme_android_windowIsFloating:I

    .line 28459
    filled-new-array {v0, v0}, [I

    move-result-object v40

    sput-object v40, Lcom/motorola/plugin/sdk/R$styleable;->ArrowTipView:[I

    .line 28472
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ArrowTipView_arrowTipBackground:I

    .line 28483
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ArrowTipView_arrowTipTextColor:I

    .line 28497
    filled-new-array {v0, v0}, [I

    move-result-object v40

    sput-object v40, Lcom/motorola/plugin/sdk/R$styleable;->BackgroundStyle:[I

    .line 28511
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BackgroundStyle_selectableItemBackground:I

    .line 28523
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BackgroundStyle_android_selectableItemBackground:I

    move/from16 v40, v15

    .line 28589
    new-array v15, v8, [I

    fill-array-data v15, :array_8

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Badge:[I

    .line 28607
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Badge_autoAdjustToWithinGrandparentBounds:I

    .line 28618
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Badge_backgroundColor:I

    .line 28635
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeFixedEdge:I

    .line 28654
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeGravity:I

    .line 28667
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeHeight:I

    .line 28680
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeRadius:I

    .line 28692
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeShapeAppearance:I

    .line 28704
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeShapeAppearanceOverlay:I

    .line 28714
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeText:I

    .line 28726
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeTextAppearance:I

    .line 28737
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeTextColor:I

    .line 28750
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeVerticalPadding:I

    .line 28763
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWidePadding:I

    .line 28776
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWidth:I

    .line 28789
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWithTextHeight:I

    .line 28802
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWithTextRadius:I

    .line 28814
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWithTextShapeAppearance:I

    .line 28826
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWithTextShapeAppearanceOverlay:I

    .line 28839
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Badge_badgeWithTextWidth:I

    .line 28852
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Badge_horizontalOffset:I

    .line 28865
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Badge_horizontalOffsetWithText:I

    .line 28878
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Badge_largeFontVerticalOffsetAdjustment:I

    .line 28887
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Badge_maxCharacterCount:I

    .line 28896
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Badge_maxNumber:I

    .line 28905
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Badge_number:I

    .line 28924
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Badge_offsetAlignmentMode:I

    .line 28937
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Badge_verticalOffset:I

    .line 28950
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Badge_verticalOffsetWithText:I

    const/16 v15, 0x10

    .line 28992
    new-array v15, v15, [I

    fill-array-data v15, :array_9

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator:[I

    .line 29019
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_hideAnimationBehavior:I

    .line 29028
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_indeterminateAnimatorDurationScale:I

    .line 29043
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_indicatorColor:I

    .line 29056
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_indicatorTrackGapSize:I

    .line 29065
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_minHideDelay:I

    .line 29085
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_showAnimationBehavior:I

    .line 29094
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_showDelay:I

    .line 29105
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_trackColor:I

    .line 29118
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_trackCornerRadius:I

    .line 29131
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_trackThickness:I

    .line 29144
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_waveAmplitude:I

    .line 29157
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_waveSpeed:I

    .line 29170
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_wavelength:I

    .line 29183
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_wavelengthDeterminate:I

    .line 29196
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_wavelengthIndeterminate:I

    .line 29206
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->BaseProgressIndicator_android_indeterminate:I

    const/16 v15, 0x11

    .line 29250
    new-array v15, v15, [I

    fill-array-data v15, :array_a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar:[I

    .line 29266
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_addElevationShadow:I

    .line 29277
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_backgroundTint:I

    .line 29290
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_elevation:I

    .line 29307
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabAlignmentMode:I

    .line 29320
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabAlignmentModeEndMargin:I

    .line 29337
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabAnchorMode:I

    .line 29354
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabAnimationMode:I

    .line 29367
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabCradleMargin:I

    .line 29380
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabCradleRoundedCornerRadius:I

    .line 29393
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_fabCradleVerticalOffset:I

    .line 29403
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_hideOnScroll:I

    .line 29421
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_menuAlignmentMode:I

    .line 29432
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_navigationIconTint:I

    .line 29442
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_paddingBottomSystemWindowInsets:I

    .line 29452
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_paddingLeftSystemWindowInsets:I

    .line 29462
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_paddingRightSystemWindowInsets:I

    .line 29472
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->BottomAppBar_removeEmbeddedFabElevation:I

    .line 29492
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView:[I

    .line 29505
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView_compatShadowEnabled:I

    .line 29515
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView_itemHorizontalTranslationEnabled:I

    .line 29527
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView_shapeAppearance:I

    .line 29539
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView_shapeAppearanceOverlay:I

    .line 29552
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->BottomNavigationView_android_minHeight:I

    .line 29612
    new-array v15, v5, [I

    fill-array-data v15, :array_b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout:[I

    .line 29631
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_backgroundTint:I

    .line 29641
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_draggable:I

    .line 29651
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_draggableOnNestedScroll:I

    .line 29668
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_expandedOffset:I

    .line 29678
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_fitToContents:I

    .line 29691
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_halfExpandedRatio:I

    .line 29701
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_hideable:I

    .line 29722
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_peekHeight:I

    .line 29745
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_saveFlags:I

    .line 29758
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_significantVelocityThreshold:I

    .line 29768
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_behavior_skipCollapsed:I

    .line 29778
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_gestureInsetBottomIgnored:I

    .line 29788
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_marginLeftSystemWindowInsets:I

    .line 29798
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_marginRightSystemWindowInsets:I

    .line 29808
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_marginTopSystemWindowInsets:I

    .line 29818
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_paddingBottomSystemWindowInsets:I

    .line 29828
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_paddingLeftSystemWindowInsets:I

    .line 29838
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_paddingRightSystemWindowInsets:I

    .line 29848
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_paddingTopSystemWindowInsets:I

    .line 29860
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_shapeAppearance:I

    .line 29872
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_shapeAppearanceOverlay:I

    .line 29882
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_shouldRemoveExpandedCorners:I

    .line 29895
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_android_elevation:I

    .line 29908
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_android_maxHeight:I

    .line 29921
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->BottomSheetBehavior_Layout_android_maxWidth:I

    .line 29939
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->BubbleTextView:[I

    .line 29951
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->BubbleTextView_centerVertically:I

    .line 29977
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->BubbleTextView_iconDisplay:I

    .line 29990
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->BubbleTextView_iconSizeOverride:I

    .line 30000
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->BubbleTextView_layoutHorizontal:I

    .line 30012
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ButtonBarLayout:[I

    .line 30024
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ButtonBarLayout_allowStacking:I

    .line 30038
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Capability:[I

    .line 30052
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Capability_queryPatterns:I

    .line 30062
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Capability_shortcutMatchRequired:I

    const/16 v15, 0xd

    .line 30098
    new-array v15, v15, [I

    fill-array-data v15, :array_c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CardView:[I

    .line 30114
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardBackgroundColor:I

    .line 30127
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardCornerRadius:I

    .line 30140
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardElevation:I

    .line 30153
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardMaxElevation:I

    .line 30163
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardPreventCornerOverlap:I

    .line 30173
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->CardView_cardUseCompatPadding:I

    .line 30186
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->CardView_contentPadding:I

    .line 30199
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->CardView_contentPaddingBottom:I

    .line 30212
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->CardView_contentPaddingLeft:I

    .line 30225
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->CardView_contentPaddingRight:I

    .line 30238
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->CardView_contentPaddingTop:I

    .line 30251
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->CardView_android_minHeight:I

    .line 30264
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->CardView_android_minWidth:I

    const/16 v15, 0xb

    .line 30296
    new-array v15, v15, [I

    fill-array-data v15, :array_d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Carousel:[I

    .line 30317
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_alignment:I

    .line 30329
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_backwardTransition:I

    .line 30346
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_emptyViewsBehavior:I

    .line 30358
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_firstView:I

    .line 30370
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_forwardTransition:I

    .line 30380
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_infinite:I

    .line 30392
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_nextState:I

    .line 30404
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_previousState:I

    .line 30421
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_touchUpMode:I

    .line 30430
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_touchUp_dampeningFactor:I

    .line 30439
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Carousel_carousel_touchUp_velocityThreshold:I

    .line 30451
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CellLayout:[I

    .line 30472
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CellLayout_containerType:I

    .line 30486
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CellSpec:[I

    .line 30506
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CellSpec_dimensionType:I

    .line 30519
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CellSpec_maxAvailableSize:I

    .line 30531
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CellStyle:[I

    .line 30546
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CellStyle_iconDrawablePadding:I

    .line 30568
    new-array v15, v7, [I

    fill-array-data v15, :array_e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference:[I

    .line 30581
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_disableDependentsState:I

    .line 30591
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_summaryOff:I

    .line 30601
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_summaryOn:I

    .line 30611
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_android_disableDependentsState:I

    .line 30621
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_android_summaryOff:I

    .line 30631
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->CheckBoxPreference_android_summaryOn:I

    .line 30649
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CheckedTextView:[I

    .line 30663
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CheckedTextView_checkMarkCompat:I

    .line 30674
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CheckedTextView_checkMarkTint:I

    .line 30700
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CheckedTextView_checkMarkTintMode:I

    .line 30712
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CheckedTextView_android_checkMark:I

    const/16 v15, 0x2a

    .line 30806
    new-array v15, v15, [I

    fill-array-data v15, :array_f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Chip:[I

    .line 30830
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Chip_checkedIcon:I

    .line 30840
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Chip_checkedIconEnabled:I

    .line 30851
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Chip_checkedIconTint:I

    .line 30861
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Chip_checkedIconVisible:I

    .line 30872
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipBackgroundColor:I

    .line 30885
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipCornerRadius:I

    .line 30898
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipEndPadding:I

    .line 30910
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipIcon:I

    .line 30920
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipIconEnabled:I

    .line 30933
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipIconSize:I

    .line 30944
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipIconTint:I

    .line 30954
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipIconVisible:I

    .line 30967
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipMinHeight:I

    .line 30980
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipMinTouchTargetSize:I

    .line 30993
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipStartPadding:I

    .line 31004
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipStrokeColor:I

    .line 31017
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipStrokeWidth:I

    .line 31028
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Chip_chipSurfaceColor:I

    .line 31040
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIcon:I

    .line 31050
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconEnabled:I

    .line 31063
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconEndPadding:I

    .line 31076
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconSize:I

    .line 31089
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconStartPadding:I

    .line 31100
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconTint:I

    .line 31110
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Chip_closeIconVisible:I

    .line 31120
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Chip_ensureMinTouchTargetSize:I

    .line 31132
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Chip_hideMotionSpec:I

    .line 31145
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Chip_iconEndPadding:I

    .line 31158
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Chip_iconStartPadding:I

    .line 31169
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Chip_rippleColor:I

    .line 31181
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->Chip_shapeAppearance:I

    .line 31193
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->Chip_shapeAppearanceOverlay:I

    .line 31205
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->Chip_showMotionSpec:I

    .line 31218
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->Chip_textEndPadding:I

    .line 31231
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->Chip_textStartPadding:I

    .line 31241
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_checkable:I

    .line 31261
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_ellipsize:I

    .line 31274
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_maxWidth:I

    .line 31284
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_text:I

    .line 31296
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_textAppearance:I

    const/16 v15, 0x28

    .line 31311
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_textColor:I

    const/16 v15, 0x29

    .line 31324
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Chip_android_textSize:I

    const/4 v15, 0x7

    .line 31348
    new-array v15, v15, [I

    fill-array-data v15, :array_10

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup:[I

    .line 31363
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_checkedChip:I

    .line 31376
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_chipSpacing:I

    .line 31389
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_chipSpacingHorizontal:I

    .line 31402
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_chipSpacingVertical:I

    .line 31412
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_selectionRequired:I

    .line 31422
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_singleLine:I

    .line 31432
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ChipGroup_singleSelection:I

    .line 31452
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator:[I

    .line 31472
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator_indeterminateAnimationTypeCircular:I

    .line 31482
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator_indeterminateTrackVisible:I

    .line 31503
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator_indicatorDirectionCircular:I

    .line 31516
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator_indicatorInset:I

    .line 31529
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CircularProgressIndicator_indicatorSize:I

    .line 31541
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ClearAllButton:[I

    .line 31555
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ClearAllButton_focusBorderColor:I

    .line 31569
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ClockFaceView:[I

    .line 31582
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ClockFaceView_clockFaceBackgroundColor:I

    .line 31593
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ClockFaceView_clockNumberTextColor:I

    .line 31609
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ClockHandView:[I

    .line 31622
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ClockHandView_clockHandColor:I

    .line 31635
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ClockHandView_materialCircleRadius:I

    .line 31648
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ClockHandView_selectorSize:I

    .line 31664
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CollapsableTextView:[I

    .line 31677
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CollapsableTextView_isCollapsable:I

    .line 31706
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CollapsableTextView_android_gravity:I

    .line 31716
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CollapsableTextView_android_minLines:I

    .line 31774
    new-array v15, v4, [I

    fill-array-data v15, :array_11

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout:[I

    .line 31806
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_collapsedTitleGravity:I

    .line 31818
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_collapsedTitleTextAppearance:I

    .line 31833
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_collapsedTitleTextColor:I

    .line 31844
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_contentScrim:I

    .line 31869
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleGravity:I

    .line 31882
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleMargin:I

    .line 31895
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginBottom:I

    .line 31908
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginEnd:I

    .line 31921
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginStart:I

    .line 31934
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginTop:I

    .line 31946
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleTextAppearance:I

    .line 31961
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_expandedTitleTextColor:I

    .line 31971
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_extraMultilineHeightEnabled:I

    .line 31981
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_forceApplySystemWindowInsetTop:I

    .line 31990
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_maxLines:I

    .line 31999
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_scrimAnimationDuration:I

    .line 32012
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_scrimVisibleHeightTrigger:I

    .line 32023
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_statusBarScrim:I

    .line 32033
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_title:I

    .line 32050
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_titleCollapseMode:I

    .line 32060
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_titleEnabled:I

    .line 32072
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_titlePositionInterpolator:I

    .line 32091
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_titleTextEllipsize:I

    .line 32103
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_toolbarId:I

    .line 32117
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_Layout:[I

    .line 32138
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_Layout_layout_collapseMode:I

    .line 32147
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier:I

    .line 32167
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem:[I

    .line 32179
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem_alpha:I

    .line 32188
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem_lStar:I

    .line 32197
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem_android_alpha:I

    .line 32208
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem_android_color:I

    .line 32217
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ColorStateListItem_android_lStar:I

    .line 32235
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CompoundButton:[I

    .line 32249
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CompoundButton_buttonCompat:I

    .line 32260
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CompoundButton_buttonTint:I

    .line 32286
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CompoundButton_buttonTintMode:I

    .line 32298
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CompoundButton_android_button:I

    const/16 v15, 0x7c

    .line 32556
    new-array v15, v15, [I

    fill-array-data v15, :array_12

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint:[I

    .line 32608
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_animateCircleAngleTo:I

    .line 32620
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_animateRelativeTo:I

    .line 32630
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_barrierAllowsGoneWidgets:I

    .line 32651
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_barrierDirection:I

    .line 32664
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_barrierMargin:I

    .line 32674
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_chainUseRtl:I

    .line 32684
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_constraint_referenced_ids:I

    .line 32694
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_constraint_referenced_tags:I

    .line 32715
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_drawPath:I

    .line 32724
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_firstHorizontalBias:I

    .line 32742
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_firstHorizontalStyle:I

    .line 32751
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_firstVerticalBias:I

    .line 32769
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_firstVerticalStyle:I

    .line 32787
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_horizontalAlign:I

    .line 32796
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_horizontalBias:I

    .line 32809
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_horizontalGap:I

    .line 32827
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_horizontalStyle:I

    .line 32836
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_lastHorizontalBias:I

    .line 32854
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_lastHorizontalStyle:I

    .line 32863
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_lastVerticalBias:I

    .line 32881
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_lastVerticalStyle:I

    .line 32890
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_maxElementsWrap:I

    .line 32909
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_verticalAlign:I

    .line 32918
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_verticalBias:I

    .line 32931
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_verticalGap:I

    .line 32949
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_verticalStyle:I

    .line 32968
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_flow_wrapMode:I

    .line 32978
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_guidelineUseRtl:I

    .line 32988
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constrainedHeight:I

    .line 32998
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constrainedWidth:I

    .line 33007
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBaseline_creator:I

    .line 33027
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBaseline_toBaselineOf:I

    .line 33047
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBaseline_toBottomOf:I

    .line 33067
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBaseline_toTopOf:I

    .line 33076
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBottom_creator:I

    .line 33096
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBottom_toBottomOf:I

    .line 33116
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintBottom_toTopOf:I

    .line 33128
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintCircle:I

    .line 33137
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintCircleAngle:I

    .line 33150
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintCircleRadius:I

    const/16 v15, 0x28

    .line 33160
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintDimensionRatio:I

    const/16 v15, 0x29

    .line 33180
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintEnd_toEndOf:I

    const/16 v15, 0x2a

    .line 33200
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintEnd_toStartOf:I

    const/16 v15, 0x2b

    .line 33213
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintGuide_begin:I

    const/16 v15, 0x2c

    .line 33226
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintGuide_end:I

    const/16 v15, 0x2d

    .line 33235
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintGuide_percent:I

    const/16 v15, 0x2e

    .line 33261
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHeight:I

    const/16 v15, 0x2f

    .line 33279
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHeight_default:I

    const/16 v15, 0x30

    .line 33300
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHeight_max:I

    const/16 v15, 0x31

    .line 33321
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHeight_min:I

    const/16 v15, 0x32

    .line 33330
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHeight_percent:I

    const/16 v15, 0x33

    .line 33339
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHorizontal_bias:I

    const/16 v15, 0x34

    .line 33357
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHorizontal_chainStyle:I

    const/16 v15, 0x35

    .line 33366
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintHorizontal_weight:I

    const/16 v15, 0x36

    .line 33375
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintLeft_creator:I

    const/16 v15, 0x37

    .line 33395
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintLeft_toLeftOf:I

    const/16 v15, 0x38

    .line 33415
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintLeft_toRightOf:I

    const/16 v15, 0x39

    .line 33424
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintRight_creator:I

    const/16 v15, 0x3a

    .line 33444
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintRight_toLeftOf:I

    const/16 v15, 0x3b

    .line 33464
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintRight_toRightOf:I

    const/16 v15, 0x3c

    .line 33484
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintStart_toEndOf:I

    const/16 v15, 0x3d

    .line 33504
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintStart_toStartOf:I

    const/16 v15, 0x3e

    .line 33514
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintTag:I

    const/16 v15, 0x3f

    .line 33523
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintTop_creator:I

    const/16 v15, 0x40

    .line 33543
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintTop_toBottomOf:I

    const/16 v15, 0x41

    .line 33563
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintTop_toTopOf:I

    const/16 v15, 0x42

    .line 33572
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintVertical_bias:I

    const/16 v15, 0x43

    .line 33590
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintVertical_chainStyle:I

    const/16 v15, 0x44

    .line 33599
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintVertical_weight:I

    const/16 v15, 0x45

    .line 33625
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintWidth:I

    const/16 v15, 0x46

    .line 33643
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintWidth_default:I

    const/16 v15, 0x47

    .line 33664
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintWidth_max:I

    const/16 v15, 0x48

    .line 33685
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintWidth_min:I

    const/16 v15, 0x49

    .line 33694
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_constraintWidth_percent:I

    const/16 v15, 0x4a

    .line 33707
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_editor_absoluteX:I

    const/16 v15, 0x4b

    .line 33720
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_editor_absoluteY:I

    const/16 v15, 0x4c

    .line 33733
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginBaseline:I

    const/16 v15, 0x4d

    .line 33746
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginBottom:I

    const/16 v15, 0x4e

    .line 33759
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginEnd:I

    const/16 v15, 0x4f

    .line 33772
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginLeft:I

    const/16 v15, 0x50

    .line 33785
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginRight:I

    const/16 v15, 0x51

    .line 33798
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginStart:I

    const/16 v15, 0x52

    .line 33811
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_goneMarginTop:I

    const/16 v15, 0x53

    .line 33824
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_marginBaseline:I

    const/16 v15, 0x54

    .line 33843
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_layout_wrapBehaviorInParent:I

    const/16 v15, 0x55

    .line 33852
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_motionProgress:I

    const/16 v15, 0x56

    .line 33861
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_motionStagger:I

    const/16 v15, 0x57

    .line 33882
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_pathMotionArc:I

    const/16 v15, 0x58

    .line 33902
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_pivotAnchor:I

    const/16 v15, 0x59

    .line 33914
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_polarRelativeTo:I

    const/16 v15, 0x5a

    .line 33941
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_quantizeMotionInterpolator:I

    const/16 v15, 0x5b

    .line 33950
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_quantizeMotionPhase:I

    const/16 v15, 0x5c

    .line 33959
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_quantizeMotionSteps:I

    const/16 v15, 0x5d

    .line 33971
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_transformPivotTarget:I

    const/16 v15, 0x5e

    .line 33992
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_transitionEasing:I

    const/16 v15, 0x5f

    .line 34001
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_transitionPathRotate:I

    const/16 v15, 0x60

    .line 34018
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_visibilityMode:I

    const/16 v15, 0x61

    .line 34027
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_alpha:I

    const/16 v15, 0x62

    .line 34040
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_elevation:I

    const/16 v15, 0x63

    .line 34052
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_id:I

    const/16 v15, 0x64

    .line 34075
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_height:I

    const/16 v15, 0x65

    .line 34088
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginBottom:I

    const/16 v15, 0x66

    .line 34101
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginEnd:I

    const/16 v15, 0x67

    .line 34114
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginLeft:I

    const/16 v15, 0x68

    .line 34127
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginRight:I

    const/16 v15, 0x69

    .line 34140
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginStart:I

    const/16 v15, 0x6a

    .line 34153
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_marginTop:I

    const/16 v15, 0x6b

    .line 34176
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_layout_width:I

    const/16 v15, 0x6c

    .line 34189
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_maxHeight:I

    const/16 v15, 0x6d

    .line 34202
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_maxWidth:I

    const/16 v15, 0x6e

    .line 34215
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_minHeight:I

    const/16 v15, 0x6f

    .line 34228
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_minWidth:I

    const/16 v15, 0x70

    .line 34245
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_orientation:I

    const/16 v15, 0x71

    .line 34254
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_rotation:I

    const/16 v15, 0x72

    .line 34263
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_rotationX:I

    const/16 v15, 0x73

    .line 34272
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_rotationY:I

    const/16 v15, 0x74

    .line 34281
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_scaleX:I

    const/16 v15, 0x75

    .line 34290
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_scaleY:I

    const/16 v15, 0x76

    .line 34303
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_transformPivotX:I

    const/16 v15, 0x77

    .line 34316
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_transformPivotY:I

    const/16 v15, 0x78

    .line 34329
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_translationX:I

    const/16 v15, 0x79

    .line 34342
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_translationY:I

    const/16 v15, 0x7a

    .line 34355
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_translationZ:I

    const/16 v15, 0x7b

    .line 34373
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Constraint_android_visibility:I

    const/16 v15, 0x73

    .line 34613
    new-array v15, v15, [I

    fill-array-data v15, :array_13

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout:[I

    .line 34653
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_barrierAllowsGoneWidgets:I

    .line 34674
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_barrierDirection:I

    .line 34687
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_barrierMargin:I

    .line 34697
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_chainUseRtl:I

    .line 34707
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_circularflow_angles:I

    .line 34716
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_circularflow_defaultAngle:I

    .line 34729
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_circularflow_defaultRadius:I

    .line 34739
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_circularflow_radiusInDP:I

    .line 34751
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_circularflow_viewCenter:I

    .line 34763
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_constraintSet:I

    .line 34773
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_constraint_referenced_ids:I

    .line 34783
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_constraint_referenced_tags:I

    .line 34792
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_firstHorizontalBias:I

    .line 34810
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_firstHorizontalStyle:I

    .line 34819
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_firstVerticalBias:I

    .line 34837
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_firstVerticalStyle:I

    .line 34855
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_horizontalAlign:I

    .line 34864
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_horizontalBias:I

    .line 34877
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_horizontalGap:I

    .line 34895
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_horizontalStyle:I

    .line 34904
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_lastHorizontalBias:I

    .line 34922
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_lastHorizontalStyle:I

    .line 34931
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_lastVerticalBias:I

    .line 34949
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_lastVerticalStyle:I

    .line 34958
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_maxElementsWrap:I

    .line 34977
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_verticalAlign:I

    .line 34986
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_verticalBias:I

    .line 34999
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_verticalGap:I

    .line 35017
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_verticalStyle:I

    .line 35036
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_flow_wrapMode:I

    .line 35046
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_guidelineUseRtl:I

    .line 35058
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layoutDescription:I

    .line 35068
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constrainedHeight:I

    .line 35078
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constrainedWidth:I

    .line 35087
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBaseline_creator:I

    .line 35107
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf:I

    .line 35127
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf:I

    .line 35147
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBaseline_toTopOf:I

    .line 35156
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBottom_creator:I

    .line 35176
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBottom_toBottomOf:I

    const/16 v15, 0x28

    .line 35196
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintBottom_toTopOf:I

    const/16 v15, 0x29

    .line 35208
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintCircle:I

    const/16 v15, 0x2a

    .line 35217
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintCircleAngle:I

    const/16 v15, 0x2b

    .line 35230
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintCircleRadius:I

    const/16 v15, 0x2c

    .line 35240
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintDimensionRatio:I

    const/16 v15, 0x2d

    .line 35260
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintEnd_toEndOf:I

    const/16 v15, 0x2e

    .line 35280
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintEnd_toStartOf:I

    const/16 v15, 0x2f

    .line 35293
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintGuide_begin:I

    const/16 v15, 0x30

    .line 35306
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintGuide_end:I

    const/16 v15, 0x31

    .line 35315
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintGuide_percent:I

    const/16 v15, 0x32

    .line 35341
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHeight:I

    const/16 v15, 0x33

    .line 35359
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHeight_default:I

    const/16 v15, 0x34

    .line 35380
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHeight_max:I

    const/16 v15, 0x35

    .line 35401
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHeight_min:I

    const/16 v15, 0x36

    .line 35410
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHeight_percent:I

    const/16 v15, 0x37

    .line 35419
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHorizontal_bias:I

    const/16 v15, 0x38

    .line 35437
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle:I

    const/16 v15, 0x39

    .line 35446
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintHorizontal_weight:I

    const/16 v15, 0x3a

    .line 35455
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintLeft_creator:I

    const/16 v15, 0x3b

    .line 35475
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintLeft_toLeftOf:I

    const/16 v15, 0x3c

    .line 35495
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintLeft_toRightOf:I

    const/16 v15, 0x3d

    .line 35504
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintRight_creator:I

    const/16 v15, 0x3e

    .line 35524
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintRight_toLeftOf:I

    const/16 v15, 0x3f

    .line 35544
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintRight_toRightOf:I

    const/16 v15, 0x40

    .line 35564
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintStart_toEndOf:I

    const/16 v15, 0x41

    .line 35584
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintStart_toStartOf:I

    const/16 v15, 0x42

    .line 35594
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintTag:I

    const/16 v15, 0x43

    .line 35603
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintTop_creator:I

    const/16 v15, 0x44

    .line 35623
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintTop_toBottomOf:I

    const/16 v15, 0x45

    .line 35643
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintTop_toTopOf:I

    const/16 v15, 0x46

    .line 35652
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintVertical_bias:I

    const/16 v15, 0x47

    .line 35670
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintVertical_chainStyle:I

    const/16 v15, 0x48

    .line 35679
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintVertical_weight:I

    const/16 v15, 0x49

    .line 35705
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintWidth:I

    const/16 v15, 0x4a

    .line 35723
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintWidth_default:I

    const/16 v15, 0x4b

    .line 35744
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintWidth_max:I

    const/16 v15, 0x4c

    .line 35765
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintWidth_min:I

    const/16 v15, 0x4d

    .line 35774
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_constraintWidth_percent:I

    const/16 v15, 0x4e

    .line 35787
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_editor_absoluteX:I

    const/16 v15, 0x4f

    .line 35800
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_editor_absoluteY:I

    const/16 v15, 0x50

    .line 35813
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginBaseline:I

    const/16 v15, 0x51

    .line 35826
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginBottom:I

    const/16 v15, 0x52

    .line 35839
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginEnd:I

    const/16 v15, 0x53

    .line 35852
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginLeft:I

    const/16 v15, 0x54

    .line 35865
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginRight:I

    const/16 v15, 0x55

    .line 35878
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginStart:I

    const/16 v15, 0x56

    .line 35891
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_goneMarginTop:I

    const/16 v15, 0x57

    .line 35904
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_marginBaseline:I

    const/16 v15, 0x58

    .line 35933
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_optimizationLevel:I

    const/16 v15, 0x59

    .line 35952
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_layout_wrapBehaviorInParent:I

    const/16 v15, 0x5a

    .line 35965
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_elevation:I

    const/16 v15, 0x5b

    .line 35988
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_height:I

    const/16 v15, 0x5c

    .line 36001
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_margin:I

    const/16 v15, 0x5d

    .line 36014
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginBottom:I

    const/16 v15, 0x5e

    .line 36027
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginEnd:I

    const/16 v15, 0x5f

    .line 36040
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginHorizontal:I

    const/16 v15, 0x60

    .line 36053
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginLeft:I

    const/16 v15, 0x61

    .line 36066
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginRight:I

    const/16 v15, 0x62

    .line 36079
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginStart:I

    const/16 v15, 0x63

    .line 36092
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginTop:I

    const/16 v15, 0x64

    .line 36105
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_marginVertical:I

    const/16 v15, 0x65

    .line 36128
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_layout_width:I

    const/16 v15, 0x66

    .line 36141
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_maxHeight:I

    const/16 v15, 0x67

    .line 36154
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_maxWidth:I

    const/16 v15, 0x68

    .line 36167
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_minHeight:I

    const/16 v15, 0x69

    .line 36180
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_minWidth:I

    const/16 v15, 0x6a

    .line 36197
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_orientation:I

    const/16 v15, 0x6b

    .line 36210
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_padding:I

    const/16 v15, 0x6c

    .line 36223
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingBottom:I

    const/16 v15, 0x6d

    .line 36236
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingEnd:I

    const/16 v15, 0x6e

    .line 36249
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingLeft:I

    const/16 v15, 0x6f

    .line 36262
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingRight:I

    const/16 v15, 0x70

    .line 36275
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingStart:I

    const/16 v15, 0x71

    .line 36288
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_paddingTop:I

    const/16 v15, 0x72

    .line 36306
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_Layout_android_visibility:I

    .line 36324
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_ReactiveGuide:[I

    .line 36336
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_ReactiveGuide_reactiveGuide_animateChange:I

    .line 36346
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_ReactiveGuide_reactiveGuide_applyToAllConstraintSets:I

    .line 36358
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_ReactiveGuide_reactiveGuide_applyToConstraintSet:I

    .line 36370
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_ReactiveGuide_reactiveGuide_valueId:I

    .line 36384
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_placeholder:[I

    .line 36398
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_placeholder_content:I

    .line 36416
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintLayout_placeholder_placeholder_emptyVisibility:I

    const/16 v15, 0x6c

    .line 36642
    new-array v15, v15, [I

    fill-array-data v15, :array_14

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride:[I

    .line 36690
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_animateCircleAngleTo:I

    .line 36702
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_animateRelativeTo:I

    .line 36712
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_barrierAllowsGoneWidgets:I

    .line 36733
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_barrierDirection:I

    .line 36746
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_barrierMargin:I

    .line 36756
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_chainUseRtl:I

    .line 36766
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_constraint_referenced_ids:I

    .line 36787
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_drawPath:I

    .line 36796
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_firstHorizontalBias:I

    .line 36814
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_firstHorizontalStyle:I

    .line 36823
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_firstVerticalBias:I

    .line 36841
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_firstVerticalStyle:I

    .line 36859
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_horizontalAlign:I

    .line 36868
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_horizontalBias:I

    .line 36881
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_horizontalGap:I

    .line 36899
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_horizontalStyle:I

    .line 36908
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_lastHorizontalBias:I

    .line 36926
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_lastHorizontalStyle:I

    .line 36935
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_lastVerticalBias:I

    .line 36953
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_lastVerticalStyle:I

    .line 36962
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_maxElementsWrap:I

    .line 36981
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_verticalAlign:I

    .line 36990
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_verticalBias:I

    .line 37003
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_verticalGap:I

    .line 37021
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_verticalStyle:I

    .line 37040
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_flow_wrapMode:I

    .line 37050
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_guidelineUseRtl:I

    .line 37060
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constrainedHeight:I

    .line 37070
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constrainedWidth:I

    .line 37079
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintBaseline_creator:I

    .line 37088
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintBottom_creator:I

    .line 37097
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintCircleAngle:I

    .line 37110
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintCircleRadius:I

    .line 37120
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintDimensionRatio:I

    .line 37133
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintGuide_begin:I

    .line 37146
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintGuide_end:I

    .line 37155
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintGuide_percent:I

    .line 37181
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHeight:I

    .line 37199
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHeight_default:I

    .line 37220
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHeight_max:I

    const/16 v15, 0x28

    .line 37241
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHeight_min:I

    const/16 v15, 0x29

    .line 37250
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHeight_percent:I

    const/16 v15, 0x2a

    .line 37259
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHorizontal_bias:I

    const/16 v15, 0x2b

    .line 37277
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHorizontal_chainStyle:I

    const/16 v15, 0x2c

    .line 37286
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintHorizontal_weight:I

    const/16 v15, 0x2d

    .line 37295
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintLeft_creator:I

    const/16 v15, 0x2e

    .line 37304
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintRight_creator:I

    const/16 v15, 0x2f

    .line 37314
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintTag:I

    const/16 v15, 0x30

    .line 37323
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintTop_creator:I

    const/16 v15, 0x31

    .line 37332
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintVertical_bias:I

    const/16 v15, 0x32

    .line 37350
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintVertical_chainStyle:I

    const/16 v15, 0x33

    .line 37359
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintVertical_weight:I

    const/16 v15, 0x34

    .line 37385
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintWidth:I

    const/16 v15, 0x35

    .line 37403
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintWidth_default:I

    const/16 v15, 0x36

    .line 37424
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintWidth_max:I

    const/16 v15, 0x37

    .line 37445
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintWidth_min:I

    const/16 v15, 0x38

    .line 37454
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_constraintWidth_percent:I

    const/16 v15, 0x39

    .line 37467
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_editor_absoluteX:I

    const/16 v15, 0x3a

    .line 37480
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_editor_absoluteY:I

    const/16 v15, 0x3b

    .line 37493
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginBaseline:I

    const/16 v15, 0x3c

    .line 37506
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginBottom:I

    const/16 v15, 0x3d

    .line 37519
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginEnd:I

    const/16 v15, 0x3e

    .line 37532
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginLeft:I

    const/16 v15, 0x3f

    .line 37545
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginRight:I

    const/16 v15, 0x40

    .line 37558
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginStart:I

    const/16 v15, 0x41

    .line 37571
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_goneMarginTop:I

    const/16 v15, 0x42

    .line 37584
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_marginBaseline:I

    const/16 v15, 0x43

    .line 37603
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_layout_wrapBehaviorInParent:I

    const/16 v15, 0x44

    .line 37612
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_motionProgress:I

    const/16 v15, 0x45

    .line 37621
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_motionStagger:I

    const/16 v15, 0x46

    .line 37635
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_motionTarget:I

    const/16 v15, 0x47

    .line 37656
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_pathMotionArc:I

    const/16 v15, 0x48

    .line 37676
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_pivotAnchor:I

    const/16 v15, 0x49

    .line 37688
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_polarRelativeTo:I

    const/16 v15, 0x4a

    .line 37715
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_quantizeMotionInterpolator:I

    const/16 v15, 0x4b

    .line 37724
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_quantizeMotionPhase:I

    const/16 v15, 0x4c

    .line 37733
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_quantizeMotionSteps:I

    const/16 v15, 0x4d

    .line 37745
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_transformPivotTarget:I

    const/16 v15, 0x4e

    .line 37766
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_transitionEasing:I

    const/16 v15, 0x4f

    .line 37775
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_transitionPathRotate:I

    const/16 v15, 0x50

    .line 37792
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_visibilityMode:I

    const/16 v15, 0x51

    .line 37801
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_alpha:I

    const/16 v15, 0x52

    .line 37814
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_elevation:I

    const/16 v15, 0x53

    .line 37826
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_id:I

    const/16 v15, 0x54

    .line 37849
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_height:I

    const/16 v15, 0x55

    .line 37862
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginBottom:I

    const/16 v15, 0x56

    .line 37875
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginEnd:I

    const/16 v15, 0x57

    .line 37888
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginLeft:I

    const/16 v15, 0x58

    .line 37901
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginRight:I

    const/16 v15, 0x59

    .line 37914
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginStart:I

    const/16 v15, 0x5a

    .line 37927
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_marginTop:I

    const/16 v15, 0x5b

    .line 37950
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_layout_width:I

    const/16 v15, 0x5c

    .line 37963
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_maxHeight:I

    const/16 v15, 0x5d

    .line 37976
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_maxWidth:I

    const/16 v15, 0x5e

    .line 37989
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_minHeight:I

    const/16 v15, 0x5f

    .line 38002
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_minWidth:I

    const/16 v15, 0x60

    .line 38019
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_orientation:I

    const/16 v15, 0x61

    .line 38028
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_rotation:I

    const/16 v15, 0x62

    .line 38037
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_rotationX:I

    const/16 v15, 0x63

    .line 38046
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_rotationY:I

    const/16 v15, 0x64

    .line 38055
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_scaleX:I

    const/16 v15, 0x65

    .line 38064
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_scaleY:I

    const/16 v15, 0x66

    .line 38077
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_transformPivotX:I

    const/16 v15, 0x67

    .line 38090
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_transformPivotY:I

    const/16 v15, 0x68

    .line 38103
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_translationX:I

    const/16 v15, 0x69

    .line 38116
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_translationY:I

    const/16 v15, 0x6a

    .line 38129
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_translationZ:I

    const/16 v15, 0x6b

    .line 38147
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintOverride_android_visibility:I

    const/16 v15, 0x7b

    .line 38403
    new-array v15, v15, [I

    fill-array-data v15, :array_15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet:[I

    .line 38455
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_animateCircleAngleTo:I

    .line 38467
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_animateRelativeTo:I

    .line 38477
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_barrierAllowsGoneWidgets:I

    .line 38498
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_barrierDirection:I

    .line 38511
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_barrierMargin:I

    .line 38521
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_chainUseRtl:I

    .line 38541
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_constraintRotate:I

    .line 38551
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_constraint_referenced_ids:I

    .line 38561
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_constraint_referenced_tags:I

    .line 38573
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_deriveConstraintsFrom:I

    .line 38594
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_drawPath:I

    .line 38603
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_firstHorizontalBias:I

    .line 38621
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_firstHorizontalStyle:I

    .line 38630
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_firstVerticalBias:I

    .line 38648
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_firstVerticalStyle:I

    .line 38666
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_horizontalAlign:I

    .line 38675
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_horizontalBias:I

    .line 38688
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_horizontalGap:I

    .line 38706
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_horizontalStyle:I

    .line 38715
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_lastHorizontalBias:I

    .line 38733
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_lastHorizontalStyle:I

    .line 38742
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_lastVerticalBias:I

    .line 38760
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_lastVerticalStyle:I

    .line 38769
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_maxElementsWrap:I

    .line 38788
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_verticalAlign:I

    .line 38797
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_verticalBias:I

    .line 38810
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_verticalGap:I

    .line 38828
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_verticalStyle:I

    .line 38847
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_flow_wrapMode:I

    .line 38857
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_guidelineUseRtl:I

    .line 38867
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constrainedHeight:I

    .line 38877
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constrainedWidth:I

    .line 38886
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBaseline_creator:I

    .line 38906
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBaseline_toBaselineOf:I

    .line 38926
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBaseline_toBottomOf:I

    .line 38946
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBaseline_toTopOf:I

    .line 38955
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBottom_creator:I

    .line 38975
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBottom_toBottomOf:I

    .line 38995
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintBottom_toTopOf:I

    .line 39007
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintCircle:I

    const/16 v15, 0x28

    .line 39016
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintCircleAngle:I

    const/16 v15, 0x29

    .line 39029
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintCircleRadius:I

    const/16 v15, 0x2a

    .line 39039
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintDimensionRatio:I

    const/16 v15, 0x2b

    .line 39059
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintEnd_toEndOf:I

    const/16 v15, 0x2c

    .line 39079
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintEnd_toStartOf:I

    const/16 v15, 0x2d

    .line 39092
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintGuide_begin:I

    const/16 v15, 0x2e

    .line 39105
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintGuide_end:I

    const/16 v15, 0x2f

    .line 39114
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintGuide_percent:I

    const/16 v15, 0x30

    .line 39132
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHeight_default:I

    const/16 v15, 0x31

    .line 39153
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHeight_max:I

    const/16 v15, 0x32

    .line 39174
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHeight_min:I

    const/16 v15, 0x33

    .line 39183
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHeight_percent:I

    const/16 v15, 0x34

    .line 39192
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHorizontal_bias:I

    const/16 v15, 0x35

    .line 39210
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHorizontal_chainStyle:I

    const/16 v15, 0x36

    .line 39219
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintHorizontal_weight:I

    const/16 v15, 0x37

    .line 39228
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintLeft_creator:I

    const/16 v15, 0x38

    .line 39248
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintLeft_toLeftOf:I

    const/16 v15, 0x39

    .line 39268
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintLeft_toRightOf:I

    const/16 v15, 0x3a

    .line 39277
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintRight_creator:I

    const/16 v15, 0x3b

    .line 39297
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintRight_toLeftOf:I

    const/16 v15, 0x3c

    .line 39317
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintRight_toRightOf:I

    const/16 v15, 0x3d

    .line 39337
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintStart_toEndOf:I

    const/16 v15, 0x3e

    .line 39357
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintStart_toStartOf:I

    const/16 v15, 0x3f

    .line 39367
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintTag:I

    const/16 v15, 0x40

    .line 39376
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintTop_creator:I

    const/16 v15, 0x41

    .line 39396
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintTop_toBottomOf:I

    const/16 v15, 0x42

    .line 39416
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintTop_toTopOf:I

    const/16 v15, 0x43

    .line 39425
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintVertical_bias:I

    const/16 v15, 0x44

    .line 39443
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintVertical_chainStyle:I

    const/16 v15, 0x45

    .line 39452
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintVertical_weight:I

    const/16 v15, 0x46

    .line 39470
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintWidth_default:I

    const/16 v15, 0x47

    .line 39491
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintWidth_max:I

    const/16 v15, 0x48

    .line 39512
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintWidth_min:I

    const/16 v15, 0x49

    .line 39521
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_constraintWidth_percent:I

    const/16 v15, 0x4a

    .line 39534
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_editor_absoluteX:I

    const/16 v15, 0x4b

    .line 39547
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_editor_absoluteY:I

    const/16 v15, 0x4c

    .line 39560
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginBaseline:I

    const/16 v15, 0x4d

    .line 39573
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginBottom:I

    const/16 v15, 0x4e

    .line 39586
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginEnd:I

    const/16 v15, 0x4f

    .line 39599
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginLeft:I

    const/16 v15, 0x50

    .line 39612
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginRight:I

    const/16 v15, 0x51

    .line 39625
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginStart:I

    const/16 v15, 0x52

    .line 39638
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_goneMarginTop:I

    const/16 v15, 0x53

    .line 39651
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_marginBaseline:I

    const/16 v15, 0x54

    .line 39670
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_layout_wrapBehaviorInParent:I

    const/16 v15, 0x55

    .line 39679
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_motionProgress:I

    const/16 v15, 0x56

    .line 39688
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_motionStagger:I

    const/16 v15, 0x57

    .line 39709
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_pathMotionArc:I

    const/16 v15, 0x58

    .line 39729
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_pivotAnchor:I

    const/16 v15, 0x59

    .line 39741
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_polarRelativeTo:I

    const/16 v15, 0x5a

    .line 39750
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_quantizeMotionSteps:I

    const/16 v15, 0x5b

    .line 39760
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_stateLabels:I

    const/16 v15, 0x5c

    .line 39781
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_transitionEasing:I

    const/16 v15, 0x5d

    .line 39790
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_transitionPathRotate:I

    const/16 v15, 0x5e

    .line 39799
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_alpha:I

    const/16 v15, 0x5f

    .line 39812
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_elevation:I

    const/16 v15, 0x60

    .line 39824
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_id:I

    const/16 v15, 0x61

    .line 39847
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_height:I

    const/16 v15, 0x62

    .line 39860
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginBottom:I

    const/16 v15, 0x63

    .line 39873
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginEnd:I

    const/16 v15, 0x64

    .line 39886
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginLeft:I

    const/16 v15, 0x65

    .line 39899
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginRight:I

    const/16 v15, 0x66

    .line 39912
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginStart:I

    const/16 v15, 0x67

    .line 39925
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_marginTop:I

    const/16 v15, 0x68

    .line 39948
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_layout_width:I

    const/16 v15, 0x69

    .line 39961
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_maxHeight:I

    const/16 v15, 0x6a

    .line 39974
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_maxWidth:I

    const/16 v15, 0x6b

    .line 39987
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_minHeight:I

    const/16 v15, 0x6c

    .line 40000
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_minWidth:I

    const/16 v15, 0x6d

    .line 40017
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_orientation:I

    const/16 v15, 0x6e

    .line 40030
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_pivotX:I

    const/16 v15, 0x6f

    .line 40043
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_pivotY:I

    const/16 v15, 0x70

    .line 40052
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_rotation:I

    const/16 v15, 0x71

    .line 40061
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_rotationX:I

    const/16 v15, 0x72

    .line 40070
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_rotationY:I

    const/16 v15, 0x73

    .line 40079
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_scaleX:I

    const/16 v15, 0x74

    .line 40088
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_scaleY:I

    const/16 v15, 0x75

    .line 40101
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_transformPivotX:I

    const/16 v15, 0x76

    .line 40114
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_transformPivotY:I

    const/16 v15, 0x77

    .line 40127
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_translationX:I

    const/16 v15, 0x78

    .line 40140
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_translationY:I

    const/16 v15, 0x79

    .line 40153
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_translationZ:I

    const/16 v15, 0x7a

    .line 40171
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ConstraintSet_android_visibility:I

    .line 40185
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout:[I

    .line 40199
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_keylines:I

    .line 40214
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_statusBarBackground:I

    const/4 v15, 0x7

    .line 40238
    new-array v15, v15, [I

    fill-array-data v15, :array_16

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout:[I

    .line 40253
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_anchor:I

    .line 40288
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_anchorGravity:I

    .line 40298
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_behavior:I

    .line 40321
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_dodgeInsetEdges:I

    .line 40343
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_insetEdge:I

    .line 40352
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_layout_keyline:I

    .line 40381
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->CoordinatorLayout_Layout_android_layout_gravity:I

    const/16 v15, 0xb

    .line 40413
    new-array v15, v15, [I

    fill-array-data v15, :array_17

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute:[I

    .line 40427
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_attributeName:I

    .line 40437
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customBoolean:I

    .line 40448
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customColorDrawableValue:I

    .line 40459
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customColorValue:I

    .line 40472
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customDimension:I

    .line 40481
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customFloatValue:I

    .line 40490
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customIntegerValue:I

    .line 40503
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customPixelDimension:I

    .line 40515
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customReference:I

    .line 40525
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_customStringValue:I

    .line 40535
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->CustomAttribute_methodName:I

    .line 40547
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DevicePadding:[I

    .line 40562
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DevicePadding_maxEmptySpace:I

    .line 40578
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DevicePaddingFormula:[I

    .line 40594
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DevicePaddingFormula_a:I

    .line 40608
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DevicePaddingFormula_b:I

    .line 40622
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DevicePaddingFormula_c:I

    const/16 v15, 0xc

    .line 40656
    new-array v15, v15, [I

    fill-array-data v15, :array_18

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference:[I

    .line 40672
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_dialogIcon:I

    .line 40684
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_dialogLayout:I

    .line 40694
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_dialogMessage:I

    .line 40704
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_dialogTitle:I

    .line 40714
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_negativeButtonText:I

    .line 40724
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_positiveButtonText:I

    .line 40736
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_dialogIcon:I

    .line 40748
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_dialogLayout:I

    .line 40758
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_dialogMessage:I

    .line 40768
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_dialogTitle:I

    .line 40778
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_negativeButtonText:I

    .line 40788
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->DialogPreference_android_positiveButtonText:I

    .line 40810
    new-array v15, v7, [I

    fill-array-data v15, :array_19

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes:[I

    .line 40822
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_dragRangeMaxRatio:I

    .line 40831
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_dragRangeMinRatio:I

    .line 40846
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_embeddingDividerColor:I

    .line 40863
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_embeddingDividerType:I

    .line 40872
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_embeddingDividerWidthDp:I

    .line 40882
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DividerAttributes_isDraggingToFullscreenAllowed:I

    .line 40908
    new-array v15, v9, [I

    fill-array-data v15, :array_1a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare:[I

    .line 40920
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_ambientShadowAlpha:I

    .line 40933
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_ambientShadowBlur:I

    .line 40946
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_ambientShadowOffsetX:I

    .line 40959
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_ambientShadowOffsetY:I

    .line 40968
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_keyShadowAlpha:I

    .line 40981
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_keyShadowBlur:I

    .line 40994
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_keyShadowOffsetX:I

    .line 41007
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowAttrDeclare_keyShadowOffsetY:I

    .line 41037
    new-array v15, v11, [I

    fill-array-data v15, :array_1b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock:[I

    .line 41050
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_ambientShadowAlpha:I

    .line 41063
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_ambientShadowBlur:I

    .line 41076
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_ambientShadowOffsetX:I

    .line 41089
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_ambientShadowOffsetY:I

    .line 41098
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_keyShadowAlpha:I

    .line 41111
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_keyShadowBlur:I

    .line 41124
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_keyShadowOffsetX:I

    .line 41137
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_keyShadowOffsetY:I

    .line 41147
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_removeTextDescent:I

    .line 41161
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextClock_textDescentExtraPadding:I

    .line 41191
    new-array v15, v11, [I

    fill-array-data v15, :array_1c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView:[I

    .line 41204
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_ambientShadowAlpha:I

    .line 41217
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_ambientShadowBlur:I

    .line 41230
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_ambientShadowOffsetX:I

    .line 41243
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_ambientShadowOffsetY:I

    .line 41256
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_drawableIconInsetSize:I

    .line 41269
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_drawableIconSize:I

    .line 41278
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_keyShadowAlpha:I

    .line 41291
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_keyShadowBlur:I

    .line 41304
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_keyShadowOffsetX:I

    .line 41317
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->DoubleShadowTextView_keyShadowOffsetY:I

    .line 41343
    new-array v15, v9, [I

    fill-array-data v15, :array_1d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle:[I

    .line 41359
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_arrowHeadLength:I

    .line 41372
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_arrowShaftLength:I

    .line 41385
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_barLength:I

    .line 41396
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_color:I

    .line 41409
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_drawableSize:I

    .line 41422
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_gapBetweenBars:I

    .line 41432
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_spinBars:I

    .line 41445
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->DrawerArrowToggle_thickness:I

    .line 41457
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->DrawerLayout:[I

    .line 41472
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->DrawerLayout_elevation:I

    .line 41484
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->EditTextPreference:[I

    .line 41496
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->EditTextPreference_useSimpleSummaryProvider:I

    const/4 v15, 0x7

    .line 41520
    new-array v15, v15, [I

    fill-array-data v15, :array_1e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton:[I

    .line 41536
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_collapsedSize:I

    .line 41549
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_elevation:I

    .line 41561
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_extendMotionSpec:I

    .line 41579
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_extendStrategy:I

    .line 41591
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_hideMotionSpec:I

    .line 41603
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_showMotionSpec:I

    .line 41615
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_shrinkMotionSpec:I

    .line 41629
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_Behavior_Layout:[I

    .line 41641
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide:I

    .line 41651
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink:I

    .line 41665
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Extra:[I

    .line 41677
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Extra_key:I

    .line 41687
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Extra_value:I

    const/16 v15, 0xb

    .line 41719
    new-array v15, v15, [I

    fill-array-data v15, :array_1f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Favorite:[I

    .line 41733
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_className:I

    .line 41743
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_container:I

    .line 41755
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_icon:I

    .line 41765
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_packageName:I

    .line 41775
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_screen:I

    .line 41785
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_spanX:I

    .line 41795
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_spanY:I

    .line 41805
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_title:I

    .line 41815
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_uri:I

    .line 41825
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_x:I

    .line 41835
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Favorite_y:I

    const/16 v15, 0x11

    .line 41879
    new-array v15, v15, [I

    fill-array-data v15, :array_20

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton:[I

    .line 41896
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_backgroundTint:I

    .line 41922
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_backgroundTintMode:I

    .line 41935
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_borderWidth:I

    .line 41948
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_elevation:I

    .line 41958
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_ensureMinTouchTargetSize:I

    .line 41971
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_fabCustomSize:I

    .line 41989
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_fabSize:I

    .line 42001
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_hideMotionSpec:I

    .line 42014
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_hoveredFocusedTranslationZ:I

    .line 42027
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_maxImageSize:I

    .line 42040
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_pressedTranslationZ:I

    .line 42051
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_rippleColor:I

    .line 42063
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_shapeAppearance:I

    .line 42075
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_shapeAppearanceOverlay:I

    .line 42087
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_showMotionSpec:I

    .line 42097
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_useCompatPadding:I

    .line 42107
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_android_enabled:I

    .line 42119
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_Behavior_Layout:[I

    .line 42131
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FloatingActionButton_Behavior_Layout_behavior_autoHide:I

    .line 42143
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FloatingToolbar:[I

    .line 42156
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FloatingToolbar_backgroundTint:I

    .line 42170
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FlowLayout:[I

    .line 42185
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FlowLayout_horizontalItemSpacing:I

    .line 42198
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FlowLayout_lineSpacing:I

    .line 42214
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FolderIconPreview:[I

    .line 42227
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FolderIconPreview_allAppsFolderPreviewColor:I

    .line 42238
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FolderIconPreview_folderIconBorderColor:I

    .line 42249
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->FolderIconPreview_folderPreviewColor:I

    .line 42263
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FolderSpec:[I

    .line 42283
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FolderSpec_dimensionType:I

    .line 42296
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FolderSpec_maxAvailableSize:I

    .line 42318
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle:[I

    .line 42336
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle_folderBorderSpace:I

    .line 42351
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle_folderCellHeight:I

    .line 42365
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle_folderCellWidth:I

    .line 42379
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle_folderFooterHeight:I

    .line 42393
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->FolderStyle_folderTopPadding:I

    .line 42419
    new-array v15, v9, [I

    fill-array-data v15, :array_21

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily:[I

    .line 42432
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderAuthority:I

    .line 42444
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderCerts:I

    .line 42454
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderFallbackQuery:I

    .line 42479
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderFetchStrategy:I

    .line 42497
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderFetchTimeout:I

    .line 42507
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderPackage:I

    .line 42517
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderQuery:I

    .line 42527
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->FontFamily_fontProviderSystemFontFamily:I

    .line 42557
    new-array v15, v11, [I

    fill-array-data v15, :array_22

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont:[I

    .line 42573
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_font:I

    .line 42590
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_fontStyle:I

    .line 42600
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_fontVariationSettings:I

    .line 42609
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_fontWeight:I

    .line 42618
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_ttcIndex:I

    .line 42630
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_android_font:I

    .line 42647
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_android_fontStyle:I

    .line 42657
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_android_fontVariationSettings:I

    .line 42666
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_android_fontWeight:I

    .line 42675
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->FontFamilyFont_android_ttcIndex:I

    .line 42691
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ForegroundLinearLayout:[I

    .line 42703
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ForegroundLinearLayout_foregroundInsidePadding:I

    .line 42718
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ForegroundLinearLayout_android_foreground:I

    .line 42745
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ForegroundLinearLayout_android_foregroundGravity:I

    .line 42761
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Fragment:[I

    .line 42775
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Fragment_android_id:I

    .line 42785
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Fragment_android_name:I

    .line 42795
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Fragment_android_tag:I

    .line 42809
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->FragmentContainerView:[I

    .line 42821
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->FragmentContainerView_android_name:I

    .line 42831
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->FragmentContainerView_android_tag:I

    const/16 v15, 0xc

    .line 42865
    new-array v15, v15, [I

    fill-array-data v15, :array_23

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor:[I

    .line 42880
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_centerColor:I

    .line 42893
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_centerX:I

    .line 42906
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_centerY:I

    .line 42917
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_endColor:I

    .line 42926
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_endX:I

    .line 42935
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_endY:I

    .line 42953
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_gradientRadius:I

    .line 42964
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_startColor:I

    .line 42973
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_startX:I

    .line 42982
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_startY:I

    .line 43001
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_tileMode:I

    .line 43019
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->GradientColor_android_type:I

    .line 43033
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->GradientColorItem:[I

    .line 43046
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->GradientColorItem_android_color:I

    .line 43055
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->GradientColorItem_android_offset:I

    const/16 v15, 0xb

    .line 43087
    new-array v15, v15, [I

    fill-array-data v15, :array_24

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Grid:[I

    .line 43101
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_columnWeights:I

    .line 43110
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_columns:I

    .line 43123
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_horizontalGaps:I

    .line 43140
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_orientation:I

    .line 43150
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_rowWeights:I

    .line 43159
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_rows:I

    .line 43169
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_skips:I

    .line 43179
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_spans:I

    .line 43189
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_useRtl:I

    .line 43199
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_validateInputs:I

    .line 43212
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Grid_grid_verticalGaps:I

    const/16 v15, 0x2b

    .line 43312
    new-array v15, v15, [I

    fill-array-data v15, :array_25

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption:[I

    .line 43338
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_allAppsCellSpecsId:I

    .line 43351
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_allAppsCellSpecsTwoPanelId:I

    .line 43365
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_allAppsSpecsId:I

    .line 43378
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_allAppsSpecsTwoPanelId:I

    .line 43391
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_allAppsStyle:I

    .line 43404
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_cellStyle:I

    .line 43414
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_dbFile:I

    .line 43426
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_defaultLayoutId:I

    .line 43438
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_demoModeLayoutId:I

    .line 43459
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_deviceCategory:I

    .line 43471
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_devicePaddingId:I

    .line 43485
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_folderSpecsId:I

    .line 43498
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_folderSpecsTwoPanelId:I

    .line 43511
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_folderStyle:I

    .line 43521
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_hotseatBorderSpace:I

    .line 43531
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_hotseatBorderSpaceLandscape:I

    .line 43545
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_hotseatSpecsId:I

    .line 43558
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_hotseatSpecsTwoPanelId:I

    .line 43572
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_inlineNavButtonsEndSpacing:I

    .line 43593
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_inlineQsb:I

    .line 43603
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_isScalable:I

    .line 43613
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_name:I

    .line 43623
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numAllAppsColumns:I

    .line 43634
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numAllAppsRowsForCellHeightCalculation:I

    .line 43643
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numColumns:I

    .line 43654
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numExtendedAllAppsColumns:I

    .line 43665
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numExtendedHotseatIcons:I

    .line 43674
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderColumns:I

    .line 43684
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderColumnsLandscape:I

    .line 43694
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderColumnsTwoPanelLandscape:I

    .line 43704
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderColumnsTwoPanelPortrait:I

    .line 43714
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderRows:I

    .line 43724
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderRowsLandscape:I

    .line 43734
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderRowsTwoPanelLandscape:I

    .line 43744
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numFolderRowsTwoPanelPortrait:I

    .line 43754
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numHotseatIcons:I

    .line 43763
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numRows:I

    .line 43773
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numSearchContainerColumns:I

    .line 43784
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_numShrunkenHotseatIcons:I

    .line 43798
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_workspaceCellSpecsId:I

    const/16 v15, 0x28

    .line 43811
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_workspaceCellSpecsTwoPanelId:I

    const/16 v15, 0x29

    .line 43825
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_workspaceSpecsId:I

    const/16 v15, 0x2a

    .line 43838
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->GridDisplayOption_workspaceSpecsTwoPanelId:I

    .line 43852
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->HotseatSpec:[I

    .line 43872
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->HotseatSpec_dimensionType:I

    .line 43885
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->HotseatSpec_maxAvailableSize:I

    .line 43899
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->IconPersonalized:[I

    .line 43913
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->IconPersonalized_sliderColor:I

    .line 43925
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->IconPersonalized_sliderRadius:I

    const/16 v15, 0xe

    .line 43963
    new-array v15, v15, [I

    fill-array-data v15, :array_26

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView:[I

    .line 43980
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_altSrc:I

    .line 43992
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_blendSrc:I

    .line 44001
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_brightness:I

    .line 44010
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_contrast:I

    .line 44019
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_crossfade:I

    .line 44028
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_imagePanX:I

    .line 44037
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_imagePanY:I

    .line 44046
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_imageRotate:I

    .line 44055
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_imageZoom:I

    .line 44065
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_overlay:I

    .line 44078
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_round:I

    .line 44087
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_roundPercent:I

    .line 44096
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_saturation:I

    .line 44105
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ImageFilterView_warmth:I

    .line 44119
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Include:[I

    .line 44133
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Include_folderItems:I

    .line 44145
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Include_workspace:I

    .line 44171
    new-array v15, v9, [I

    fill-array-data v15, :array_27

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Insets:[I

    .line 44184
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Insets_marginLeftSystemWindowInsets:I

    .line 44194
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Insets_marginRightSystemWindowInsets:I

    .line 44204
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Insets_marginTopSystemWindowInsets:I

    .line 44214
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Insets_paddingBottomSystemWindowInsets:I

    .line 44224
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Insets_paddingLeftSystemWindowInsets:I

    .line 44234
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Insets_paddingRightSystemWindowInsets:I

    .line 44244
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Insets_paddingStartSystemWindowInsets:I

    .line 44254
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Insets_paddingTopSystemWindowInsets:I

    .line 44266
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->InsettableFrameLayout_Layout:[I

    .line 44278
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->InsettableFrameLayout_Layout_layout_ignoreInsets:I

    const/16 v15, 0x13

    .line 44326
    new-array v15, v15, [I

    fill-array-data v15, :array_28

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute:[I

    .line 44349
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_curveFit:I

    .line 44358
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_framePosition:I

    .line 44367
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_motionProgress:I

    .line 44381
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_motionTarget:I

    .line 44393
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_transformPivotTarget:I

    .line 44414
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_transitionEasing:I

    .line 44423
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_transitionPathRotate:I

    .line 44432
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_alpha:I

    .line 44445
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_elevation:I

    .line 44454
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_rotation:I

    .line 44463
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_rotationX:I

    .line 44472
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_rotationY:I

    .line 44481
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_scaleX:I

    .line 44490
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_scaleY:I

    .line 44503
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_transformPivotX:I

    .line 44516
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_transformPivotY:I

    .line 44529
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_translationX:I

    .line 44542
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_translationY:I

    .line 44555
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->KeyAttribute_android_translationZ:I

    const/16 v15, 0x15

    .line 44607
    new-array v15, v15, [I

    fill-array-data v15, :array_29

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle:[I

    .line 44631
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_curveFit:I

    .line 44640
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_framePosition:I

    .line 44649
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_motionProgress:I

    .line 44663
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_motionTarget:I

    .line 44684
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_transitionEasing:I

    .line 44693
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_transitionPathRotate:I

    .line 44707
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_waveOffset:I

    .line 44716
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_wavePeriod:I

    .line 44725
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_wavePhase:I

    .line 44749
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_waveShape:I

    .line 44766
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_waveVariesBy:I

    .line 44775
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_alpha:I

    .line 44788
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_elevation:I

    .line 44797
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_rotation:I

    .line 44806
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_rotationX:I

    .line 44815
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_rotationY:I

    .line 44824
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_scaleX:I

    .line 44833
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_scaleY:I

    .line 44846
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_translationX:I

    .line 44859
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_translationY:I

    .line 44872
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->KeyCycle_android_translationZ:I

    .line 44873
    new-array v15, v0, [I

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyFrame:[I

    .line 44875
    new-array v15, v0, [I

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyFramesAcceleration:[I

    .line 44877
    new-array v15, v0, [I

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyFramesVelocity:[I

    const/16 v15, 0xc

    .line 44912
    new-array v15, v15, [I

    fill-array-data v15, :array_2a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition:[I

    .line 44933
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_curveFit:I

    .line 44954
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_drawPath:I

    .line 44963
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_framePosition:I

    .line 44982
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_keyPositionType:I

    .line 44996
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_motionTarget:I

    .line 45017
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_pathMotionArc:I

    .line 45026
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_percentHeight:I

    .line 45035
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_percentWidth:I

    .line 45044
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_percentX:I

    .line 45053
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_percentY:I

    .line 45062
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_sizePercent:I

    .line 45083
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->KeyPosition_transitionEasing:I

    const/16 v15, 0x15

    .line 45135
    new-array v15, v15, [I

    fill-array-data v15, :array_2b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle:[I

    .line 45159
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_curveFit:I

    .line 45168
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_framePosition:I

    .line 45177
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_motionProgress:I

    .line 45191
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_motionTarget:I

    .line 45212
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_transitionEasing:I

    .line 45221
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_transitionPathRotate:I

    .line 45230
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_waveDecay:I

    .line 45244
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_waveOffset:I

    .line 45253
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_wavePeriod:I

    .line 45262
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_wavePhase:I

    .line 45286
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_waveShape:I

    .line 45295
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_alpha:I

    .line 45308
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_elevation:I

    .line 45317
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_rotation:I

    .line 45326
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_rotationX:I

    .line 45335
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_rotationY:I

    .line 45344
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_scaleX:I

    .line 45353
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_scaleY:I

    .line 45366
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_translationX:I

    .line 45379
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_translationY:I

    .line 45392
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->KeyTimeCycle_android_translationZ:I

    const/16 v15, 0xd

    .line 45428
    new-array v15, v15, [I

    fill-array-data v15, :array_2c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger:[I

    .line 45442
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_framePosition:I

    .line 45456
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_motionTarget:I

    .line 45466
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_motion_postLayoutCollision:I

    .line 45478
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_motion_triggerOnCollision:I

    .line 45488
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_onCross:I

    .line 45498
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_onNegativeCross:I

    .line 45508
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_onPositiveCross:I

    .line 45520
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_triggerId:I

    .line 45532
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_triggerReceiver:I

    .line 45541
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_triggerSlack:I

    .line 45553
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_viewTransitionOnCross:I

    .line 45565
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_viewTransitionOnNegativeCross:I

    .line 45577
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->KeyTrigger_viewTransitionOnPositiveCross:I

    const/16 v15, 0x4c

    .line 45739
    new-array v15, v15, [I

    fill-array-data v15, :array_2d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout:[I

    .line 45769
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Layout_barrierAllowsGoneWidgets:I

    .line 45790
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Layout_barrierDirection:I

    .line 45803
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Layout_barrierMargin:I

    .line 45813
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Layout_chainUseRtl:I

    .line 45823
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Layout_constraint_referenced_ids:I

    .line 45833
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Layout_constraint_referenced_tags:I

    .line 45843
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Layout_guidelineUseRtl:I

    .line 45853
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constrainedHeight:I

    .line 45863
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constrainedWidth:I

    .line 45872
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBaseline_creator:I

    .line 45892
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBaseline_toBaselineOf:I

    .line 45912
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBaseline_toBottomOf:I

    .line 45932
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBaseline_toTopOf:I

    .line 45941
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBottom_creator:I

    .line 45961
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBottom_toBottomOf:I

    .line 45981
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintBottom_toTopOf:I

    .line 45993
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintCircle:I

    .line 46002
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintCircleAngle:I

    .line 46015
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintCircleRadius:I

    .line 46025
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintDimensionRatio:I

    .line 46045
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintEnd_toEndOf:I

    .line 46065
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintEnd_toStartOf:I

    .line 46078
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintGuide_begin:I

    .line 46091
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintGuide_end:I

    .line 46100
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintGuide_percent:I

    .line 46126
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHeight:I

    .line 46144
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHeight_default:I

    .line 46165
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHeight_max:I

    .line 46186
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHeight_min:I

    .line 46195
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHeight_percent:I

    .line 46204
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHorizontal_bias:I

    .line 46222
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHorizontal_chainStyle:I

    .line 46231
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintHorizontal_weight:I

    .line 46240
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintLeft_creator:I

    .line 46260
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintLeft_toLeftOf:I

    .line 46280
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintLeft_toRightOf:I

    .line 46289
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintRight_creator:I

    .line 46309
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintRight_toLeftOf:I

    .line 46329
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintRight_toRightOf:I

    .line 46349
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintStart_toEndOf:I

    const/16 v15, 0x28

    .line 46369
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintStart_toStartOf:I

    const/16 v15, 0x29

    .line 46378
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintTop_creator:I

    const/16 v15, 0x2a

    .line 46398
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintTop_toBottomOf:I

    const/16 v15, 0x2b

    .line 46418
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintTop_toTopOf:I

    const/16 v15, 0x2c

    .line 46427
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintVertical_bias:I

    const/16 v15, 0x2d

    .line 46445
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintVertical_chainStyle:I

    const/16 v15, 0x2e

    .line 46454
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintVertical_weight:I

    const/16 v15, 0x2f

    .line 46480
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintWidth:I

    const/16 v15, 0x30

    .line 46498
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintWidth_default:I

    const/16 v15, 0x31

    .line 46519
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintWidth_max:I

    const/16 v15, 0x32

    .line 46540
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintWidth_min:I

    const/16 v15, 0x33

    .line 46549
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_constraintWidth_percent:I

    const/16 v15, 0x34

    .line 46562
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_editor_absoluteX:I

    const/16 v15, 0x35

    .line 46575
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_editor_absoluteY:I

    const/16 v15, 0x36

    .line 46588
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginBaseline:I

    const/16 v15, 0x37

    .line 46601
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginBottom:I

    const/16 v15, 0x38

    .line 46614
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginEnd:I

    const/16 v15, 0x39

    .line 46627
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginLeft:I

    const/16 v15, 0x3a

    .line 46640
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginRight:I

    const/16 v15, 0x3b

    .line 46653
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginStart:I

    const/16 v15, 0x3c

    .line 46666
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_goneMarginTop:I

    const/16 v15, 0x3d

    .line 46679
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_marginBaseline:I

    const/16 v15, 0x3e

    .line 46698
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_layout_wrapBehaviorInParent:I

    const/16 v15, 0x3f

    .line 46711
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_maxHeight:I

    const/16 v15, 0x40

    .line 46724
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_maxWidth:I

    const/16 v15, 0x41

    .line 46737
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_minHeight:I

    const/16 v15, 0x42

    .line 46750
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_minWidth:I

    const/16 v15, 0x43

    .line 46773
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_height:I

    const/16 v15, 0x44

    .line 46786
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginBottom:I

    const/16 v15, 0x45

    .line 46799
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginEnd:I

    const/16 v15, 0x46

    .line 46812
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginLeft:I

    const/16 v15, 0x47

    .line 46825
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginRight:I

    const/16 v15, 0x48

    .line 46838
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginStart:I

    const/16 v15, 0x49

    .line 46851
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_marginTop:I

    const/16 v15, 0x4a

    .line 46874
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_layout_width:I

    const/16 v15, 0x4b

    .line 46891
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->Layout_android_orientation:I

    const/16 v15, 0x9

    .line 46919
    new-array v15, v15, [I

    fill-array-data v15, :array_2e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat:[I

    .line 46935
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_divider:I

    .line 46948
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_dividerPadding:I

    .line 46958
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_measureWithLargestChild:I

    .line 46977
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_showDividers:I

    .line 46987
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_android_baselineAligned:I

    .line 46996
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_android_baselineAlignedChildIndex:I

    .line 47025
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_android_gravity:I

    .line 47042
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_android_orientation:I

    .line 47051
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_android_weightSum:I

    .line 47069
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_Layout:[I

    .line 47100
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_Layout_android_layout_gravity:I

    .line 47123
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_Layout_android_layout_height:I

    .line 47132
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_Layout_android_layout_weight:I

    .line 47155
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->LinearLayoutCompat_Layout_android_layout_width:I

    .line 47171
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LinearProgressIndicator:[I

    .line 47191
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LinearProgressIndicator_indeterminateAnimationType:I

    .line 47212
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LinearProgressIndicator_indicatorDirectionLinear:I

    .line 47225
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LinearProgressIndicator_trackStopIndicatorSize:I

    .line 47239
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ListPopupWindow:[I

    .line 47254
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ListPopupWindow_android_dropDownHorizontalOffset:I

    .line 47267
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ListPopupWindow_android_dropDownVerticalOffset:I

    .line 47287
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference:[I

    .line 47302
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference_entries:I

    .line 47314
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference_entryValues:I

    .line 47324
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference_useSimpleSummaryProvider:I

    .line 47336
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference_android_entries:I

    .line 47348
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ListPreference_android_entryValues:I

    .line 47368
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator:[I

    .line 47382
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator_containerColor:I

    .line 47395
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator_containerHeight:I

    .line 47408
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator_containerWidth:I

    .line 47423
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator_indicatorColor:I

    .line 47436
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->LoadingIndicator_indicatorSize:I

    .line 47454
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LoggablePref:[I

    .line 47465
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LoggablePref_logIdOff:I

    .line 47475
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LoggablePref_logIdOn:I

    .line 47493
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LoggablePref_android_defaultValue:I

    .line 47503
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->LoggablePref_android_key:I

    .line 47557
    new-array v15, v2, [I

    fill-array-data v15, :array_2f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView:[I

    .line 47582
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_asyncUpdates:I

    .line 47592
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_autoPlay:I

    .line 47602
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_cacheComposition:I

    .line 47612
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_clipTextToBoundingBox:I

    .line 47622
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_clipToCompositionBounds:I

    .line 47633
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_colorFilter:I

    .line 47644
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_defaultFontFileExtension:I

    .line 47654
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove:I

    .line 47666
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_fallbackRes:I

    .line 47676
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_fileName:I

    .line 47686
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_ignoreDisabledSystemAnimations:I

    .line 47696
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_imageAssetsFolder:I

    .line 47706
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_loop:I

    .line 47715
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_progress:I

    .line 47727
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_rawRes:I

    .line 47746
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_renderMode:I

    .line 47755
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_repeatCount:I

    .line 47772
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_repeatMode:I

    .line 47781
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_scale:I

    .line 47790
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_speed:I

    .line 47800
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_url:I

    .line 47810
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->LottieAnimationView_lottie_useCompositionFrameRate:I

    .line 47830
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog:[I

    .line 47846
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog_backgroundInsetBottom:I

    .line 47859
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog_backgroundInsetEnd:I

    .line 47872
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog_backgroundInsetStart:I

    .line 47885
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog_backgroundInsetTop:I

    .line 47896
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialog_backgroundTint:I

    .line 47918
    new-array v15, v7, [I

    fill-array-data v15, :array_30

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme:[I

    .line 47933
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogBodyTextStyle:I

    .line 47942
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogButtonSpacerVisibility:I

    .line 47954
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogTheme:I

    .line 47966
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogTitleIconStyle:I

    .line 47978
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogTitlePanelStyle:I

    .line 47990
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAlertDialogTheme_materialAlertDialogTitleTextStyle:I

    const/4 v15, 0x7

    .line 48014
    new-array v15, v15, [I

    fill-array-data v15, :array_31

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView:[I

    .line 48028
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_dropDownBackgroundTint:I

    .line 48040
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_simpleItemLayout:I

    .line 48051
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_simpleItemSelectedColor:I

    .line 48062
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_simpleItemSelectedRippleColor:I

    .line 48074
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_simpleItems:I

    .line 48122
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_android_inputType:I

    .line 48135
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialAutoCompleteTextView_android_popupElevation:I

    .line 48189
    new-array v15, v2, [I

    fill-array-data v15, :array_32

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton:[I

    .line 48207
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_backgroundTint:I

    .line 48233
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_backgroundTintMode:I

    .line 48246
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_cornerRadius:I

    .line 48259
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_elevation:I

    .line 48271
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_icon:I

    .line 48295
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_iconGravity:I

    .line 48308
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_iconPadding:I

    .line 48321
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_iconSize:I

    .line 48332
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_iconTint:I

    .line 48358
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_iconTintMode:I

    .line 48369
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_rippleColor:I

    .line 48381
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_shapeAppearance:I

    .line 48393
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_shapeAppearanceOverlay:I

    .line 48404
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_strokeColor:I

    .line 48417
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_strokeWidth:I

    .line 48427
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_toggleCheckedStateOnClick:I

    .line 48442
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_background:I

    .line 48452
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_checkable:I

    .line 48469
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_insetBottom:I

    .line 48486
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_insetLeft:I

    .line 48503
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_insetRight:I

    .line 48520
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButton_android_insetTop:I

    .line 48542
    new-array v15, v7, [I

    fill-array-data v15, :array_33

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup:[I

    .line 48557
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_buttonSizeChange:I

    .line 48578
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_innerCornerSize:I

    .line 48590
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_shapeAppearance:I

    .line 48602
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_shapeAppearanceOverlay:I

    .line 48612
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_android_enabled:I

    .line 48625
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonGroup_android_spacing:I

    .line 48651
    new-array v15, v9, [I

    fill-array-data v15, :array_34

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup:[I

    .line 48666
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_checkedButton:I

    .line 48687
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_innerCornerSize:I

    .line 48697
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_selectionRequired:I

    .line 48709
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_shapeAppearance:I

    .line 48721
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_shapeAppearanceOverlay:I

    .line 48731
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_singleSelection:I

    .line 48741
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_android_enabled:I

    .line 48754
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialButtonToggleGroup_android_spacing:I

    const/16 v15, 0xb

    .line 48786
    new-array v15, v15, [I

    fill-array-data v15, :array_35

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar:[I

    .line 48801
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_backgroundTint:I

    .line 48813
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_dayInvalidStyle:I

    .line 48825
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_daySelectedStyle:I

    .line 48837
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_dayStyle:I

    .line 48849
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_dayTodayStyle:I

    .line 48859
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_nestedScrollable:I

    .line 48870
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_rangeFillColor:I

    .line 48882
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_yearSelectedStyle:I

    .line 48894
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_yearStyle:I

    .line 48906
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_yearTodayStyle:I

    .line 48916
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendar_android_windowFullscreen:I

    .line 48946
    new-array v15, v11, [I

    fill-array-data v15, :array_36

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem:[I

    .line 48961
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemFillColor:I

    .line 48973
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemShapeAppearance:I

    .line 48985
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemShapeAppearanceOverlay:I

    .line 48996
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemStrokeColor:I

    .line 49009
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemStrokeWidth:I

    .line 49020
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_itemTextColor:I

    .line 49037
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_android_insetBottom:I

    .line 49054
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_android_insetLeft:I

    .line 49071
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_android_insetRight:I

    .line 49088
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCalendarItem_android_insetTop:I

    const/16 v15, 0xd

    .line 49124
    new-array v15, v15, [I

    fill-array-data v15, :array_37

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView:[I

    .line 49140
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_cardForegroundColor:I

    .line 49152
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_checkedIcon:I

    .line 49171
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_checkedIconGravity:I

    .line 49184
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_checkedIconMargin:I

    .line 49197
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_checkedIconSize:I

    .line 49208
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_checkedIconTint:I

    .line 49219
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_rippleColor:I

    .line 49231
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_shapeAppearance:I

    .line 49243
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_shapeAppearanceOverlay:I

    .line 49253
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_state_dragged:I

    .line 49264
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_strokeColor:I

    .line 49277
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_strokeWidth:I

    .line 49287
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCardView_android_checkable:I

    const/16 v15, 0xb

    .line 49319
    new-array v15, v15, [I

    fill-array-data v15, :array_38

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox:[I

    .line 49335
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_buttonCompat:I

    .line 49347
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_buttonIcon:I

    .line 49362
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_buttonIconTint:I

    .line 49388
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_buttonIconTintMode:I

    .line 49399
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_buttonTint:I

    .line 49409
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_centerIfNoTextEnabled:I

    .line 49427
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_checkedState:I

    .line 49437
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_errorAccessibilityLabel:I

    .line 49447
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_errorShown:I

    .line 49457
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_useMaterialThemeColors:I

    .line 49469
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBox_android_button:I

    .line 49483
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBoxStates:[I

    .line 49495
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBoxStates_state_error:I

    .line 49505
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialCheckBoxStates_state_indeterminate:I

    .line 49525
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider:[I

    .line 49543
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider_dividerColor:I

    .line 49556
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider_dividerInsetEnd:I

    .line 49569
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider_dividerInsetStart:I

    .line 49582
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider_dividerThickness:I

    .line 49592
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialDivider_lastItemDecorated:I

    .line 49606
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialRadioButton:[I

    .line 49619
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialRadioButton_buttonTint:I

    .line 49629
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialRadioButton_useMaterialThemeColors:I

    .line 49643
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialShape:[I

    .line 49657
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialShape_shapeAppearance:I

    .line 49669
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialShape_shapeAppearanceOverlay:I

    const/4 v15, 0x7

    .line 49693
    new-array v15, v15, [I

    fill-array-data v15, :array_39

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch:[I

    .line 49708
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_thumbIcon:I

    .line 49721
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_thumbIconSize:I

    .line 49732
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_thumbIconTint:I

    .line 49758
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_thumbIconTintMode:I

    .line 49770
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_trackDecoration:I

    .line 49781
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_trackDecorationTint:I

    .line 49807
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MaterialSwitch_trackDecorationTintMode:I

    .line 49827
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance:[I

    .line 49840
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance_fontVariationSettings:I

    .line 49853
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance_lineHeight:I

    .line 49863
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance_android_fontVariationSettings:I

    .line 49872
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance_android_letterSpacing:I

    .line 49885
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextAppearance_android_lineHeight:I

    .line 49901
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextView:[I

    .line 49916
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextView_lineHeight:I

    .line 49929
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextView_android_lineHeight:I

    .line 49941
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTextView_android_textAppearance:I

    .line 49957
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTimePicker:[I

    .line 49970
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTimePicker_backgroundTint:I

    .line 49982
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTimePicker_clockIcon:I

    .line 49994
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialTimePicker_keyboardIcon:I

    .line 50014
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar:[I

    .line 50027
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar_logoAdjustViewBounds:I

    .line 50056
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar_logoScaleType:I

    .line 50067
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar_navigationIconTint:I

    .line 50077
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar_subtitleCentered:I

    .line 50087
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MaterialToolbar_titleCentered:I

    .line 50109
    new-array v15, v7, [I

    fill-array-data v15, :array_3a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup:[I

    .line 50130
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_checkableBehavior:I

    .line 50140
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_enabled:I

    .line 50152
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_id:I

    .line 50171
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_menuCategory:I

    .line 50180
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_orderInCategory:I

    .line 50190
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MenuGroup_android_visible:I

    .line 50246
    new-array v15, v3, [I

    fill-array-data v15, :array_3b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem:[I

    .line 50265
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_actionLayout:I

    .line 50275
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_actionProviderClass:I

    .line 50285
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_actionViewClass:I

    .line 50306
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_alphabeticModifiers:I

    .line 50316
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_contentDescription:I

    .line 50327
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_iconTint:I

    .line 50353
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_iconTintMode:I

    .line 50374
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_numericModifiers:I

    .line 50403
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_showAsAction:I

    .line 50413
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_tooltipText:I

    .line 50423
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_alphabeticShortcut:I

    .line 50433
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_checkable:I

    .line 50443
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_checked:I

    .line 50453
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_enabled:I

    .line 50465
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_icon:I

    .line 50477
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_id:I

    .line 50496
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_menuCategory:I

    .line 50506
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_numericShortcut:I

    .line 50516
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_onClick:I

    .line 50525
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_orderInCategory:I

    .line 50535
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_title:I

    .line 50545
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_titleCondensed:I

    .line 50555
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->MenuItem_android_visible:I

    const/16 v15, 0x9

    .line 50583
    new-array v15, v15, [I

    fill-array-data v15, :array_3c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MenuView:[I

    .line 50597
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_preserveIconSpacing:I

    .line 50609
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_subMenuArrow:I

    .line 50624
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_headerBackground:I

    .line 50636
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_horizontalDivider:I

    .line 50651
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_itemBackground:I

    .line 50660
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_itemIconDisabledAlpha:I

    .line 50672
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_itemTextAppearance:I

    .line 50684
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_verticalDivider:I

    .line 50696
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MenuView_android_windowAnimationStyle:I

    .line 50718
    new-array v15, v7, [I

    fill-array-data v15, :array_3d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MockView:[I

    .line 50732
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_diagonalsColor:I

    .line 50742
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_label:I

    .line 50753
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_labelBackgroundColor:I

    .line 50764
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_labelColor:I

    .line 50774
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_showDiagonals:I

    .line 50784
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MockView_mock_showLabel:I

    .line 50814
    new-array v15, v11, [I

    fill-array-data v15, :array_3e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Motion:[I

    .line 50838
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Motion_animateCircleAngleTo:I

    .line 50850
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Motion_animateRelativeTo:I

    .line 50871
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Motion_drawPath:I

    .line 50880
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Motion_motionPathRotate:I

    .line 50889
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Motion_motionStagger:I

    .line 50910
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Motion_pathMotionArc:I

    .line 50937
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Motion_quantizeMotionInterpolator:I

    .line 50946
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Motion_quantizeMotionPhase:I

    .line 50955
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Motion_quantizeMotionSteps:I

    .line 50976
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Motion_transitionEasing:I

    .line 51002
    new-array v15, v9, [I

    fill-array-data v15, :array_3f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect:[I

    .line 51014
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_alpha:I

    .line 51023
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_end:I

    .line 51043
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_move:I

    .line 51052
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_start:I

    .line 51062
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_strict:I

    .line 51075
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_translationX:I

    .line 51088
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_translationY:I

    .line 51100
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MotionEffect_motionEffect_viewTransition:I

    .line 51114
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionHelper:[I

    .line 51126
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionHelper_onHide:I

    .line 51136
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionHelper_onShow:I

    .line 51196
    new-array v15, v5, [I

    fill-array-data v15, :array_40

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel:[I

    .line 51217
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_borderRound:I

    .line 51226
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_borderRoundPercent:I

    .line 51239
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_scaleFromTextSize:I

    .line 51251
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textBackground:I

    .line 51260
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textBackgroundPanX:I

    .line 51269
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textBackgroundPanY:I

    .line 51278
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textBackgroundRotate:I

    .line 51287
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textBackgroundZoom:I

    .line 51298
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textOutlineColor:I

    .line 51311
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textOutlineThickness:I

    .line 51320
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textPanX:I

    .line 51329
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textPanY:I

    .line 51338
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textureBlurFactor:I

    .line 51355
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textureEffect:I

    .line 51368
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textureHeight:I

    .line 51381
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_textureWidth:I

    .line 51398
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_autoSizeTextType:I

    .line 51408
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_fontFamily:I

    .line 51437
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_gravity:I

    .line 51446
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_shadowRadius:I

    .line 51456
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_text:I

    .line 51471
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_textColor:I

    .line 51484
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_textSize:I

    .line 51502
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_textStyle:I

    .line 51521
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->MotionLabel_android_typeface:I

    .line 51543
    new-array v15, v7, [I

    fill-array-data v15, :array_41

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout:[I

    .line 51556
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_applyMotionScene:I

    .line 51568
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_currentState:I

    .line 51580
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_layoutDescription:I

    .line 51599
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_motionDebug:I

    .line 51608
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_motionProgress:I

    .line 51618
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->MotionLayout_showPaths:I

    .line 51632
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionScene:[I

    .line 51643
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionScene_defaultDuration:I

    .line 51661
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionScene_layoutDuringTransition:I

    .line 51677
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotionTelltales:[I

    .line 51690
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotionTelltales_telltales_tailColor:I

    .line 51699
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MotionTelltales_telltales_tailScale:I

    .line 51718
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MotionTelltales_telltales_velocityMode:I

    .line 51730
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MotoButtonBarLayout:[I

    .line 51742
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MotoButtonBarLayout_allowStacking:I

    .line 51760
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->MultiSelectListPreference:[I

    .line 51774
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->MultiSelectListPreference_entries:I

    .line 51786
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->MultiSelectListPreference_entryValues:I

    .line 51798
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->MultiSelectListPreference_android_entries:I

    .line 51810
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->MultiSelectListPreference_android_entryValues:I

    .line 51836
    new-array v15, v9, [I

    fill-array-data v15, :array_42

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator:[I

    .line 51852
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_expandedHeight:I

    .line 51865
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_expandedMarginHorizontal:I

    .line 51887
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_expandedWidth:I

    .line 51900
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_marginHorizontal:I

    .line 51912
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_shapeAppearance:I

    .line 51923
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_android_color:I

    .line 51936
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_android_height:I

    .line 51949
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarActiveIndicator_android_width:I

    .line 52003
    new-array v15, v2, [I

    fill-array-data v15, :array_43

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView:[I

    .line 52023
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_activeIndicatorLabelPadding:I

    .line 52034
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_backgroundTint:I

    .line 52047
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_elevation:I

    .line 52059
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_horizontalItemTextAppearanceActive:I

    .line 52071
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_horizontalItemTextAppearanceInactive:I

    .line 52084
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_iconLabelHorizontalSpacing:I

    .line 52096
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemActiveIndicatorStyle:I

    .line 52108
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemBackground:I

    .line 52126
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemGravity:I

    .line 52143
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemIconGravity:I

    .line 52156
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemIconSize:I

    .line 52167
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemIconTint:I

    .line 52180
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemPaddingBottom:I

    .line 52193
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemPaddingTop:I

    .line 52204
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemRippleColor:I

    .line 52216
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemTextAppearanceActive:I

    .line 52226
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemTextAppearanceActiveBoldEnabled:I

    .line 52238
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemTextAppearanceInactive:I

    .line 52249
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_itemTextColor:I

    .line 52269
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_labelVisibilityMode:I

    .line 52279
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_measureBottomPaddingFromLabelBaseline:I

    .line 52291
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->NavigationBarView_menu:I

    const/16 v15, 0xd

    .line 52327
    new-array v15, v15, [I

    fill-array-data v15, :array_44

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView:[I

    .line 52345
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_contentMarginTop:I

    .line 52355
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_expanded:I

    .line 52367
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_headerLayout:I

    .line 52380
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_headerMarginBottom:I

    .line 52393
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_itemMinHeight:I

    .line 52406
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_itemSpacing:I

    .line 52424
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_menuGravity:I

    .line 52434
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_paddingBottomSystemWindowInsets:I

    .line 52444
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_paddingStartSystemWindowInsets:I

    .line 52454
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_paddingTopSystemWindowInsets:I

    .line 52464
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_scrollingEnabled:I

    .line 52476
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_shapeAppearance:I

    .line 52488
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->NavigationRailView_shapeAppearanceOverlay:I

    .line 52574
    new-array v15, v13, [I

    fill-array-data v15, :array_45

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView:[I

    .line 52595
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_bottomInsetScrimEnabled:I

    .line 52608
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_dividerInsetEnd:I

    .line 52621
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_dividerInsetStart:I

    .line 52634
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_drawerLayoutCornerSize:I

    .line 52647
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_elevation:I

    .line 52657
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_endInsetScrimEnabled:I

    .line 52669
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_headerLayout:I

    .line 52681
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemBackground:I

    .line 52694
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemHorizontalPadding:I

    .line 52707
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemIconPadding:I

    .line 52720
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemIconSize:I

    .line 52731
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemIconTint:I

    .line 52740
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemMaxLines:I

    .line 52751
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemRippleColor:I

    .line 52763
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeAppearance:I

    .line 52775
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeAppearanceOverlay:I

    .line 52786
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeFillColor:I

    .line 52799
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeInsetBottom:I

    .line 52812
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeInsetEnd:I

    .line 52825
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeInsetStart:I

    .line 52838
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemShapeInsetTop:I

    .line 52850
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemTextAppearance:I

    .line 52860
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemTextAppearanceActiveBoldEnabled:I

    .line 52871
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemTextColor:I

    .line 52884
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_itemVerticalPadding:I

    .line 52896
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_menu:I

    .line 52908
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_shapeAppearance:I

    .line 52920
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_shapeAppearanceOverlay:I

    .line 52930
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_startInsetScrimEnabled:I

    .line 52945
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_subheaderColor:I

    .line 52958
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_subheaderInsetEnd:I

    .line 52971
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_subheaderInsetStart:I

    .line 52983
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_subheaderTextAppearance:I

    .line 52993
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_topInsetScrimEnabled:I

    .line 53008
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_android_background:I

    .line 53018
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_android_fitsSystemWindows:I

    .line 53047
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_android_layout_gravity:I

    .line 53060
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->NavigationView_android_maxWidth:I

    .line 53074
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->OnClick:[I

    .line 53096
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->OnClick_clickAction:I

    .line 53108
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->OnClick_targetId:I

    const/16 v15, 0x13

    .line 53156
    new-array v15, v15, [I

    fill-array-data v15, :array_46

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe:[I

    .line 53179
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_autoCompleteMode:I

    .line 53202
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_dragDirection:I

    .line 53211
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_dragScale:I

    .line 53220
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_dragThreshold:I

    .line 53232
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_limitBoundsTo:I

    .line 53241
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_maxAcceleration:I

    .line 53250
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_maxVelocity:I

    .line 53260
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_moveWhenScrollAtTop:I

    .line 53279
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_nestedScrollFlags:I

    .line 53302
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_onTouchUp:I

    .line 53314
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_rotationCenterId:I

    .line 53333
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_springBoundary:I

    .line 53342
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_springDamping:I

    .line 53351
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_springMass:I

    .line 53360
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_springStiffness:I

    .line 53369
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_springStopThreshold:I

    .line 53381
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_touchAnchorId:I

    .line 53403
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_touchAnchorSide:I

    .line 53415
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->OnSwipe_touchRegionId:I

    .line 53428
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PagedView:[I

    .line 53443
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PagedView_pageIndicator:I

    .line 53455
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PersonalWorkSlidingTabStrip:[I

    .line 53467
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PersonalWorkSlidingTabStrip_alignOnIcon:I

    .line 53483
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindow:[I

    .line 53495
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindow_overlapAnchor:I

    .line 53507
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindow_android_popupAnimationStyle:I

    .line 53522
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindow_android_popupBackground:I

    .line 53534
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindowBackgroundState:[I

    .line 53546
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PopupWindowBackgroundState_state_above_anchor:I

    .line 53628
    new-array v15, v12, [I

    fill-array-data v15, :array_47

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Preference:[I

    .line 53648
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Preference_allowDividerAbove:I

    .line 53658
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Preference_allowDividerBelow:I

    .line 53676
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Preference_defaultValue:I

    .line 53686
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Preference_dependency:I

    .line 53696
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Preference_enableCopying:I

    .line 53706
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Preference_enabled:I

    .line 53716
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Preference_fragment:I

    .line 53728
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Preference_icon:I

    .line 53738
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Preference_iconSpaceReserved:I

    .line 53748
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Preference_isPreferenceVisible:I

    .line 53758
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Preference_key:I

    .line 53770
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Preference_layout:I

    .line 53779
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Preference_order:I

    .line 53789
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Preference_persistent:I

    .line 53799
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Preference_selectable:I

    .line 53809
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Preference_shouldDisableView:I

    .line 53819
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Preference_singleLineTitle:I

    .line 53829
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Preference_summary:I

    .line 53839
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Preference_title:I

    .line 53851
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Preference_widgetLayout:I

    .line 53869
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_defaultValue:I

    .line 53879
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_dependency:I

    .line 53889
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_enabled:I

    .line 53899
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_fragment:I

    .line 53911
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_icon:I

    .line 53921
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_iconSpaceReserved:I

    .line 53931
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_key:I

    .line 53943
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_layout:I

    .line 53952
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_order:I

    .line 53962
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_persistent:I

    .line 53972
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_selectable:I

    .line 53982
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_shouldDisableView:I

    .line 53992
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_singleLineTitle:I

    .line 54002
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_summary:I

    .line 54012
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_title:I

    .line 54024
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->Preference_android_widgetLayout:I

    .line 54042
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragment:[I

    .line 54054
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragment_allowDividerAfterLastItem:I

    .line 54069
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragment_android_divider:I

    .line 54082
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragment_android_dividerHeight:I

    .line 54094
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragment_android_layout:I

    .line 54112
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragmentCompat:[I

    .line 54124
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragmentCompat_allowDividerAfterLastItem:I

    .line 54139
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragmentCompat_android_divider:I

    .line 54152
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragmentCompat_android_dividerHeight:I

    .line 54164
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceFragmentCompat_android_layout:I

    .line 54180
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceGroup:[I

    .line 54191
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceGroup_initialExpandedChildrenCount:I

    .line 54201
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceGroup_orderingFromXml:I

    .line 54211
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceGroup_android_orderingFromXml:I

    .line 54229
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceImageView:[I

    .line 54244
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceImageView_maxHeight:I

    .line 54257
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceImageView_maxWidth:I

    .line 54270
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceImageView_android_maxHeight:I

    .line 54283
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceImageView_android_maxWidth:I

    const/16 v15, 0x11

    .line 54327
    new-array v15, v15, [I

    fill-array-data v15, :array_48

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme:[I

    .line 54345
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_checkBoxPreferenceStyle:I

    .line 54357
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_dialogPreferenceStyle:I

    .line 54369
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_dropdownPreferenceStyle:I

    .line 54381
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_editTextPreferenceStyle:I

    .line 54393
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceCategoryStyle:I

    .line 54405
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceCategoryTitleTextAppearance:I

    .line 54420
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceCategoryTitleTextColor:I

    .line 54432
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceFragmentCompatStyle:I

    .line 54444
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceFragmentListStyle:I

    .line 54456
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceFragmentStyle:I

    .line 54468
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceInformationStyle:I

    .line 54480
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceScreenStyle:I

    .line 54492
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceStyle:I

    .line 54504
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_preferenceTheme:I

    .line 54516
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_seekBarPreferenceStyle:I

    .line 54528
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_switchPreferenceCompatStyle:I

    .line 54540
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->PreferenceTheme_switchPreferenceStyle:I

    .line 54554
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PreviewFragment:[I

    .line 54568
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PreviewFragment_android_id:I

    .line 54578
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PreviewFragment_android_name:I

    const/16 v15, 0x50

    .line 54763
    new-array v15, v15, [I

    fill-array-data v15, :array_49

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption:[I

    .line 54794
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpace:I

    .line 54804
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceHorizontal:I

    .line 54815
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceLandscape:I

    .line 54826
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceLandscapeHorizontal:I

    .line 54836
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceLandscapeVertical:I

    .line 54847
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscape:I

    .line 54858
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscapeHorizontal:I

    .line 54869
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelLandscapeVertical:I

    .line 54880
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortrait:I

    .line 54891
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortraitHorizontal:I

    .line 54902
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceTwoPanelPortraitVertical:I

    .line 54912
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsBorderSpaceVertical:I

    .line 54923
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellHeight:I

    .line 54933
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellHeightLandscape:I

    .line 54943
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellHeightTwoPanelLandscape:I

    .line 54953
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellHeightTwoPanelPortrait:I

    .line 54963
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellWidth:I

    .line 54973
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellWidthLandscape:I

    .line 54983
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellWidthTwoPanelLandscape:I

    .line 54993
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsCellWidthTwoPanelPortrait:I

    .line 55003
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconSize:I

    .line 55013
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconSizeLandscape:I

    .line 55023
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconSizeTwoPanelLandscape:I

    .line 55033
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconSizeTwoPanelPortrait:I

    .line 55043
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconTextSize:I

    .line 55053
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconTextSizeTwoPanelLandscape:I

    .line 55063
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_allAppsIconTextSizeTwoPanelPortrait:I

    .line 55073
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpace:I

    .line 55083
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceHorizontal:I

    .line 55094
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceLandscape:I

    .line 55104
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceLandscapeHorizontal:I

    .line 55114
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceLandscapeVertical:I

    .line 55125
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelLandscape:I

    .line 55136
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelLandscapeHorizontal:I

    .line 55147
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelLandscapeVertical:I

    .line 55158
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelPortrait:I

    .line 55169
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelPortraitHorizontal:I

    .line 55180
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceTwoPanelPortraitVertical:I

    .line 55190
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_borderSpaceVertical:I

    .line 55201
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_canBeDefault:I

    const/16 v15, 0x28

    .line 55211
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_horizontalMargin:I

    const/16 v15, 0x29

    .line 55221
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_horizontalMarginLandscape:I

    const/16 v15, 0x2a

    .line 55231
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_horizontalMarginTwoPanelLandscape:I

    const/16 v15, 0x2b

    .line 55241
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_horizontalMarginTwoPanelPortrait:I

    const/16 v15, 0x2c

    .line 55251
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatBarBottomSpace:I

    const/16 v15, 0x2d

    .line 55261
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatBarBottomSpaceLandscape:I

    const/16 v15, 0x2e

    .line 55271
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatBarBottomSpaceTwoPanelLandscape:I

    const/16 v15, 0x2f

    .line 55281
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatBarBottomSpaceTwoPanelPortrait:I

    const/16 v15, 0x30

    .line 55291
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatQsbSpace:I

    const/16 v15, 0x31

    .line 55301
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatQsbSpaceLandscape:I

    const/16 v15, 0x32

    .line 55311
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatQsbSpaceTwoPanelLandscape:I

    const/16 v15, 0x33

    .line 55321
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_hotseatQsbSpaceTwoPanelPortrait:I

    const/16 v15, 0x34

    .line 55330
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconImageSize:I

    const/16 v15, 0x35

    .line 55339
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconPaddings:I

    const/16 v15, 0x36

    .line 55349
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconSizeLandscape:I

    const/16 v15, 0x37

    .line 55359
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconSizeTwoPanelLandscape:I

    const/16 v15, 0x38

    .line 55369
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconSizeTwoPanelPortrait:I

    const/16 v15, 0x39

    .line 55378
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconTextSize:I

    const/16 v15, 0x3a

    .line 55388
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconTextSizeLandscape:I

    const/16 v15, 0x3b

    .line 55398
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconTextSizeTwoPanelLandscape:I

    const/16 v15, 0x3c

    .line 55408
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_iconTextSizeTwoPanelPortrait:I

    const/16 v15, 0x3d

    .line 55418
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellHeight:I

    const/16 v15, 0x3e

    .line 55428
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellHeightLandscape:I

    const/16 v15, 0x3f

    .line 55438
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellHeightTwoPanelLandscape:I

    const/16 v15, 0x40

    .line 55448
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellHeightTwoPanelPortrait:I

    const/16 v15, 0x41

    .line 55457
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellWidth:I

    const/16 v15, 0x42

    .line 55467
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellWidthLandscape:I

    const/16 v15, 0x43

    .line 55477
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellWidthTwoPanelLandscape:I

    const/16 v15, 0x44

    .line 55487
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minCellWidthTwoPanelPortrait:I

    const/16 v15, 0x45

    .line 55496
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minHeightDps:I

    const/16 v15, 0x46

    .line 55505
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_minWidthDps:I

    const/16 v15, 0x47

    .line 55515
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_name:I

    const/16 v15, 0x48

    .line 55526
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_startAlignTaskbar:I

    const/16 v15, 0x49

    .line 55537
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_startAlignTaskbarLandscape:I

    const/16 v15, 0x4a

    .line 55548
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_startAlignTaskbarTwoPanelLandscape:I

    const/16 v15, 0x4b

    .line 55559
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_startAlignTaskbarTwoPanelPortrait:I

    const/16 v15, 0x4c

    .line 55569
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_transientTaskbarIconSize:I

    const/16 v15, 0x4d

    .line 55579
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_transientTaskbarIconSizeLandscape:I

    const/16 v15, 0x4e

    .line 55589
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_transientTaskbarIconSizeTwoPanelLandscape:I

    const/16 v15, 0x4f

    .line 55599
    sput v15, Lcom/motorola/plugin/sdk/R$styleable;->ProfileDisplayOption_transientTaskbarIconSizeTwoPanelPortrait:I

    .line 55619
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet:[I

    .line 55632
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet_layout_constraintTag:I

    .line 55641
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet_motionProgress:I

    .line 55658
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet_visibilityMode:I

    .line 55667
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet_android_alpha:I

    .line 55685
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->PropertySet_android_visibility:I

    .line 55697
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RadialViewGroup:[I

    .line 55712
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RadialViewGroup_materialCircleRadius:I

    .line 55726
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RangeSlider:[I

    .line 55741
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RangeSlider_minSeparation:I

    .line 55753
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RangeSlider_values:I

    .line 55767
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RecycleListView:[I

    .line 55782
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RecycleListView_paddingBottomNoButtons:I

    .line 55795
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RecycleListView_paddingTopNoTitle:I

    const/16 v15, 0xc

    .line 55829
    new-array v15, v15, [I

    fill-array-data v15, :array_4a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView:[I

    .line 55843
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_fastScrollEnabled:I

    .line 55855
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_fastScrollHorizontalThumbDrawable:I

    .line 55867
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_fastScrollHorizontalTrackDrawable:I

    .line 55879
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_fastScrollVerticalThumbDrawable:I

    .line 55891
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_fastScrollVerticalTrackDrawable:I

    .line 55901
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_layoutManager:I

    .line 55911
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_reverseLayout:I

    .line 55920
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_spanCount:I

    .line 55930
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_stackFromEnd:I

    .line 55940
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_android_clipToPadding:I

    .line 55958
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_android_descendantFocusability:I

    .line 55975
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerView_android_orientation:I

    .line 55987
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerViewFastScroller:[I

    .line 55999
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RecyclerViewFastScroller_canThumbDetach:I

    .line 56013
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ResponsiveSpec:[I

    .line 56033
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ResponsiveSpec_dimensionType:I

    .line 56046
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ResponsiveSpec_maxAvailableSize:I

    .line 56058
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ResponsiveSpecGroup:[I

    .line 56069
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ResponsiveSpecGroup_maxAspectRatio:I

    const/16 v15, 0xb

    .line 56102
    new-array v15, v15, [I

    fill-array-data v15, :array_4b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout:[I

    .line 56117
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_onSurfaceBack:I

    .line 56128
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_onSurfaceHome:I

    .line 56139
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_onSurfaceOverview:I

    .line 56150
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_secondaryBack:I

    .line 56161
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_secondaryHome:I

    .line 56172
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_secondaryOverview:I

    .line 56183
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_surfaceBack:I

    .line 56194
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_surfaceContainer:I

    .line 56205
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_surfaceHome:I

    .line 56216
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_surfaceOverview:I

    .line 56227
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->RootSandboxLayout_tutorialSubtitle:I

    .line 56243
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RoundedImageView:[I

    .line 56258
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RoundedImageView_cornerRadius:I

    .line 56269
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RoundedImageView_placeholderBg:I

    .line 56278
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->RoundedImageView_shape:I

    .line 56336
    new-array v15, v4, [I

    fill-array-data v15, :array_4c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle:[I

    .line 56356
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_actionDividerHeight:I

    .line 56369
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_bottomDividerEndPadding:I

    .line 56382
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_bottomDividerStartPadding:I

    .line 56395
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_contentEndPadding:I

    .line 56408
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_contentStartPadding:I

    .line 56418
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_disableRecyclerViewItemAnimator:I

    .line 56431
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_endItemEndPadding:I

    .line 56444
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_endItemStartPadding:I

    .line 56457
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_iconSize:I

    .line 56470
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_imageSize:I

    .line 56483
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_progressBarEndPadding:I

    .line 56496
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_progressBarInlineWidth:I

    .line 56509
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_progressBarStartPadding:I

    .line 56522
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_seekBarInlineWidth:I

    .line 56535
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_subContentEndPadding:I

    .line 56548
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_subContentStartPadding:I

    .line 56559
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_subtitleColor:I

    .line 56572
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_textActionPadding:I

    .line 56583
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_tintColor:I

    .line 56594
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_titleColor:I

    .line 56607
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_titleEndPadding:I

    .line 56620
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_titleItemEndPadding:I

    .line 56633
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_titleItemStartPadding:I

    .line 56646
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->RowStyle_titleStartPadding:I

    .line 56658
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ScrimInsetsFrameLayout:[I

    .line 56675
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ScrimInsetsFrameLayout_insetForeground:I

    .line 56687
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ScrollingViewBehavior_Layout:[I

    .line 56702
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ScrollingViewBehavior_Layout_behavior_overlapTop:I

    const/16 v15, 0xd

    .line 56738
    new-array v15, v15, [I

    fill-array-data v15, :array_4d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar:[I

    .line 56754
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_backgroundTint:I

    .line 56764
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_defaultMarginsEnabled:I

    .line 56774
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_defaultScrollFlagsEnabled:I

    .line 56787
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_elevation:I

    .line 56797
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_forceDefaultNavigationOnClickListener:I

    .line 56807
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_hideNavigationIcon:I

    .line 56818
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_navigationIconTint:I

    .line 56829
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_strokeColor:I

    .line 56842
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_strokeWidth:I

    .line 56852
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_tintNavigationIcon:I

    .line 56862
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_android_hint:I

    .line 56872
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_android_text:I

    .line 56884
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SearchBar_android_textAppearance:I

    .line 56898
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SearchResultSuggestion:[I

    .line 56912
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SearchResultSuggestion_customIcon:I

    .line 56922
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SearchResultSuggestion_matchTextInsetWithQuery:I

    .line 56990
    new-array v15, v1, [I

    fill-array-data v15, :array_4e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SearchView:[I

    .line 57009
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_animateMenuItems:I

    .line 57019
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_animateNavigationIcon:I

    .line 57029
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_autoShowKeyboard:I

    .line 57039
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_backHandlingEnabled:I

    .line 57050
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_backgroundTint:I

    .line 57062
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_closeIcon:I

    .line 57074
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_commitIcon:I

    .line 57084
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_defaultQueryHint:I

    .line 57096
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_goIcon:I

    .line 57108
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_headerLayout:I

    .line 57118
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_hideNavigationIcon:I

    .line 57128
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_iconifiedByDefault:I

    .line 57140
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_layout:I

    .line 57152
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_queryBackground:I

    .line 57162
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_queryHint:I

    .line 57174
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_searchHintIcon:I

    .line 57186
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_searchIcon:I

    .line 57196
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_searchPrefixText:I

    .line 57208
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_submitBackground:I

    .line 57220
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_suggestionRowLayout:I

    .line 57230
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_useDrawerArrowDrawable:I

    .line 57242
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_voiceIcon:I

    .line 57260
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_focusable:I

    .line 57270
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_hint:I

    .line 57302
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_imeOptions:I

    .line 57350
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_inputType:I

    .line 57363
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_maxWidth:I

    .line 57373
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_text:I

    .line 57385
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->SearchView_android_textAppearance:I

    const/4 v15, 0x7

    .line 57409
    new-array v15, v15, [I

    fill-array-data v15, :array_4f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference:[I

    .line 57422
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_adjustable:I

    .line 57431
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_min:I

    .line 57440
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_seekBarIncrement:I

    .line 57450
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_showSeekBarValue:I

    .line 57460
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_updatesContinuously:I

    .line 57472
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_android_layout:I

    .line 57481
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SeekBarPreference_android_max:I

    .line 57499
    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ShadowDrawable:[I

    .line 57512
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ShadowDrawable_darkTintColor:I

    .line 57525
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ShadowDrawable_android_elevation:I

    .line 57536
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ShadowDrawable_android_shadowColor:I

    .line 57551
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ShadowDrawable_android_src:I

    .line 57573
    new-array v15, v7, [I

    fill-array-data v15, :array_50

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo:[I

    .line 57589
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_ambientShadowBlur:I

    .line 57600
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_ambientShadowColor:I

    .line 57613
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_keyShadowBlur:I

    .line 57624
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_keyShadowColor:I

    .line 57637
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_keyShadowOffsetX:I

    .line 57650
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ShadowInfo_keyShadowOffsetY:I

    const/16 v15, 0x9

    .line 57678
    new-array v15, v15, [I

    fill-array-data v15, :array_51

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout:[I

    .line 57695
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_offsetX:I

    .line 57708
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_offsetY:I

    .line 57719
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_shadowColor:I

    .line 57732
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_shadowCornerRadius:I

    .line 57745
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_shadowRadius:I

    .line 57755
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_showInBottom:I

    .line 57765
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_showInLeft:I

    .line 57775
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_showInRight:I

    .line 57785
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ShadowLayout_showInTop:I

    .line 57815
    new-array v15, v11, [I

    fill-array-data v15, :array_52

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance:[I

    .line 57836
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerFamily:I

    .line 57853
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerFamilyBottomLeft:I

    .line 57870
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerFamilyBottomRight:I

    .line 57887
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerFamilyTopLeft:I

    .line 57904
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerFamilyTopRight:I

    .line 57921
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerSize:I

    .line 57938
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerSizeBottomLeft:I

    .line 57955
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerSizeBottomRight:I

    .line 57972
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerSizeTopLeft:I

    .line 57989
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ShapeAppearance_cornerSizeTopRight:I

    const/16 v15, 0xb

    .line 58021
    new-array v15, v15, [I

    fill-array-data v15, :array_53

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView:[I

    .line 58038
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPadding:I

    .line 58051
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingBottom:I

    .line 58064
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingEnd:I

    .line 58077
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingLeft:I

    .line 58090
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingRight:I

    .line 58103
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingStart:I

    .line 58116
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_contentPaddingTop:I

    .line 58128
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_shapeAppearance:I

    .line 58140
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_shapeAppearanceOverlay:I

    .line 58151
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_strokeColor:I

    .line 58164
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ShapeableImageView_strokeWidth:I

    .line 58190
    new-array v15, v9, [I

    fill-array-data v15, :array_54

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout:[I

    .line 58204
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_backgroundTint:I

    .line 58214
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_behavior_draggable:I

    .line 58226
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_coplanarSiblingViewId:I

    .line 58238
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_shapeAppearance:I

    .line 58250
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_shapeAppearanceOverlay:I

    .line 58263
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_android_elevation:I

    .line 58276
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_android_maxHeight:I

    .line 58289
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SideSheetBehavior_Layout_android_maxWidth:I

    .line 58309
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec:[I

    .line 58325
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec_fixedSize:I

    .line 58335
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec_matchWorkspace:I

    .line 58348
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec_maxSize:I

    .line 58357
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec_ofAvailableSpace:I

    .line 58366
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SizeSpec_ofRemainderSpace:I

    .line 58422
    new-array v15, v3, [I

    fill-array-data v15, :array_55

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SliceView:[I

    .line 58439
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_expandToAvailableHeight:I

    .line 58452
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_gridBottomPadding:I

    .line 58465
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_gridSubtitleSize:I

    .line 58478
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_gridTextVerticalPadding:I

    .line 58491
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_gridTitleSize:I

    .line 58504
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_gridTopPadding:I

    .line 58517
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_headerSubtitleSize:I

    .line 58530
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_headerTextVerticalPadding:I

    .line 58543
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_headerTitleSize:I

    .line 58553
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_hideHeaderRow:I

    .line 58566
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_imageCornerRadius:I

    .line 58579
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowInlineRangeHeight:I

    .line 58592
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowMaxHeight:I

    .line 58605
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowMinHeight:I

    .line 58618
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowRangeHeight:I

    .line 58631
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowRangeSingleTextHeight:I

    .line 58643
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_rowStyle:I

    .line 58654
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_subtitleColor:I

    .line 58667
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_subtitleSize:I

    .line 58680
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_textVerticalPadding:I

    .line 58691
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_tintColor:I

    .line 58702
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_titleColor:I

    .line 58715
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->SliceView_titleSize:I

    .line 58803
    new-array v15, v14, [I

    fill-array-data v15, :array_56

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Slider:[I

    .line 58825
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Slider_haloColor:I

    .line 58838
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Slider_haloRadius:I

    .line 58857
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Slider_labelBehavior:I

    .line 58869
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Slider_labelStyle:I

    .line 58882
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Slider_minTouchTargetSize:I

    .line 58893
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbColor:I

    .line 58906
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbElevation:I

    .line 58919
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbHeight:I

    .line 58932
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbRadius:I

    .line 58943
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbStrokeColor:I

    .line 58956
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbStrokeWidth:I

    .line 58969
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbTrackGapSize:I

    .line 58982
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Slider_thumbWidth:I

    .line 58993
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickColor:I

    .line 59004
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickColorActive:I

    .line 59015
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickColorInactive:I

    .line 59028
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickRadiusActive:I

    .line 59041
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickRadiusInactive:I

    .line 59051
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Slider_tickVisible:I

    .line 59062
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackColor:I

    .line 59073
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackColorActive:I

    .line 59084
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackColorInactive:I

    .line 59097
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackCornerSize:I

    .line 59110
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackHeight:I

    .line 59121
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconActiveColor:I

    .line 59133
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconActiveEnd:I

    .line 59145
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconActiveStart:I

    .line 59156
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconInactiveColor:I

    .line 59168
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconInactiveEnd:I

    .line 59180
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconInactiveStart:I

    .line 59193
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackIconSize:I

    .line 59206
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackInsideCornerSize:I

    .line 59219
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->Slider_trackStopIndicatorSize:I

    .line 59229
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_enabled:I

    .line 59246
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_orientation:I

    .line 59255
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_stepSize:I

    .line 59272
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_value:I

    .line 59292
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_valueFrom:I

    .line 59312
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->Slider_android_valueTo:I

    .line 59332
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout:[I

    .line 59345
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_isChildClippingToResizeDividerEnabled:I

    .line 59355
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_isOverlappingEnabled:I

    .line 59365
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_isUserResizingEnabled:I

    .line 59382
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_userResizeBehavior:I

    .line 59394
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_userResizingDividerDrawable:I

    .line 59406
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_Layout:[I

    .line 59417
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SlidingPaneLayout_Layout_android_layout_weight:I

    .line 59433
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Snackbar:[I

    .line 59447
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Snackbar_snackbarButtonStyle:I

    .line 59459
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Snackbar_snackbarStyle:I

    .line 59471
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Snackbar_snackbarTextViewStyle:I

    .line 59501
    new-array v15, v11, [I

    fill-array-data v15, :array_57

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout:[I

    .line 59514
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_actionTextColorAlpha:I

    .line 59531
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_animationMode:I

    .line 59540
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_backgroundOverlayColorAlpha:I

    .line 59551
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_backgroundTint:I

    .line 59577
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_backgroundTintMode:I

    .line 59590
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_elevation:I

    .line 59603
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_maxActionInlineWidth:I

    .line 59615
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_shapeAppearance:I

    .line 59627
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_shapeAppearanceOverlay:I

    .line 59640
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SnackbarLayout_android_maxWidth:I

    .line 59660
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->Spinner:[I

    .line 59675
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Spinner_popupTheme:I

    .line 59698
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Spinner_android_dropDownWidth:I

    .line 59710
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Spinner_android_entries:I

    .line 59725
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Spinner_android_popupBackground:I

    .line 59737
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Spinner_android_prompt:I

    .line 59753
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairFilter:[I

    .line 59765
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairFilter_primaryActivityName:I

    .line 59775
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairFilter_secondaryActivityAction:I

    .line 59785
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairFilter_secondaryActivityName:I

    const/16 v15, 0xf

    .line 59825
    new-array v15, v15, [I

    fill-array-data v15, :array_58

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule:[I

    .line 59841
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_animationBackgroundColor:I

    .line 59851
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_clearTop:I

    .line 59869
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_finishPrimaryWithSecondary:I

    .line 59887
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_finishSecondaryWithPrimary:I

    .line 59904
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitChangeAnimation:I

    .line 59921
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitCloseAnimation:I

    .line 59941
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitLayoutDirection:I

    .line 59959
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitMaxAspectRatioInLandscape:I

    .line 59977
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitMaxAspectRatioInPortrait:I

    .line 59986
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitMinHeightDp:I

    .line 59995
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitMinSmallestWidthDp:I

    .line 60004
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitMinWidthDp:I

    .line 60021
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitOpenAnimation:I

    .line 60030
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_splitRatio:I

    .line 60040
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->SplitPairRule_tag:I

    const/16 v15, 0xf

    .line 60080
    new-array v15, v15, [I

    fill-array-data v15, :array_59

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule:[I

    .line 60096
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_animationBackgroundColor:I

    .line 60113
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_finishPrimaryWithPlaceholder:I

    .line 60123
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_placeholderActivityName:I

    .line 60140
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitChangeAnimation:I

    .line 60157
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitCloseAnimation:I

    .line 60177
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitLayoutDirection:I

    .line 60195
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitMaxAspectRatioInLandscape:I

    .line 60213
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitMaxAspectRatioInPortrait:I

    .line 60222
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitMinHeightDp:I

    .line 60231
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitMinSmallestWidthDp:I

    .line 60240
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitMinWidthDp:I

    .line 60257
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitOpenAnimation:I

    .line 60266
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_splitRatio:I

    .line 60276
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_stickyPlaceholder:I

    .line 60286
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->SplitPlaceholderRule_tag:I

    .line 60300
    filled-new-array {v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->State:[I

    .line 60314
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->State_constraints:I

    .line 60326
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->State_android_id:I

    .line 60348
    new-array v15, v7, [I

    fill-array-data v15, :array_5a

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable:[I

    .line 60361
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_constantSize:I

    .line 60371
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_dither:I

    .line 60380
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_enterFadeDuration:I

    .line 60389
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_exitFadeDuration:I

    .line 60399
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_variablePadding:I

    .line 60409
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawable_android_visible:I

    .line 60421
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawableItem:[I

    .line 60435
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->StateListDrawableItem_android_drawable:I

    .line 60447
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->StateListSizeChange:[I

    .line 60466
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->StateListSizeChange_widthChange:I

    .line 60478
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->StateSet:[I

    .line 60492
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->StateSet_defaultState:I

    .line 60504
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->StickyScroller_Layout:[I

    .line 60516
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->StickyScroller_Layout_layout_sticky:I

    const/16 v15, 0xe

    .line 60554
    new-array v15, v15, [I

    fill-array-data v15, :array_5b

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat:[I

    .line 60569
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_showText:I

    .line 60579
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_splitTrack:I

    .line 60592
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_switchMinWidth:I

    .line 60605
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_switchPadding:I

    .line 60617
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_switchTextAppearance:I

    .line 60630
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_thumbTextPadding:I

    .line 60641
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_thumbTint:I

    .line 60667
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_thumbTintMode:I

    .line 60679
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_track:I

    .line 60690
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_trackTint:I

    .line 60716
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_trackTintMode:I

    .line 60726
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_android_textOff:I

    .line 60736
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_android_textOn:I

    .line 60748
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->SwitchCompat_android_thumb:I

    .line 60760
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SwitchMaterial:[I

    .line 60772
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SwitchMaterial_useMaterialThemeColors:I

    .line 60802
    new-array v15, v11, [I

    fill-array-data v15, :array_5c

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference:[I

    .line 60816
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_disableDependentsState:I

    .line 60826
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_summaryOff:I

    .line 60836
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_summaryOn:I

    .line 60846
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_switchTextOff:I

    .line 60856
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_switchTextOn:I

    .line 60866
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_android_disableDependentsState:I

    .line 60876
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_android_summaryOff:I

    .line 60886
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_android_summaryOn:I

    .line 60896
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_android_switchTextOff:I

    .line 60906
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreference_android_switchTextOn:I

    .line 60936
    new-array v15, v11, [I

    fill-array-data v15, :array_5d

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat:[I

    .line 60950
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_disableDependentsState:I

    .line 60960
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_summaryOff:I

    .line 60970
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_summaryOn:I

    .line 60980
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_switchTextOff:I

    .line 60990
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_switchTextOn:I

    .line 61000
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_android_disableDependentsState:I

    .line 61010
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_android_summaryOff:I

    .line 61020
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_android_summaryOn:I

    .line 61030
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_android_switchTextOff:I

    .line 61040
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->SwitchPreferenceCompat_android_switchTextOn:I

    .line 61056
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TabItem:[I

    .line 61070
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TabItem_android_icon:I

    .line 61082
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TabItem_android_layout:I

    .line 61092
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TabItem_android_text:I

    .line 61156
    new-array v15, v6, [I

    fill-array-data v15, :array_5e

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout:[I

    .line 61176
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabBackground:I

    .line 61189
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabContentStart:I

    .line 61207
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabGravity:I

    .line 61218
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIconTint:I

    .line 61239
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIconTintMode:I

    .line 61251
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicator:I

    .line 61260
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorAnimationDuration:I

    .line 61284
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorAnimationMode:I

    .line 61295
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorColor:I

    .line 61305
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorFullWidth:I

    .line 61324
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorGravity:I

    .line 61337
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabIndicatorHeight:I

    .line 61347
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabInlineLabel:I

    .line 61360
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabMaxWidth:I

    .line 61373
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabMinWidth:I

    .line 61391
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabMode:I

    .line 61404
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabPadding:I

    .line 61417
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabPaddingBottom:I

    .line 61430
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabPaddingEnd:I

    .line 61443
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabPaddingStart:I

    .line 61456
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabPaddingTop:I

    .line 61467
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabRippleColor:I

    .line 61479
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabSelectedTextAppearance:I

    .line 61490
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabSelectedTextColor:I

    .line 61502
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabTextAppearance:I

    .line 61513
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabTextColor:I

    .line 61523
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->TabLayout_tabUnboundedRipple:I

    .line 61540
    filled-new-array {v0, v0, v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TaskView:[I

    .line 61554
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TaskView_borderColor:I

    .line 61566
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TaskView_focusBorderColor:I

    .line 61577
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TaskView_hoverBorderColor:I

    const/16 v15, 0x10

    .line 61619
    new-array v15, v15, [I

    fill-array-data v15, :array_5f

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance:[I

    .line 61634
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_fontFamily:I

    .line 61644
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_fontVariationSettings:I

    .line 61658
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_textAllCaps:I

    .line 61668
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_textLocale:I

    .line 61678
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_fontFamily:I

    .line 61689
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_shadowColor:I

    .line 61698
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_shadowDx:I

    .line 61707
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_shadowDy:I

    .line 61716
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_shadowRadius:I

    .line 61731
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textColor:I

    .line 61746
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textColorHint:I

    .line 61761
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textColorLink:I

    .line 61770
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textFontWeight:I

    .line 61783
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textSize:I

    .line 61801
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_textStyle:I

    .line 61820
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->TextAppearance_android_typeface:I

    const/16 v15, 0xe

    .line 61858
    new-array v15, v15, [I

    fill-array-data v15, :array_60

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects:[I

    .line 61876
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_borderRound:I

    .line 61885
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_borderRoundPercent:I

    .line 61896
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_textFillColor:I

    .line 61907
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_textOutlineColor:I

    .line 61920
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_textOutlineThickness:I

    .line 61930
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_fontFamily:I

    .line 61941
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_shadowColor:I

    .line 61950
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_shadowDx:I

    .line 61959
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_shadowDy:I

    .line 61968
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_shadowRadius:I

    .line 61978
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_text:I

    .line 61991
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_textSize:I

    .line 62009
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_textStyle:I

    .line 62028
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->TextEffects_android_typeface:I

    .line 62040
    filled-new-array {v0}, [I

    move-result-object v15

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TextInputEditText:[I

    .line 62052
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TextInputEditText_textInputLayoutFocusedRectEnabled:I

    const/16 v15, 0x4b

    .line 62212
    new-array v15, v15, [I

    fill-array-data v15, :array_61

    sput-object v15, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout:[I

    .line 62243
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxBackgroundColor:I

    .line 62261
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxBackgroundMode:I

    .line 62274
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxCollapsedPaddingTop:I

    .line 62287
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxCornerRadiusBottomEnd:I

    .line 62300
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxCornerRadiusBottomStart:I

    .line 62313
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxCornerRadiusTopEnd:I

    .line 62326
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxCornerRadiusTopStart:I

    .line 62337
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxStrokeColor:I

    .line 62348
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxStrokeErrorColor:I

    .line 62361
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxStrokeWidth:I

    .line 62374
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_boxStrokeWidthFocused:I

    .line 62384
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterEnabled:I

    .line 62393
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterMaxLength:I

    .line 62405
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterOverflowTextAppearance:I

    .line 62417
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterOverflowTextColor:I

    .line 62429
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterTextAppearance:I

    .line 62441
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_counterTextColor:I

    .line 62452
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_cursorColor:I

    .line 62463
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_cursorErrorColor:I

    .line 62473
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconCheckable:I

    .line 62483
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconContentDescription:I

    .line 62495
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconDrawable:I

    .line 62508
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconMinSize:I

    .line 62528
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconMode:I

    .line 62555
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconScaleType:I

    .line 62566
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconTint:I

    .line 62590
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_endIconTintMode:I

    .line 62599
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorAccessibilityLiveRegion:I

    .line 62609
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorContentDescription:I

    .line 62619
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorEnabled:I

    .line 62631
    sput v10, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorIconDrawable:I

    .line 62643
    sput v31, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorIconTint:I

    .line 62667
    sput v32, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorIconTintMode:I

    .line 62679
    sput v33, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorTextAppearance:I

    .line 62690
    sput v34, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_errorTextColor:I

    .line 62700
    sput v35, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_expandedHintEnabled:I

    .line 62710
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_helperText:I

    .line 62720
    sput v37, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_helperTextEnabled:I

    .line 62732
    sput v13, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_helperTextTextAppearance:I

    .line 62743
    sput v14, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_helperTextTextColor:I

    const/16 v12, 0x28

    .line 62753
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_hintAnimationEnabled:I

    const/16 v12, 0x29

    .line 62763
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_hintEnabled:I

    const/16 v12, 0x2a

    .line 62772
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_hintMaxLines:I

    const/16 v12, 0x2b

    .line 62784
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_hintTextAppearance:I

    const/16 v12, 0x2c

    .line 62795
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_hintTextColor:I

    const/16 v12, 0x2d

    .line 62805
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_passwordToggleContentDescription:I

    const/16 v12, 0x2e

    .line 62817
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_passwordToggleDrawable:I

    const/16 v12, 0x2f

    .line 62827
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_passwordToggleEnabled:I

    const/16 v12, 0x30

    .line 62838
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_passwordToggleTint:I

    const/16 v12, 0x31

    .line 62862
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_passwordToggleTintMode:I

    const/16 v12, 0x32

    .line 62872
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_placeholderText:I

    const/16 v12, 0x33

    .line 62884
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_placeholderTextAppearance:I

    const/16 v12, 0x34

    .line 62895
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_placeholderTextColor:I

    const/16 v12, 0x35

    .line 62905
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_prefixText:I

    const/16 v12, 0x36

    .line 62917
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_prefixTextAppearance:I

    const/16 v12, 0x37

    .line 62928
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_prefixTextColor:I

    const/16 v12, 0x38

    .line 62940
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_shapeAppearance:I

    const/16 v12, 0x39

    .line 62952
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_shapeAppearanceOverlay:I

    const/16 v12, 0x3a

    .line 62962
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconCheckable:I

    const/16 v12, 0x3b

    .line 62972
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconContentDescription:I

    const/16 v12, 0x3c

    .line 62984
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconDrawable:I

    const/16 v12, 0x3d

    .line 62997
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconMinSize:I

    const/16 v12, 0x3e

    .line 63024
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconScaleType:I

    const/16 v12, 0x3f

    .line 63035
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconTint:I

    const/16 v12, 0x40

    .line 63059
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_startIconTintMode:I

    const/16 v12, 0x41

    .line 63069
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_suffixText:I

    const/16 v12, 0x42

    .line 63081
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_suffixTextAppearance:I

    const/16 v12, 0x43

    .line 63092
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_suffixTextColor:I

    const/16 v12, 0x44

    .line 63102
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_enabled:I

    const/16 v12, 0x45

    .line 63112
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_hint:I

    const/16 v12, 0x46

    .line 63121
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_maxEms:I

    const/16 v12, 0x47

    .line 63134
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_maxWidth:I

    const/16 v12, 0x48

    .line 63143
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_minEms:I

    const/16 v12, 0x49

    .line 63156
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_minWidth:I

    const/16 v12, 0x4a

    .line 63171
    sput v12, Lcom/motorola/plugin/sdk/R$styleable;->TextInputLayout_android_textColorHint:I

    .line 63187
    filled-new-array {v0, v0, v0}, [I

    move-result-object v12

    sput-object v12, Lcom/motorola/plugin/sdk/R$styleable;->ThemeEnforcement:[I

    .line 63199
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ThemeEnforcement_enforceMaterialTheme:I

    .line 63209
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ThemeEnforcement_enforceTextAppearance:I

    .line 63221
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ThemeEnforcement_android_textAppearance:I

    .line 63291
    new-array v10, v10, [I

    fill-array-data v10, :array_62

    sput-object v10, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar:[I

    .line 63318
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_buttonGravity:I

    .line 63328
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_collapseContentDescription:I

    .line 63340
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_collapseIcon:I

    .line 63353
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetEnd:I

    .line 63366
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetEndWithActions:I

    .line 63379
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetLeft:I

    .line 63392
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetRight:I

    .line 63405
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetStart:I

    .line 63418
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_contentInsetStartWithNavigation:I

    .line 63430
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_logo:I

    .line 63440
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_logoDescription:I

    .line 63453
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_maxButtonHeight:I

    .line 63465
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_menu:I

    .line 63475
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_navigationContentDescription:I

    .line 63487
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_navigationIcon:I

    .line 63499
    sput v16, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_popupTheme:I

    .line 63509
    sput v17, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_subtitle:I

    .line 63521
    sput v18, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_subtitleTextAppearance:I

    .line 63532
    sput v19, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_subtitleTextColor:I

    .line 63542
    sput v20, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_title:I

    .line 63555
    sput v21, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMargin:I

    .line 63568
    sput v22, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMarginBottom:I

    .line 63581
    sput v2, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMarginEnd:I

    .line 63594
    sput v3, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMarginStart:I

    .line 63607
    sput v4, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMarginTop:I

    .line 63620
    sput v5, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleMargins:I

    .line 63632
    sput v27, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleTextAppearance:I

    .line 63643
    sput v6, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_titleTextColor:I

    .line 63672
    sput v8, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_android_gravity:I

    .line 63685
    sput v1, Lcom/motorola/plugin/sdk/R$styleable;->Toolbar_android_minHeight:I

    const/16 v1, 0x9

    .line 63713
    new-array v1, v1, [I

    fill-array-data v1, :array_63

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip:[I

    .line 63728
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_backgroundTint:I

    .line 63738
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_showMarker:I

    .line 63751
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_layout_margin:I

    .line 63764
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_minHeight:I

    .line 63777
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_minWidth:I

    .line 63790
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_padding:I

    .line 63800
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_text:I

    .line 63812
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_textAppearance:I

    .line 63827
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Tooltip_android_textColor:I

    const/16 v1, 0xc

    .line 63861
    new-array v1, v1, [I

    fill-array-data v1, :array_64

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->Transform:[I

    .line 63877
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Transform_transformPivotTarget:I

    .line 63890
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_elevation:I

    .line 63899
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_rotation:I

    .line 63908
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_rotationX:I

    .line 63917
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_rotationY:I

    .line 63926
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_scaleX:I

    .line 63935
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_scaleY:I

    .line 63948
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_transformPivotX:I

    .line 63961
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_transformPivotY:I

    .line 63974
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_translationX:I

    .line 63987
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_translationY:I

    .line 64000
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->Transform_android_translationZ:I

    const/16 v1, 0xb

    .line 64032
    new-array v1, v1, [I

    fill-array-data v1, :array_65

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->Transition:[I

    .line 64056
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Transition_autoTransition:I

    .line 64068
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Transition_constraintSetEnd:I

    .line 64080
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Transition_constraintSetStart:I

    .line 64089
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Transition_duration:I

    .line 64107
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Transition_layoutDuringTransition:I

    .line 64135
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->Transition_motionInterpolator:I

    .line 64156
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->Transition_pathMotionArc:I

    .line 64165
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->Transition_staggered:I

    .line 64175
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->Transition_transitionDisable:I

    .line 64194
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->Transition_transitionFlags:I

    .line 64206
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->Transition_android_id:I

    .line 64226
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->Variant:[I

    .line 64241
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->Variant_constraints:I

    .line 64254
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->Variant_region_heightLessThan:I

    .line 64267
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->Variant_region_heightMoreThan:I

    .line 64280
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->Variant_region_widthLessThan:I

    .line 64293
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->Variant_region_widthMoreThan:I

    .line 64313
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->View:[I

    .line 64329
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->View_paddingEnd:I

    .line 64342
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->View_paddingStart:I

    .line 64354
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->View_theme:I

    .line 64372
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->View_android_focusable:I

    .line 64384
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->View_android_theme:I

    .line 64400
    filled-new-array {v0, v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->ViewBackgroundHelper:[I

    .line 64413
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ViewBackgroundHelper_backgroundTint:I

    .line 64439
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ViewBackgroundHelper_backgroundTintMode:I

    .line 64454
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ViewBackgroundHelper_android_background:I

    .line 64466
    filled-new-array {v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->ViewPager2:[I

    .line 64485
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ViewPager2_android_orientation:I

    .line 64501
    filled-new-array {v0, v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->ViewStubCompat:[I

    .line 64515
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ViewStubCompat_android_id:I

    .line 64527
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ViewStubCompat_android_inflatedId:I

    .line 64539
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ViewStubCompat_android_layout:I

    const/16 v1, 0xf

    .line 64579
    new-array v1, v1, [I

    fill-array-data v1, :array_66

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition:[I

    .line 64593
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_SharedValue:I

    .line 64605
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_SharedValueId:I

    .line 64617
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_clearsTag:I

    .line 64626
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_duration:I

    .line 64638
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_ifTagNotSet:I

    .line 64650
    sput v28, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_ifTagSet:I

    .line 64678
    sput v7, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_motionInterpolator:I

    .line 64692
    sput v29, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_motionTarget:I

    .line 64712
    sput v9, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_onStateTransition:I

    .line 64733
    sput v30, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_pathMotionArc:I

    .line 64745
    sput v11, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_setsTag:I

    .line 64755
    sput v36, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_transitionDisable:I

    .line 64764
    sput v38, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_upDuration:I

    .line 64782
    sput v39, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_viewTransitionMode:I

    .line 64794
    sput v40, Lcom/motorola/plugin/sdk/R$styleable;->ViewTransition_android_id:I

    .line 64815
    filled-new-array {v0, v0, v0, v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections:[I

    .line 64830
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections_alsoKeepInApp:I

    .line 64840
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections_category:I

    .line 64851
    sput v24, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections_provider:I

    .line 64864
    sput v25, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections_sectionDrawable:I

    .line 64877
    sput v26, Lcom/motorola/plugin/sdk/R$styleable;->WidgetSections_sectionTitle:I

    .line 64891
    filled-new-array {v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->WidgetsListRowHeader:[I

    .line 64906
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->WidgetsListRowHeader_appIconSize:I

    .line 64916
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->WidgetsListRowHeader_collapsable:I

    .line 64930
    filled-new-array {v0, v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->WorkspaceSpec:[I

    .line 64950
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->WorkspaceSpec_dimensionType:I

    .line 64963
    sput v23, Lcom/motorola/plugin/sdk/R$styleable;->WorkspaceSpec_maxAvailableSize:I

    .line 64975
    filled-new-array {v0}, [I

    move-result-object v1

    sput-object v1, Lcom/motorola/plugin/sdk/R$styleable;->include:[I

    .line 64989
    sput v0, Lcom/motorola/plugin/sdk/R$styleable;->include_constraintSet:I

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_7
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_9
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_10
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_11
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_12
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_13
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_14
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_15
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_16
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_17
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_18
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_19
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_1f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_20
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_21
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_22
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_23
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_24
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_25
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_26
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_27
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_28
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_29
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_2f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_30
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_31
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_32
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_33
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_34
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_35
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_36
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_37
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_38
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_39
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_3f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_40
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_41
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_42
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_43
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_44
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_45
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_46
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_47
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_48
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_49
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_4f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_50
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_51
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_52
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_53
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_54
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_55
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_56
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_57
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_58
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_59
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5a
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5b
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5c
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5d
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5e
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_5f
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_60
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_61
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_62
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_63
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_64
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_65
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data

    :array_66
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>()V
    .locals 0

    .line 24505
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
