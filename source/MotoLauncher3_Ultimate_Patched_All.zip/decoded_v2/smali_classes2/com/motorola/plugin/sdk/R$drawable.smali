.class public final Lcom/motorola/plugin/sdk/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static abc_ab_share_pack_mtrl_alpha:I

.field public static abc_action_bar_item_background_material:I

.field public static abc_btn_borderless_material:I

.field public static abc_btn_check_material:I

.field public static abc_btn_check_material_anim:I

.field public static abc_btn_check_to_on_mtrl_000:I

.field public static abc_btn_check_to_on_mtrl_015:I

.field public static abc_btn_colored_material:I

.field public static abc_btn_default_mtrl_shape:I

.field public static abc_btn_radio_material:I

.field public static abc_btn_radio_material_anim:I

.field public static abc_btn_radio_to_on_mtrl_000:I

.field public static abc_btn_radio_to_on_mtrl_015:I

.field public static abc_btn_switch_to_on_mtrl_00001:I

.field public static abc_btn_switch_to_on_mtrl_00012:I

.field public static abc_cab_background_internal_bg:I

.field public static abc_cab_background_top_material:I

.field public static abc_cab_background_top_mtrl_alpha:I

.field public static abc_control_background_material:I

.field public static abc_dialog_material_background:I

.field public static abc_edit_text_material:I

.field public static abc_ic_ab_back_material:I

.field public static abc_ic_arrow_drop_right_black_24dp:I

.field public static abc_ic_arrow_forward:I

.field public static abc_ic_clear_material:I

.field public static abc_ic_commit_search_api_mtrl_alpha:I

.field public static abc_ic_go_search_api_material:I

.field public static abc_ic_menu_copy_mtrl_am_alpha:I

.field public static abc_ic_menu_cut_mtrl_alpha:I

.field public static abc_ic_menu_overflow_material:I

.field public static abc_ic_menu_paste_mtrl_am_alpha:I

.field public static abc_ic_menu_selectall_mtrl_alpha:I

.field public static abc_ic_menu_share_mtrl_alpha:I

.field public static abc_ic_permission:I

.field public static abc_ic_search_api_material:I

.field public static abc_ic_slice_send:I

.field public static abc_ic_voice_search_api_material:I

.field public static abc_item_background_holo_dark:I

.field public static abc_item_background_holo_light:I

.field public static abc_list_divider_material:I

.field public static abc_list_divider_mtrl_alpha:I

.field public static abc_list_focused_holo:I

.field public static abc_list_longpressed_holo:I

.field public static abc_list_pressed_holo_dark:I

.field public static abc_list_pressed_holo_light:I

.field public static abc_list_selector_background_transition_holo_dark:I

.field public static abc_list_selector_background_transition_holo_light:I

.field public static abc_list_selector_disabled_holo_dark:I

.field public static abc_list_selector_disabled_holo_light:I

.field public static abc_list_selector_holo_dark:I

.field public static abc_list_selector_holo_light:I

.field public static abc_menu_hardkey_panel_mtrl_mult:I

.field public static abc_popup_background_mtrl_mult:I

.field public static abc_ratingbar_indicator_material:I

.field public static abc_ratingbar_material:I

.field public static abc_ratingbar_small_material:I

.field public static abc_scrubber_control_off_mtrl_alpha:I

.field public static abc_scrubber_control_to_pressed_mtrl_000:I

.field public static abc_scrubber_control_to_pressed_mtrl_005:I

.field public static abc_scrubber_primary_mtrl_alpha:I

.field public static abc_scrubber_track_mtrl_alpha:I

.field public static abc_seekbar_thumb_material:I

.field public static abc_seekbar_tick_mark_material:I

.field public static abc_seekbar_track_material:I

.field public static abc_slice_gradient:I

.field public static abc_slice_remote_input_bg:I

.field public static abc_slice_ripple_drawable:I

.field public static abc_slice_see_more_bg:I

.field public static abc_spinner_mtrl_am_alpha:I

.field public static abc_spinner_textfield_background_material:I

.field public static abc_star_black_48dp:I

.field public static abc_star_half_black_48dp:I

.field public static abc_switch_thumb_material:I

.field public static abc_switch_track_mtrl_alpha:I

.field public static abc_tab_indicator_material:I

.field public static abc_tab_indicator_mtrl_alpha:I

.field public static abc_text_cursor_material:I

.field public static abc_text_select_handle_left_mtrl:I

.field public static abc_text_select_handle_middle_mtrl:I

.field public static abc_text_select_handle_right_mtrl:I

.field public static abc_textfield_activated_mtrl_alpha:I

.field public static abc_textfield_default_mtrl_alpha:I

.field public static abc_textfield_search_activated_mtrl_alpha:I

.field public static abc_textfield_search_default_mtrl_alpha:I

.field public static abc_textfield_search_material:I

.field public static abc_vector_test:I

.field public static add_item_dialog_background:I

.field public static all_apps_clear_input_button:I

.field public static all_apps_divider:I

.field public static all_apps_edu_circle:I

.field public static all_apps_folder_editor_name_bg:I

.field public static all_apps_menu_button:I

.field public static all_apps_menu_button_overlay:I

.field public static all_apps_search_hint:I

.field public static all_apps_tabs_background:I

.field public static appicon_calendar_week_1:I

.field public static appicon_calendar_week_1_zh_cn:I

.field public static arrow_toast_rounded_background:I

.field public static arrow_toast_rounded_desktop_background:I

.field public static assistant_gesture:I

.field public static avd_hide_password:I

.field public static avd_show_password:I

.field public static back_gesture:I

.field public static bg_all_apps_button:I

.field public static bg_all_apps_searchbox:I

.field public static bg_bubble_bar_drop_target:I

.field public static bg_bubble_dismiss_circle:I

.field public static bg_bubble_expanded_view_drop_target:I

.field public static bg_celllayout:I

.field public static bg_circle:I

.field public static bg_discovery_ad:I

.field public static bg_discovery_hint:I

.field public static bg_discovery_personalize_button:I

.field public static bg_discovery_privacy_button:I

.field public static bg_discovery_privacy_cancel:I

.field public static bg_floating_desktop_select:I

.field public static bg_notification_content:I

.field public static bg_overview_clear_all_button:I

.field public static bg_ps_header:I

.field public static bg_ps_lock_button:I

.field public static bg_ps_mask_left_corner:I

.field public static bg_ps_mask_right_corner:I

.field public static bg_ps_transition_image:I

.field public static bg_ps_unlock_button:I

.field public static bg_rounded_corner_bottom_sheet:I

.field public static bg_rounded_corner_bottom_sheet_handle:I

.field public static bg_sandbox_close_button:I

.field public static bg_sandbox_feedback:I

.field public static bg_taskbar_edu_tooltip:I

.field public static bg_wellbeing_toast:I

.field public static bg_widgets_content:I

.field public static bg_widgets_full_sheet:I

.field public static bg_widgets_header:I

.field public static bg_widgets_header_states:I

.field public static bg_widgets_header_states_two_pane:I

.field public static bg_widgets_header_two_pane:I

.field public static bg_widgets_searchbox:I

.field public static bg_work_apps_paused_action_button:I

.field public static bg_workspace_card_button:I

.field public static bottom_sheet_top_border:I

.field public static branch_arrow:I

.field public static branch_box_bg:I

.field public static branch_close:I

.field public static branch_gif_bg:I

.field public static branch_personalize:I

.field public static branch_personalize_bg:I

.field public static branch_switch_bg:I

.field public static branch_thumb:I

.field public static branch_thumb_off:I

.field public static branch_track:I

.field public static btn_checkbox_checked_mtrl:I

.field public static btn_checkbox_checked_to_unchecked_mtrl_animation:I

.field public static btn_checkbox_unchecked_mtrl:I

.field public static btn_checkbox_unchecked_to_checked_mtrl_animation:I

.field public static btn_radio_off_mtrl:I

.field public static btn_radio_off_to_on_mtrl_animation:I

.field public static btn_radio_on_mtrl:I

.field public static btn_radio_on_to_off_mtrl_animation:I

.field public static bubble_drop_target_background:I

.field public static bubble_ic_overflow_button:I

.field public static button_bottom_rounded_colored_ripple:I

.field public static button_rounded_colored_ripple:I

.field public static button_taskbar_edu_bordered:I

.field public static button_taskbar_edu_colored:I

.field public static button_top_rounded_bordered_ripple:I

.field public static cast_search_bar_bg:I

.field public static cast_search_bar_icon_bg:I

.field public static checkbox_item_bg:I

.field public static checkbox_selector:I

.field public static chip_hint_background_light:I

.field public static com_motorola_cn_calendar_dynamic_icons_week_1:I

.field public static com_motorola_cn_calendar_dynamic_icons_week_1_zh_cn:I

.field public static custom_list_preference_cancel:I

.field public static custom_list_preference_cancel_bg:I

.field public static deep_shortcuts_text_placeholder:I

.field public static default_sandbox_app_icon:I

.field public static default_sandbox_app_task_thumbnail:I

.field public static default_sandbox_wallpaper:I

.field public static design_fab_background:I

.field public static design_ic_visibility:I

.field public static design_ic_visibility_off:I

.field public static design_password_eye:I

.field public static design_snackbar_background:I

.field public static dialog_btn_filled:I

.field public static dialog_btn_outline:I

.field public static discovery_link_bg:I

.field public static discovery_smart_bg:I

.field public static divider:I

.field public static dm_all_apps_search_hint:I

.field public static dm_allapp_icon_selector:I

.field public static dm_bg_all_apps:I

.field public static dm_bg_desktop_shortcut:I

.field public static dm_bg_search_container:I

.field public static dm_bg_suggest_item_focused:I

.field public static dm_bg_suggest_item_nomal:I

.field public static dm_desktop_icon_selector:I

.field public static dm_suggest_item_bg:I

.field public static dm_workspace_cell_available_bg:I

.field public static dm_workspace_cell_unavailable_bg:I

.field public static drop_target_background:I

.field public static drop_target_frame:I

.field public static drop_target_frame_hover:I

.field public static eldin_add:I

.field public static eldin_voice:I

.field public static enter_home_gardening_icon:I

.field public static floating_dismiss_background:I

.field public static floating_dismiss_ic_close:I

.field public static fly_away_bg:I

.field public static free_form_btn:I

.field public static free_form_btn_bg:I

.field public static free_form_btn_layer:I

.field public static full_rounded_colored_ripple:I

.field public static full_rounded_colored_ripple_outline:I

.field public static full_rounded_transparent_ripple:I

.field public static fullscreen_folder_content_bg:I

.field public static gesture_tutorial_action_button_background:I

.field public static gesture_tutorial_back_step_shape:I

.field public static gesture_tutorial_cancel_button_background:I

.field public static gesture_tutorial_close_button:I

.field public static gesture_tutorial_complete_checkmark:I

.field public static gesture_tutorial_complete_checkmark_bg:I

.field public static gesture_tutorial_finger_dot:I

.field public static gesture_tutorial_home_step_shape:I

.field public static gesture_tutorial_loop_back:I

.field public static gesture_tutorial_loop_home:I

.field public static gesture_tutorial_loop_overview:I

.field public static gesture_tutorial_menu_back_button_background:I

.field public static gesture_tutorial_menu_home_button_background:I

.field public static gesture_tutorial_menu_overview_button_background:I

.field public static gesture_tutorial_overview_step_shape:I

.field public static gesture_tutorial_ripple:I

.field public static global_search_know_bg:I

.field public static gm_edit_24:I

.field public static gutter_horizontal:I

.field public static home_gesture:I

.field public static home_settings_switch_thumb:I

.field public static home_settings_switch_thumb_checked:I

.field public static home_settings_switch_thumb_unchecked:I

.field public static home_settings_switch_track:I

.field public static home_style_radio_btn:I

.field public static horizontal_ellipsis:I

.field public static hotseat_edu_notification_icon:I

.field public static hotseat_icon:I

.field public static hotseat_search_bar:I

.field public static ic_add:I

.field public static ic_all_apps_bg_hand:I

.field public static ic_all_apps_bg_icon_1:I

.field public static ic_all_apps_bg_icon_2:I

.field public static ic_all_apps_bg_icon_3:I

.field public static ic_all_apps_bg_icon_4:I

.field public static ic_all_apps_button:I

.field public static ic_all_set:I

.field public static ic_allapps_search:I

.field public static ic_app_locked:I

.field public static ic_app_locked_prc:I

.field public static ic_app_unlocked:I

.field public static ic_app_unlocked_prc:I

.field public static ic_apps:I

.field public static ic_arrow_back:I

.field public static ic_arrow_back_black_24:I

.field public static ic_arrow_down:I

.field public static ic_arrow_down_24dp:I

.field public static ic_arrow_down_prc:I

.field public static ic_arrow_up:I

.field public static ic_arrow_up_prc:I

.field public static ic_block_no_shadow:I

.field public static ic_branch_download:I

.field public static ic_branch_setting:I

.field public static ic_branch_thumb:I

.field public static ic_branch_work:I

.field public static ic_bubble_dismiss_white:I

.field public static ic_call_answer:I

.field public static ic_call_answer_low:I

.field public static ic_call_answer_video:I

.field public static ic_call_answer_video_low:I

.field public static ic_call_decline:I

.field public static ic_call_decline_low:I

.field public static ic_caption_desktop_button_foreground:I

.field public static ic_checked:I

.field public static ic_chevron_down:I

.field public static ic_clear:I

.field public static ic_clear_all:I

.field public static ic_clear_black_24:I

.field public static ic_clock_black_24dp:I

.field public static ic_clone_app_badge:I

.field public static ic_close:I

.field public static ic_conversations_widget_category:I

.field public static ic_corp:I

.field public static ic_corp_off:I

.field public static ic_deepshortcut_placeholder:I

.field public static ic_delete:I

.field public static ic_desktop:I

.field public static ic_disable:I

.field public static ic_display_settings:I

.field public static ic_drag_handle:I

.field public static ic_edit:I

.field public static ic_empty_recents:I

.field public static ic_empty_recents_prc:I

.field public static ic_endless_mode:I

.field public static ic_endless_mode_close:I

.field public static ic_endless_mode_open:I

.field public static ic_enlarge:I

.field public static ic_expand_less:I

.field public static ic_expand_less_24px:I

.field public static ic_expand_more:I

.field public static ic_expand_more_24px:I

.field public static ic_explore:I

.field public static ic_external_display:I

.field public static ic_folder:I

.field public static ic_freeform:I

.field public static ic_fullscreen_close:I

.field public static ic_fullscreen_open:I

.field public static ic_global_search:I

.field public static ic_gm_close_24:I

.field public static ic_home_style_setting:I

.field public static ic_hourglass_top:I

.field public static ic_icon_size_hint:I

.field public static ic_ime_switcher:I

.field public static ic_info_no_shadow:I

.field public static ic_install_no_shadow:I

.field public static ic_install_to_private:I

.field public static ic_instant_app_badge:I

.field public static ic_keyboard:I

.field public static ic_keyboard_black_24dp:I

.field public static ic_launcher_browser:I

.field public static ic_launcher_calendar_18_front:I

.field public static ic_launcher_calendar_back:I

.field public static ic_launcher_home:I

.field public static ic_launcher_moto_app_launcher_foreground:I

.field public static ic_lock:I

.field public static ic_lock_circle:I

.field public static ic_m3_chip_check:I

.field public static ic_m3_chip_checked_circle:I

.field public static ic_m3_chip_close:I

.field public static ic_minify:I

.field public static ic_minus:I

.field public static ic_more:I

.field public static ic_more_white:I

.field public static ic_moto_app_launcher_back:I

.field public static ic_moto_app_launcher_front:I

.field public static ic_mtrl_checked_circle:I

.field public static ic_mtrl_chip_checked_black:I

.field public static ic_mtrl_chip_checked_circle:I

.field public static ic_mtrl_chip_close_circle:I

.field public static ic_new_tab:I

.field public static ic_not_select:I

.field public static ic_note_taking_widget_category:I

.field public static ic_overview_freeform:I

.field public static ic_overview_freeform_prc:I

.field public static ic_overview_ready_for:I

.field public static ic_overview_ready_for_prc:I

.field public static ic_overview_smart_connection:I

.field public static ic_overview_smart_connection_prc:I

.field public static ic_palette:I

.field public static ic_pin:I

.field public static ic_plus:I

.field public static ic_private_profile_app_badge:I

.field public static ic_private_profile_app_scroller_badge:I

.field public static ic_private_space_with_background:I

.field public static ic_ps_settings:I

.field public static ic_radio_btn_checked:I

.field public static ic_radio_btn_unchecked:I

.field public static ic_ready_for:I

.field public static ic_ready_for_icon:I

.field public static ic_refresh:I

.field public static ic_remove_no_shadow:I

.field public static ic_remove_no_shadow_desktop:I

.field public static ic_reorder:I

.field public static ic_save_app_pair_left_right:I

.field public static ic_save_app_pair_up_down:I

.field public static ic_screenshot:I

.field public static ic_screenshot_prc:I

.field public static ic_search_black_24:I

.field public static ic_secure_folder:I

.field public static ic_select:I

.field public static ic_select_star:I

.field public static ic_select_windows:I

.field public static ic_setting:I

.field public static ic_smart_connection:I

.field public static ic_split_exit:I

.field public static ic_split_horizontal:I

.field public static ic_split_left:I

.field public static ic_split_right:I

.field public static ic_split_top:I

.field public static ic_split_vertical:I

.field public static ic_star:I

.field public static ic_sysbar_accessibility_button:I

.field public static ic_sysbar_back:I

.field public static ic_sysbar_back_kids:I

.field public static ic_sysbar_home:I

.field public static ic_sysbar_home_kids:I

.field public static ic_sysbar_notifications:I

.field public static ic_sysbar_quick_settings:I

.field public static ic_sysbar_recent:I

.field public static ic_sysbar_rotate_button_ccw_start_0:I

.field public static ic_sysbar_rotate_button_ccw_start_90:I

.field public static ic_sysbar_rotate_button_cw_start_0:I

.field public static ic_sysbar_rotate_button_cw_start_90:I

.field public static ic_taskbar_all_apps_button:I

.field public static ic_taskbar_all_apps_search_button:I

.field public static ic_tip_view_remove_no_shadow:I

.field public static ic_touch:I

.field public static ic_transient_taskbar_all_apps_button:I

.field public static ic_transient_taskbar_all_apps_search_button:I

.field public static ic_trending_up:I

.field public static ic_uninstall_no_shadow:I

.field public static ic_unpin:I

.field public static ic_vault_app_badge:I

.field public static ic_visibility:I

.field public static ic_wallpaper:I

.field public static ic_warning:I

.field public static ic_widget:I

.field public static ic_widget_height_decrease:I

.field public static ic_widget_height_increase:I

.field public static ic_widget_resize_handle:I

.field public static ic_widget_setting:I

.field public static ic_widget_stack_remove:I

.field public static ic_widget_width_decrease:I

.field public static ic_widget_width_increase:I

.field public static ic_work_app_badge:I

.field public static icon_applock_dark:I

.field public static icon_applock_light:I

.field public static icon_applock_row_dark:I

.field public static icon_applock_row_light:I

.field public static icon_menu_arrow_background:I

.field public static icon_personalize_recyclerview:I

.field public static icon_size_bg:I

.field public static icon_size_minus:I

.field public static icon_size_minus_bg:I

.field public static icon_size_plus:I

.field public static icon_size_plus_bg:I

.field public static indeterminate_static:I

.field public static keyboard_quick_switch_overview_button_background:I

.field public static keyboard_quick_switch_task_view_background:I

.field public static keyboard_quick_switch_thumbnail_background:I

.field public static keyboard_quick_switch_view_background:I

.field public static list_preference_dialog:I

.field public static m3_avd_hide_password:I

.field public static m3_avd_show_password:I

.field public static m3_bottom_sheet_drag_handle:I

.field public static m3_password_eye:I

.field public static m3_popupmenu_background_overlay:I

.field public static m3_radiobutton_ripple:I

.field public static m3_selection_control_ripple:I

.field public static m3_split_button_chevron_avd:I

.field public static m3_tabs_background:I

.field public static m3_tabs_line_indicator:I

.field public static m3_tabs_rounded_line_indicator:I

.field public static m3_tabs_transparent_background:I

.field public static material_cursor_drawable:I

.field public static material_ic_calendar_black_24dp:I

.field public static material_ic_clear_black_24dp:I

.field public static material_ic_edit_black_24dp:I

.field public static material_ic_keyboard_arrow_left_black_24dp:I

.field public static material_ic_keyboard_arrow_next_black_24dp:I

.field public static material_ic_keyboard_arrow_previous_black_24dp:I

.field public static material_ic_keyboard_arrow_right_black_24dp:I

.field public static material_ic_menu_arrow_down_black_24dp:I

.field public static material_ic_menu_arrow_up_black_24dp:I

.field public static middle_item_primary:I

.field public static mock_app_icon:I

.field public static mock_taskbar_background:I

.field public static mtrl_bottomsheet_drag_handle:I

.field public static mtrl_checkbox_button:I

.field public static mtrl_checkbox_button_checked_unchecked:I

.field public static mtrl_checkbox_button_icon:I

.field public static mtrl_checkbox_button_icon_checked_indeterminate:I

.field public static mtrl_checkbox_button_icon_checked_unchecked:I

.field public static mtrl_checkbox_button_icon_indeterminate_checked:I

.field public static mtrl_checkbox_button_icon_indeterminate_unchecked:I

.field public static mtrl_checkbox_button_icon_unchecked_checked:I

.field public static mtrl_checkbox_button_icon_unchecked_indeterminate:I

.field public static mtrl_checkbox_button_unchecked_checked:I

.field public static mtrl_dialog_background:I

.field public static mtrl_dropdown_arrow:I

.field public static mtrl_ic_arrow_drop_down:I

.field public static mtrl_ic_arrow_drop_up:I

.field public static mtrl_ic_cancel:I

.field public static mtrl_ic_check_mark:I

.field public static mtrl_ic_checkbox_checked:I

.field public static mtrl_ic_checkbox_unchecked:I

.field public static mtrl_ic_error:I

.field public static mtrl_ic_indeterminate:I

.field public static mtrl_navigation_bar_item_background:I

.field public static mtrl_popupmenu_background:I

.field public static mtrl_popupmenu_background_overlay:I

.field public static mtrl_switch_thumb:I

.field public static mtrl_switch_thumb_checked:I

.field public static mtrl_switch_thumb_checked_pressed:I

.field public static mtrl_switch_thumb_checked_unchecked:I

.field public static mtrl_switch_thumb_pressed:I

.field public static mtrl_switch_thumb_pressed_checked:I

.field public static mtrl_switch_thumb_pressed_unchecked:I

.field public static mtrl_switch_thumb_unchecked:I

.field public static mtrl_switch_thumb_unchecked_checked:I

.field public static mtrl_switch_thumb_unchecked_pressed:I

.field public static mtrl_switch_track:I

.field public static mtrl_switch_track_decoration:I

.field public static mtrl_tabs_default_indicator:I

.field public static navigation_empty_icon:I

.field public static notification_action_background:I

.field public static notification_bg:I

.field public static notification_bg_low:I

.field public static notification_bg_low_normal:I

.field public static notification_bg_low_pressed:I

.field public static notification_bg_normal:I

.field public static notification_bg_normal_pressed:I

.field public static notification_circle:I

.field public static notification_icon_background:I

.field public static notification_oversize_large_icon_bg:I

.field public static notification_template_icon_bg:I

.field public static notification_template_icon_low_bg:I

.field public static notification_tile_bg:I

.field public static notify_panel_notification_icon_bg:I

.field public static overlay_tab_bg:I

.field public static overview_btn_bg:I

.field public static overview_btn_bg_prc:I

.field public static overview_btn_circle_bg:I

.field public static overview_btn_circle_bg_prc:I

.field public static overview_gesture:I

.field public static overview_locked_bg:I

.field public static overview_locked_bg_prc:I

.field public static overview_unlocked_bg:I

.field public static overview_unlocked_bg_prc:I

.field public static padded_rounded_action_button:I

.field public static page_indicator:I

.field public static pending_widget_bg:I

.field public static popup_background:I

.field public static preference_list_divider_material:I

.field public static private_space_app_divider:I

.field public static private_space_install_app_icon:I

.field public static ps_lock_background:I

.field public static ps_settings_background:I

.field public static qsb_host_view_focus_bg:I

.field public static rating_layer:I

.field public static ready_for_bg:I

.field public static ready_for_bg_round:I

.field public static ready_for_bg_row:I

.field public static redesigned_hotseat_icon:I

.field public static redesigned_top_task_view:I

.field public static rotate_prompt_bg:I

.field public static rotate_tutorial_warning:I

.field public static round_rect_folder:I

.field public static round_rect_primary:I

.field public static rounded_action_button:I

.field public static rounded_popup_ripple:I

.field public static selector_switch_layout_color:I

.field public static sensi_seekbar_progress:I

.field public static sensi_seekbar_thumb:I

.field public static sensi_seekbar_thumb_default:I

.field public static sensi_seekbar_thumb_disabled:I

.field public static sensi_seekbar_thumb_pressed:I

.field public static sensi_seekbar_tickmark:I

.field public static sensi_seekbar_track_background:I

.field public static sensi_seekbar_track_selected:I

.field public static sensi_settingslib_switch_thumb:I

.field public static setting_switchbar_thumb:I

.field public static setting_switchbar_track:I

.field public static settingslib_arrow_drop_down:I

.field public static settingslib_expressive_button_background_filled:I

.field public static settingslib_expressive_button_background_outline:I

.field public static settingslib_expressive_icon_bullet_start:I

.field public static settingslib_expressive_icon_check:I

.field public static settingslib_expressive_icon_chevron:I

.field public static settingslib_expressive_icon_close:I

.field public static settingslib_expressive_icon_collapse:I

.field public static settingslib_expressive_icon_cross:I

.field public static settingslib_expressive_icon_expand:I

.field public static settingslib_expressive_icon_level_high:I

.field public static settingslib_expressive_icon_level_low:I

.field public static settingslib_expressive_icon_level_medium:I

.field public static settingslib_expressive_icon_level_normal:I

.field public static settingslib_expressive_icon_up:I

.field public static settingslib_expressive_spinner_background:I

.field public static settingslib_expressive_spinner_background_outlined:I

.field public static settingslib_expressive_spinner_dropdown_background:I

.field public static settingslib_expressive_switch_thumb_icon:I

.field public static settingslib_list_divider:I

.field public static settingslib_progress_horizontal:I

.field public static settingslib_round_background:I

.field public static settingslib_round_background_bottom:I

.field public static settingslib_round_background_bottom_highlighted:I

.field public static settingslib_round_background_bottom_selected:I

.field public static settingslib_round_background_center:I

.field public static settingslib_round_background_center_highlighted:I

.field public static settingslib_round_background_center_selected:I

.field public static settingslib_round_background_highlighted:I

.field public static settingslib_round_background_selected:I

.field public static settingslib_round_background_top:I

.field public static settingslib_round_background_top_highlighted:I

.field public static settingslib_round_background_top_selected:I

.field public static settingslib_spinner_background:I

.field public static settingslib_spinner_dropdown_background:I

.field public static settingslib_switch_thumb:I

.field public static settingslib_switch_track:I

.field public static shape_button:I

.field public static shape_button_invalid:I

.field public static single_item_primary:I

.field public static single_item_primary_hover:I

.field public static slidingpanelayout_divider:I

.field public static smart_eye_btn:I

.field public static smart_eye_icon:I

.field public static sp_extra_action_bg:I

.field public static sp_smart_card_bg_opaque:I

.field public static split_instructions_background:I

.field public static switch_layout_close_bg:I

.field public static switch_layout_open_bg:I

.field public static tab_background:I

.field public static tab_selected_background:I

.field public static tab_unselected_background:I

.field public static task_menu_bg:I

.field public static task_menu_item_bg:I

.field public static task_menu_item_bg_bottom:I

.field public static task_menu_item_bg_top:I

.field public static taskbar_divider_button:I

.field public static taskbar_icon_click_feedback_roundrect:I

.field public static test_level_drawable:I

.field public static toast_bg:I

.field public static tooltip_frame:I

.field public static tooltip_frame_dark:I

.field public static tooltip_frame_light:I

.field public static top_round_rect_primary:I

.field public static top_task_view:I

.field public static tutorial_step_indicator_pill:I

.field public static view_carousel:I

.field public static widget_cell_add_button_background:I

.field public static widget_internal_focus_bg:I

.field public static widget_picker_collapse_handle:I

.field public static widget_picker_preview_pane_scroll_thumb:I

.field public static widget_picker_tabs_background:I

.field public static widget_reconfigure_button_frame:I

.field public static widget_resize_frame:I

.field public static widget_search:I

.field public static widget_stack_bg:I

.field public static widget_stack_edit_btn_bg:I

.field public static widget_stack_edit_item_bg:I

.field public static widget_suggestions:I

.field public static widget_suggestions_icon:I

.field public static widgets_surface_background:I

.field public static widgets_tray_expand_button:I

.field public static work_apps_toggle_background:I

.field public static work_card:I

.field public static work_mode_fab_background:I


# direct methods
.method static constructor <clinit>()V
    .locals 0

    .line 0
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 18326
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
