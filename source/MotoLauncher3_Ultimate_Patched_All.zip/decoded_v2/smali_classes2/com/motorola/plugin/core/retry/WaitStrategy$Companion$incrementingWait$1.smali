.class public final Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/WaitStrategy;


# instance fields
.field final synthetic $increment:J

.field final synthetic $incrementTimeUnit:Ljava/util/concurrent/TimeUnit;

.field final synthetic $initialTime:J

.field final synthetic $initialTimeUnit:Ljava/util/concurrent/TimeUnit;

.field private final incrementTimeInMillis:J

.field private final initialTimeInMillis:J


# direct methods
.method constructor <init>(Ljava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;J)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->$initialTimeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->$initialTime:J

    iput-object p4, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->$incrementTimeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p5, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->$increment:J

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->initialTimeInMillis:J

    .line 60
    invoke-virtual {p4, p5, p6}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->incrementTimeInMillis:J

    return-void
.end method


# virtual methods
.method public computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
    .locals 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->initialTimeInMillis:J

    iget-wide v2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->incrementTimeInMillis:J

    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->getAttemptNumber()J

    move-result-wide p0

    const-wide/16 v4, 0x1

    sub-long/2addr p0, v4

    mul-long/2addr v2, p0

    add-long/2addr v0, v2

    const-wide/16 p0, 0x0

    cmp-long v2, v0, p0

    if-ltz v2, :cond_0

    return-wide v0

    :cond_0
    return-wide p0
.end method

.method public final getIncrementTimeInMillis()J
    .locals 2

    .line 60
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->incrementTimeInMillis:J

    return-wide v0
.end method

.method public final getInitialTimeInMillis()J
    .locals 2

    .line 59
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;->initialTimeInMillis:J

    return-wide v0
.end method
