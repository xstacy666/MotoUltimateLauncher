.class public final Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;
.super Ljava/lang/Object;
.source "RetryStrategy.kt"


# static fields
.field static final synthetic $$INSTANCE:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    invoke-direct {v0}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;-><init>()V

    sput-object v0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final ifException(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryStrategy;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    new-instance p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifException$1;

    invoke-direct {p0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifException$1;-><init>(Ljava/util/function/Predicate;)V

    return-object p0
.end method

.method public final ifExceptionClass(Ljava/lang/Class;)Lcom/motorola/plugin/core/retry/RetryStrategy;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    new-instance p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifExceptionClass$1;

    invoke-direct {p0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifExceptionClass$1;-><init>(Ljava/lang/Class;)V

    return-object p0
.end method

.method public final ifResult(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryStrategy;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    new-instance p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifResult$1;

    invoke-direct {p0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifResult$1;-><init>(Ljava/util/function/Predicate;)V

    return-object p0
.end method

.method public final neverTry()Lcom/motorola/plugin/core/retry/RetryStrategy;
    .locals 0

    .line 18
    new-instance p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$neverTry$1;

    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$neverTry$1;-><init>()V

    return-object p0
.end method
