.class public interface abstract Lcom/motorola/plugin/core/retry/StopStrategy;
.super Ljava/lang/Object;
.source "StopStrategy.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    sput-object v0, Lcom/motorola/plugin/core/retry/StopStrategy;->Companion:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    return-void
.end method


# virtual methods
.method public abstract shouldStop(Lcom/motorola/plugin/core/retry/Attempt;)Z
.end method
