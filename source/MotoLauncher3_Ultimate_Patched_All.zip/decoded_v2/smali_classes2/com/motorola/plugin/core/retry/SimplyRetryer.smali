.class public final Lcom/motorola/plugin/core/retry/SimplyRetryer;
.super Ljava/lang/Object;
.source "SimplyRetryer.kt"


# instance fields
.field private counter:J

.field private final maxCount:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 0
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v2, v0, v1}, Lcom/motorola/plugin/core/retry/SimplyRetryer;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->maxCount:I

    return-void
.end method

.method public synthetic constructor <init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const/16 p1, 0x14

    .line 12
    :cond_0
    invoke-direct {p0, p1}, Lcom/motorola/plugin/core/retry/SimplyRetryer;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final canRetry()Z
    .locals 4

    .line 16
    monitor-enter p0

    .line 17
    :try_start_0
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->counter:J

    iget v2, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->maxCount:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    int-to-long v2, v2

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    monitor-exit p0

    return v0

    :catchall_0
    move-exception v0

    .line 16
    monitor-exit p0

    throw v0
.end method

.method public final failed()J
    .locals 4

    .line 24
    monitor-enter p0

    .line 25
    :try_start_0
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->counter:J

    const-wide/16 v2, 0x1

    add-long/2addr v2, v0

    iput-wide v2, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->counter:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    monitor-exit p0

    return-wide v0

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final reset()V
    .locals 2

    .line 28
    monitor-enter p0

    const-wide/16 v0, 0x0

    .line 29
    :try_start_0
    iput-wide v0, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->counter:J

    .line 30
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final success()V
    .locals 2

    .line 20
    monitor-enter p0

    const-wide/16 v0, 0x0

    .line 21
    :try_start_0
    iput-wide v0, p0, Lcom/motorola/plugin/core/retry/SimplyRetryer;->counter:J

    .line 22
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method
