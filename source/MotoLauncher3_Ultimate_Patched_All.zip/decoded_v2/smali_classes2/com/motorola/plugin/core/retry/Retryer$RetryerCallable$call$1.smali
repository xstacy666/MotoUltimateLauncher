.class final Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable$call$1;
.super Lkotlin/jvm/internal/Lambda;
.source "Retryer.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field final synthetic this$0:Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;


# direct methods
.method constructor <init>(Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable$call$1;->this$0:Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 156
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable$call$1;->this$0:Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;

    invoke-static {p0}, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;->access$getCallable$p(Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;)Ljava/util/concurrent/Callable;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
