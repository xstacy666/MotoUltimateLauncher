.class public final Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;
.super Ljava/lang/Object;
.source "BlockStrategy.kt"


# static fields
.field static final synthetic $$INSTANCE:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    invoke-direct {v0}, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;-><init>()V

    sput-object v0, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final coroutineDelayStrategy()Lcom/motorola/plugin/core/retry/BlockStrategy;
    .locals 0

    .line 18
    new-instance p0, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion$coroutineDelayStrategy$1;

    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion$coroutineDelayStrategy$1;-><init>()V

    return-object p0
.end method
