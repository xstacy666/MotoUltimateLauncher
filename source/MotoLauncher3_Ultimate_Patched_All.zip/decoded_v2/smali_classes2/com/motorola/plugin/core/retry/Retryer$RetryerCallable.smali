.class final Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;
.super Ljava/lang/Object;
.source "Retryer.kt"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field private final callable:Ljava/util/concurrent/Callable;

.field private final retryer:Lcom/motorola/plugin/core/retry/Retryer;


# direct methods
.method public constructor <init>(Lcom/motorola/plugin/core/retry/Retryer;Ljava/util/concurrent/Callable;)V
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;->retryer:Lcom/motorola/plugin/core/retry/Retryer;

    .line 148
    iput-object p2, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;->callable:Ljava/util/concurrent/Callable;

    return-void
.end method

.method public static final synthetic access$getCallable$p(Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;)Ljava/util/concurrent/Callable;
    .locals 0

    .line 147
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;->callable:Ljava/util/concurrent/Callable;

    return-object p0
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;,
            Lcom/motorola/plugin/core/retry/RetryException;
        }
    .end annotation

    .line 156
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;->retryer:Lcom/motorola/plugin/core/retry/Retryer;

    new-instance v1, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable$call$1;

    invoke-direct {v1, p0}, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable$call$1;-><init>(Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;)V

    invoke-static {v0, v1}, Lcom/motorola/plugin/core/retry/RetryerKt;->callBlocking(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
