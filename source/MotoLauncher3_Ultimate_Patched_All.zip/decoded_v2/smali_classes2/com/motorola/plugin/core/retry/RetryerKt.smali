.class public final Lcom/motorola/plugin/core/retry/RetryerKt;
.super Ljava/lang/Object;
.source "Retryer.kt"


# direct methods
.method public static final callBlocking(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 173
    new-instance v0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;-><init>(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)V

    const/4 p0, 0x1

    invoke-static {v1, v0, p0, v1}, Lkotlinx/coroutines/BuildersKt;->runBlocking$default(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
