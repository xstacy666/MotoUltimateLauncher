.class public final Lcom/motorola/plugin/core/retry/RetryerBuilder;
.super Ljava/lang/Object;
.source "RetryerBuilder.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;


# instance fields
.field private attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

.field private blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

.field private final listeners:Ljava/util/List;

.field private retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

.field private stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

.field private waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;


# direct methods
.method public static synthetic $r8$lambda$b6XavBqAuGYP6BgRUHNCjf5xcAI(Ljava/lang/Object;)Z
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryIfResultNull$lambda-0(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->Companion:Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    sget-object v0, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    invoke-virtual {v0}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->neverTry()Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v0

    iput-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    .line 18
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->listeners:Ljava/util/List;

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/RetryerBuilder;-><init>()V

    return-void
.end method

.method private static final retryIfResultNull$lambda-0(Ljava/lang/Object;)Z
    .locals 0

    .line 0
    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final build()Lcom/motorola/plugin/core/retry/Retryer;
    .locals 8

    .line 165
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    if-nez v0, :cond_0

    sget-object v0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;->Companion:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    invoke-virtual {v0}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;->noTimeLimit()Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    move-result-object v0

    :cond_0
    move-object v2, v0

    .line 166
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

    if-nez v0, :cond_1

    sget-object v0, Lcom/motorola/plugin/core/retry/StopStrategy;->Companion:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    invoke-virtual {v0}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;->neverStop()Lcom/motorola/plugin/core/retry/StopStrategy;

    move-result-object v0

    :cond_1
    move-object v3, v0

    .line 167
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;

    if-nez v0, :cond_2

    sget-object v0, Lcom/motorola/plugin/core/retry/WaitStrategy;->Companion:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    invoke-virtual {v0}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->noWait()Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object v0

    :cond_2
    move-object v4, v0

    .line 168
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

    if-nez v0, :cond_3

    sget-object v0, Lcom/motorola/plugin/core/retry/BlockStrategy;->Companion:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    invoke-virtual {v0}, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;->coroutineDelayStrategy()Lcom/motorola/plugin/core/retry/BlockStrategy;

    move-result-object v0

    :cond_3
    move-object v5, v0

    .line 169
    iget-object v6, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    .line 170
    new-instance v1, Lcom/motorola/plugin/core/retry/Retryer;

    .line 176
    iget-object v7, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->listeners:Ljava/util/List;

    .line 170
    invoke-direct/range {v1 .. v7}, Lcom/motorola/plugin/core/retry/Retryer;-><init>(Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;Lcom/motorola/plugin/core/retry/StopStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/BlockStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;Ljava/util/Collection;)V

    return-object v1
.end method

.method public final retryIf(Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    invoke-static {v0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfException()Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 3

    .line 86
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    const-class v2, Ljava/lang/Exception;

    invoke-virtual {v1, v2}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifExceptionClass(Ljava/lang/Class;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v0

    iput-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfException(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 121
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    invoke-virtual {v1, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifException(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfExceptionOfType(Ljava/lang/Class;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    invoke-virtual {v1, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifExceptionClass(Ljava/lang/Class;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfResult(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    invoke-virtual {v1, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifResult(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object p1

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfResultNull()Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 3

    .line 131
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    new-instance v2, Lcom/motorola/plugin/core/retry/RetryerBuilder$$ExternalSyntheticLambda0;

    invoke-direct {v2}, Lcom/motorola/plugin/core/retry/RetryerBuilder$$ExternalSyntheticLambda0;-><init>()V

    invoke-virtual {v1, v2}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifResult(Ljava/util/function/Predicate;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v0

    iput-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final retryIfRuntimeException()Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 3

    .line 97
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    sget-object v1, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    const-class v2, Ljava/lang/RuntimeException;

    invoke-virtual {v1, v2}, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->ifExceptionClass(Ljava/lang/Class;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/motorola/plugin/core/retry/RetryStrategyKt;->plus(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)Lcom/motorola/plugin/core/retry/RetryStrategy;

    move-result-object v0

    iput-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public final withAttemptTimeLimiter(Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    return-object p0
.end method

.method public final withBlockStrategy(Lcom/motorola/plugin/core/retry/BlockStrategy;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

    return-object p0
.end method

.method public final withRetryListener(Lkotlin/jvm/functions/Function1;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->listeners:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    return-object p0
.end method

.method public final withStopStrategy(Lcom/motorola/plugin/core/retry/StopStrategy;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

    return-object p0
.end method

.method public final withWaitStrategy(Lcom/motorola/plugin/core/retry/WaitStrategy;)Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;->waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;

    return-object p0
.end method
