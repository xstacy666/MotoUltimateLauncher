.class public final synthetic Lcom/motorola/plugin/core/retry/RetryerBuilder$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Predicate;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final test(Ljava/lang/Object;)Z
    .locals 0

    .line 0
    invoke-static {p1}, Lcom/motorola/plugin/core/retry/RetryerBuilder;->$r8$lambda$b6XavBqAuGYP6BgRUHNCjf5xcAI(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method
