.class public final Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/WaitStrategy;


# instance fields
.field final synthetic $maxDuration:J

.field final synthetic $maxTimeUnit:Ljava/util/concurrent/TimeUnit;

.field final synthetic $minDuration:J

.field final synthetic $minTimeUnit:Ljava/util/concurrent/TimeUnit;

.field private final maxTimeInMillis:J

.field private final minTimeInMillis:J


# direct methods
.method constructor <init>(Ljava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;J)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->$minTimeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->$minDuration:J

    iput-object p4, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->$maxTimeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p5, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->$maxDuration:J

    .line 43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 45
    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->minTimeInMillis:J

    .line 46
    invoke-virtual {p4, p5, p6}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->maxTimeInMillis:J

    return-void
.end method


# virtual methods
.method public computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
    .locals 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    sget-object p1, Lkotlin/random/Random;->Default:Lkotlin/random/Random$Default;

    invoke-virtual {p1}, Lkotlin/random/Random$Default;->nextLong()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    iget-wide v2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->maxTimeInMillis:J

    iget-wide p0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->minTimeInMillis:J

    sub-long/2addr v2, p0

    rem-long/2addr v0, v2

    add-long/2addr v0, p0

    return-wide v0
.end method

.method public final getMaxTimeInMillis()J
    .locals 2

    .line 46
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->maxTimeInMillis:J

    return-wide v0
.end method

.method public final getMinTimeInMillis()J
    .locals 2

    .line 45
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;->minTimeInMillis:J

    return-wide v0
.end method
