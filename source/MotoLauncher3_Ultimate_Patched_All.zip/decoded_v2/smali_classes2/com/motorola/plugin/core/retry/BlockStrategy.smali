.class public interface abstract Lcom/motorola/plugin/core/retry/BlockStrategy;
.super Ljava/lang/Object;
.source "BlockStrategy.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    sput-object v0, Lcom/motorola/plugin/core/retry/BlockStrategy;->Companion:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    return-void
.end method


# virtual methods
.method public abstract block(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end method
