.class final Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;
.super Ljava/lang/Object;
.source "Retryer.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/Attempt;


# instance fields
.field private final attemptNumber:J

.field private final result:Ljava/lang/Object;

.field private final timeInMillsSinceFirstAttempt:J


# direct methods
.method public constructor <init>(Ljava/lang/Object;JJ)V
    .locals 0

    .line 101
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->result:Ljava/lang/Object;

    .line 102
    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->attemptNumber:J

    .line 103
    iput-wide p4, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->timeInMillsSinceFirstAttempt:J

    return-void
.end method


# virtual methods
.method public get()Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    .line 115
    invoke-virtual {p0}, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->getResult()Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public getAttemptNumber()J
    .locals 2

    .line 102
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->attemptNumber:J

    return-wide v0
.end method

.method public getExceptionCause()Ljava/lang/Throwable;
    .locals 1

    .line 111
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "The attempt resulted in a result, not in an exception"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public getResult()Ljava/lang/Object;
    .locals 0

    .line 101
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->result:Ljava/lang/Object;

    return-object p0
.end method

.method public getTimeInMillsSinceFirstAttempt()J
    .locals 2

    .line 103
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/Retryer$ResultAttempt;->timeInMillsSinceFirstAttempt:J

    return-wide v0
.end method

.method public isException()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    return p0
.end method

.method public isResult()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    return p0
.end method
