.class public final Lcom/motorola/plugin/core/retry/StopStrategy$Companion;
.super Ljava/lang/Object;
.source "StopStrategy.kt"


# static fields
.field static final synthetic $$INSTANCE:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    invoke-direct {v0}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;-><init>()V

    sput-object v0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final neverStop()Lcom/motorola/plugin/core/retry/StopStrategy;
    .locals 0

    .line 18
    new-instance p0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$neverStop$1;

    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$neverStop$1;-><init>()V

    return-object p0
.end method

.method public final stopAfterAttempt(I)Lcom/motorola/plugin/core/retry/StopStrategy;
    .locals 0

    .line 26
    new-instance p0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterAttempt$1;

    invoke-direct {p0, p1}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterAttempt$1;-><init>(I)V

    return-object p0
.end method

.method public final stopAfterDelay(JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/StopStrategy;
    .locals 0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    new-instance p0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterDelay$1;

    invoke-direct {p0, p3, p1, p2}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterDelay$1;-><init>(Ljava/util/concurrent/TimeUnit;J)V

    return-object p0
.end method
