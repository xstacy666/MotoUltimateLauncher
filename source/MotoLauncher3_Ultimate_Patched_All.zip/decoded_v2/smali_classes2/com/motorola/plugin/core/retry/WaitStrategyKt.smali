.class public final Lcom/motorola/plugin/core/retry/WaitStrategyKt;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"


# direct methods
.method public static final plus(Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    new-instance v0, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;

    invoke-direct {v0, p0, p1}, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;-><init>(Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;)V

    return-object v0
.end method
