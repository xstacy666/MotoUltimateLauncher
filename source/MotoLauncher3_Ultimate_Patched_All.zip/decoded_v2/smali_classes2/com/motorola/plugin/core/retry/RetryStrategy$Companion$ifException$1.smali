.class public final Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifException$1;
.super Ljava/lang/Object;
.source "RetryStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/RetryStrategy;


# instance fields
.field final synthetic $delegate:Ljava/util/function/Predicate;


# direct methods
.method constructor <init>(Ljava/util/function/Predicate;)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifException$1;->$delegate:Ljava/util/function/Predicate;

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public match(Lcom/motorola/plugin/core/retry/Attempt;)Z
    .locals 1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->isException()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    .line 40
    :cond_0
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$ifException$1;->$delegate:Ljava/util/function/Predicate;

    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->getExceptionCause()Ljava/lang/Throwable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Ljava/util/function/Predicate;->test(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method
