.class public final enum Lcom/motorola/plugin/core/Level;
.super Ljava/lang/Enum;
.source "PluginConfig.kt"


# static fields
.field private static final synthetic $VALUES:[Lcom/motorola/plugin/core/Level;

.field public static final enum ASSERT:Lcom/motorola/plugin/core/Level;

.field public static final enum DEBUG:Lcom/motorola/plugin/core/Level;

.field public static final enum ERROR:Lcom/motorola/plugin/core/Level;

.field public static final enum INFO:Lcom/motorola/plugin/core/Level;

.field public static final enum VERBOSE:Lcom/motorola/plugin/core/Level;

.field public static final enum WARN:Lcom/motorola/plugin/core/Level;


# instance fields
.field private final level:I


# direct methods
.method private static final synthetic $values()[Lcom/motorola/plugin/core/Level;
    .locals 6

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/Level;->VERBOSE:Lcom/motorola/plugin/core/Level;

    sget-object v1, Lcom/motorola/plugin/core/Level;->DEBUG:Lcom/motorola/plugin/core/Level;

    sget-object v2, Lcom/motorola/plugin/core/Level;->INFO:Lcom/motorola/plugin/core/Level;

    sget-object v3, Lcom/motorola/plugin/core/Level;->WARN:Lcom/motorola/plugin/core/Level;

    sget-object v4, Lcom/motorola/plugin/core/Level;->ERROR:Lcom/motorola/plugin/core/Level;

    sget-object v5, Lcom/motorola/plugin/core/Level;->ASSERT:Lcom/motorola/plugin/core/Level;

    filled-new-array/range {v0 .. v5}, [Lcom/motorola/plugin/core/Level;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 32
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "VERBOSE"

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1, v2, v3}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->VERBOSE:Lcom/motorola/plugin/core/Level;

    .line 33
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "DEBUG"

    const/4 v2, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2, v4}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->DEBUG:Lcom/motorola/plugin/core/Level;

    .line 34
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "INFO"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v3, v2}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->INFO:Lcom/motorola/plugin/core/Level;

    .line 35
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "WARN"

    const/4 v3, 0x5

    invoke-direct {v0, v1, v4, v3}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->WARN:Lcom/motorola/plugin/core/Level;

    .line 36
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "ERROR"

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2, v4}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->ERROR:Lcom/motorola/plugin/core/Level;

    .line 37
    new-instance v0, Lcom/motorola/plugin/core/Level;

    const-string v1, "ASSERT"

    const/4 v2, 0x7

    invoke-direct {v0, v1, v3, v2}, Lcom/motorola/plugin/core/Level;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/motorola/plugin/core/Level;->ASSERT:Lcom/motorola/plugin/core/Level;

    invoke-static {}, Lcom/motorola/plugin/core/Level;->$values()[Lcom/motorola/plugin/core/Level;

    move-result-object v0

    sput-object v0, Lcom/motorola/plugin/core/Level;->$VALUES:[Lcom/motorola/plugin/core/Level;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 0

    .line 31
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lcom/motorola/plugin/core/Level;->level:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/motorola/plugin/core/Level;
    .locals 1

    .line 0
    const-class v0, Lcom/motorola/plugin/core/Level;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/motorola/plugin/core/Level;

    return-object p0
.end method

.method public static values()[Lcom/motorola/plugin/core/Level;
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/Level;->$VALUES:[Lcom/motorola/plugin/core/Level;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/motorola/plugin/core/Level;

    return-object v0
.end method


# virtual methods
.method public final getLevel()I
    .locals 0

    .line 31
    iget p0, p0, Lcom/motorola/plugin/core/Level;->level:I

    return p0
.end method
