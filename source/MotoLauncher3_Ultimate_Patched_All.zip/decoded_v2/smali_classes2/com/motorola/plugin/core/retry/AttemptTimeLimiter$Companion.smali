.class public final Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;
.super Ljava/lang/Object;
.source "AttemptTimeLimiter.kt"


# static fields
.field static final synthetic $$INSTANCE:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    invoke-direct {v0}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;-><init>()V

    sput-object v0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final fixedTimeLimit(JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;
    .locals 0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    new-instance p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;

    invoke-direct {p0, p3, p1, p2}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;-><init>(Ljava/util/concurrent/TimeUnit;J)V

    return-object p0
.end method

.method public final noTimeLimit()Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;
    .locals 0

    .line 19
    new-instance p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$noTimeLimit$1;

    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$noTimeLimit$1;-><init>()V

    return-object p0
.end method
