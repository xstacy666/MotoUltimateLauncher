.class final Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;
.super Ljava/lang/Object;
.source "Retryer.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/Attempt;


# instance fields
.field private final attemptNumber:J

.field private final e:Ljava/util/concurrent/ExecutionException;

.field private final timeInMillsSinceFirstAttempt:J


# direct methods
.method public constructor <init>(Ljava/lang/Throwable;JJ)V
    .locals 0

    .line 119
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 120
    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->attemptNumber:J

    .line 121
    iput-wide p4, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->timeInMillsSinceFirstAttempt:J

    .line 123
    new-instance p2, Ljava/util/concurrent/ExecutionException;

    invoke-direct {p2, p1}, Ljava/util/concurrent/ExecutionException;-><init>(Ljava/lang/Throwable;)V

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->e:Ljava/util/concurrent/ExecutionException;

    return-void
.end method


# virtual methods
.method public get()Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;
        }
    .end annotation

    .line 139
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->e:Ljava/util/concurrent/ExecutionException;

    throw p0
.end method

.method public getAttemptNumber()J
    .locals 2

    .line 120
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->attemptNumber:J

    return-wide v0
.end method

.method public getExceptionCause()Ljava/lang/Throwable;
    .locals 0

    .line 135
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->e:Ljava/util/concurrent/ExecutionException;

    invoke-virtual {p0}, Ljava/util/concurrent/ExecutionException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    return-object p0
.end method

.method public getResult()Ljava/lang/Object;
    .locals 1

    .line 132
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "The attempt resulted in an exception, not in a result"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public getTimeInMillsSinceFirstAttempt()J
    .locals 2

    .line 121
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/Retryer$ExceptionAttempt;->timeInMillsSinceFirstAttempt:J

    return-wide v0
.end method

.method public isException()Z
    .locals 0

    .line 0
    const/4 p0, 0x1

    return p0
.end method

.method public isResult()Z
    .locals 0

    .line 0
    const/4 p0, 0x0

    return p0
.end method
