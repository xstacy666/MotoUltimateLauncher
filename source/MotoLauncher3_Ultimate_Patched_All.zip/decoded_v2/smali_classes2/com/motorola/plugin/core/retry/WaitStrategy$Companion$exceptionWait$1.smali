.class public final Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/WaitStrategy;


# instance fields
.field final synthetic $exceptionClass:Ljava/lang/Class;

.field final synthetic $function:Lkotlin/jvm/functions/Function1;


# direct methods
.method constructor <init>(Ljava/lang/Class;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;->$exceptionClass:Ljava/lang/Class;

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;->$function:Lkotlin/jvm/functions/Function1;

    .line 125
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 127
    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->isException()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 128
    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->getExceptionCause()Ljava/lang/Throwable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;->$exceptionClass:Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 130
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;->$function:Lkotlin/jvm/functions/Function1;

    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    return-wide p0

    :cond_0
    const-wide/16 p0, 0x0

    return-wide p0
.end method
