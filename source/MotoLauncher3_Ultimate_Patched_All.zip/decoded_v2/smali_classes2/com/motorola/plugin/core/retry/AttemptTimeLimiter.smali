.class public interface abstract Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;
.super Ljava/lang/Object;
.source "AttemptTimeLimiter.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    sput-object v0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;->Companion:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    return-void
.end method


# virtual methods
.method public abstract call(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
.end method
