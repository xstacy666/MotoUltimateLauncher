.class public final Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterAttempt$1;
.super Ljava/lang/Object;
.source "StopStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/StopStrategy;


# instance fields
.field final synthetic $attemptNumber:I


# direct methods
.method constructor <init>(I)V
    .locals 0

    iput p1, p0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterAttempt$1;->$attemptNumber:I

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public shouldStop(Lcom/motorola/plugin/core/retry/Attempt;)Z
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->getAttemptNumber()J

    move-result-wide v0

    iget p0, p0, Lcom/motorola/plugin/core/retry/StopStrategy$Companion$stopAfterAttempt$1;->$attemptNumber:I

    int-to-long p0, p0

    cmp-long p0, v0, p0

    if-ltz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method
