.class public final Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/WaitStrategy;


# instance fields
.field final synthetic $other:Lcom/motorola/plugin/core/retry/WaitStrategy;

.field final synthetic $this_plus:Lcom/motorola/plugin/core/retry/WaitStrategy;


# direct methods
.method constructor <init>(Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;->$this_plus:Lcom/motorola/plugin/core/retry/WaitStrategy;

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;->$other:Lcom/motorola/plugin/core/retry/WaitStrategy;

    .line 141
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 143
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;->$this_plus:Lcom/motorola/plugin/core/retry/WaitStrategy;

    invoke-interface {v0, p1}, Lcom/motorola/plugin/core/retry/WaitStrategy;->computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J

    move-result-wide v0

    .line 144
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/WaitStrategyKt$plus$1;->$other:Lcom/motorola/plugin/core/retry/WaitStrategy;

    invoke-interface {p0, p1}, Lcom/motorola/plugin/core/retry/WaitStrategy;->computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J

    move-result-wide p0

    add-long/2addr v0, p0

    return-wide v0
.end method
