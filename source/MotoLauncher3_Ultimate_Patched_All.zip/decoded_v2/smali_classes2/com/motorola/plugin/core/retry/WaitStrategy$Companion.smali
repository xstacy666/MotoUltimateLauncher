.class public final Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"


# static fields
.field static final synthetic $$INSTANCE:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    invoke-direct {v0}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;-><init>()V

    sput-object v0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic exponentialWait$default(Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;JLjava/util/concurrent/TimeUnit;JILjava/lang/Object;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 6

    and-int/lit8 p6, p6, 0x4

    if-eqz p6, :cond_0

    const-wide/16 p4, 0x1

    :cond_0
    move-object v0, p0

    move-wide v1, p1

    move-object v3, p3

    move-wide v4, p4

    .line 69
    invoke-virtual/range {v0 .. v5}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->exponentialWait(JLjava/util/concurrent/TimeUnit;J)Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic fibonacciWait$default(Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;JLjava/util/concurrent/TimeUnit;JILjava/lang/Object;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 6

    and-int/lit8 p6, p6, 0x4

    if-eqz p6, :cond_0

    const-wide/16 p4, 0x1

    :cond_0
    move-object v0, p0

    move-wide v1, p1

    move-object v3, p3

    move-wide v4, p4

    .line 85
    invoke-virtual/range {v0 .. v5}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->fibonacciWait(JLjava/util/concurrent/TimeUnit;J)Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic randomWait$default(Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;ILjava/lang/Object;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 0

    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_0

    move-wide p4, p1

    :cond_0
    and-int/lit8 p7, p7, 0x8

    if-eqz p7, :cond_1

    move-object p6, p3

    .line 40
    :cond_1
    invoke-virtual/range {p0 .. p6}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->randomWait(JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final varargs compositeJoin([Lcom/motorola/plugin/core/retry/WaitStrategy;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    invoke-virtual {p0}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->noWait()Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p0

    .line 117
    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    aget-object v2, p1, v1

    add-int/lit8 v1, v1, 0x1

    .line 118
    invoke-static {p0, v2}, Lcom/motorola/plugin/core/retry/WaitStrategyKt;->plus(Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;)Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p0

    goto :goto_0

    :cond_0
    return-object p0
.end method

.method public final exceptionWait(Ljava/lang/Class;Lkotlin/jvm/functions/Function1;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;

    invoke-direct {p0, p1, p2}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exceptionWait$1;-><init>(Ljava/lang/Class;Lkotlin/jvm/functions/Function1;)V

    return-object p0
.end method

.method public final exponentialWait(JLjava/util/concurrent/TimeUnit;J)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 2

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exponentialWait$1;

    move-wide v0, p1

    move-object p1, p3

    move-wide p2, v0

    invoke-direct/range {p0 .. p5}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$exponentialWait$1;-><init>(Ljava/util/concurrent/TimeUnit;JJ)V

    return-object p0
.end method

.method public final fibonacciWait(JLjava/util/concurrent/TimeUnit;J)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 2

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;

    move-wide v0, p1

    move-object p1, p3

    move-wide p2, v0

    invoke-direct/range {p0 .. p5}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;-><init>(Ljava/util/concurrent/TimeUnit;JJ)V

    return-object p0
.end method

.method public final fixedWait(JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fixedWait$1;

    invoke-direct {p0, p3, p1, p2}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fixedWait$1;-><init>(Ljava/util/concurrent/TimeUnit;J)V

    return-object p0
.end method

.method public final incrementingWait(JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 2

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;

    move-wide v0, p1

    move-object p1, p3

    move-wide p2, v0

    move-wide v0, p4

    move-object p4, p6

    move-wide p5, v0

    invoke-direct/range {p0 .. p6}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$incrementingWait$1;-><init>(Ljava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;J)V

    return-object p0
.end method

.method public final noWait()Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 0

    .line 22
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$noWait$1;

    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$noWait$1;-><init>()V

    return-object p0
.end method

.method public final randomWait(JLjava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 2

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    new-instance p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;

    move-wide v0, p1

    move-object p1, p3

    move-wide p2, v0

    move-wide v0, p4

    move-object p4, p6

    move-wide p5, v0

    invoke-direct/range {p0 .. p6}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$randomWait$1;-><init>(Ljava/util/concurrent/TimeUnit;JLjava/util/concurrent/TimeUnit;J)V

    return-object p0
.end method
