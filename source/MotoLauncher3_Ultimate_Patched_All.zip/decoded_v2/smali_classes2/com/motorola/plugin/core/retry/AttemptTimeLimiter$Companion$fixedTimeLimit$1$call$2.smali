.class final Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "AttemptTimeLimiter.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field final synthetic $callable:Lkotlin/jvm/functions/Function1;

.field label:I


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->$callable:Lkotlin/jvm/functions/Function1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 0

    .line 0
    new-instance p1, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;

    iget-object p0, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->$callable:Lkotlin/jvm/functions/Function1;

    invoke-direct {p1, p0, p2}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;-><init>(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 28
    iget v1, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    return-object p1

    .line 29
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 28
    :cond_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 29
    iget-object p1, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->$callable:Lkotlin/jvm/functions/Function1;

    iput v2, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;->label:I

    invoke-interface {p1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2

    return-object v0

    :cond_2
    return-object p0
.end method
