.class public final Lcom/motorola/plugin/core/retry/RetryStrategy$Companion$neverTry$1;
.super Ljava/lang/Object;
.source "RetryStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/RetryStrategy;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public match(Lcom/motorola/plugin/core/retry/Attempt;)Z
    .locals 0

    .line 0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return p0
.end method
