.class public final Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/WaitStrategy;


# instance fields
.field final synthetic $maximumTime:J

.field final synthetic $maximumTimeTimeUnit:Ljava/util/concurrent/TimeUnit;

.field final synthetic $multiplier:J

.field private final maxTimeInMillis:J


# direct methods
.method constructor <init>(Ljava/util/concurrent/TimeUnit;JJ)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->$maximumTimeTimeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->$maximumTime:J

    iput-wide p4, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->$multiplier:J

    .line 86
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 88
    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    iput-wide p1, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->maxTimeInMillis:J

    return-void
.end method

.method private final fib(J)J
    .locals 10

    .line 0
    const-wide/16 v0, 0x0

    cmp-long p0, p1, v0

    if-nez p0, :cond_0

    return-wide v0

    :cond_0
    const-wide/16 v2, 0x1

    cmp-long p0, p1, v2

    if-nez p0, :cond_1

    return-wide v2

    :cond_1
    const-wide/16 v4, 0x2

    cmp-long p0, v4, p1

    if-gtz p0, :cond_3

    move-wide v6, v4

    move-wide v4, v0

    move-wide v0, v2

    :goto_0
    add-long v8, v6, v2

    add-long/2addr v4, v0

    cmp-long p0, v6, p1

    if-nez p0, :cond_2

    return-wide v4

    :cond_2
    move-wide v6, v4

    move-wide v4, v0

    move-wide v0, v6

    move-wide v6, v8

    goto :goto_0

    :cond_3
    return-wide v0
.end method


# virtual methods
.method public computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
    .locals 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    invoke-interface {p1}, Lcom/motorola/plugin/core/retry/Attempt;->getAttemptNumber()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->fib(J)J

    move-result-wide v0

    .line 92
    iget-wide v2, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->$multiplier:J

    mul-long/2addr v2, v0

    .line 93
    iget-wide p0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->maxTimeInMillis:J

    cmp-long v0, v2, p0

    const-wide/16 v4, 0x0

    if-gtz v0, :cond_0

    cmp-long v0, v2, v4

    if-gez v0, :cond_1

    :cond_0
    move-wide v2, p0

    :cond_1
    cmp-long p0, v2, v4

    if-ltz p0, :cond_2

    return-wide v2

    :cond_2
    return-wide v4
.end method

.method public final getMaxTimeInMillis()J
    .locals 2

    .line 88
    iget-wide v0, p0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion$fibonacciWait$1;->maxTimeInMillis:J

    return-wide v0
.end method
