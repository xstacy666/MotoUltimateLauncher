.class final Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "Retryer.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field final synthetic $callable:Lkotlin/jvm/functions/Function0;

.field final synthetic $this_callBlocking:Lcom/motorola/plugin/core/retry/Retryer;

.field label:I


# direct methods
.method constructor <init>(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$this_callBlocking:Lcom/motorola/plugin/core/retry/Retryer;

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$callable:Lkotlin/jvm/functions/Function0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1

    .line 0
    new-instance p1, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;

    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$this_callBlocking:Lcom/motorola/plugin/core/retry/Retryer;

    iget-object p0, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$callable:Lkotlin/jvm/functions/Function0;

    invoke-direct {p1, v0, p0, p2}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;-><init>(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-virtual {p0, p1, p2}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 173
    iget v1, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    return-object p1

    .line 174
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 173
    :cond_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 174
    iget-object p1, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$this_callBlocking:Lcom/motorola/plugin/core/retry/Retryer;

    new-instance v1, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1$1;

    iget-object v3, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->$callable:Lkotlin/jvm/functions/Function0;

    const/4 v4, 0x0

    invoke-direct {v1, v3, v4}, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1$1;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)V

    iput v2, p0, Lcom/motorola/plugin/core/retry/RetryerKt$callBlocking$1;->label:I

    invoke-virtual {p1, v1, p0}, Lcom/motorola/plugin/core/retry/Retryer;->call(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2

    return-object v0

    :cond_2
    return-object p0
.end method
