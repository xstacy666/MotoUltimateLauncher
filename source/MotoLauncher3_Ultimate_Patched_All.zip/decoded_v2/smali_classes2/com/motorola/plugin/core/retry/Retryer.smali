.class public final Lcom/motorola/plugin/core/retry/Retryer;
.super Ljava/lang/Object;
.source "Retryer.kt"


# instance fields
.field private final attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

.field private final blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

.field private final listeners:Ljava/util/Collection;

.field private final retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

.field private final stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

.field private final waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;


# direct methods
.method public constructor <init>(Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;Lcom/motorola/plugin/core/retry/StopStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/BlockStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;Ljava/util/Collection;)V
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer;->attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    .line 33
    iput-object p2, p0, Lcom/motorola/plugin/core/retry/Retryer;->stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

    .line 34
    iput-object p3, p0, Lcom/motorola/plugin/core/retry/Retryer;->waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;

    .line 35
    iput-object p4, p0, Lcom/motorola/plugin/core/retry/Retryer;->blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

    .line 36
    iput-object p5, p0, Lcom/motorola/plugin/core/retry/Retryer;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    .line 37
    iput-object p6, p0, Lcom/motorola/plugin/core/retry/Retryer;->listeners:Ljava/util/Collection;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;Lcom/motorola/plugin/core/retry/StopStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/BlockStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;Ljava/util/Collection;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_0

    .line 32
    sget-object p1, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;->Companion:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;

    invoke-virtual {p1}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion;->noTimeLimit()Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    move-result-object p1

    :cond_0
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_1

    .line 33
    sget-object p2, Lcom/motorola/plugin/core/retry/StopStrategy;->Companion:Lcom/motorola/plugin/core/retry/StopStrategy$Companion;

    invoke-virtual {p2}, Lcom/motorola/plugin/core/retry/StopStrategy$Companion;->neverStop()Lcom/motorola/plugin/core/retry/StopStrategy;

    move-result-object p2

    :cond_1
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_2

    .line 34
    sget-object p3, Lcom/motorola/plugin/core/retry/WaitStrategy;->Companion:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    invoke-virtual {p3}, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->noWait()Lcom/motorola/plugin/core/retry/WaitStrategy;

    move-result-object p3

    :cond_2
    and-int/lit8 p7, p7, 0x8

    if-eqz p7, :cond_3

    .line 35
    sget-object p4, Lcom/motorola/plugin/core/retry/BlockStrategy;->Companion:Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;

    invoke-virtual {p4}, Lcom/motorola/plugin/core/retry/BlockStrategy$Companion;->coroutineDelayStrategy()Lcom/motorola/plugin/core/retry/BlockStrategy;

    move-result-object p4

    :cond_3
    move-object p7, p5

    move-object p8, p6

    move-object p5, p3

    move-object p6, p4

    move-object p3, p1

    move-object p4, p2

    move-object p2, p0

    .line 32
    invoke-direct/range {p2 .. p8}, Lcom/motorola/plugin/core/retry/Retryer;-><init>(Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;Lcom/motorola/plugin/core/retry/StopStrategy;Lcom/motorola/plugin/core/retry/WaitStrategy;Lcom/motorola/plugin/core/retry/BlockStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;Ljava/util/Collection;)V

    return-void
.end method

.method public static final synthetic access$getAttemptTimeLimiter$p(Lcom/motorola/plugin/core/retry/Retryer;)Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->attemptTimeLimiter:Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;

    return-object p0
.end method

.method public static final synthetic access$getBlockStrategy$p(Lcom/motorola/plugin/core/retry/Retryer;)Lcom/motorola/plugin/core/retry/BlockStrategy;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->blockStrategy:Lcom/motorola/plugin/core/retry/BlockStrategy;

    return-object p0
.end method

.method public static final synthetic access$getListeners$p(Lcom/motorola/plugin/core/retry/Retryer;)Ljava/util/Collection;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->listeners:Ljava/util/Collection;

    return-object p0
.end method

.method public static final synthetic access$getRetryStrategy$p(Lcom/motorola/plugin/core/retry/Retryer;)Lcom/motorola/plugin/core/retry/RetryStrategy;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->retryStrategy:Lcom/motorola/plugin/core/retry/RetryStrategy;

    return-object p0
.end method

.method public static final synthetic access$getStopStrategy$p(Lcom/motorola/plugin/core/retry/Retryer;)Lcom/motorola/plugin/core/retry/StopStrategy;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->stopStrategy:Lcom/motorola/plugin/core/retry/StopStrategy;

    return-object p0
.end method

.method public static final synthetic access$getWaitStrategy$p(Lcom/motorola/plugin/core/retry/Retryer;)Lcom/motorola/plugin/core/retry/WaitStrategy;
    .locals 0

    .line 32
    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer;->waitStrategy:Lcom/motorola/plugin/core/retry/WaitStrategy;

    return-object p0
.end method


# virtual methods
.method public final call(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/ExecutionException;,
            Lcom/motorola/plugin/core/retry/RetryException;
        }
    .end annotation

    .line 55
    new-instance v0, Lcom/motorola/plugin/core/retry/Retryer$call$2;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lcom/motorola/plugin/core/retry/Retryer$call$2;-><init>(Lcom/motorola/plugin/core/retry/Retryer;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)V

    invoke-static {v0, p2}, Lkotlinx/coroutines/CoroutineScopeKt;->coroutineScope(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final wrap(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Callable;
    .locals 1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    new-instance v0, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;

    invoke-direct {v0, p0, p1}, Lcom/motorola/plugin/core/retry/Retryer$RetryerCallable;-><init>(Lcom/motorola/plugin/core/retry/Retryer;Ljava/util/concurrent/Callable;)V

    return-object v0
.end method
