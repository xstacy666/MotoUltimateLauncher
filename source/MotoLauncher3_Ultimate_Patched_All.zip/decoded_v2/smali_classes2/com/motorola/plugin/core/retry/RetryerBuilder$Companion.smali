.class public final Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;
.super Ljava/lang/Object;
.source "RetryerBuilder.kt"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 179
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/motorola/plugin/core/retry/RetryerBuilder$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final newBuilder()Lcom/motorola/plugin/core/retry/RetryerBuilder;
    .locals 1

    .line 187
    new-instance p0, Lcom/motorola/plugin/core/retry/RetryerBuilder;

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lcom/motorola/plugin/core/retry/RetryerBuilder;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object p0
.end method
