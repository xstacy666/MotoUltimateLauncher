.class public final Lcom/motorola/plugin/core/R$style;
.super Ljava/lang/Object;
.source "R.java"


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f1202be

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f1202bf

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f1202c0

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f1202c1

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f1202c2

.field public static final TrampolineFullScreen:I = 0x7f12045b

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f1204a7

.field public static final Widget_Compat_NotificationActionText:I = 0x7f1204a8


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
