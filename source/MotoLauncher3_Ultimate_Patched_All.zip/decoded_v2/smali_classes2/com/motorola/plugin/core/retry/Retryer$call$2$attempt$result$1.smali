.class final Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "Retryer.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field final synthetic $$this$coroutineScope:Lkotlinx/coroutines/CoroutineScope;

.field final synthetic $callable:Lkotlin/jvm/functions/Function2;

.field label:I


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$callable:Lkotlin/jvm/functions/Function2;

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$$this$coroutineScope:Lkotlinx/coroutines/CoroutineScope;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2

    .line 0
    new-instance v0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;

    iget-object v1, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$callable:Lkotlin/jvm/functions/Function2;

    iget-object p0, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$$this$coroutineScope:Lkotlinx/coroutines/CoroutineScope;

    invoke-direct {v0, v1, p0, p1}, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;-><init>(Lkotlin/jvm/functions/Function2;Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)V

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 0
    check-cast p1, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->invoke(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invoke(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0

    .line 0
    invoke-virtual {p0, p1}, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->create(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p0

    check-cast p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p0, p1}, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 60
    iget v1, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->label:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    return-object p1

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    iget-object p1, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$callable:Lkotlin/jvm/functions/Function2;

    iget-object v1, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->$$this$coroutineScope:Lkotlinx/coroutines/CoroutineScope;

    iput v2, p0, Lcom/motorola/plugin/core/retry/Retryer$call$2$attempt$result$1;->label:I

    invoke-interface {p1, v1, p0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2

    return-object v0

    :cond_2
    return-object p0
.end method
