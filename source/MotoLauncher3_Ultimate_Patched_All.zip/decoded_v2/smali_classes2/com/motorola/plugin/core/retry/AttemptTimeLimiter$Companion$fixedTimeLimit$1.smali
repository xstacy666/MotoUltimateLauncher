.class public final Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;
.super Ljava/lang/Object;
.source "AttemptTimeLimiter.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;


# instance fields
.field final synthetic $duration:J

.field final synthetic $timeUnit:Ljava/util/concurrent/TimeUnit;


# direct methods
.method constructor <init>(Ljava/util/concurrent/TimeUnit;J)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;->$timeUnit:Ljava/util/concurrent/TimeUnit;

    iput-wide p2, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;->$duration:J

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 3

    .line 28
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;->$timeUnit:Ljava/util/concurrent/TimeUnit;

    iget-wide v1, p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1;->$duration:J

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v0

    new-instance p0, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;

    const/4 v2, 0x0

    invoke-direct {p0, p1, v2}, Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$fixedTimeLimit$1$call$2;-><init>(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V

    invoke-static {v0, v1, p0, p2}, Lkotlinx/coroutines/TimeoutKt;->withTimeout(JLkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
