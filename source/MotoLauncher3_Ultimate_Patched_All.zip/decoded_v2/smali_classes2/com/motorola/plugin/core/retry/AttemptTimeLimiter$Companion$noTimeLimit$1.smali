.class public final Lcom/motorola/plugin/core/retry/AttemptTimeLimiter$Companion$noTimeLimit$1;
.super Ljava/lang/Object;
.source "AttemptTimeLimiter.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/AttemptTimeLimiter;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public call(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0

    .line 21
    invoke-interface {p1, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
