.class public interface abstract Lcom/motorola/plugin/core/retry/RetryStrategy;
.super Ljava/lang/Object;
.source "RetryStrategy.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    sput-object v0, Lcom/motorola/plugin/core/retry/RetryStrategy;->Companion:Lcom/motorola/plugin/core/retry/RetryStrategy$Companion;

    return-void
.end method


# virtual methods
.method public abstract match(Lcom/motorola/plugin/core/retry/Attempt;)Z
.end method
