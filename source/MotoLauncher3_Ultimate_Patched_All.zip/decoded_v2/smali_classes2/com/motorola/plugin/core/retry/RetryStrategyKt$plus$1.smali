.class public final Lcom/motorola/plugin/core/retry/RetryStrategyKt$plus$1;
.super Ljava/lang/Object;
.source "RetryStrategy.kt"

# interfaces
.implements Lcom/motorola/plugin/core/retry/RetryStrategy;


# instance fields
.field final synthetic $other:Lcom/motorola/plugin/core/retry/RetryStrategy;

.field final synthetic $this_plus:Lcom/motorola/plugin/core/retry/RetryStrategy;


# direct methods
.method constructor <init>(Lcom/motorola/plugin/core/retry/RetryStrategy;Lcom/motorola/plugin/core/retry/RetryStrategy;)V
    .locals 0

    iput-object p1, p0, Lcom/motorola/plugin/core/retry/RetryStrategyKt$plus$1;->$this_plus:Lcom/motorola/plugin/core/retry/RetryStrategy;

    iput-object p2, p0, Lcom/motorola/plugin/core/retry/RetryStrategyKt$plus$1;->$other:Lcom/motorola/plugin/core/retry/RetryStrategy;

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public match(Lcom/motorola/plugin/core/retry/Attempt;)Z
    .locals 1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    iget-object v0, p0, Lcom/motorola/plugin/core/retry/RetryStrategyKt$plus$1;->$this_plus:Lcom/motorola/plugin/core/retry/RetryStrategy;

    invoke-interface {v0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy;->match(Lcom/motorola/plugin/core/retry/Attempt;)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Lcom/motorola/plugin/core/retry/RetryStrategyKt$plus$1;->$other:Lcom/motorola/plugin/core/retry/RetryStrategy;

    invoke-interface {p0, p1}, Lcom/motorola/plugin/core/retry/RetryStrategy;->match(Lcom/motorola/plugin/core/retry/Attempt;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method
