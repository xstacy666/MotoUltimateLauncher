.class public interface abstract Lcom/motorola/plugin/core/retry/WaitStrategy;
.super Ljava/lang/Object;
.source "WaitStrategy.kt"


# static fields
.field public static final Companion:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;->$$INSTANCE:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    sput-object v0, Lcom/motorola/plugin/core/retry/WaitStrategy;->Companion:Lcom/motorola/plugin/core/retry/WaitStrategy$Companion;

    return-void
.end method


# virtual methods
.method public abstract computeSleepTime(Lcom/motorola/plugin/core/retry/Attempt;)J
.end method
