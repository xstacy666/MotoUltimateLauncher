.class public interface abstract Lcom/motorola/plugin/core/retry/Attempt;
.super Ljava/lang/Object;
.source "Attempt.kt"


# virtual methods
.method public abstract get()Ljava/lang/Object;
.end method

.method public abstract getAttemptNumber()J
.end method

.method public abstract getExceptionCause()Ljava/lang/Throwable;
.end method

.method public abstract getResult()Ljava/lang/Object;
.end method

.method public abstract getTimeInMillsSinceFirstAttempt()J
.end method

.method public abstract isException()Z
.end method

.method public abstract isResult()Z
.end method
