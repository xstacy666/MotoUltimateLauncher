.class Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;
.super Ljava/lang/Object;
.source "AllAppsApi.java"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field final synthetic this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;


# direct methods
.method constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V
    .locals 0

    .line 173
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    .line 175
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetsCount()I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfputsCount(I)V

    invoke-static {v0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fputmCount(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;I)V

    .line 176
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-virtual {p1}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fputmPackageName(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Ljava/lang/String;)V

    .line 178
    :try_start_0
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fgetmHostContext(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fgetmPackageName(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    .line 179
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fputmOverlayContext(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 181
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Fail to create mOverlayContext: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/content/pm/PackageManager$NameNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 183
    :goto_0
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {p0, p2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$mhandleOnServiceConnected(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/IBinder;)V

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2

    .line 187
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetLOG()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 188
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fgetmCount(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " onServiceDisconnected"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 190
    :cond_0
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fputmOverlayContext(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V

    .line 191
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$mhandleConnectionError(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/RemoteException;)V

    return-void
.end method
