.class public final synthetic Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

.field public final synthetic f$1:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    iput-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;->f$1:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;->f$1:Landroid/content/Context;

    invoke-static {v0, p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->$r8$lambda$uItxcyL1RSn7jZzqjskx_34M4c0(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V

    return-void
.end method
