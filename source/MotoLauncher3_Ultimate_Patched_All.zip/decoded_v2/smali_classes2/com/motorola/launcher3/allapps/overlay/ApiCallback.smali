.class public interface abstract Lcom/motorola/launcher3/allapps/overlay/ApiCallback;
.super Ljava/lang/Object;
.source "ApiCallback.java"


# virtual methods
.method public abstract isReconnectEnabled()Z
.end method

.method public abstract onAllAppsTransition(FI)V
.end method

.method public abstract onGoBackToLauncher(I)V
.end method

.method public abstract onScrollUpdated(F)V
.end method

.method public abstract onSearchBarAttached(Landroid/os/Bundle;)V
.end method

.method public abstract onSearchBarDetached(Landroid/os/Bundle;)V
.end method

.method public abstract onSearchUiAttached(Landroid/os/Bundle;)V
.end method

.method public abstract onSearchUiDetached(Landroid/os/Bundle;)V
.end method

.method public abstract onServiceConnected(Landroid/os/Bundle;)V
.end method

.method public abstract onServiceDisconnected(Landroid/os/Bundle;)V
.end method

.method public abstract onSideScreenAttached(Landroid/os/Bundle;)V
.end method

.method public abstract onSideScreenDetached(Landroid/os/Bundle;)V
.end method

.method public abstract onTabChanged(I)V
.end method

.method public abstract onUpdateOverlayConfig(Landroid/os/Bundle;)V
.end method
