.class final Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;
.super Landroid/os/Handler;
.source "AllAppsApi.java"


# instance fields
.field private final mApiRef:Ljava/lang/ref/SoftReference;


# direct methods
.method private constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V
    .locals 1

    .line 1208
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 1209
    new-instance v0, Ljava/lang/ref/SoftReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/SoftReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;->mApiRef:Ljava/lang/ref/SoftReference;

    return-void
.end method

.method synthetic constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Lcom/motorola/launcher3/allapps/overlay/AllAppsApi-IA;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 0

    .line 1213
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;->mApiRef:Ljava/lang/ref/SoftReference;

    invoke-virtual {p0}, Ljava/lang/ref/SoftReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    if-eqz p0, :cond_0

    .line 1215
    invoke-static {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$mhandleRemoteMessage(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Message;)V

    :cond_0
    return-void
.end method
