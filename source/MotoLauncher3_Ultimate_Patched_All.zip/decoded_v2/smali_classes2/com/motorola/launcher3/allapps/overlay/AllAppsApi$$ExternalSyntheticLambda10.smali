.class public final synthetic Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

.field public final synthetic f$1:Landroid/os/Bundle;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    iput-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;->f$1:Landroid/os/Bundle;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;->f$1:Landroid/os/Bundle;

    invoke-static {v0, p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->$r8$lambda$Ob6b_778o9uGHrsaFknk7Js6beI(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    return-void
.end method
