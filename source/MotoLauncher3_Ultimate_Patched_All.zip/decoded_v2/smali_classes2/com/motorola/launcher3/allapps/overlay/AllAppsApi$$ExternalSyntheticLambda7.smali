.class public final synthetic Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;


# direct methods
.method public synthetic constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda7;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda7;->f$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->$r8$lambda$7RHgOjLtXvip3BYaNMnH2dL6clE(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V

    return-void
.end method
