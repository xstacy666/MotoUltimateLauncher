.class Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;
.super Ljava/lang/Object;
.source "AllAppsApi.java"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field final synthetic this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;


# direct methods
.method constructor <init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V
    .locals 0

    .line 195
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 1

    .line 197
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetsCount2()I

    move-result p2

    add-int/lit8 p2, p2, 0x1

    invoke-static {p2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfputsCount2(I)V

    invoke-static {p1, p2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fputmCount2(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;I)V

    .line 198
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$sfgetTAG()Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "bindService2: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;->this$0:Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->-$$Nest$fgetmCount2(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)I

    move-result p0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    .line 0
    return-void
.end method
