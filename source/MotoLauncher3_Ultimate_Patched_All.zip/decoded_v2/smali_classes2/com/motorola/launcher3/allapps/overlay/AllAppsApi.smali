.class public Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;
.super Ljava/lang/Object;
.source "AllAppsApi.java"


# static fields
.field public static final DBG:Z

.field private static final LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

.field private static LOG:Z = false

.field private static final TAG:Ljava/lang/String; = "AllAppsApi"

.field private static sAllAppsOverlayPackageConfig:Ljava/lang/String;

.field private static sAllAppsOverlayPkg:Ljava/lang/String;

.field private static sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

.field private static sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

.field private static sAllAppsOverlayServiceConfig:Ljava/lang/String;

.field private static sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

.field private static sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

.field private static sCount:I

.field private static sCount2:I


# instance fields
.field private isBoundService2:Z

.field private final mAllAppsVersion:I

.field private mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

.field private final mCheckConnectionRunnable:Ljava/lang/Runnable;

.field private mConnectAttemptCount:I

.field private final mConnectRunnable:Ljava/lang/Runnable;

.field private mCount:I

.field private mCount2:I

.field private final mDataBundle:Landroid/os/Bundle;

.field private mHostContext:Landroid/content/Context;

.field private mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

.field private mIsBinding:Z

.field private mIsDestroyed:Z

.field private mIsLightNavigationBar:Z

.field private mIsLightStatusBar:Z

.field private mIsResumed:Z

.field private final mIsRtl:Z

.field private mIsStatusBarHidden:Z

.field private mIsTranslucentNavigationBar:Z

.field private final mLocalMessenger:Landroid/os/Messenger;

.field private final mMainThreadHandler:Landroid/os/Handler;

.field private mOverlayContext:Landroid/content/Context;

.field private mPackageName:Ljava/lang/String;

.field private mRemoteMessenger:Landroid/os/Messenger;

.field private mSentWindowAttributes:Z

.field private final mServiceConnection:Landroid/content/ServiceConnection;

.field private final mServiceConnection2:Landroid/content/ServiceConnection;

.field private final mSettingsActivityLaunchIntent:Landroid/content/Intent;

.field private mTabOffset:I


# direct methods
.method public static synthetic $r8$lambda$0LS4fFqApmua3WqCCmwz6kw5Crw(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 743
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "; "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7RHgOjLtXvip3BYaNMnH2dL6clE(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->checkConnection()V

    return-void
.end method

.method public static synthetic $r8$lambda$ASfSVaSoMBBWHrRaB7byfSRec-4(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySideScreenDetached$11(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$DFwXXILb5_yfGgnYC7gv3D53bmc(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySideScreenAttached$5(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$InI2w_-4z7XSVyQ3OSr6Oo9B2Ms(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySearchUiDetached$13(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ob6b_778o9uGHrsaFknk7Js6beI(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySearchBarDetached$15(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$XNiZDFplctLI2ZzJFZb0gCFOMvM(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    .line 773
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "; "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$a86q8yB9aE23bLUHvWmIiIntgiY(Landroid/content/pm/ResolveInfo;)Ljava/lang/String;
    .locals 2

    .line 772
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v1, v1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object p0, p0, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ioE6BL5dhqxAAVDxVL9FP3pRwa4(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifyServiceDisconnected$16(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$iuVI-nqIqZewZaSWMSxkFV5HvLY(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySearchBarAttached$14(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kD2gMJ9Ylq9YUSx4KmAn_aa8kYc(Landroid/content/pm/ResolveInfo;)Ljava/lang/String;
    .locals 2

    .line 742
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v1, v1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object p0, p0, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sfhK-kvCYA5X2-CSDsWAJ4ZFIpc(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$notifySearchUiAttached$12(Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$uItxcyL1RSn7jZzqjskx_34M4c0(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->lambda$new$0(Landroid/content/Context;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetmCount(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmCount2(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)I
    .locals 0

    .line 0
    iget p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount2:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetmHostContext(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)Landroid/content/Context;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmPackageName(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)Ljava/lang/String;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mPackageName:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputmCount(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmCount2(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;I)V
    .locals 0

    .line 0
    iput p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount2:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmOverlayContext(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mOverlayContext:Landroid/content/Context;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputmPackageName(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Ljava/lang/String;)V
    .locals 0

    .line 0
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mPackageName:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$mhandleConnectionError(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/RemoteException;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mhandleOnServiceConnected(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/IBinder;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleOnServiceConnected(Landroid/os/IBinder;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mhandleRemoteMessage(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Message;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleRemoteMessage(Landroid/os/Message;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetLOG()Z
    .locals 1

    .line 0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetTAG()Ljava/lang/String;
    .locals 1

    .line 0
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetsCount()I
    .locals 1

    .line 0
    sget v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount:I

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgetsCount2()I
    .locals 1

    .line 0
    sget v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount2:I

    return v0
.end method

.method static bridge synthetic -$$Nest$sfputsCount(I)V
    .locals 0

    .line 0
    sput p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount:I

    return-void
.end method

.method static bridge synthetic -$$Nest$sfputsCount2(I)V
    .locals 0

    .line 0
    sput p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount2:I

    return-void
.end method

.method static constructor <clinit>()V
    .locals 6

    .line 42
    sget-object v0, Landroid/os/Build;->TYPE:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 43
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "debug"

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_1

    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "eng"

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Landroid/os/Build;->TAGS:Ljava/lang/String;

    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "intcfg"

    invoke-virtual {v2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 46
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "bldccfg"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move v0, v4

    goto :goto_1

    :cond_1
    :goto_0
    move v0, v3

    :goto_1
    sput-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->DBG:Z

    .line 77
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    .line 80
    sput-boolean v3, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    .line 81
    sput v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount:I

    .line 82
    sput v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sCount2:I

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/view/WindowManager$LayoutParams;Lcom/motorola/launcher3/allapps/overlay/ApiCallback;ZLandroid/content/Intent;I)V
    .locals 3

    .line 150
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 87
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iput-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mDataBundle:Landroid/os/Bundle;

    const/4 v1, 0x0

    .line 109
    iput v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mTabOffset:I

    .line 114
    iput-boolean v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    .line 119
    iput-boolean v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService2:Z

    .line 151
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v1, :cond_0

    .line 152
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v2, "new AllAppsApi"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    if-eqz p1, :cond_2

    if-eqz p3, :cond_1

    .line 159
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 160
    iput-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    .line 161
    const-string p2, "token"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    iput-object p3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    .line 163
    iput-boolean p4, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsRtl:Z

    .line 164
    iput-object p5, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mSettingsActivityLaunchIntent:Landroid/content/Intent;

    .line 165
    iput p6, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mAllAppsVersion:I

    .line 167
    new-instance p2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;

    const/4 p3, 0x0

    invoke-direct {p2, p0, p3}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$MainThreadHandler;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Lcom/motorola/launcher3/allapps/overlay/AllAppsApi-IA;)V

    iput-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    .line 168
    new-instance p3, Landroid/os/Messenger;

    invoke-direct {p3, p2}, Landroid/os/Messenger;-><init>(Landroid/os/Handler;)V

    iput-object p3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mLocalMessenger:Landroid/os/Messenger;

    .line 169
    new-instance p2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;

    invoke-direct {p2, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda6;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/content/Context;)V

    iput-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectRunnable:Ljava/lang/Runnable;

    .line 172
    new-instance p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda7;

    invoke-direct {p1, p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda7;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    .line 173
    new-instance p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;

    invoke-direct {p1, p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$1;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection:Landroid/content/ServiceConnection;

    .line 194
    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    .line 195
    new-instance p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;

    invoke-direct {p1, p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$2;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;)V

    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection2:Landroid/content/ServiceConnection;

    return-void

    .line 157
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "callbacks must not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    .line 155
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "hostContext must not be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private declared-synchronized checkConnection()V
    .locals 3

    monitor-enter p0

    .line 979
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    if-nez v0, :cond_1

    .line 980
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 981
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " service bound but not connected, retrying..."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 983
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 985
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public static clearAllAppsOverlayConfig()V
    .locals 3

    .line 1333
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 1334
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v2, "Cleared AllAppsOverlay config"

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    .line 1335
    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    .line 1336
    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    .line 1337
    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    .line 1338
    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    .line 1339
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method private static disableAllAppsOverlayConfig()V
    .locals 2

    .line 1314
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v1, "Disabled AllAppsOverlay config"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1315
    const-string v0, ""

    sput-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    .line 1316
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sput-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    .line 1317
    sput-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    .line 1318
    sput-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    return-void
.end method

.method public static getAllAppsOverlayPackageConfig(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1343
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    .line 1347
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "all_apps_overlay_package"

    const-string v2, "string"

    .line 1348
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    .line 1347
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    .line 1349
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "loaded all_apps_overlay_package: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1351
    :catch_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "Failed to load AllAppsOverlay package config"

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1353
    :goto_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 1354
    const-string p0, ""

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    .line 1356
    :cond_1
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPackageConfig:Ljava/lang/String;

    return-object p0
.end method

.method public static getAllAppsOverlayPkg(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    .line 808
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    if-nez v0, :cond_1

    .line 809
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 810
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    if-nez v1, :cond_0

    .line 811
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->loadAllAppsOverlayConfig(Landroid/content/Context;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 813
    :cond_0
    :goto_0
    monitor-exit v0

    goto :goto_2

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 815
    :cond_1
    :goto_2
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "getAllAppsOverlayPkg: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 816
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    return-object p0
.end method

.method public static getAllAppsOverlayServiceConfig(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1360
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    .line 1364
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "all_apps_overlay_service"

    const-string v2, "string"

    .line 1365
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    .line 1364
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    .line 1366
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "loaded all_apps_overlay_service: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1368
    :catch_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "Failed to load AllAppsOverlay service config"

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1370
    :goto_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 1371
    const-string p0, "com.motorola.launcher3.ALL_APPS_OVERLAY_SERVICE"

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    .line 1373
    :cond_1
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayServiceConfig:Ljava/lang/String;

    return-object p0
.end method

.method public static getAllAppsOverlayServiceInfo(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ResolveInfo;
    .locals 5

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    .line 725
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :catch_0
    move-exception p0

    goto/16 :goto_1

    .line 729
    :cond_0
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 730
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 731
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 732
    invoke-virtual {v2, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 734
    :cond_1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v1, 0x80

    .line 735
    invoke-virtual {p0, v2, v1}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    .line 737
    new-instance v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda0;

    invoke-direct {v2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v2}, Ljava/util/Comparator;->comparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 738
    sget-boolean v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->DBG:Z

    if-eqz v2, :cond_3

    .line 739
    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "AllApps overlay services -> "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 740
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2

    const-string p1, "@empty"

    :cond_2
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ": "

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 741
    invoke-interface {v1}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object p1

    new-instance v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda1;

    invoke-direct {v4}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda1;-><init>()V

    .line 742
    invoke-interface {p1, v4}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object p1

    new-instance v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda2;

    invoke-direct {v4}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda2;-><init>()V

    .line 743
    invoke-interface {p1, v4}, Ljava/util/stream/Stream;->reduce(Ljava/util/function/BinaryOperator;)Ljava/util/Optional;

    move-result-object p1

    const-string v4, "none"

    .line 744
    invoke-virtual {p1, v4}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 739
    invoke-static {v2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 746
    :cond_3
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ResolveInfo;

    .line 747
    iget-object v2, v1, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 748
    const-string v3, "com.motorola.launcher3.permission.ALL_APPS_OVERLAY"

    invoke-static {p0, v3, v2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isPermissionGranted(Landroid/content/pm/PackageManager;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 749
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Get AllApps overlay service: "

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    .line 752
    :cond_4
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "getAllAppsOverlayServiceInfo -> Skip "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", no ALL_APPS_OVERLAY permission"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 757
    :goto_1
    sget-object p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Get AllApps overlay service error: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    return-object v0
.end method

.method public static getAllAppsOverlaySettingsServiceConfig(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    .line 1377
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    .line 1382
    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "all_apps_overlay_settings_service"

    const-string v2, "string"

    .line 1383
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    .line 1382
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    .line 1381
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    .line 1384
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "loaded all_apps_overlay_settings_service: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1387
    :catch_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "Failed to load AllAppsOverlay settings service config"

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1389
    :goto_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    .line 1390
    const-string p0, "com.motorola.launcher3.ALL_APPS_OVERLAY_SETTINGS_SERVICE"

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    .line 1392
    :cond_1
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySettingsServiceConfig:Ljava/lang/String;

    return-object p0
.end method

.method public static getAllAppsOverlaySettingsServiceInfo(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;
    .locals 5

    .line 764
    :try_start_0
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlaySettingsServiceConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 765
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 766
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v0, 0x80

    .line 767
    invoke-virtual {p0, v1, v0}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    .line 769
    new-instance v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda0;

    invoke-direct {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v1}, Ljava/util/Comparator;->comparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    .line 770
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->DBG:Z

    if-eqz v1, :cond_0

    .line 771
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "AllApps overlay settings services: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v0}, Ljava/util/List;->stream()Ljava/util/stream/Stream;

    move-result-object v3

    new-instance v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda4;

    invoke-direct {v4}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda4;-><init>()V

    .line 772
    invoke-interface {v3, v4}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object v3

    new-instance v4, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda5;

    invoke-direct {v4}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda5;-><init>()V

    .line 773
    invoke-interface {v3, v4}, Ljava/util/stream/Stream;->reduce(Ljava/util/function/BinaryOperator;)Ljava/util/Optional;

    move-result-object v3

    const-string v4, "none"

    .line 774
    invoke-virtual {v3, v4}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 771
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 776
    :cond_0
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ResolveInfo;

    .line 777
    iget-object v2, v1, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 778
    const-string v3, "com.motorola.launcher3.permission.ALL_APPS_OVERLAY"

    invoke-static {p0, v3, v2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isPermissionGranted(Landroid/content/pm/PackageManager;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 779
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Get AllApps overlay settings service: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    .line 782
    :cond_1
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "getAllAppsOverlaySettingsServiceInfo -> Skip "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", no ALL_APPS_OVERLAY permission"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    .line 787
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Get AllApps overlay settings service error: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;
    .locals 5

    if-nez p0, :cond_0

    .line 427
    const-string p0, ""

    return-object p0

    .line 429
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 431
    invoke-virtual {p0}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v2, 0x1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    if-eqz v2, :cond_1

    const/4 v2, 0x0

    goto :goto_1

    .line 435
    :cond_1
    const-string v4, ", "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 437
    :goto_1
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ": "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 439
    :cond_2
    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 440
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static getMenusPair(Landroid/content/Context;)Landroid/util/Pair;
    .locals 4

    .line 208
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlaySettingsServiceInfo(Landroid/content/Context;)Landroid/content/pm/ResolveInfo;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 209
    iget-object v2, v0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-nez v2, :cond_0

    goto :goto_0

    .line 213
    :cond_0
    iget-object v2, v2, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 216
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 222
    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v0, v0, Landroid/content/pm/ServiceInfo;->metaData:Landroid/os/Bundle;

    if-nez v0, :cond_1

    .line 223
    sget-object v0, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    .line 224
    :cond_1
    const-string v2, "menus"

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2

    .line 226
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "getMenusPair: No menus found in AllApps overlay settings service"

    invoke-static {p0, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    .line 229
    :cond_2
    new-instance v1, Landroid/util/Pair;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, p0, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v1

    :catch_0
    move-exception p0

    .line 218
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to create AllApps overlay settings service context: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 219
    invoke-virtual {p0}, Landroid/content/pm/PackageManager$NameNotFoundException;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    .line 218
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    .line 210
    :cond_3
    :goto_0
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "getMenusPair: No AllApps overlay settings service found"

    invoke-static {p0, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1
.end method

.method public static getPriority(Landroid/content/pm/ResolveInfo;)I
    .locals 4

    const v0, 0x7fffffff

    .line 794
    :try_start_0
    iget-object v1, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v1, v1, Landroid/content/pm/ServiceInfo;->metaData:Landroid/os/Bundle;

    const-string v2, "priority"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    .line 796
    :catch_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "priority is not available in "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object p0, p0, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return v0
.end method

.method private getTabIndex(Landroid/os/Bundle;)I
    .locals 1

    .line 1186
    const-string p0, "tabIndex"

    const/4 v0, -0x1

    invoke-virtual {p1, p0, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result p0

    return p0
.end method

.method private declared-synchronized handleConnect(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    monitor-enter p0

    .line 949
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 950
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " handleConnect: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 952
    :cond_0
    :goto_0
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 953
    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 954
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 955
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isNotDestroyed()Z

    move-result p2

    const/4 v1, 0x0

    if-eqz p2, :cond_3

    const/4 p2, 0x1

    .line 963
    iput-boolean p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    .line 964
    iget-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection:Landroid/content/ServiceConnection;

    const/16 v2, 0x221

    invoke-virtual {p1, v0, p2, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result p1

    .line 965
    sget-boolean p2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz p2, :cond_1

    .line 966
    sget-object p2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " bindService "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    if-nez p1, :cond_2

    .line 969
    invoke-direct {p0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V

    goto :goto_1

    .line 971
    :cond_2
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    const-wide/16 v0, 0x1388

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    .line 974
    :cond_3
    invoke-direct {p0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 976
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized handleConnectionError(Landroid/os/RemoteException;)V
    .locals 7

    monitor-enter p0

    const/4 v0, 0x0

    .line 1012
    :try_start_0
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    .line 1013
    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    invoke-interface {v1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->isReconnectEnabled()Z

    move-result v1

    if-eqz v1, :cond_0

    move v1, v2

    goto :goto_0

    :catchall_0
    move-exception p1

    goto/16 :goto_3

    :cond_0
    move v1, v0

    .line 1014
    :goto_0
    sget-boolean v3, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v3, :cond_2

    .line 1015
    sget-object v3, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget v5, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " handleConnectionError: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    if-eqz p1, :cond_1

    .line 1016
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, ", "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :cond_1
    const-string p1, ""

    :goto_1
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 1015
    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 1019
    :cond_2
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    invoke-virtual {p1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1020
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->safeUnboundService()V

    const/4 p1, 0x0

    .line 1021
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    .line 1022
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mSentWindowAttributes:Z

    .line 1024
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->clearAllAppsOverlayConfig()V

    .line 1025
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifyServiceDisconnected(Landroid/os/Bundle;)V

    if-eqz v1, :cond_4

    .line 1028
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectRunnable:Ljava/lang/Runnable;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1029
    iget p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectAttemptCount:I

    add-int/2addr p1, v2

    iput p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectAttemptCount:I

    int-to-double v1, p1

    const-wide/high16 v3, 0x3ff8000000000000L    # 1.5

    .line 1030
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    const-wide v3, 0x408f400000000000L    # 1000.0

    mul-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    const-wide/32 v3, 0xea60

    cmp-long p1, v1, v3

    if-gtz p1, :cond_3

    .line 1031
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isNotDestroyed()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 1032
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectRunnable:Ljava/lang/Runnable;

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1033
    sget-boolean p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz p1, :cond_4

    .line 1034
    sget-object p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " Retrying in "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    .line 1037
    :cond_3
    iput v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectAttemptCount:I

    .line 1038
    sget-boolean p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz p1, :cond_4

    .line 1039
    sget-object p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Giving up reconnect retries"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1043
    :cond_4
    :goto_2
    monitor-exit p0

    return-void

    :goto_3
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized handleOnServiceConnected(Landroid/os/IBinder;)V
    .locals 4

    monitor-enter p0

    const/4 v0, 0x0

    .line 996
    :try_start_0
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    .line 997
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v1, :cond_0

    .line 998
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " onServiceConnected"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1000
    :cond_0
    :goto_0
    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCheckConnectionRunnable:Ljava/lang/Runnable;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 1001
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isNotDestroyed()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 1002
    new-instance v1, Landroid/os/Messenger;

    invoke-direct {v1, p1}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    iput-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    .line 1003
    iput v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectAttemptCount:I

    .line 1004
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->onAttachedToWindow()V

    .line 1005
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    sget-object v0, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    invoke-interface {p1, v0}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onServiceConnected(Landroid/os/Bundle;)V

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    .line 1007
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1009
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized handleRemoteMessage(Landroid/os/Message;)V
    .locals 2

    monitor-enter p0

    .line 820
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_0

    .line 821
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    goto/16 :goto_0

    .line 852
    :pswitch_1
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 853
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySearchBarDetached(Landroid/os/Bundle;)V

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    goto/16 :goto_1

    .line 842
    :pswitch_2
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 843
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySearchUiDetached(Landroid/os/Bundle;)V

    goto/16 :goto_0

    .line 832
    :pswitch_3
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 833
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySideScreenDetached(Landroid/os/Bundle;)V

    goto/16 :goto_0

    .line 847
    :pswitch_4
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 848
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySearchBarAttached(Landroid/os/Bundle;)V

    goto :goto_0

    .line 869
    :pswitch_5
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-interface {v0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onUpdateOverlayConfig(Landroid/os/Bundle;)V

    goto :goto_0

    .line 865
    :pswitch_6
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    iget p1, p1, Landroid/os/Message;->arg1:I

    invoke-interface {v0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onGoBackToLauncher(I)V

    goto :goto_0

    .line 861
    :pswitch_7
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    iget v1, p1, Landroid/os/Message;->arg1:I

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    iget p1, p1, Landroid/os/Message;->arg2:I

    invoke-interface {v0, v1, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onAllAppsTransition(FI)V

    goto :goto_0

    .line 823
    :pswitch_8
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    iget p1, p1, Landroid/os/Message;->arg1:I

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    invoke-interface {v0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onScrollUpdated(F)V

    goto :goto_0

    .line 857
    :pswitch_9
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifyTabChanged(Landroid/os/Bundle;)V

    goto :goto_0

    .line 837
    :pswitch_a
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 838
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySearchUiAttached(Landroid/os/Bundle;)V

    goto :goto_0

    .line 827
    :pswitch_b
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Optional;->ofNullable(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object p1

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p1, v0}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/os/Bundle;

    .line 828
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->notifySideScreenAttached(Landroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 874
    :cond_0
    :goto_0
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_b
        :pswitch_a
        :pswitch_0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public static hasAllAppsOverlayService(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 0

    .line 144
    invoke-static {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceInfo(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 145
    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public static isAllAppsOverlaySearchBarEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 1248
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    if-nez v0, :cond_1

    .line 1249
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 1250
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    if-nez v1, :cond_0

    .line 1251
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->loadAllAppsOverlayConfig(Landroid/content/Context;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 1253
    :cond_0
    :goto_0
    monitor-exit v0

    goto :goto_2

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 1255
    :cond_1
    :goto_2
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static isAllAppsOverlaySearchUiEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 1259
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    if-nez v0, :cond_1

    .line 1260
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 1261
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    if-nez v1, :cond_0

    .line 1262
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->loadAllAppsOverlayConfig(Landroid/content/Context;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 1264
    :cond_0
    :goto_0
    monitor-exit v0

    goto :goto_2

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 1266
    :cond_1
    :goto_2
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static isAllAppsOverlaySideScreenEnabled(Landroid/content/Context;)Z
    .locals 2

    .line 1237
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    if-nez v0, :cond_1

    .line 1238
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 1239
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    if-nez v1, :cond_0

    .line 1240
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->loadAllAppsOverlayConfig(Landroid/content/Context;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 1242
    :cond_0
    :goto_0
    monitor-exit v0

    goto :goto_2

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    .line 1244
    :cond_1
    :goto_2
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public static isDeviceManagedOrCope(Landroid/content/Context;)Z
    .locals 2

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return v0

    .line 1325
    :cond_0
    const-class v1, Landroid/app/admin/DevicePolicyManager;

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/admin/DevicePolicyManager;

    if-nez p0, :cond_1

    return v0

    .line 1329
    :cond_1
    invoke-virtual {p0}, Landroid/app/admin/DevicePolicyManager;->isDeviceManaged()Z

    move-result v1

    if-nez v1, :cond_3

    invoke-virtual {p0}, Landroid/app/admin/DevicePolicyManager;->isOrganizationOwnedDeviceWithManagedProfile()Z

    move-result p0

    if-eqz p0, :cond_2

    goto :goto_0

    :cond_2
    return v0

    :cond_3
    :goto_0
    const/4 p0, 0x1

    return p0
.end method

.method private isNotDestroyed()Z
    .locals 0

    .line 992
    iget-boolean p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public static isPermissionGranted(Landroid/content/pm/PackageManager;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 0

    .line 804
    invoke-virtual {p0, p1, p2}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method private synthetic lambda$new$0(Landroid/content/Context;)V
    .locals 1

    .line 170
    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPkg(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 171
    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 169
    invoke-direct {p0, p1, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnect(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private synthetic lambda$notifySearchBarAttached$14(Landroid/os/Bundle;)V
    .locals 0

    .line 1138
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSearchBarAttached(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifySearchBarDetached$15(Landroid/os/Bundle;)V
    .locals 0

    .line 1152
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSearchBarDetached(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifySearchUiAttached$12(Landroid/os/Bundle;)V
    .locals 0

    .line 1110
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSearchUiAttached(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifySearchUiDetached$13(Landroid/os/Bundle;)V
    .locals 0

    .line 1124
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSearchUiDetached(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifyServiceDisconnected$16(Landroid/os/Bundle;)V
    .locals 0

    .line 1166
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onServiceDisconnected(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifySideScreenAttached$5(Landroid/os/Bundle;)V
    .locals 0

    .line 1050
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSideScreenAttached(Landroid/os/Bundle;)V

    return-void
.end method

.method private synthetic lambda$notifySideScreenDetached$11(Landroid/os/Bundle;)V
    .locals 0

    .line 1096
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-interface {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onSideScreenDetached(Landroid/os/Bundle;)V

    return-void
.end method

.method public static loadAllAppsOverlayConfig(Landroid/content/Context;)V
    .locals 4

    .line 1270
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isDeviceManagedOrCope(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1271
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->disableAllAppsOverlayConfig()V

    return-void

    .line 1274
    :cond_0
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    if-eqz v0, :cond_1

    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    if-eqz v0, :cond_1

    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    if-eqz v0, :cond_1

    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    if-nez v0, :cond_7

    .line 1278
    :cond_1
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOAD_ALL_APPS_OVERLAY_CONFIG_LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 1279
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    if-eqz v1, :cond_2

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    if-eqz v1, :cond_2

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    if-eqz v1, :cond_2

    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_6

    goto :goto_0

    :catchall_0
    move-exception p0

    goto/16 :goto_5

    .line 1285
    :cond_2
    :goto_0
    :try_start_1
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPackageConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 1284
    invoke-static {p0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceInfo(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    if-eqz p0, :cond_5

    .line 1286
    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-nez p0, :cond_3

    goto :goto_2

    .line 1289
    :cond_3
    iget-object v1, p0, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    .line 1290
    iget-object p0, p0, Landroid/content/pm/ServiceInfo;->metaData:Landroid/os/Bundle;

    if-nez p0, :cond_4

    .line 1291
    sget-object p0, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    goto :goto_1

    :catch_0
    move-exception p0

    goto :goto_3

    .line 1292
    :cond_4
    :goto_1
    const-string v1, "sideScreen"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    .line 1294
    const-string v1, "searchUi"

    invoke-virtual {p0, v1, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    sput-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    .line 1296
    const-string v1, "searchBar"

    invoke-virtual {p0, v1, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    sput-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    goto :goto_4

    .line 1287
    :cond_5
    :goto_2
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->disableAllAppsOverlayConfig()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_4

    .line 1300
    :goto_3
    :try_start_2
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Failed to load AllAppsOverlay config: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1301
    invoke-static {}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->disableAllAppsOverlayConfig()V

    .line 1303
    :goto_4
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Loaded AllAppsOverlay config: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlayPkg:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySideScreenEnabled:Ljava/lang/Boolean;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchBarEnabled:Ljava/lang/Boolean;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sAllAppsOverlaySearchUiEnabled:Ljava/lang/Boolean;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1309
    :cond_6
    monitor-exit v0

    :cond_7
    return-void

    :goto_5
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public static newInstance(Landroid/content/Context;Landroid/view/WindowManager$LayoutParams;Lcom/motorola/launcher3/allapps/overlay/ApiCallback;ZLandroid/content/Intent;I)Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;
    .locals 9

    .line 124
    invoke-static {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPackageConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 125
    invoke-static {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceInfo(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ResolveInfo;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 129
    new-instance v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;

    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    move v6, p3

    move-object v7, p4

    move v8, p5

    invoke-direct/range {v2 .. v8}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;-><init>(Landroid/content/Context;Landroid/view/WindowManager$LayoutParams;Lcom/motorola/launcher3/allapps/overlay/ApiCallback;ZLandroid/content/Intent;I)V

    return-object v2

    .line 127
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "newInstance > Service not found: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private declared-synchronized notifySearchBarAttached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1134
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1135
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySearchBarAttached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1137
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1138
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda11;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda11;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1139
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1140
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1142
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1145
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifySearchBarDetached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1148
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1149
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySearchBarDetached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1151
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1152
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda10;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1153
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1154
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1156
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1159
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifySearchUiAttached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1106
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1107
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySearchUiAttached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1109
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1110
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda8;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1111
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1112
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1114
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1117
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifySearchUiDetached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1120
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1121
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySearchUiDetached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1123
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1124
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda9;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda9;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1125
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1126
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1128
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1131
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifyServiceDisconnected(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1162
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1163
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifyServiceDisconnected: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1165
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1166
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda3;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1167
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1168
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1170
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1173
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifySideScreenAttached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1046
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1047
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySideScreenAttached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1049
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1050
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda12;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda12;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1051
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1052
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1054
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1089
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifySideScreenDetached(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1092
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1093
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifySideScreenDetached: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 1095
    :cond_0
    :goto_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 1096
    new-instance v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda13;

    invoke-direct {v0, p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi$$ExternalSyntheticLambda13;-><init>(Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;Landroid/os/Bundle;)V

    .line 1097
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    if-eq p1, v1, :cond_1

    .line 1098
    iget-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mMainThreadHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    .line 1100
    :cond_1
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1103
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized notifyTabChanged(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 1176
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 1177
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1178
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " notifyTabChanged: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    .line 1180
    :cond_0
    :goto_0
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getTabIndex(Landroid/os/Bundle;)I

    move-result p1

    .line 1181
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    invoke-virtual {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsTabIndex(I)I

    move-result p1

    invoke-interface {v0, p1}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->onTabChanged(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1183
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private obtainViewMessage(I)Landroid/os/Message;
    .locals 1

    const/4 v0, 0x0

    .line 334
    invoke-static {v0, p1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object p1

    .line 335
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsRtl:Z

    if-eqz v0, :cond_0

    .line 336
    iget v0, p1, Landroid/os/Message;->arg1:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 338
    :cond_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsLightStatusBar:Z

    if-eqz v0, :cond_1

    .line 339
    iget v0, p1, Landroid/os/Message;->arg1:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 341
    :cond_1
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsStatusBarHidden:Z

    if-eqz v0, :cond_2

    .line 342
    iget v0, p1, Landroid/os/Message;->arg1:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 344
    :cond_2
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsLightNavigationBar:Z

    if-eqz v0, :cond_3

    .line 345
    iget v0, p1, Landroid/os/Message;->arg1:I

    or-int/lit8 v0, v0, 0x8

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 347
    :cond_3
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsTranslucentNavigationBar:Z

    if-eqz v0, :cond_4

    .line 348
    iget v0, p1, Landroid/os/Message;->arg1:I

    or-int/lit8 v0, v0, 0x10

    iput v0, p1, Landroid/os/Message;->arg1:I

    .line 351
    :cond_4
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mLocalMessenger:Landroid/os/Messenger;

    iput-object v0, p1, Landroid/os/Message;->replyTo:Landroid/os/Messenger;

    .line 352
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    iput-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    return-object p1
.end method

.method private safeUnboundService()V
    .locals 3

    .line 1190
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 1191
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 1192
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " safeUnboundService"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 1195
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection:Landroid/content/ServiceConnection;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0

    .line 1197
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v1, :cond_1

    .line 1198
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " safeUnboundService: "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    return-void
.end method

.method private declared-synchronized sendRemote(Landroid/os/Message;)Z
    .locals 1

    monitor-enter p0

    const/4 v0, 0x0

    .line 877
    :try_start_0
    invoke-direct {p0, p1, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return p1

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method private declared-synchronized sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    .locals 2

    monitor-enter p0

    .line 881
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 882
    monitor-exit p0

    return v1

    .line 883
    :cond_0
    :try_start_1
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    if-nez v0, :cond_2

    .line 884
    sget-boolean p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz p1, :cond_1

    .line 885
    sget-object p1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iget v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " mRemoteMessenger is null"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_4

    .line 888
    :cond_1
    :goto_0
    monitor-exit p0

    return v1

    .line 891
    :cond_2
    :try_start_2
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_4

    if-eqz p2, :cond_3

    .line 893
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_3

    .line 895
    :cond_3
    :goto_1
    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p2

    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mDataBundle:Landroid/os/Bundle;

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    goto :goto_2

    :cond_4
    if-eqz p2, :cond_5

    .line 898
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mDataBundle:Landroid/os/Bundle;

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 899
    invoke-virtual {p1, p2}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    goto :goto_2

    .line 901
    :cond_5
    iget-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mDataBundle:Landroid/os/Bundle;

    invoke-virtual {p1, p2}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    .line 904
    :goto_2
    iget-object p2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    invoke-virtual {p2, p1}, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 905
    monitor-exit p0

    const/4 p0, 0x1

    return p0

    .line 907
    :goto_3
    :try_start_3
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnectionError(Landroid/os/RemoteException;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 908
    monitor-exit p0

    return v1

    :goto_4
    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p1
.end method

.method private sendSetSettingsActivityLaunchIntent()V
    .locals 0

    .line 0
    return-void
.end method


# virtual methods
.method public bindService2()V
    .locals 5

    .line 233
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService2:Z

    if-eqz v0, :cond_0

    .line 234
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "bindService2: already bound"

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 237
    :cond_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection2:Landroid/content/ServiceConnection;

    monitor-enter v0

    .line 238
    :try_start_0
    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPkg(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 239
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 240
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_1

    .line 243
    :cond_1
    :try_start_1
    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v3}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 244
    invoke-virtual {v2, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 245
    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection2:Landroid/content/ServiceConnection;

    const/16 v4, 0x41

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    const/4 v1, 0x1

    .line 247
    iput-boolean v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService2:Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception p0

    .line 249
    :try_start_2
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v1, :cond_2

    .line 250
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " bindService2 error: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 253
    :cond_2
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public endScroll(F)V
    .locals 2

    const/4 v0, 0x0

    const/16 v1, 0x15

    .line 294
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 295
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 296
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method

.method public getAllAppsTabIndex(I)I
    .locals 0

    .line 646
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getTabOffset()I

    move-result p0

    add-int/2addr p1, p0

    return p1
.end method

.method public getDataBundle()Landroid/os/Bundle;
    .locals 0

    .line 1221
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mDataBundle:Landroid/os/Bundle;

    return-object p0
.end method

.method public getOverlayContext()Landroid/content/Context;
    .locals 0

    .line 918
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mOverlayContext:Landroid/content/Context;

    return-object p0
.end method

.method public getOverlayTabIndex(I)I
    .locals 0

    .line 656
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getTabOffset()I

    move-result p0

    sub-int/2addr p1, p0

    return p1
.end method

.method public getServicePackage()Ljava/lang/String;
    .locals 0

    .line 914
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mPackageName:Ljava/lang/String;

    return-object p0
.end method

.method public getTabOffset()I
    .locals 0

    .line 1225
    iget p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mTabOffset:I

    return p0
.end method

.method public declared-synchronized hideSearchBar()V
    .locals 3

    monitor-enter p0

    .line 385
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySearchBarEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 386
    monitor-exit p0

    return-void

    .line 388
    :cond_0
    :try_start_1
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 389
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " hideSearchBar"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x27

    .line 391
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 392
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 393
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public declared-synchronized hideSearchUi()V
    .locals 3

    monitor-enter p0

    .line 415
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySearchUiEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 416
    monitor-exit p0

    return-void

    .line 418
    :cond_0
    :try_start_1
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 419
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " hideSearchUi"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x2a

    .line 421
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 422
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 423
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public declared-synchronized hideSideScreen(ILjava/lang/Integer;)V
    .locals 3

    monitor-enter p0

    .line 664
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySideScreenEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 665
    monitor-exit p0

    return-void

    .line 667
    :cond_0
    :try_start_1
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_3

    .line 668
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 669
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " hideSideScreen: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x1d

    .line 672
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 673
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 674
    const-string v2, "animate"

    invoke-virtual {v1, v2, p1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    if-eqz p2, :cond_2

    .line 676
    const-string p1, "duration"

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-virtual {v1, p1, p2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 678
    :cond_2
    invoke-direct {p0, v0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 680
    :cond_3
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public isBoundService()Z
    .locals 0

    .line 988
    iget-object p0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mRemoteMessenger:Landroid/os/Messenger;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public declared-synchronized onAllAppsHidden()V
    .locals 4

    monitor-enter p0

    .line 366
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    const/16 v1, 0x2d

    if-eqz v0, :cond_0

    .line 367
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " onAllAppsHidden: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 369
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 370
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 371
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onAllAppsTransition(FF)V
    .locals 3

    monitor-enter p0

    .line 709
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 710
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 711
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onAllAppsTransition: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/4 v1, 0x6

    .line 714
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 715
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 716
    const-string v2, "translationY"

    invoke-virtual {v1, v2, p1}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    .line 717
    const-string p1, "alpha"

    invoke-virtual {v1, p1, p2}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    .line 718
    invoke-direct {p0, v0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 720
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized onAllAppsTransition(FI)V
    .locals 3

    monitor-enter p0

    .line 694
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 695
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 696
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onAllAppsTransition: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/4 v1, 0x6

    .line 699
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 700
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 701
    iput p2, v0, Landroid/os/Message;->arg2:I

    .line 702
    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 703
    const-string p2, "KEY_LAYOUT_PARAMS"

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    invoke-virtual {p1, p2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 704
    invoke-direct {p0, v0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 706
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized onAttachedToWindow()V
    .locals 4

    monitor-enter p0

    .line 300
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mSentWindowAttributes:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 301
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 302
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onAttachedToWindow"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x3

    .line 304
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->obtainViewMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 305
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getDataBundle()Landroid/os/Bundle;

    move-result-object v1

    const-string v2, "allAppsVersion"

    iget v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mAllAppsVersion:I

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 306
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onAttachedToWindow: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getDataBundle()Landroid/os/Bundle;

    move-result-object v3

    invoke-static {v3}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 307
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    .line 308
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mSentWindowAttributes:Z

    .line 309
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendSetSettingsActivityLaunchIntent()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 312
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onClickMenuItem(Ljava/lang/String;)V
    .locals 3

    monitor-enter p0

    .line 324
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 325
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onClickMenuItem: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x2c

    .line 327
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 328
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 329
    const-string v2, "menuAction"

    invoke-virtual {v1, v2, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 330
    invoke-direct {p0, v0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 331
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized onDestroy()V
    .locals 3

    monitor-enter p0

    .line 496
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 497
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onDestroy"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    .line 499
    :cond_0
    :goto_0
    invoke-direct {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->safeUnboundService()V

    const/4 v0, 0x1

    .line 500
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    const/4 v0, 0x0

    .line 501
    iput-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 502
    iput-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    .line 503
    iput-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 504
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onDetachedFromWindow()V
    .locals 3

    monitor-enter p0

    .line 444
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 445
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 446
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onDetachedFromWindow"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 449
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mSentWindowAttributes:Z

    const/4 v0, 0x0

    const/16 v1, 0x17

    .line 450
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 451
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 453
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onOverlayChanged(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 683
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 684
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 685
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onOverlayChanged"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x2b

    .line 688
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 689
    invoke-direct {p0, v0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 691
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized onPause()V
    .locals 3

    monitor-enter p0

    .line 484
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 485
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 486
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onPause"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    .line 488
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsResumed:Z

    const/4 v0, 0x0

    const/16 v1, 0x16

    .line 490
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 491
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 493
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized onResume(Z)V
    .locals 3

    monitor-enter p0

    .line 467
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 468
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 469
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onResume: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_0
    :goto_0
    const/4 v0, 0x1

    .line 471
    iput-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsResumed:Z

    .line 473
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 p1, 0x0

    const/16 v0, 0x18

    .line 475
    invoke-static {p1, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object p1

    .line 476
    invoke-direct {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    goto :goto_1

    :cond_1
    if-eqz p1, :cond_2

    .line 478
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->reconnect()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 481
    :cond_2
    :goto_1
    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized onUpdateOverlayConfig(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 456
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 457
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 458
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " onUpdateOverlayConfig: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x8

    .line 461
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 462
    invoke-direct {p0, v0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 464
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized reattachOverlay()V
    .locals 4

    monitor-enter p0

    .line 546
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 547
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 548
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " reattachOverlay"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x24

    .line 551
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 553
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 554
    const-string v2, "configuration"

    iget-object v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 555
    iput-object v1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 556
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 558
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public declared-synchronized reconnect()V
    .locals 5

    monitor-enter p0

    .line 922
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCallbacks:Lcom/motorola/launcher3/allapps/overlay/ApiCallback;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/motorola/launcher3/allapps/overlay/ApiCallback;->isReconnectEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    move v0, v1

    .line 923
    :goto_0
    sget-boolean v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v2, :cond_1

    .line 924
    sget-object v2, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget v4, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " reconnect: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v4, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v4, ", "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 926
    :cond_1
    iget-object v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPackageConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    .line 927
    iget-object v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v3, v2}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceInfo(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ResolveInfo;

    move-result-object v3

    if-nez v3, :cond_2

    .line 929
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "reconnect > Service not found: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 930
    monitor-exit p0

    return-void

    .line 932
    :cond_2
    :try_start_1
    iget-boolean v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsBinding:Z

    if-nez v2, :cond_3

    if-eqz v0, :cond_3

    .line 933
    iput v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mConnectAttemptCount:I

    .line 934
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 935
    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayPkg(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    .line 936
    invoke-static {v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getAllAppsOverlayServiceConfig(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 934
    invoke-direct {p0, v0, v1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->handleConnect(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 938
    :cond_3
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public setTabOffset(I)V
    .locals 0

    .line 1229
    iput p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mTabOffset:I

    return-void
.end method

.method public declared-synchronized showSearchBar()V
    .locals 3

    monitor-enter p0

    .line 374
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySearchBarEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 375
    monitor-exit p0

    return-void

    .line 377
    :cond_0
    :try_start_1
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 378
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " showSearchBar"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_1
    :goto_0
    const/16 v0, 0x26

    .line 380
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->obtainViewMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 381
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 382
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public declared-synchronized showSearchUi(Landroid/os/Bundle;)V
    .locals 3

    monitor-enter p0

    .line 404
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySearchUiEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 405
    monitor-exit p0

    return-void

    .line 407
    :cond_0
    :try_start_1
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 408
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " showSearchUi: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    const/16 v0, 0x29

    .line 410
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->obtainViewMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 411
    invoke-direct {p0, v0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;Landroid/os/Bundle;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 412
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public declared-synchronized showSideScreen(I)V
    .locals 3

    monitor-enter p0

    .line 625
    :try_start_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isAllAppsOverlaySideScreenEnabled(Landroid/content/Context;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    .line 626
    monitor-exit p0

    return-void

    .line 628
    :cond_0
    :try_start_1
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_2

    .line 629
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_1

    .line 630
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " showSideScreen: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    const/16 v0, 0x1c

    .line 633
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->obtainViewMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 634
    invoke-virtual {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getOverlayTabIndex(I)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 635
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 637
    :cond_2
    monitor-exit p0

    return-void

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public startScroll()V
    .locals 1

    .line 275
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getTabOffset()I

    move-result v0

    invoke-virtual {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->startScroll(I)V

    return-void
.end method

.method public startScroll(I)V
    .locals 3

    .line 279
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 280
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " startScroll: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v0, 0x0

    const/16 v1, 0x14

    .line 282
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 283
    invoke-virtual {p0, p1}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getOverlayTabIndex(I)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 284
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method

.method public declared-synchronized turnOff()V
    .locals 3

    monitor-enter p0

    .line 510
    :try_start_0
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mIsDestroyed:Z

    if-nez v0, :cond_1

    .line 511
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 512
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " turnOff"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v0, 0x0

    const/16 v1, 0x1f

    .line 515
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 516
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    .line 517
    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->onDestroy()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 519
    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public unbindService2()V
    .locals 4

    .line 257
    iget-boolean v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService2:Z

    if-nez v0, :cond_0

    .line 258
    sget-object p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    const-string v0, "unbindService2: already unbound"

    invoke-static {p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 261
    :cond_0
    iget-object v0, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection2:Landroid/content/ServiceConnection;

    monitor-enter v0

    .line 263
    :try_start_0
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "unbindService2: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount2:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 264
    iget-object v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mServiceConnection2:Landroid/content/ServiceConnection;

    invoke-virtual {v1, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v1, 0x0

    .line 265
    iput-boolean v1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->isBoundService2:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :catch_0
    move-exception p0

    .line 267
    :try_start_1
    sget-boolean v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v1, :cond_1

    .line 268
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " unbindService2 error: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 271
    :cond_1
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public updateHostWindowLp(Landroid/view/WindowManager$LayoutParams;)V
    .locals 0

    .line 1233
    iput-object p1, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mHostWindowLp:Landroid/view/WindowManager$LayoutParams;

    return-void
.end method

.method public updateScroll(F)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x5

    .line 288
    invoke-static {v0, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v0

    .line 289
    invoke-static {p1}, Ljava/lang/Float;->floatToIntBits(F)I

    move-result p1

    iput p1, v0, Landroid/os/Message;->arg1:I

    .line 290
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z

    return-void
.end method

.method public declared-synchronized updateView()V
    .locals 4

    monitor-enter p0

    .line 357
    :try_start_0
    sget-boolean v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->LOG:Z

    if-eqz v0, :cond_0

    .line 358
    sget-object v0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget v2, p0, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->mCount:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " updateView"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    const/16 v0, 0x25

    .line 360
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->obtainViewMessage(I)Landroid/os/Message;

    move-result-object v0

    .line 361
    sget-object v1, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->TAG:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "updateView: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getDataBundle()Landroid/os/Bundle;

    move-result-object v3

    invoke-static {v3}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->getBundleStr(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 362
    invoke-direct {p0, v0}, Lcom/motorola/launcher3/allapps/overlay/AllAppsApi;->sendRemote(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 363
    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
