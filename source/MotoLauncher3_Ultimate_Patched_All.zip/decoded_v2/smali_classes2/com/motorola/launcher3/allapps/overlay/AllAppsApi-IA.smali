.class public abstract synthetic Lcom/motorola/launcher3/allapps/overlay/AllAppsApi-IA;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"
