.class public Lcom/motorola/settings/widget/MotoButtonBarLayout;
.super Landroid/widget/LinearLayout;
.source "MotoButtonBarLayout.java"


# instance fields
.field private mAllowStacking:Z

.field private mLastWidthSize:I

.field private mStacked:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    .line 32
    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, -0x1

    .line 29
    iput v0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mLastWidthSize:I

    .line 34
    sget-object v0, Lcom/android/settingslib/widget/theme/R$styleable;->MotoButtonBarLayout:[I

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    .line 35
    sget p2, Lcom/android/settingslib/widget/theme/R$styleable;->MotoButtonBarLayout_allowStacking:I

    const/4 v0, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    iput-boolean p2, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mAllowStacking:Z

    .line 36
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method

.method public static findActivity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 1

    .line 204
    :goto_0
    instance-of v0, p0, Landroid/content/ContextWrapper;

    if-eqz v0, :cond_1

    .line 205
    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :cond_0

    .line 206
    check-cast p0, Landroid/app/Activity;

    return-object p0

    .line 208
    :cond_0
    check-cast p0, Landroid/content/ContextWrapper;

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method private getNextVisibleChildIndex(I)I
    .locals 2

    .line 140
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v0

    :goto_0
    if-ge p1, v0, :cond_1

    .line 141
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_0

    return p1

    :cond_0
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    return p0
.end method

.method private isStacked()Z
    .locals 0

    .line 170
    iget-boolean p0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mStacked:Z

    return p0
.end method

.method private setStacked(Z)V
    .locals 1

    .line 149
    iget-boolean v0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mStacked:Z

    if-eq v0, p1, :cond_4

    if-eqz p1, :cond_0

    iget-boolean v0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mAllowStacking:Z

    if-eqz v0, :cond_4

    .line 150
    :cond_0
    iput-boolean p1, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mStacked:Z

    .line 152
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    if-eqz p1, :cond_1

    const v0, 0x800005

    goto :goto_0

    :cond_1
    const/16 v0, 0x50

    .line 153
    :goto_0
    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 155
    sget v0, Lcom/android/settingslib/widget/theme/R$id;->spacer:I

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_3

    if-eqz p1, :cond_2

    const/16 p1, 0x8

    goto :goto_1

    :cond_2
    const/4 p1, 0x4

    .line 157
    :goto_1
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 162
    :cond_3
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result p1

    add-int/lit8 p1, p1, -0x2

    :goto_2
    if-ltz p1, :cond_4

    .line 164
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->bringChildToFront(Landroid/view/View;)V

    add-int/lit8 p1, p1, -0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method private shouldButtonsBeStacked()Z
    .locals 9

    .line 175
    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 180
    :cond_0
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v0

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    move v5, v4

    :goto_0
    if-gt v3, v0, :cond_4

    .line 182
    invoke-virtual {p0, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    .line 183
    instance-of v7, v6, Landroid/widget/TextView;

    if-nez v7, :cond_1

    goto :goto_1

    .line 185
    :cond_1
    check-cast v6, Landroid/widget/TextView;

    .line 186
    invoke-virtual {v6}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v7

    .line 188
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 192
    invoke-virtual {v6}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v8

    invoke-interface {v7}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Landroid/text/TextPaint;->measureText(Ljava/lang/String;)F

    move-result v7

    .line 193
    invoke-virtual {v6}, Landroid/widget/TextView;->getMeasuredWidth()I

    move-result v6

    int-to-float v6, v6

    const/4 v8, 0x0

    cmpl-float v8, v6, v8

    if-eqz v8, :cond_3

    cmpg-float v6, v6, v7

    if-gtz v6, :cond_3

    move v5, v1

    :cond_3
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_4
    if-ge v4, v0, :cond_6

    if-eqz v5, :cond_5

    goto :goto_2

    :cond_5
    return v2

    :cond_6
    :goto_2
    return v1
.end method


# virtual methods
.method protected onMeasure(II)V
    .locals 5

    .line 41
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    .line 46
    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->shouldButtonsBeStacked()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    .line 47
    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result v3

    if-nez v3, :cond_0

    .line 48
    invoke-direct {p0, v2}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->setStacked(Z)V

    .line 51
    :cond_0
    iget-boolean v3, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mAllowStacking:Z

    const/4 v4, 0x0

    if-eqz v3, :cond_2

    .line 52
    iget v3, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mLastWidthSize:I

    if-le v0, v3, :cond_1

    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result v3

    if-eqz v3, :cond_1

    if-nez v1, :cond_1

    .line 54
    invoke-direct {p0, v4}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->setStacked(Z)V

    .line 57
    :cond_1
    iput v0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mLastWidthSize:I

    .line 66
    :cond_2
    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result v1

    if-nez v1, :cond_3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    const/high16 v3, 0x40000000    # 2.0f

    if-ne v1, v3, :cond_3

    const/high16 v1, -0x80000000

    .line 67
    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    move v1, v2

    goto :goto_0

    :cond_3
    move v0, p1

    move v1, v4

    .line 75
    :goto_0
    invoke-super {p0, v0, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    .line 77
    iget-boolean v0, p0, Lcom/motorola/settings/widget/MotoButtonBarLayout;->mAllowStacking:Z

    if-eqz v0, :cond_4

    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result v0

    if-nez v0, :cond_4

    .line 78
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getMeasuredWidthAndState()I

    move-result v0

    const/high16 v3, -0x1000000

    and-int/2addr v0, v3

    const/high16 v3, 0x1000000

    if-ne v0, v3, :cond_4

    .line 81
    invoke-direct {p0, v2}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->setStacked(Z)V

    move v1, v2

    :cond_4
    if-eqz v1, :cond_5

    .line 89
    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    .line 95
    :cond_5
    invoke-direct {p0, v4}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->getNextVisibleChildIndex(I)I

    move-result p1

    if-ltz p1, :cond_d

    .line 97
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    .line 98
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 99
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getPaddingTop()I

    move-result v1

    invoke-virtual {p2}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    add-int/2addr v1, p2

    iget p2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v1, p2

    iget p2, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v1, p2

    .line 102
    invoke-direct {p0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->isStacked()Z

    move-result p2

    if-eqz p2, :cond_c

    .line 103
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p2

    iget p2, p2, Landroid/content/res/Configuration;->orientation:I

    const/4 v0, 0x2

    if-ne p2, v0, :cond_6

    move p2, v2

    goto :goto_1

    :cond_6
    move p2, v4

    .line 105
    :goto_1
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->findActivity(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v0

    if-eqz v0, :cond_7

    .line 106
    invoke-virtual {v0}, Landroid/app/Activity;->isInMultiWindowMode()Z

    move-result v0

    if-eqz v0, :cond_7

    move v4, v2

    :cond_7
    if-nez p2, :cond_b

    if-eqz v4, :cond_8

    goto :goto_4

    :cond_8
    add-int/2addr p1, v2

    .line 121
    :goto_2
    invoke-direct {p0, p1}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->getNextVisibleChildIndex(I)I

    move-result p1

    const/4 p2, -0x1

    if-eq p1, p2, :cond_9

    .line 122
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    .line 123
    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 124
    invoke-virtual {p2}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    iget v2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr p2, v2

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr p2, v0

    add-int/2addr v1, p2

    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    .line 127
    :cond_9
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getPaddingBottom()I

    move-result p1

    add-int/2addr v1, p1

    :cond_a
    :goto_3
    move v4, v1

    goto :goto_5

    :cond_b
    :goto_4
    add-int/2addr p1, v2

    .line 111
    invoke-direct {p0, p1}, Lcom/motorola/settings/widget/MotoButtonBarLayout;->getNextVisibleChildIndex(I)I

    move-result p1

    if-ltz p1, :cond_a

    int-to-float p2, v1

    .line 113
    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result p1

    int-to-float p1, p1

    .line 114
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x41800000    # 16.0f

    mul-float/2addr v0, v1

    add-float/2addr p1, v0

    add-float/2addr p2, p1

    float-to-int v1, p2

    goto :goto_3

    .line 130
    :cond_c
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getPaddingBottom()I

    move-result p1

    add-int v4, v1, p1

    .line 134
    :cond_d
    :goto_5
    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getMinimumHeight()I

    move-result p1

    if-eq p1, v4, :cond_e

    .line 135
    invoke-virtual {p0, v4}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    :cond_e
    return-void
.end method
